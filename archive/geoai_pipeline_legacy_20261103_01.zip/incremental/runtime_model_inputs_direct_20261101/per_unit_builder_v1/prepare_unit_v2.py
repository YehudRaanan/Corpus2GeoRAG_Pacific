"""One callable preparation step per sealed ordered unit. CPU only;no new policy."""
import os,sys,json,gzip,copy,hashlib,importlib.util,urllib.request,urllib.parse,html
from pathlib import Path
from datetime import datetime,timezone
from collections import defaultdict,Counter
from functools import lru_cache
BUILDER_ROOT=Path(__file__).parent
PROJECT=BUILDER_ROOT.parents[1]
PILOT=Path(r'D:\Projects\GeoAI-luke-pilot-20261028')
SOURCE_ROOT=PROJECT/'review_treatments/first_run_input_20261101_v1'
PINNED_SEAL='03cd6fd90d609815c431ea234d9c32f0c10e98287b60d515439f15305b5e4089'
sys.dont_write_bytecode=True
sys.path[:0]=[str(PILOT),str(PROJECT/'integration_direct_20261101'),str(PROJECT/'durable_units_direct_20261101')]
def read(path):return json.loads(Path(path).read_text(encoding='utf8'))
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block)
 return h.hexdigest()
@lru_cache(None)
def load_cached(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
@lru_cache(None)
def local_metadata():
 with gzip.open(Path(r'C:\Users\User\.cache\geoai_bigquery_20261018/entity_metadata.json.gz'),'rt',encoding='utf8') as stream:return json.load(stream)
@lru_cache(None)
def ordered_units():
 seal=read(SOURCE_ROOT/'seal.json');assert digest(SOURCE_ROOT/'seal.json')==PINNED_SEAL
 assert digest(SOURCE_ROOT/'sealed_units.jsonl.gz')==seal['sealed_units_sha256']
 assert digest(SOURCE_ROOT/'retained_mentions.parquet')==seal['retained_parquet_sha256']
 with gzip.open(SOURCE_ROOT/'sealed_units.jsonl.gz','rt',encoding='utf8') as stream:return [json.loads(line) for line in stream]

def prepare_source(unit,output):
 import pyarrow.parquet as pq
 from run_first_real_unit import processing_record,mention_id,group_mentions
 from durable_unit import seal_unit,recover,sha,encoded
 from build_unit_candidate_ledger import raw_links,template_targets,policy,decision,POLICY
 output=Path(output);output.mkdir(parents=True,exist_ok=False)
 rawpath=Path(unit['source_path']);source=rawpath.read_bytes();assert sha(source)==unit['source_sha256']
 rows=pq.read_table(SOURCE_ROOT/'retained_mentions.parquet',filters=[('wiki_site','=',unit['wiki_site']),('page_id','=',unit['page_id']),('processing_revision_id','=',unit['processing_revision_id'])],use_threads=False).to_pylist();rows.sort(key=lambda r:r['source_row_index'])
 assert len(rows)==unit['retained_count'] and {r['source_row_index'] for r in rows}==set(unit['expected_row_indices'])
 assert {r['occurrence_id'] for r in rows}=={mention_id(unit['input_sha256'],i) for i in unit['expected_row_indices']}
 assert all(r['processing_revision_sha256']==unit['source_sha256'] and r['first_run_scope_member'] for r in rows)
 groups=group_mentions([processing_record(r) for r in rows]);assert not groups['unresolved'] and sum(len(g['members']) for g in groups['groups'])==len(rows)
 shard={k:unit[k] for k in ('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')};shard['row_indices']=unit['expected_row_indices']
 handoff=dict(manifest=unit,shards=[shard],occurrences=[dict(r,original_row_index=r['source_row_index']) for r in rows],decisions=[],pending_evidence=[dict(occurrence_id=r['occurrence_id'],source_row_index=r['source_row_index'],raw_type=r['entity_group'],status='PENDING_MATCHING_NOT_RUN',none_decision=False) for r in rows],version=f'unit-{unit["page_id"]}-{unit["processing_revision_id"]}-source-pending-v1',prior_version=None,input_seal_sha256=PINNED_SEAL)
 for name,value in [('unit.json',unit),('source_members.json',rows),('groups.json',groups)]: (output/name).write_bytes(encoded(value))
 unit_hash=sha(encoded(handoff));seal_unit(output/'sealed_pending',handoff,source,unit_hash);assert recover(output/'sealed_pending',unit_hash)['handoff']==handoff
 proof=dict(status='SEALED_UNIT_SOURCE_AND_GROUPING_ONLY',page_id=unit['page_id'],processing_revision_id=unit['processing_revision_id'],occurrences=len(rows),groups=len(groups['groups']),identity_decisions=0,pending=len(rows),none=0,matching_stage='NOT_RUN',unit_sha256=unit_hash,input_seal_sha256=PINNED_SEAL,output_sha256={str(p.relative_to(output)):digest(p) for p in output.rglob('*') if p.is_file()})
 (output/'receipt.json').write_bytes(encoded(proof))
 raw=source.decode('utf8');view=policy.build_view(raw);assert digest(POLICY)==read(PROJECT/'integration_direct_20261101/candidate_cache_0002/ledger.json')['policy_code_sha256']
 links=[dict(row,component=decision(view,row)) for row in raw_links(raw)];templates=[dict(row,component=decision(view,row)) for row in template_targets(raw,include_unsupported=True)];bytitle=defaultdict(list)
 for row in links:bytitle[row['target_title']].append(row)
 retained={title for title,rr in bytitle.items() if any(r['component']['status']=='IN' for r in rr)};mappings=defaultdict(list)
 for path in [PILOT/'Data/external/hundred_page_pilot_20261028/collection_titles_final/title_qid_mapping.parquet',PILOT/'Data/external/hundred_page_pilot_20261028/template_name_pilot_20261029/recovery_100_v2/title_qid_mapping.parquet']:
  for row in pq.read_table(path,filters=[('target_title','in',sorted(retained))],use_threads=False).to_pylist():
   if isinstance(row.get('qid'),str) and row['qid'].startswith('Q'):mappings[row['target_title']].append(dict(cache_file=str(path),assertion=row))
 metadata=local_metadata();needed={x['assertion']['qid'] for rr in mappings.values() for x in rr};meta_path=Path(r'C:\Users\User\.cache\geoai_bigquery_20261018/entity_metadata.json.gz');candidate_meta={}
 for qid,record in metadata.items():
  title=record.get('sitelinks',{}).get('enwiki',{}).get('title')
  if title in retained:mappings[title].append(dict(cache_file=str(meta_path),assertion=dict(target_title=title,qid=qid,qid_status='CACHED_EXACT_ENWIKI_SITELINK',mapping_temporal_basis='CACHED_CURRENT_TITLE_RESOLUTION')))
  if qid in needed or title in retained:candidate_meta[qid]=dict(cache_file=str(meta_path),assertion=dict(qid=qid,label=record.get('label'),aliases=record.get('aliases',[]),native_types=record.get('direct_types',[]),parents=record.get('parents',[]),metadata_revision=record.get('revision'),metadata_modified=record.get('modified'),metadata_source=record.get('reference_source'),metadata_temporal_basis='CACHED_METADATA_SEPARATE_FROM_PROCESSING_REVISION',metadata_path=str(meta_path)))
 targets=[];active=set()
 for title,rr in sorted(bytitle.items()):
  assertions=mappings.get(title,[]) if title in retained else [];qids=sorted({r['assertion']['qid'] for r in assertions})
  # Conflicting source mappings stay visible;do not select one silently.
  active.update(qids);targets.append(dict(target_title=title,source_links=rr,included_from_relevant_component=title in retained,cached_title_assertions=assertions,candidate_qids=qids,mapping_conflict=len(qids)>1,cache_status='RESOLVED_CACHED_MAPPING' if qids else 'UNRESOLVED' if title in retained else 'EXCLUDED_COMPONENT_ONLY'))
 ledger=dict(source_unit=unit,source_temporal_basis='VERIFIED_PROCESSING_REVISION_NOT_EXTRACTION_REVISION',policy_code_sha256=digest(POLICY),all_raw_targets_with_inclusion_evidence=targets,template_evidence=templates,active_cached_candidates=[dict(qid=q,cached_metadata=[candidate_meta[q]] if q in candidate_meta else [],type_policy_applied=False,accepted_identity=False) for q in sorted(active)],unresolved_relevant_targets=[r['target_title'] for r in targets if r['included_from_relevant_component'] and not r['candidate_qids']],completeness='NOT_ESTABLISHED;unsupported templates and uncached/unlinked targets remainunknown,notNONE',original_groups=str(output/'groups.json'),source_members=str(output/'source_members.json'))
 cand=output/'candidate_inputs_0001';cand.mkdir();(cand/'ledger.json').write_bytes(encoded(ledger));(cand/'receipt.json').write_bytes(encoded(dict(ledger_sha256=digest(cand/'ledger.json'),policy_code_sha256=digest(POLICY),mapping_conflicts=sum(t['mapping_conflict'] for t in targets))))
 return output

def register_cache_version(record,activate=False):
 cache=BUILDER_ROOT/'alias_cache';cache.mkdir(exist_ok=True);record=dict(record)
 assert digest(Path(record['response_file']))==record['response_sha256']
 version=cache/'versions'/record['qid']/f"{record['source_revision']}-{record['response_sha256']}.json";version.parent.mkdir(parents=True,exist_ok=True)
 body=json.dumps(record,ensure_ascii=False,sort_keys=True,indent=2)
 if version.exists():
  existing=read(version);fields=['qid','aliases','source_revision','source_modified','response_sha256','source_field','language']
  assert all(existing.get(key)==record.get(key) for key in fields),'Immutable source revision changed'
 else:version.write_text(body,encoding='utf8')
 active=cache/(record['qid']+'.json')
 if activate or not active.exists():active.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
 return version

def cached_aliases(entities,output):
 api=load_cached('generic_runtime_aliases',PROJECT/'runtime_model_inputs_direct_20261101/runtime_alias_application_v1/alias_enrichment.py');cache=BUILDER_ROOT/'alias_cache';cache.mkdir(exist_ok=True)
 for evidence_path,response_path in [(PROJECT/'runtime_model_inputs_direct_20261101/runtime_alias_application_v1/alias_source_evidence.json',PROJECT/'runtime_model_inputs_direct_20261101/runtime_alias_application_v1/provider_cache/official_aliases_0.json'),(PROJECT/'runtime_model_inputs_direct_20261101/second_unit_8385178_1360005623_v1/alias_evidence.json',PROJECT/'runtime_model_inputs_direct_20261101/second_unit_8385178_1360005623_v1/alias_provider_cache/official_aliases_0.json')]:
  for item in read(evidence_path):
   record=dict(item['source']);record['response_file']=str(response_path);register_cache_version(record)
 provider={};missing=[]
 for entity in entities:
  qid=entity['qid'];path=cache/(qid+'.json')
  if path.exists():
   record=read(path);assert record['qid']==qid;register_cache_version(record);provider[qid]=record
  else:missing.append(qid)
 receipts=[]
 for offset in range(0,len(missing),50):
  cache_root=Path(output)/'alias_provider_cache';cache_root.mkdir(exist_ok=True);attempt=1
  while (cache_root/f'batch_{offset//50:04d}_attempt_{attempt:04d}').exists():attempt+=1
  target=cache_root/f'batch_{offset//50:04d}_attempt_{attempt:04d}'
  fetched,part=api.fetch_aliases(missing[offset:offset+50],target);receipts.extend(part)
  for qid,record in fetched.items():
   record['response_file']=str(next(p for p in target.glob('*.json') if digest(p)==record['response_sha256']));register_cache_version(record,activate=True);provider[qid]=record
 receipts.append(dict(cache_first=True,cached_qids=sorted(set(provider)-set(missing)),fetched_qids=sorted(missing),immutable_versions=True))
 return provider,receipts

def prepare_inputs(source_directory,output_directory,dry_scan=False):
 ROOT=Path(output_directory);ROOT.mkdir(parents=True,exist_ok=True);BASE=PROJECT;SOURCE=Path(source_directory);source_unit=json.loads((SOURCE/'unit.json').read_text(encoding='utf8'));PAGE=source_unit['page_id'];REV=source_unit['processing_revision_id'];COUNT=source_unit['retained_count'];VERSION=f'unit-{PAGE}-rev{REV}-onecontext-aliases-v1'
 sys.dont_write_bytecode=True
 for k,v in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1'}.items():os.environ[k]=v
 sys.path.insert(0,str(PILOT));sys.path.insert(0,str(PILOT/'Data/external/laya_pilot_20261030/upstream'))
 def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
 def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
 def write(n,x):(ROOT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
 def load(n,p):
  return load_cached(n,p)
 receipt=read(SOURCE/'receipt.json');ledger=read(SOURCE/'candidate_inputs_0001/ledger.json');assert (receipt['page_id'],receipt['processing_revision_id'],receipt['occurrences'])==(PAGE,REV,COUNT)
 assert sha(SOURCE/'candidate_inputs_0001/ledger.json')==read(SOURCE/'candidate_inputs_0001/receipt.json')['ledger_sha256']
 protected={str(SOURCE/'receipt.json'):sha(SOURCE/'receipt.json'),str(SOURCE/'candidate_inputs_0001/ledger.json'):sha(SOURCE/'candidate_inputs_0001/ledger.json')}
 for n,h in receipt['output_sha256'].items():assert sha(SOURCE/n)==h;protected[str(SOURCE/n)]=h
 seal=read(SOURCE/'sealed_pending/seal.json');unit=read(SOURCE/'unit.json');groups=read(SOURCE/'groups.json')['groups'];source_bytes=(SOURCE/'sealed_pending/source.private.bin').read_bytes();assert hashlib.sha256(source_bytes).hexdigest()==unit['source_sha256'];raw_source=source_bytes.decode('utf8')
 allids=[m['occurrence_id'] for g in groups for m in g['members']];assert len(allids)==len(set(allids))==COUNT and set(allids)==set(seal['pending_occurrence_ids'])
 assert all((g['key']['page_id'],g['key']['revision_id'])==(PAGE,REV) for g in groups)
 # Only targets backed by IN components of this exact processing source may enter.
 allowed={q for t in ledger['all_raw_targets_with_inclusion_evidence'] if t['included_from_relevant_component'] for q in t['candidate_qids']}
 entities=[]
 for candidate in ledger['active_cached_candidates']:
  q=candidate['qid'];assert q in allowed
  labels=sorted({m['assertion']['label'] for m in candidate['cached_metadata'] if m['assertion'].get('label')})
  if not labels:
   labels=sorted({a['assertion']['canonical_target_title'] for t in ledger['all_raw_targets_with_inclusion_evidence'] if t['included_from_relevant_component'] and q in t['candidate_qids'] for a in t['cached_title_assertions'] if a['assertion'].get('qid')==q and a['assertion'].get('canonical_target_title')})
  if not labels:raise ValueError('Mapped QID has no source-backed display title:'+q)
  aliases=sorted({a for m in candidate['cached_metadata'] for a in (m['assertion'].get('aliases') or []) if a});native=sorted({p for m in candidate['cached_metadata'] for p in m['assertion'].get('native_types',[])})
  entities.append(dict(qid=q,label=labels[0],aliases=sorted(set(labels[1:]+aliases)),native_types=native,page_id=PAGE,revision_id=REV,metadata_evidence=candidate['cached_metadata'],source_targets=[t['target_title'] for t in ledger['all_raw_targets_with_inclusion_evidence'] if t['included_from_relevant_component'] and q in t['candidate_qids']]))
 # Targeted public resolution of the four explicitly retained unresolved targets.
 missing=ledger['unresolved_relevant_targets'];resolution=[];added=[]
 if missing:
  params=dict(action='query',titles='|'.join(missing[:50]),redirects=1,prop='pageprops|info',ppprop='wikibase_item|disambiguation',inprop='url',format='json');url='https://en.wikipedia.org/w/api.php?'+urllib.parse.urlencode(params);now=datetime.now(timezone.utc).isoformat()
  if (ROOT/'public_target_resolution.json').exists():
   data_bytes=(ROOT/'public_target_resolution.json').read_bytes();now=read(ROOT/'target_resolution_evidence.json')[0]['retrieved_utc']
  else:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'GeoAI-SecondUnitInputPrep/1.0 (read-only)'}),timeout=25) as response:data_bytes=response.read()
  (ROOT/'public_target_resolution.json').write_bytes(data_bytes);data=json.loads(data_bytes);assert 'error' not in data
  redirects={x['from']:x['to'] for x in data['query'].get('redirects',[])};normal={x['from']:x['to'] for x in data['query'].get('normalized',[])};pages={p['title']:p for p in data['query']['pages'].values()}
  for target in missing:
   title=normal.get(target,target);chain=[]
   while title in redirects:chain.append(dict(source=title,target=redirects[title]));title=redirects[title]
   page=pages.get(title);props=(page or {}).get('pageprops',{});qid=props.get('wikibase_item');ok=bool(page and 'missing' not in page and qid and 'disambiguation' not in props)
   ev=dict(source_target=target,lookup_attempted=target in missing[:50],public_lookup_limit=50,resolved=ok,qid=qid if ok else None,current_title=title,pageid=(page or {}).get('pageid'),lastrevid=(page or {}).get('lastrevid'),redirect_chain=chain,source_url=url,retrieved_utc=now,response_sha256=sha(ROOT/'public_target_resolution.json'),source_component_evidence=[t for t in ledger['all_raw_targets_with_inclusion_evidence'] if t['target_title']==target and t['included_from_relevant_component']])
   assert ev['source_component_evidence'];resolution.append(ev)
   if ok and qid not in {e['qid'] for e in entities}:
    entities.append(dict(qid=qid,label=title,aliases=[],native_types=[],page_id=PAGE,revision_id=REV,metadata_evidence=[ev],source_targets=[target]));added.append(qid)
 write('target_resolution_evidence.json',resolution)
 a=load('runtime_alias_provider',BASE/'runtime_model_inputs_direct_20261101/runtime_alias_application_v1/alias_enrichment.py');provider,alias_receipts=cached_aliases(entities,ROOT);entities,alias_evidence=a.enrich_entities(entities,provider);assert len(entities)==len({e['qid'] for e in entities});write('entity_candidates.json',entities);write('alias_evidence.json',alias_evidence)
 alias_snapshot=hashlib.sha256(json.dumps([dict(qid=e['qid'],label=e['label'],aliases=e['aliases']) for e in entities],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();VERSION+='-'+alias_snapshot[:12]
 # Use the existing literal exact function, with its same native-type projection.
 from GG_Data.entity_resolution.hundred_page_pilot.filter_qid_inventory import _types
 from GG_Data.entity_resolution.hundred_page_pilot.match_exact import exact_pairs
 type_path=PILOT/'GG_Data/entity_resolution/hundred_page_pilot/filter_qid_inventory.py';exact_path=PILOT/'GG_Data/entity_resolution/hundred_page_pilot/match_exact.py';protected[str(type_path)]=sha(type_path);protected[str(exact_path)]=sha(exact_path)
 metadata=local_metadata()
 flat=[];exact_entities=[]
 for g in groups:
  flat.append(dict(id=g['group_id'],page_id=PAGE,revision_id=REV,name=g['key']['word'],type=g['key']['entity_group'],repaired_source_row_indices=[m['source_row_index'] for m in g['members'] if m.get('word_original',m['word'])!=m['word']],source_review_statuses=['MISC_POLICY_PENDING'] if g['key']['entity_group']=='MISC' else []))
 for e in entities:
  te=_types(e['native_types'],metadata);e['type_evidence']=te
  exact_entities.append(dict(qid=e['qid'],label=e['label'],page_id=PAGE,revision_id=REV,qid_source_status='KEEP',**te))
 exact=exact_pairs(flat,exact_entities);exact_gid={x['group_id']:x for x in exact};exact_ids={m['occurrence_id'] for g in groups if g['group_id'] in exact_gid for m in g['members']};write('protected_exact_evidence.json',dict(status='APPROVED_EXISTING_ROUTE_PROPOSAL_NOT_CANONICAL_STATE_WRITE',matches=exact,occurrence_ids=sorted(exact_ids),source_stage_was='NOT_RUN',policy='Same first-unit unique literal exact function;no alias-exact expansion;MISC and DATE not autoaccepted'))
 del metadata
 EVENTS={'Q362':'KNOWN_SEPARATE_EVENT','Q52418':'KNOWN_SEPARATE_EVENT','Q713516':'KNOWN_SEPARATE_EVENT','Q1645012':'EXISTING_EVENT_HYPOTHESIS_ROUTE'}
 ordinary_entities=[e for e in entities if e['qid'] not in EVENTS];event_entities=[e for e in entities if e['qid'] in EVENTS]
 # Event names/aliases identify separate-route raw groups only by exact stored surface.
 event_names={name.casefold() for e in event_entities for name in [e['label']]+e['aliases']}
 def basis(m,word):
  text=m['prepared_text'];a,b=m['prepared_start'],m['prepared_end'];rs,re=m.get('selected_raw_start'),m.get('selected_raw_end')
  if isinstance(rs,int) and isinstance(re,int) and raw_source[rs:re]==word:return 'DIRECT_RAW_MENTION_SPAN'
  try:segments=json.loads(m.get('prepared_provenance_json') or 'null')
  except (ValueError,TypeError):return None
  if isinstance(segments,list) and len(segments)==len(text) and all(isinstance(x,list) and len(x)==2 for x in segments):
   if html.unescape(''.join(raw_source[x:y] for x,y in segments[a:b]))==word:return 'VERIFIED_PREPARED_CHARACTER_SOURCE_MAP'
  if isinstance(segments,list) and all(isinstance(x,list) and len(x)>=5 for x in segments):
   chars=[]
   for j in range(a,b):
    seg=next((x for x in segments if x[0]<=j<x[1] and x[4]=='linear'),None)
    if seg is None:return None
    pos=seg[2]+j-seg[0];chars.append(raw_source[pos:pos+1])
   if ''.join(chars)==word:return 'VERIFIED_PREPARED_LINEAR_SEGMENTS'
  return None
 representatives=[];raw_objects=[];routes={};unusable_groups=[]
 for g in groups:
  gid=g['group_id'];word=g['key']['word'];typ=g['key']['entity_group']
  route='PROTECTED_EXACT' if gid in exact_gid else 'DATE_DEFERRED' if typ=='DATE' else 'EVENT_SEPARATE' if word.casefold() in event_names else 'ORDINARY_MODEL_INPUT'
  routes[gid]=route
  if route!='ORDINARY_MODEL_INPUT':continue
  usable=[];bad=[]
  for member in g['members']:
   text=member.get('prepared_text');start,end=member.get('prepared_start'),member.get('prepared_end');why=[]
   if not isinstance(text,str) or not isinstance(start,int) or not isinstance(end,int) or not 0<=start<end<=len(text) or text[start:end]!=word:why.append('PREPARED_SPAN_NOT_VERIFIED')
   if member.get('processing_revision_id')!=REV or member.get('processing_revision_sha256')!=unit['source_sha256']:why.append('PROCESSING_REVISION_MISMATCH')
   if member.get('processing_surface_status') not in {'VERIFIED_ORIGINAL_SPAN_ONLY','VERIFIED_EXPANDED_SOURCE_ANCHOR'}:why.append('UNAPPROVED_SURFACE_STATUS')
   support=basis(member,word) if not why else None
   if not support:why.append('RAW_OR_PREPARED_SOURCE_MAP_NOT_VERIFIED')
   if why:bad.append(dict(occurrence_id=member['occurrence_id'],reasons=why));continue
   left,right=min(160,start),min(160,len(text)-end);usable.append((-(left+right),member['source_row_index'],member['occurrence_id'],member,left,right,support))
  if not usable:routes[gid]='PENDING_NO_VERIFIED_CONTEXT';unusable_groups.append(dict(group_id=gid,name=word,members=bad));continue
  _,_,_,member,left,right,support=min(usable,key=lambda x:x[:3]);start,end=member['prepared_start'],member['prepared_end'];window=member['prepared_text'][start-left:end+right]
  representatives.append(dict(group_id=gid,name=word,representative_occurrence_id=member['occurrence_id'],source_row_index=member['source_row_index'],context=window,mention_span_in_context=[left,left+len(word)],chosen_fragment_sha256=hashlib.sha256(member['prepared_text'].encode()).hexdigest(),fragment_window_span=[start-left,end+right],source_basis=support,page_id=PAGE,processing_revision_id=REV,processing_revision_sha256=unit['source_sha256'],all_occurrence_ids=[m['occurrence_id'] for m in g['members']],unusable_members=bad,selection_rule='Max usable context <=160 characters eachside inone verifiedfragment;then source_row_index,occurrence_id',shared_identity_not_assumed=True))
  raw_objects.append(dict(id=gid,name=word,aliases=[],description='',type=typ,context=window,page_id=PAGE,processing_revision_id=REV))
 write('representative_contexts.json',representatives);write('all_groups_and_members.json',read(SOURCE/'groups.json'));write('deferred_routes.json',dict(event_candidates=event_entities,groups=[dict(group_id=g['group_id'],name=g['key']['word'],route=routes[g['group_id']],occurrence_ids=[m['occurrence_id'] for m in g['members']]) for g in groups if routes[g['group_id']]!='ORDINARY_MODEL_INPUT'],unusable_groups=unusable_groups));write('all_occurrence_mapping.json',[dict(occurrence_id=m['occurrence_id'],source_row_index=m['source_row_index'],group_id=g['group_id'],route=routes[g['group_id']],protected_exact_qid=exact_gid[g['group_id']]['qid'] if g['group_id'] in exact_gid else None,page_id=PAGE,processing_revision_id=REV) for g in groups for m in g['members']])
 tri=load('approved_trigram',PILOT/'GG_Data/entity_resolution/trigram.py')
 def model_entity(e):return dict(id=e['qid'],name=e['label'],aliases=e['aliases'],description='',type=None)
 wiki_objects=[model_entity(e) for e in ordinary_entities]
 def ranked(query,candidates):
  def sim(c):
   aa=[tri.trigrams(n) for n in [query['name']]+query.get('aliases',[])];b=tri.trigrams(c['name'])
   return max((2*len(a&b)/(len(a)+len(b)) for a in aa if a and b),default=0.)
  return sorted(copy.deepcopy(candidates),key=lambda c:(-sim(c),c['id']))
 raw_requests=[]
 for query in (raw_objects if ordinary_entities else []):
  # Ranking raw-to-WIKI uses all label/alias evidence for each distinct QID.
  scored=[]
  for e in ordinary_entities:scored.extend(tri.rank_candidates(e,[dict(id=query['id'],name=query['name'],page_id=PAGE,revision_id=REV)]));scored[-1]['qid']=e['qid']
  order={r['qid']:r['trigram'] for r in scored};candidates=sorted(copy.deepcopy(wiki_objects),key=lambda c:(-order[c['id']],c['id']))
  raw_requests.append(dict(id=f'second-unit{PAGE}-{REV}:reverse:{query["id"]}',direction='reverse',entity=query,candidates=candidates,candidate_order_policy='All retained ordinary QIDs;maxlabel/aliastrigram descending,thenQID;no topKcut'))
 for query in (wiki_objects if raw_objects else []):raw_requests.append(dict(id=f'second-unit{PAGE}-{REV}:forward:{query["id"]}',direction='forward',entity=query,candidates=ranked(query,raw_objects),candidate_order_policy='All ordinary pendingrawgroups;maxquerylabel/aliastrigram descending,thenrawID;no topKcut'))
 write('checkpoint_scope.json',dict(status='SCOPE_AND_CONTEXT_READY_CPU_ONLY',page_id=PAGE,processing_revision_id=REV,occurrences=COUNT,groups=len(groups),retained_candidates_before_public=len(ledger['active_cached_candidates']),public_targets_resolved=sum(x['resolved'] for x in resolution),candidate_QIDs=len(entities),ordinary_QIDs=len(ordinary_entities),separate_Event_QIDs=len(event_entities),protected_exact_groups=len(exact_gid),protected_exact_occurrences=len(exact_ids),ordinary_raw_groups=len(raw_objects),route_group_counts=dict(Counter(routes.values())),questions=len(raw_requests),coverage='UNKNOWN_NOT_GLOBAL_NONE',unresolved_targets=[x['source_target'] for x in resolution if not x['resolved']],model_calls=0))
 print(json.dumps(read(ROOT/'checkpoint_scope.json'),indent=2),flush=True)
 runner=load('second_unit_runner',BASE/'training/train_joint_laya_expanded.py');formatter=load('second_unit_formatter',PILOT/'GG_Data/entity_resolution/laya_model/model.py')
 from transformers import AutoTokenizer
 from laya.common import build_sequence
 from laya.train import to_internal
 Tok=AutoTokenizer.from_pretrained(str(PILOT/'Data/external/laya_pilot_20261030/base_checkpoint/tokenizer'),local_files_only=True)
 requests=[];items=[];ready=[];capacity=[]
 for raw in raw_requests:
  row=runner.format_question(formatter,raw);full=formatter.token_diagnostics(Tok,row,1000000,100000);bounded=formatter.token_diagnostics(Tok,row,4096,512);assert full['fits'] and 'gold' not in row
  q=to_internal('match',row['questions']['match']);ids,markers=build_sequence(Tok,row['state'],q,1000000,100000);ci=[c['id'] for c in raw['candidates']];assert len(set(ci))==len(ci) and len(markers)==len(ci)+1 and list(row['metadata']['option_ids'].values())==ci+[None];assert all(ids[m]==Tok.mask_token_id for m in markers)
  positions=[dict(option_index=i,option_key=key,identity=identity,is_none=identity is None,marker_token_position=markers[i]) for i,(key,identity) in enumerate(row['metadata']['option_ids'].items())]
  request=dict(raw=raw,formatted=row,answer_positions=positions,input_version=VERSION,representative_context_semantic_relevance_guaranteed=False,candidate_coverage=dict(status='unknown',source_scope=unit['coverage_scope'],source_inventory_complete=False,declared_candidate_list_retained=True),page_id=PAGE,processing_revision_id=REV,processing_revision_sha256=unit['source_sha256'])
  item=dict(id=raw['id'],direction=raw['direction'],candidate_ids=ci,ids=ids,markers=markers,qtype=0,unlabelled=True,input_version=VERSION,diagnostic_full=full,diagnostic_4096_512=bounded)
  if bounded['fits']:
   small,mm=build_sequence(Tok,row['state'],q,4096,512);assert (small,mm)==(ids,markers)
   if not dry_scan:ready.append(item)
  
  if not dry_scan:requests.append(request);items.append(item)
  capacity.append(dict(id=raw['id'],direction=raw['direction'],candidate_count=len(ci),sequence_tokens=len(ids),head_tokens=full['head_tokens'],fits4096_512=bounded['fits'],bounded_diagnostic=bounded))
 
 if not dry_scan:
  write('unlabelled_requests_and_formatted.json',requests);write('full_untruncated_encoded_items.json',items);write('capacity_ready_items.json',ready)
 write('capacity_measurements.json',capacity)
 for p,h in protected.items():assert sha(p)==h
 summary=dict(status='SEALED_UNIT_CPU_PREPARED_NO_MODEL_CALLS',application_version='runtime-alias-enrichment-v1',input_version=VERSION,page_id=PAGE,processing_revision_id=REV,scope=read(ROOT/'checkpoint_scope.json'),summary={d:dict(questions=sum(x['direction']==d for x in capacity),ready=sum(x['direction']==d and x['fits4096_512'] for x in capacity),candidate_counts=sorted({x['candidate_count'] for x in capacity if x['direction']==d}),token_range=[min((x['sequence_tokens'] for x in capacity if x['direction']==d),default=None),max((x['sequence_tokens'] for x in capacity if x['direction']==d),default=None)],head_range=[min((x['head_tokens'] for x in capacity if x['direction']==d),default=None),max((x['head_tokens'] for x in capacity if x['direction']==d),default=None)]) for d in ['forward','reverse']},limits=dict(max_len=4096,head_max_len=512),capacity_ready=sum(x['fits4096_512'] for x in capacity),capacity_pending=sum(not x['fits4096_512'] for x in capacity),no_silent_truncation=True,no_candidate_dropped=True,no_gold_labels=True,exact_not_canonical_state_write=True,policy_version='owner-approved-opening-v1',protected_source_sha256=protected,formatter_sha256=sha(PILOT/'GG_Data/entity_resolution/laya_model/model.py'),runner_sha256=sha(BASE/'training/train_joint_laya_expanded.py'),tokenizer_sha256=sha(PILOT/'Data/external/laya_pilot_20261030/base_checkpoint/tokenizer/tokenizer.json'),alias_provenance=alias_receipts,output_sha256={n:sha(ROOT/n) for n in ['capacity_measurements.json','entity_candidates.json','representative_contexts.json','all_occurrence_mapping.json','protected_exact_evidence.json','target_resolution_evidence.json','deferred_routes.json']})
 summary.update(schema_version='geoai-prepared-unit-v2',execution_mode='CAPACITY_SOURCE_SCAN' if dry_scan else 'MATERIALIZED_INPUTS',alias_snapshot_sha256=alias_snapshot,scanned_questions=len(capacity),materialized_questions=len(items),known_encoder_limits_unchanged=True)
 if not dry_scan:
  for name in ['unlabelled_requests_and_formatted.json','full_untruncated_encoded_items.json','capacity_ready_items.json']:summary['output_sha256'][name]=sha(ROOT/name)
 write('scan_manifest.json' if dry_scan else 'manifest.json',summary);print(json.dumps({k:v for k,v in summary.items() if k not in ['protected_source_sha256','output_sha256','alias_provenance']},indent=2))

 return summary

def finalize_package(output_directory):
    output=Path(output_directory);manifest=read(output/'manifest.json');requests=read(output/'unlabelled_requests_and_formatted.json');items=read(output/'full_untruncated_encoded_items.json');ready=read(output/'capacity_ready_items.json');ready_ids={x['id'] for x in ready};mapping=read(output/'all_occurrence_mapping.json');source=Path(manifest['source_directory']);unit=read(source/'unit.json')
    assert len(mapping)==unit['retained_count'] and len({x['occurrence_id'] for x in mapping})==len(mapping)
    reverse=[r for r in requests if r['raw']['direction']=='reverse'];forward=[r for r in requests if r['raw']['direction']=='forward']
    rp={(r['raw']['entity']['id'],c['id']) for r in reverse for c in r['raw']['candidates']};fp={(c['id'],r['raw']['entity']['id']) for r in forward for c in r['raw']['candidates']};assert rp==fp
    for item in items:
        assert len(set(item['candidate_ids']))==len(item['candidate_ids']) and len(item['markers'])==len(item['candidate_ids'])+1 and item['diagnostic_full']['state_tokens_dropped']==0
        assert item['diagnostic_4096_512']['fits']==(item['id'] in ready_ids)
    def save(name,value):(output/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
    save('capacity_ready_requests.json',[r for r in requests if r['raw']['id'] in ready_ids]);save('capacity_pending_requests.json',[r for r in requests if r['raw']['id'] not in ready_ids])
    exact=read(output/'protected_exact_evidence.json');match={x['group_id']:x for x in exact['matches']};decisions=[]
    for row in mapping:
        if row['route']!='PROTECTED_EXACT':continue
        q=match[row['group_id']]
        decisions.append(dict(occurrence_id=row['occurrence_id'],qid=q['qid'],evidence=dict(method='APPROVED_UNIQUE_LITERAL_EXACT',match=q,page_id=unit['page_id'],processing_revision_id=unit['processing_revision_id'],source_sha256=unit['source_sha256'],source_seal_sha256=digest(source/'sealed_pending/seal.json'),canonical_state_not_written=True)))
    save('exact_decision_patch.json',dict(decision_version=f'unit-{unit["page_id"]}-{unit["processing_revision_id"]}-literal-exact-v1',decisions=decisions))
    verification=dict(status='INDEPENDENT_PACKAGE_READBACK_PASS',occurrences=len(mapping),questions=len(items),ready=len(ready),pending_capacity=len(items)-len(ready),candidate_pair_universe_identical_both_directions=len(rp),exact_occurrences=len(decisions),known_Event_route_only=True,event_routing_completeness='NOT_ESTABLISHED_BEYOND_SUPPLIED_KNOWN_QID_ROUTES',no_candidate_or_context_truncation=True,no_model_calls=True)
    save('verification.json',verification)
    for name in ['capacity_ready_requests.json','capacity_pending_requests.json','exact_decision_patch.json','verification.json']:manifest['output_sha256'][name]=digest(output/name)
    manifest['event_routing_completeness']='Known supplied QID routes preserved;new Eventclassification is not certified by aliases/native labels and needs existing Eventconsumer evidence.'
    save('manifest.json',manifest)
    save('inference_handoff.json',dict(input_version=manifest['input_version'],policy_version=manifest['policy_version'],manifest_sha256=digest(output/'manifest.json'),source_directory=str(source),source_unit_sha256=read(source/'receipt.json')['unit_sha256'],ready_requests='capacity_ready_requests.json',ready_items='capacity_ready_items.json',ready_questions=len(ready),capacity_pending_requests='capacity_pending_requests.json',capacity_pending_questions=len(items)-len(ready),exact_patch='exact_decision_patch.json',all_occurrences='all_occurrence_mapping.json',coverage='unknown',event_routing_gap=manifest['event_routing_completeness'],requires_artifact_input_version_binding=True,expected_weights_sha256='d65940e9c55cdd3496c906a8b538eda25487fe44156c50221457b73b95f6a042',inference_limits=dict(max_len=4096,head_max_len=512),file_sha256={n:digest(output/n) for n in ['capacity_ready_requests.json','capacity_ready_items.json','capacity_pending_requests.json','exact_decision_patch.json','all_occurrence_mapping.json','verification.json']}))
    return manifest


def prepare_unit(order_index,output_directory,source_directory=None,seed_directory=None,dry_scan=False):
    units=ordered_units()
    if not 0<=order_index<len(units):raise ValueError('Unit index outside sealed ordering')
    unit=units[order_index];output_directory=Path(output_directory);manifest_name='scan_manifest.json' if dry_scan else 'manifest.json'
    if unit['wiki_site']!='enwiki':raise ValueError('This existing collection supports enwiki only;no broader source scope selected')
    counterpart='manifest.json' if dry_scan else 'scan_manifest.json'
    if (output_directory/counterpart).exists():raise ValueError('Scan and materialized artifacts require separate versioned directories')
    if (output_directory/manifest_name).exists():
        manifest=read(output_directory/manifest_name)
        if (manifest['page_id'],manifest['processing_revision_id'])!=(unit['page_id'],unit['processing_revision_id']):raise ValueError('Output directory belongs to another sealed unit')
        for name,expected in manifest['output_sha256'].items():assert digest(output_directory/name)==expected
        for name,expected in manifest['protected_source_sha256'].items():assert digest(Path(name))==expected
        assert read(Path(manifest['source_directory'])/'unit.json')==unit
        return manifest # Completed artifact versions are immutable on resume.
    output_directory.mkdir(parents=True,exist_ok=True)
    source=Path(source_directory) if source_directory else output_directory/'source'
    if not (source/'receipt.json').exists():
        if source_directory and source.exists():raise ValueError('Supplied source directory incomplete;not owned forrepair')
        if source.exists():
            attempt=2
            while (output_directory/f'source_retry_{attempt:04d}').exists():attempt+=1
            source=output_directory/f'source_retry_{attempt:04d}'
        prepare_source(unit,source)
    assert read(source/'unit.json')==unit
    if seed_directory:
        import shutil
        for name in ['public_target_resolution.json','target_resolution_evidence.json']:
            target=output_directory/name
            if not target.exists() and (Path(seed_directory)/name).is_file():shutil.copyfile(Path(seed_directory)/name,target)
    result=prepare_inputs(source,output_directory,dry_scan=dry_scan)
    result.update(sealed_order_index=order_index,input_seal_sha256=PINNED_SEAL,sealed_order_sha256=read(SOURCE_ROOT/'seal.json')['sealed_units_sha256'],builder_sha256=digest(Path(__file__)),source_directory=str(source),unit_key=f"{unit['wiki_site']}:{unit['page_id']}:{unit['processing_revision_id']}")
    (output_directory/manifest_name).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    return result if dry_scan else finalize_package(output_directory)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--index',type=int,required=True);parser.add_argument('--out',type=Path,required=True);parser.add_argument('--source',type=Path);parser.add_argument('--seed',type=Path);parser.add_argument('--scan',action='store_true');args=parser.parse_args()
    result=prepare_unit(args.index,args.out,args.source,args.seed,dry_scan=args.scan)
    print(json.dumps(dict(manifest=str(args.out/('scan_manifest.json' if args.scan else 'manifest.json')),page_id=result['page_id'],processing_revision_id=result['processing_revision_id'],scope=result['scope'],summary=result['summary'],capacity_ready=result['capacity_ready'],capacity_pending=result['capacity_pending']),indent=2))
