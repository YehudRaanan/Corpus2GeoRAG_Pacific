"""Exactly units11-20: CPU input preparation,incremental atomic readiness index."""
import contextlib,json,os,traceback
from pathlib import Path
from datetime import datetime,timezone
import prepare_unit_v4 as builder
HERE=Path(__file__).parent;OUT=HERE/'batch_0011_0020_v4';OUT.mkdir(exist_ok=True);INDEX=OUT/'readiness_index.json'
def now():return datetime.now(timezone.utc).isoformat()
def save(value):
 temp=INDEX.with_suffix('.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8');os.replace(temp,INDEX)
units=builder.ordered_units();rows=[dict(unit_number=i+1,sealed_order_index=i,page_id=units[i]['page_id'],processing_revision_id=units[i]['processing_revision_id'],occurrences=units[i]['retained_count'],status='NOT_STARTED') for i in range(10,20)]
index=dict(schema_version='geoai-bounded-readiness-index-v1',scope='SEALED_UNITS_11_THROUGH_20_ONLY',verified_runtime_limits=dict(max_len=7680,head_max_len=896),runtime_budget_evidence='Parent reportsTRAINsmoke/fullunit9passed;DATAdoesnotrunGPU',builder=str(HERE/'prepare_unit_v4.py'),builder_sha256=builder.digest(HERE/'prepare_unit_v4.py'),units=rows,updated_utc=now(),matching_policy_unchanged=True,no_GPU_calls=True,units_not_declared_complete=True)
save(index)
# Reusing an older output undera different budget mustfail withoutmutating it.
old=HERE/'unit_0004_13404868_1212134108_v1';before=builder.digest(old/'manifest.json')
try:builder.prepare_unit(3,old,runtime_limits=(7680,896));raise AssertionError('Different budget reusedoldoutput')
except ValueError as exc:assert 'different runtime budget' in str(exc)
assert builder.digest(old/'manifest.json')==before
for position,i in enumerate(range(10,20)):
 row=rows[position];out=OUT/f'unit_{i+1:04d}_{row["page_id"]}_{row["processing_revision_id"]}_v4';row.update(status='PREPARING',directory=str(out),started_utc=now());index['updated_utc']=now();save(index)
 try:
  with (OUT/f'unit_{i+1:04d}_preparation.log').open('a',encoding='utf8') as log,contextlib.redirect_stdout(log):m=builder.prepare_unit(i,out,runtime_limits=(7680,896))
  for name,sha in m['output_sha256'].items():assert builder.digest(out/name)==sha
  for name,sha in m['protected_source_sha256'].items():assert builder.digest(Path(name))==sha
  requests=builder.read(out/'capacity_ready_requests.json');items=builder.read(out/'capacity_ready_items.json');assert len(requests)==len(items)==m['capacity_ready']
  assert m['materialized_questions']==m['scanned_questions'] and m['limits']==dict(max_len=7680,head_max_len=896)
  row.update(status='INPUTS_PREPARED' if m['capacity_pending']==0 else 'INPUTS_PREPARED_WITH_CAPACITY_GAPS',input_version=m['input_version'],manifest=str(out/'manifest.json'),manifest_sha256=builder.digest(out/'manifest.json'),handoff=str(out/'inference_handoff.json'),handoff_sha256=builder.digest(out/'inference_handoff.json'),ready_requests=str(out/'capacity_ready_requests.json'),ready_items=str(out/'capacity_ready_items.json'),ready_requests_sha256=builder.digest(out/'capacity_ready_requests.json'),ready_items_sha256=builder.digest(out/'capacity_ready_items.json'),capacity_ready=m['capacity_ready'],capacity_pending=m['capacity_pending'],scanned_questions=m['scanned_questions'],groups=m['scope']['groups'],ordinary_QIDs=m['scope']['ordinary_QIDs'],exact_occurrences=m['scope']['protected_exact_occurrences'],source_unresolved_targets=m['scope']['unresolved_targets'],context_gap_groups=m['scope']['route_group_counts'].get('PENDING_NO_VERIFIED_CONTEXT',0),coverage='unknown',Event_classification='NOT_CERTIFIED_BEYOND_SUPPLIED_KNOWN_ROUTES',summary=m['summary'],file_bytes={name:(out/name).stat().st_size for name in ['manifest.json','capacity_ready_requests.json','capacity_ready_items.json','capacity_pending_requests.json']},unit_complete=False,finished_utc=now())
 except Exception as exc:
  out.mkdir(exist_ok=True);failure=dict(exception=type(exc).__name__,reason=str(exc),traceback=traceback.format_exc(),unit_number=i+1,page_id=row['page_id'],processing_revision_id=row['processing_revision_id'],no_GPU_calls=True)
  path=out/'preparation_failure.json';path.write_text(json.dumps(failure,indent=2),encoding='utf8');row.update(status='PREPARATION_BLOCKED',failure=str(path),exception=type(exc).__name__,reason=str(exc),unit_complete=False,finished_utc=now())
 index['updated_utc']=now();save(index);print(json.dumps({key:row[key] for key in ['unit_number','page_id','status','manifest','capacity_ready','capacity_pending','reason'] if key in row}),flush=True)
index['status']='BOUNDED_PREPARATION_ATTEMPTED_UNITS_11_TO_20';index['updated_utc']=now();save(index);print('INDEX',str(INDEX),builder.digest(INDEX),flush=True)
