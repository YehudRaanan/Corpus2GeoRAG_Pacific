"""Execute source-bound DATE adjudication using accepted QIDs only; never parse mention text."""
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"D:\Projects\GeoAI-incremental-dev-20261101")
BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "structured_execution_334_v1"
AUDIT = ROOT / "orchestration_direct_20261101/approved_event_integration_0002/remaining_route_audit.json"
SOURCE_RELEASE = ROOT / "orchestration_direct_20261101/policy_v2_all17_sources_0340_0001/source_release.json"
FIELDS = ("input_sha256", "wiki_site", "page_id", "support_revision_id", "source_sha256", "policy_version")
METHOD = "APPROVED_STRUCTURED_QID_ONLY_DATE_CHECK_V1"

def read(p): return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p): return {"path": str(Path(p).resolve()), "sha256": sha(p)}
def check(ref):
    if sha(ref["path"]) != ref["sha256"]: raise ValueError("ARTIFACT_HASH_MISMATCH: " + ref["path"])
def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)+"\n",encoding="utf-8")
    return pin(path)
def content_hash(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()

def decide(row, decisions, scope, registry):
    """Missing same-scope identity is terminal unresolved, never another entity's dates."""
    oid = row["occurrence_id"]
    matching = [d for d in decisions if d["occurrence_id"] == oid and d.get("qid")]
    qids = sorted({d["qid"] for d in matching})
    result = {"occurrence_id": oid, "status": "UNRESOLVED", "method": METHOD,
              "reason": "NO_SAME_PAGE_REVISION_RESOLVED_QID", "qid": None,
              "original_occurrence": row, "page_id": scope["page_id"],
              "processing_revision_id": scope["processing_revision_id"],
              "evidence": {"accepted_qids_for_occurrence": qids, "raw_text_parsed": False,
                 "structured_time_lookup": "NOT_APPLICABLE_WITHOUT_RESOLVED_QID",
                 "classification": "NOT_APPLICABLE_WITHOUT_RESOLVED_QID"}}
    if not qids: return result
    if len(qids) != 1:
        result["reason"] = "CONFLICTING_SAME_SCOPE_QID_DECISIONS"
        return result
    qid = qids[0]
    result["qid"] = qid
    ref = registry.get(qid)
    if ref is None:
        result["reason"] = "MISSING_NATIVE_RECORD_FOR_RESOLVED_QID"
        return result
    native = ref["envelope"]["entity"]
    if native.get("id") != qid or ref["envelope"].get("requested_qid") != qid:
        raise ValueError("NATIVE_QID_MISMATCH")
    result["evidence"].update(structured_time_lookup="NATIVE_RECORD_INSPECTED",
        classification="UNKNOWN_NO_APPROVED_DATE_OR_PERIOD_CLASSIFICATION_BINDING",
        native_revision=native.get("lastrevid"), native_type_statements=native.get("claims",{}).get("P31",[]),
        native_time_statements={k:v for k,v in native.get("claims",{}).items()
          if any(s.get("mainsnak",{}).get("datatype")=="time" for s in v)}, provenance=ref.get("provenance"))
    result["reason"] = "UNKNOWN_APPROVED_TEMPORAL_CLASSIFICATION"
    return result

def execute():
    audit = read(AUDIT)
    proof_ref = audit["consumer_successor_verification"]
    check(proof_ref)
    proof = read(proof_ref["path"])
    source_release = read(SOURCE_RELEASE)
    registry_ref = source_release["native_registry"]
    check(registry_ref)
    registry = read(registry_ref["path"])["selected_references"]
    assert len(registry) == 340
    expected = {e["unit"]: e for e in audit["units"]}
    assert len(expected) == 17 and audit["raw_DATE_occurrences"] == 334
    assert {u["unit"] for u in proof["unit_audit"]} == set(expected)
    processor = pin(Path(__file__).resolve())
    dependencies = [pin(AUDIT),proof_ref,pin(SOURCE_RELEASE),registry_ref,pin(BASE/"handoff.json")]
    OUTPUT.mkdir(exist_ok=False)
    handoff = {"version":"structured_qid_only_date_execution_v1", "policy":"NO_RAW_TEXT_DATES_NO_INVENTED_TYPE_ALLOWLIST",
               "processor":processor,"input_pins":dependencies,"units":[],"network_requests":0,
               "raw_text_parser_used":False,"integration_state_changed":False,"publication":False,
               "full_process_completion_claimed":False}
    total = Counter()
    seen = set()
    for entry in proof["unit_audit"]:
        sealed_path = Path(entry["sealed_unit"]["unit_directory"]) / "unit.private.json"
        assert sha(sealed_path) == entry["sealed_unit"]["unit_sha256"]
        sealed = read(sealed_path)
        scope = sealed["manifest"]
        assert scope["page_id"] == expected[entry["unit"]]["page_id"]
        raw_path = Path(scope["source_path"])
        assert sha(raw_path) == scope["source_sha256"]
        raw_text = raw_path.read_bytes().decode("utf-8-sig")
        rows = sorted([r for r in sealed["occurrences"] if r.get("entity_group")=="DATE"],key=lambda r:r["occurrence_id"])
        assert len(rows) == expected[entry["unit"]]["date_occurrences"]
        for row in rows:
            assert row["occurrence_id"] not in seen
            seen.add(row["occurrence_id"])
            assert str(row["page_id"]) == str(scope["page_id"])
            assert str(row["processing_revision_id"]) == str(scope["processing_revision_id"])
            assert row["processing_revision_sha256"] == scope["source_sha256"]
            assert row["prepared_text"][row["processing_surface_start"]:row["processing_surface_end"]] == row["processing_surface"]
            assert raw_text[row["selected_raw_start"]:row["selected_raw_end"]] == row["processing_surface"]
        outcomes = [decide(row,sealed["decisions"],scope,registry) for row in rows]
        folder = OUTPUT / ("unit_%02d_%s" % (entry["unit"],scope["page_id"]))
        folder.mkdir()
        input_ref = save(folder/"input_occurrences.json",rows)
        output_ref = save(folder/"outcomes.json",outcomes)
        counts = {s:sum(o["status"]==s for o in outcomes) for s in ["RESOLVED","UNRESOLVED","NOT_APPLICABLE"]}
        receipt = {"route":"date_route","version":handoff["version"],"execution":"EXECUTED",
            "status":"COMPLETED_UNRESOLVED" if counts["UNRESOLVED"] else "COMPLETED",
            "source_scope":{k:scope[k] for k in FIELDS},"processing_revision_id":scope["processing_revision_id"],
            "input_occurrences_sha256":content_hash(rows),"input_occurrences":input_ref,
            "sealed_unit":pin(sealed_path),"source_file":pin(raw_path),"processor":processor,
            "input_pins":dependencies,"artifacts":[output_ref],"counts":counts,
            "outcomes":[{k:o[k] for k in ["occurrence_id","status","method","reason"]} for o in outcomes],
            "raw_text_parser_used":False,"native_time_projection_performed":False,
            "existing_event_rows_and_statement_time":"NOT_APPLICABLE_NO_DATE_OCCURRENCE_HAS_RESOLVED_QID",
            "scope_complete":True,"executed_at_utc":datetime.now(timezone.utc).isoformat()}
        receipt_ref = save(folder/"route_receipt.json",receipt)
        handoff["units"].append({"unit":entry["unit"],"page_id":scope["page_id"],
           "processing_revision_id":scope["processing_revision_id"],"counts":counts,"route_receipts":{"date_route":receipt_ref}})
        total.update(counts)
    assert len(seen) == 334
    handoff["counts"] = dict(total)
    handoff["reason_counts"] = dict(Counter(o["reason"] for u in handoff["units"] for o in read(read(u["route_receipts"]["date_route"]["path"])["artifacts"][0]["path"])))
    save(OUTPUT/"handoff.json",handoff)
    print(json.dumps({"units":len(handoff["units"]),"counts":dict(total),"reason_counts":handoff["reason_counts"],"handoff":pin(OUTPUT/"handoff.json")}))

if __name__ == "__main__": execute()
