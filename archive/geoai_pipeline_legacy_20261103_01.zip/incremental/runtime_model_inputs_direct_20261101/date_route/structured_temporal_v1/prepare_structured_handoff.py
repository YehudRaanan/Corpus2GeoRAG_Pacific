"""Cache-only source handoff. No raw-text dates, new identities or inferred bounds."""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(r"D:\Projects\GeoAI-incremental-dev-20261101")
OUT = Path(__file__).resolve().parent
INDEX = ROOT / "orchestration_direct_20261101/reconciliation_units11_20_v2/sealed_successors.json"
REGISTRY = ROOT / "pair_relations_direct_20261101/accepted11_20_sources_0001/cache_generation_001/native_registry.json"

def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def pin(p): return {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,v): p.write_text(json.dumps(v,sort_keys=True,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

def prepare():
    index = read(INDEX)
    assert [u["unit"] for u in index["units"]] == [11,12,13,14,15,17,18,20]
    registry = read(REGISTRY)
    refs = registry["selected_references"]
    entities, units = {}, []
    counts = Counter()
    for entry in index["units"]:
        path = Path(entry["sealed_unit"]["unit_directory"]) / "unit.private.json"
        assert pin(path)["sha256"] == entry["sealed_unit"]["unit_sha256"]
        unit = read(path)
        scope = unit["manifest"]
        assert pin(Path(scope["source_path"]))["sha256"] == scope["source_sha256"]
        rows = {r["occurrence_id"]: r for r in unit["occurrences"]}
        mapped = {}
        for decision in unit["decisions"]:
            q = decision.get("qid")
            if not q: continue
            assert q.startswith("Q") and decision["occurrence_id"] in rows
            row = rows[decision["occurrence_id"]]
            assert str(row["page_id"]) == str(scope["page_id"])
            assert str(row["processing_revision_id"]) == str(scope["processing_revision_id"])
            assert row["processing_revision_sha256"] == scope["source_sha256"]
            mapped.setdefault(q,[]).append(decision["occurrence_id"])
        raw_dates = [r for r in unit["occurrences"] if r.get("entity_group") == "DATE"]
        gaps = []
        for q in mapped:
            if q not in refs:
                gaps.append(q)
                continue
            ref = refs[q]
            record = ref["envelope"]["entity"]
            assert ref["envelope"]["requested_qid"] == record["id"] == q
            assert ref["entity_revision"] == record.get("lastrevid")
            claims = record.get("claims",{})
            # Preserve native statements; selecting which properties populate a date is NOT done here.
            time_claims = {prop: statements for prop,statements in claims.items()
                           if any(s.get("mainsnak",{}).get("datatype") == "time" for s in statements)}
            entities[q] = {"qid":q,"entity_revision":ref["entity_revision"],"entity_modified":ref.get("entity_modified"),
                "reference_policy":ref["policy"],"provenance":ref["provenance"],
                "labels":record.get("labels",{}),"type_statements":{p:claims.get(p,[]) for p in ["P31","P279"]},
                "event_time_statements":{p:claims.get(p,[]) for p in ["P580","P582","P585"]},
                "other_native_time_statements_for_review":{p:s for p,s in time_claims.items() if p not in {"P580","P582","P585"}}}
        units.append({"unit":entry["unit"],"source_scope":scope,"sealed_unit":pin(path),
                      "accepted_qid_occurrence_mapping":mapped,"missing_cached_qids":sorted(gaps),
                      "raw_date_outcomes":[{"occurrence_id":r["occurrence_id"],"status":"RETAINED_UNRESOLVED",
                         "reason":"RAW_DATE_NOT_USED_FOR_TEMPORAL_ENRICHMENT","original_occurrence":r} for r in raw_dates],
                      "temporal_route_completed":False})
        counts.update(units=1,raw_date_retained_unresolved=len(raw_dates),mapped_qid_scopes=len(mapped),
                      mapped_qid_scopes_with_cache=len(mapped)-len(gaps),missing_cached_qid_scopes=len(gaps))
    save(OUT/"structured_entities.json",entities)
    save(OUT/"units.json",units)
    callables = []
    for file,name,line in [("event_model.py","event_rows",46),("relations.py","statement_time",95),("relations.py","point_date_range",54)]:
        path = Path(r"D:\Projects\GeoAI\GG_Data\pipeline")/file
        callables.append({**pin(path),"callable":name,"line":line,"executed_by_this_preparation":False})
    counts.update(unique_cached_qids=len(entities),unique_qids_with_native_time=sum(bool(e["other_native_time_statements_for_review"]) or any(e["event_time_statements"].values()) for e in entities.values()),
                  unique_qids_with_event_time=sum(any(e["event_time_statements"].values()) for e in entities.values()))
    handoff={"version":"structured_temporal_source_handoff_v1","status":"SOURCE_EVIDENCE_ONLY_NOT_ROUTE_COMPLETION",
             "source_index":pin(INDEX),"registry":pin(REGISTRY),"processor":pin(Path(__file__).resolve()),
             "artifacts":[pin(OUT/"structured_entities.json"),pin(OUT/"units.json")],"existing_callables":callables,
             "counts":dict(counts),"network_requests":0,"raw_text_parser_used":False,
             "new_qids_or_bounds_assigned":False,"integration_state_changed":False,
             "excluded_units":[16,19],"temporal_route_completed":False}
    save(OUT/"handoff.json",handoff)
    print(json.dumps(handoff["counts"]))

if __name__ == "__main__": prepare()
