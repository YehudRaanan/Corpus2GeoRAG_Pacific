"""Independent persisted DATE execution readback against sealed source rows and decisions."""
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT = BASE / "structured_execution_334_v1"
def read(p): return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(r): assert sha(r["path"]) == r["sha256"],r["path"]
def content_hash(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest()

handoff = read(OUT/"handoff.json")
for ref in [handoff["processor"],*handoff["input_pins"]]: check(ref)
audit = read(handoff["input_pins"][0]["path"])
proof = read(audit["consumer_successor_verification"]["path"])
expected = {u["unit"]:u for u in proof["unit_audit"]}
assert len(expected)==17
seen = set()
counts,reasons = Counter(),Counter()
for unit in handoff["units"]:
    ref = unit["route_receipts"]["date_route"]
    check(ref)
    receipt = read(ref["path"])
    sealed_path = Path(expected[unit["unit"]]["sealed_unit"]["unit_directory"])/"unit.private.json"
    assert sha(sealed_path) == expected[unit["unit"]]["sealed_unit"]["unit_sha256"]
    sealed = read(sealed_path)
    scope = sealed["manifest"]
    rows = sorted([r for r in sealed["occurrences"] if r.get("entity_group")=="DATE"],key=lambda r:r["occurrence_id"])
    assert receipt["source_scope"] == {k:scope[k] for k in receipt["source_scope"]}
    assert receipt["processing_revision_id"] == scope["processing_revision_id"]
    assert receipt["input_occurrences_sha256"] == content_hash(rows)
    for artifact in [receipt["input_occurrences"],receipt["sealed_unit"],receipt["source_file"],receipt["processor"],*receipt["input_pins"],*receipt["artifacts"]]: check(artifact)
    assert read(receipt["input_occurrences"]["path"]) == rows
    outcomes = read(receipt["artifacts"][0]["path"])
    assert len(outcomes)==len(rows)
    raw = Path(scope["source_path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==scope["source_sha256"]
    text=raw.decode("utf-8-sig")
    for row,outcome in zip(rows,outcomes):
        assert row==outcome["original_occurrence"]
        assert row["occurrence_id"]==outcome["occurrence_id"] and row["occurrence_id"] not in seen
        seen.add(row["occurrence_id"])
        assert str(row["page_id"])==str(scope["page_id"])
        assert str(row["processing_revision_id"])==str(scope["processing_revision_id"])
        assert row["processing_revision_sha256"]==scope["source_sha256"]
        assert row["prepared_text"][row["processing_surface_start"]:row["processing_surface_end"]]==row["processing_surface"]
        assert text[row["selected_raw_start"]:row["selected_raw_end"]]==row["processing_surface"]
        qids={d["qid"] for d in sealed["decisions"] if d["occurrence_id"]==row["occurrence_id"] and d.get("qid")}
        assert not qids and outcome["qid"] is None
        assert outcome["reason"]=="NO_SAME_PAGE_REVISION_RESOLVED_QID"
        assert outcome["status"]=="UNRESOLVED" and not outcome["evidence"]["raw_text_parsed"]
        assert "date" not in outcome and "time_from" not in outcome and "time_to" not in outcome
        counts[outcome["status"]]+=1
        reasons[outcome["reason"]]+=1
    assert receipt["execution"]=="EXECUTED" and receipt["status"]=="COMPLETED_UNRESOLVED" and receipt["scope_complete"]
    assert not receipt["raw_text_parser_used"] and not receipt["native_time_projection_performed"]
    assert receipt["outcomes"]==[{k:o[k] for k in ["occurrence_id","status","method","reason"]} for o in outcomes]
assert len(seen)==audit["raw_DATE_occurrences"]==334
assert {u["unit"] for u in handoff["units"]}==set(expected)
# A different occurrence's QID must never supply this mention's date.
spec=importlib.util.spec_from_file_location("structured_date",BASE/"execute_date_route_v1.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
sample=rows[0]
assert module.decide(sample,[{"occurrence_id":"OTHER_OCCURRENCE","qid":"Q362"}],scope,{})["reason"]=="NO_SAME_PAGE_REVISION_RESOLVED_QID"
# Even a QID with native dates remains unresolved without approved classification.
mock={"Q1":{"envelope":{"requested_qid":"Q1","entity":{"id":"Q1","claims":{}}}}}
assert module.decide(sample,[{"occurrence_id":sample["occurrence_id"],"qid":"Q1"}],scope,mock)["reason"]=="UNKNOWN_APPROVED_TEMPORAL_CLASSIFICATION"
# Historical diagnostic artifacts remain byte-identical to their explicit correction marker.
marker=read(BASE.parent/"RAW_DATE_DIAGNOSTIC_ONLY_v2.json")
for artifact in marker["artifacts"]: check(artifact)
report={"status":"PASS_INDEPENDENT_READBACK","units":17,"unique_occurrences":len(seen),"counts":dict(counts),"reason_counts":dict(reasons),
        "sealed_rows_and_original_spans_preserved":True,"all_source_and_artifact_hashes_verified":True,
        "same_scope_identity_absence_independently_confirmed":True,"unrelated_qid_not_borrowed":True,
        "unknown_classification_not_resolved":True,"raw_text_parsing_used":False,"prior_diagnostics_preserved":True,
        "handoff":{"path":str(OUT/"handoff.json"),"sha256":sha(OUT/"handoff.json")}}
(OUT/"independent_verification.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report))
