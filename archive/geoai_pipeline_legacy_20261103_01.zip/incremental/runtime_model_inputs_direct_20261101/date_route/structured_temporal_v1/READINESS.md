# Structured temporal source handoff

This supersedes the completion interpretation of the earlier raw-text DATE parser outputs. RAW_DATE_DIAGNOSTIC_ONLY_v2.json is the explicit append-only correction; original artifacts remain intact. Neither parser receipt family may admit approved temporal-route completion.

Eight corrected sealed units (11-15,17,18,20) supply 192 accepted QID/page/revision scopes. The pinned existing local registry supplies 124 scopes / 115 unique QIDs, including 80 QIDs with native time datatype statements and 22 with P580/P582/P585. The other 68 scopes lack records in this selected registry; this is not a claim that no later local record exists. All 158 raw DATE occurrences remain original and unresolved for temporal enrichment, without inferred bounds.

Actual existing callables: GG_Data/pipeline/event_model.py:event_rows(record, source, decision) line46 preserves P31, P580/P582/P585, native precision/calendar and source claims, and invokes approved point_date_range only for the established Event case. GG_Data/pipeline/relations.py:statement_time(statement) line95 handles relation qualifier times under relation-date-selection-v1.2.0, including its relation-specific historical/start selection. It must not be applied as an entity-wide date resolver. relation_selection.temporal_group is comparison/ranking only, not evidence generation. The date_parts helper parses native Wikidata time syntax, not mention text.

This handoff preserves all source statements/references, entity revision/modified, reference provenance and same-page/revision accepted occurrence mapping. Other time properties are retained for review, not projected into a newly invented ontology. No temporal selector or Event population callable was executed in this preparation.

Concrete evidence: Q12296445 (Asiatic-Pacific Theater) P580 day precision 1941-12-07; P582 retains BOTH year precision1945 and day precision1946-03-02. Q1572785 (Battle of Rabaul) P580 day1942-01-23, P582 month1942-02, P585 year1942 are retained together. This handoff does not replace these with one fabricated interval.

Remaining runtime dependencies: RELATIONS must release a pinned whole-record registry covering the chosen mapped QIDs and the approved Event classification/selection/anchor/predicate inputs; then its existing Event and relation temporal code can execute with receipts. Integration must bind structured enrichment to that identity/source generation and keep raw DATE custody separate from enrichment completion. No new business date semantics are needed to preserve native fields; missing coverage does not authorize text parsing. No Event-specific rules are extended to arbitrary non-Event entities here. A decision would be needed only if broader projection of other native time properties is requested.

No network, GPU, policy change or integration mutation. Full temporal-route completion is not claimed.
