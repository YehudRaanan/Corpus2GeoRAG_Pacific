"""Exact local mention grouping; generated-fixture checks only for now.

A group is a unit of work, not proof that its members share an identity.
The source adapter must supply supported page/revision values; this module
never guesses them from a containing source or assigns Wikidata identities.
"""

import hashlib
import json


KEY_FIELDS = ("wiki_site", "page_id", "revision_id", "word", "entity_group")


def group_mentions(mentions):
    """Return exact-key groups and records with unresolved source attribution."""
    groups = {}
    unresolved = []
    for mention in mentions:
        # Keep the complete original record, including its occurrence and context.
        member = dict(mention)
        missing = [field for field in KEY_FIELDS[:3] if member.get(field) in (None, "")]
        if missing:
            # A containing-support revision cannot stand in for extraction revision.
            unresolved.append({"member": member, "missing_fields": missing})
            continue

        # Use the supplied values exactly: no case folding or type conversion.
        key = tuple(member[field] for field in KEY_FIELDS)
        if key not in groups:
            encoded_key = json.dumps(key, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            groups[key] = {
                "group_id": "group_" + hashlib.sha256(encoded_key).hexdigest(),
                "key": dict(zip(KEY_FIELDS, key)),
                "members": [],
            }
        # Append every occurrence; grouping must never deduplicate evidence.
        groups[key]["members"].append(member)
    return {"groups": list(groups.values()), "unresolved": unresolved}


def _self_check():
    """Run only tiny generated examples; do not load or process project data."""
    from copy import deepcopy

    def toy(occurrence_id, **changes):
        row = {
            "wiki_site": "enwiki", "page_id": 1, "revision_id": 10,
            "occurrence_id": occurrence_id, "word": "Tokyo", "entity_group": "LOC",
            "context": "Original context for " + occurrence_id,
        }
        row.update(changes)
        return row

    mentions = [
        toy("first"), toy("second"),
        toy("different_page", page_id=2),
        toy("different_revision", revision_id=11),
        toy("different_type", entity_group="ORG"),
        toy("different_case", word="tokyo"),
        toy("different_site", wiki_site="jawiki"),
        toy("pending_revision", revision_id=None, containing_support_revision_id=11),
        toy("pending_page", page_id=None),
    ]
    original = deepcopy(mentions)
    result = group_mentions(mentions)
    assert len(result["groups"]) == 6, "Expected six separate exact-key groups"
    assert result["groups"][0]["members"] == mentions[:2], "Same-key members and contexts must all survive"
    members = [member for group in result["groups"] for member in group["members"]]
    assert len(members) == 7, "Every resolved occurrence must survive"
    assert {m["occurrence_id"] for m in members} == {m["occurrence_id"] for m in mentions[:7]}
    assert len(result["unresolved"]) == 2, "Missing page/revision stays unresolved"
    assert result["unresolved"][0] == {"member": mentions[7], "missing_fields": ["revision_id"]}
    assert result["unresolved"][1] == {"member": mentions[8], "missing_fields": ["page_id"]}
    assert len({group["group_id"] for group in result["groups"]}) == 6
    reversed_result = group_mentions(list(reversed(mentions)))
    assert {group["group_id"] for group in reversed_result["groups"]} == {
        group["group_id"] for group in result["groups"]
    }, "Group IDs depend on keys, not input order"
    assert mentions == original, "Input records must remain unchanged"
    print("PASS: 9 generated mentions -> 6 groups / 7 retained members + 2 unresolved; all checks passed")


if __name__ == "__main__":
    _self_check()

