# E4 / Task 4 / R7 — internal pair-count increment

2026-11-01 20:05 UTC: **PASS — seven focused checks and six fresh-process verification checks**. One small stage file, standard library only; no production data, consumer export or matching policy changes.

Code: `pair_counts.py`. Generated output: `case_20261101T200502169693Z/`.

The stage reuses the existing `aggregate_units` occurrence eligibility and conflict/pending rules. For every accepted QID it collects distinct `(wiki_site, page_id)` supports, intersects those page sets, and returns private integer shared-page counts, both integer denominators and both directional strengths. Existing typed/provenance evidence stays in the original aggregation/history; this projection computes identity-level counts. No consumer weight representation is selected under G11.

## Plain before/after example

Initially Q1 appears on pages 1 and 2, Q2 on page 1, and Q3 on page 2. A correction changes the Q1 occurrence on page 2 to explicit unmatched, preserving its source member and previous accepted decision in history.

| Pair | Shared pages before → after | Source denominator | Target denominator | Source → target strength | Target → source strength |
|---|---|---|---|---|---|
| Q1 / Q2 | 1 → 1 | 2 → 1 | 1 → 1 | 0.5 → 1.0 | 1.0 → 1.0 |
| Q1 / Q3 | 1 → 0 | 2 → 1 | 1 → 1 | 0.5 → 0.0 | 1.0 → 0.0 |
| Q2 / Q3 | 0 → 0 | 1 → 1 | 1 → 1 | 0.0 → 0.0 | 0.0 → 0.0 |

The Q1/Q2 numerator does not change, yet its outgoing strength must change because Q1's denominator changed. The check compares literal hand-derived rows before and after, so retaining stale strengths fails. Zero-count rows are private diagnostic rows, not a consumer-edge policy.

## Measured verification

TDD RED: the initial empty implementation returned `[]`; the expected before-state assertion failed. GREEN: seven checks passed after the small implementation: exact before/after values, all affected denominators, integer count types, preserved source members/history, exact correction replay as no-op, empty state, and unchanged shared sources.

A separate process verified code/payload/shared-source hashes, replayed saved initial versions and the correction into a fresh reducer, checked before/after output and hand-derived final values, rejected duplicate contribution by exact replay, and confirmed three retained decision versions across two units. Four original occurrences/support records remain; one is now explicitly unmatched. `transitions_and_history.json` preserves both pair projections, every version and both source texts.

## Evidence

| Artifact | SHA-256 |
|---|---|
| pair_counts.py | 6efcce0b21f8133b810aa616ab70ecb04c543f3d89db4ef7f197a891d44ec8ea |
| case_20261101T200502169693Z/verification.json | d8f340bd4880eb504825b4fcfb9dcb73c4207e81c13de11ac47e6e5784367f1b |

`independent_verification.json` holds fresh-process evidence. `verification.json` pins the output payload and unchanged `aggregate_occurrences.py`, `occurrence_decisions.py`, and `source_custody/local_unit_contract.py`.

## Scope and next dependency

The implementation rebuilds all pairs for the three-identity generated fixture (quadratic in the number of active identities); it is not an approved full-corpus algorithm or resource envelope. Version validation/history remains owned by existing `replace_unit`; no new durable store or history protocol was added. Original accepted-decision provenance is preserved, not recomputed or relabeled as model output. No integration, plans, input or training files were edited. No nested agents, paid operations, publication or dependency installation. Backup status: **Unprotected**.

No blocker remains for this bounded increment. Parent review is next; combining these internal counts with E5 pair-specific native/fallback history is a separate assignment. Consumer weight export still waits for G11, and production sizing/recovery for G16. Shared plans remained read-only.
