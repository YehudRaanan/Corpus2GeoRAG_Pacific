"""Generated E4/R7 internal page counts. No consumer weight export or model calls."""
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
INTEGRATION = ROOT / "integration_direct_20261101"
sys.path.insert(0, str(INTEGRATION))
from aggregate_occurrences import aggregate_units
from occurrence_decisions import SCOPE_FIELDS, replace_unit


# Physical pages, not mentions, support each pair. Example: Q1 on pages 1/2, Q2 on 1 -> 1/2 and 1/1.
def pair_counts(state):
    pages = {}
    for occurrence in aggregate_units(state)["occurrences"]:
        if occurrence["not_counted_reasons"]:
            continue  # Existing reducer decides eligibility; pending/conflict/unmatched stay in its evidence.
        qid = occurrence["decision_values"][0]
        for support in occurrence["supports"]:
            scope = support["unit_scope"]
            pages.setdefault(qid, set()).add((scope["wiki_site"], scope["page_id"]))
    # ponytail: rebuild all pairs for this three-identity fixture; index affected pairs only after scale is approved.
    pairs = []
    for source, target in combinations(sorted(pages), 2):
        shared = len(pages[source] & pages[target])
        pairs.append(dict(source_qid=source, target_qid=target, shared_page_count=shared,
                          source_page_count=len(pages[source]), target_page_count=len(pages[target]),
                          source_strength=shared / len(pages[source]), target_strength=shared / len(pages[target])))
    return pairs


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")


def digest(data):
    return hashlib.sha256(data).hexdigest()


# Generated inputs use the exact existing unit interface. Example: page 2 contains separate Q1/Q3 occurrences.
def fixture_unit(page, indices, qids):
    source = f"Generated source for physical page {page}".encode()
    scope = dict(input_sha256=digest(b"generated-three-identities-two-pages"), wiki_site="enwiki",
                 page_id=page, support_revision_id=10, source_sha256=digest(source),
                 policy_version="generated-pair-count-v1")
    members = [dict(occurrence_id=f"o{index}", original_row_index=index, word=f"Generated {qid}",
                    entity_group="LOC", wiki_site="enwiki", page_id=page, revision_id=10,
                    source_pointer=dict(page=page, revision=10, occurrence=f"o{index}"))
               for index, qid in zip(indices, qids)]
    handoff = dict(manifest=dict(scope, expected_row_indices=indices), shards=[dict(scope, row_indices=indices)],
                   occurrences=members, decisions=[dict(occurrence_id=m["occurrence_id"], qid=qid,
                   evidence=dict(source="generated accepted decision")) for m, qid in zip(members, qids)],
                   version=f"page-{page}-v1", prior_version=None)
    return handoff, source


# This catches stale denominators: withdrawing Q1/page2 must change Q1->Q2 even though that shared page stays.
def self_check():
    protected_paths = [INTEGRATION / name for name in ("aggregate_occurrences.py", "occurrence_decisions.py")]
    protected_paths += [ROOT / "source_custody/local_unit_contract.py"]
    protected = {str(p): digest(p.read_bytes()) for p in protected_paths}
    first, source1 = fixture_unit(1, [0, 1], ["Q1", "Q2"])
    second, source2 = fixture_unit(2, [2, 3], ["Q1", "Q3"])
    state = {}
    replace_unit(state, first, source1)
    replace_unit(state, second, source2)
    original = deepcopy(state)
    before = pair_counts(state)
    assert before == [dict(source_qid="Q1", target_qid="Q2", shared_page_count=1,
                           source_page_count=2, target_page_count=1, source_strength=0.5, target_strength=1.0),
                      dict(source_qid="Q1", target_qid="Q3", shared_page_count=1,
                           source_page_count=2, target_page_count=1, source_strength=0.5, target_strength=1.0),
                      dict(source_qid="Q2", target_qid="Q3", shared_page_count=0,
                           source_page_count=1, target_page_count=1, source_strength=0.0, target_strength=0.0)], before
    assert state == original
    correction = deepcopy(second)
    correction.update(version="page-2-v2", prior_version="page-2-v1")
    correction["decisions"][0]["qid"] = None  # Before Q1/page2 -> after explicit unmatched; source member retained.
    assert replace_unit(state, correction, source2) is True
    after = pair_counts(state)
    assert after == [dict(source_qid="Q1", target_qid="Q2", shared_page_count=1,
                          source_page_count=1, target_page_count=1, source_strength=1.0, target_strength=1.0),
                     dict(source_qid="Q1", target_qid="Q3", shared_page_count=0,
                          source_page_count=1, target_page_count=1, source_strength=0.0, target_strength=0.0),
                     dict(source_qid="Q2", target_qid="Q3", shared_page_count=0,
                          source_page_count=1, target_page_count=1, source_strength=0.0, target_strength=0.0)], after
    assert all(type(row[key]) is int for rows in (before, after) for row in rows
               for key in ("shared_page_count", "source_page_count", "target_page_count"))
    final = deepcopy(state)
    assert replace_unit(state, correction, source2) is False and state == final
    assert pair_counts(state) == after
    for key, history in original.items():
        assert state[key][:len(history)] == history
        assert all(v["occurrences"] == history[0]["occurrences"] for v in state[key])
    assert sorted(len(history) for history in state.values()) == [1, 2]
    aggregate = aggregate_units(state)
    assert aggregate["unique_occurrences"] == 4 and aggregate["support_records"] == 4
    assert sum(r["decision_values"] == [None] for r in aggregate["occurrences"]) == 1
    assert pair_counts({}) == []
    assert protected == {str(p): digest(p.read_bytes()) for p in protected_paths}
    output = HERE / ("case_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    output.mkdir()
    payload = dict(before=before, after=after,
                   units=[dict(scope=dict(zip(SCOPE_FIELDS, key)), versions=history) for key, history in state.items()],
                   sources={"1": source1.decode(), "2": source2.decode()}, aggregate_after=aggregate)
    (output / "transitions_and_history.json").write_bytes(encoded(payload))
    verification = dict(status="PASS", checks=["hand_computed_before_and_after", "all_denominators_updated",
                        "integer_counts", "history_and_members_retained", "exact_retry_noop", "empty_state",
                        "shared_sources_unchanged"], generated_only=True, consumer_export=False,
                        code_sha256=digest(Path(__file__).read_bytes()), protected_sha256=protected,
                        output_sha256=digest((output / "transitions_and_history.json").read_bytes()), backup_status="Unprotected")
    (output / "verification.json").write_bytes(encoded(verification))
    print(json.dumps(dict(status="PASS", checks=len(verification["checks"]), output=str(output),
                         code_sha256=verification["code_sha256"], verification_sha256=digest((output / "verification.json").read_bytes()))))


if __name__ == "__main__":
    self_check()
