# E4 / Task 4 / R7 — first real-unit counts

2026-11-01 20:23 UTC: **PASS**. Eight focused checks plus independent fresh-process readback using separate counting logic. No new count formula or relation/consumer policy.

Unit: enwiki page 48975579 / processing revision 1375061414. Decision version: first-unit-exact-v1.

Before reading for computation, real_counts.py verified the completed E2/E4 handoff status, caller-pinned unit hash, every receipt-recorded output/protected hash, the handoff writer code hash and unchanged pair_counts.py hash. Existing E2 recover then validated the sealed unit/source/membership. Existing replace_unit and aggregate_units reproduced the saved handoff aggregation exactly. Counts used the existing pair_counts function without modification.

Results:

- All 136 original occurrences remain referenced by the exact sealed handoff.
- Thirty accepted occurrences support ten accepted QIDs, all on one physical page.
- The 45 unordered accepted-identity pairs each have integer shared_page_count=1 and integer source_page_count=target_page_count=1. Both internally calculated directional strengths are 1.0.
- All 106 pending records are saved unchanged in pending.json. They do not become explicit unmatched decisions or count endpoints. Explicit unmatched count stays zero.
- Exact decision replay adds no state/history contribution. A fresh reducer reconstructed from the same sealed handoff gives identical pair counts and history. One supplied decision version remains.

Example: two accepted QIDs with several mentions on this same page have one shared-page support, regardless of their mention totals. A pending occurrence remains evidence only. These are partial counts for this declared retained unit, not whole-page completeness, corpus totals or semantic accuracy claims.

Independent verification imported neither pair_counts nor aggregate_units. It reconstructed accepted-QID mention totals and physical-page sets directly from the sealed occurrence decisions, checked all 45 unique pairs and integer denominators, compared all pending records and checked the accepted/pending partition of all 136 IDs. All 18 protected input/code/receipt hashes matched. No shared source changed.

## Deliverables

Owned root: D:/Projects/GeoAI-incremental-dev-20261101/counts_direct_20261101.

Stage: real_counts.py. Output: real_counts_20261101T202248289937Z/{counts.json,pending.json,verification.json,independent_verification.json}.

| Artifact | SHA-256 |
|---|---|
| real_counts.py | a13dc48a0adc711d67d1a555b66a384f71a4235f3e740079e0827413f45badad |
| counts.json | 6fde44762c0418a98f6105a1e6b8e8c1eca20d2c767e9edc1c3e39edaf02b150 |
| pending.json | 53068250304f7d62493fa55026e8ca9290cdbb9ce34baf4ef610e8a6d1e00ec1 |
| verification.json | 590cfa27e187541d9b155857d5979089a8b89a842684d198bd3d92c5fe535b4b |
| source sealed unit | 35d0edd3f0eb17aa0e468f25a25dbfd1daf257bec938f05bb510e848ec5ae0f6 |

This is an execution adapter around already tested components; the earlier generated denominator/history regression remains unchanged. No fixture suites were rerun for this bounded real-data execution.

## Limits and next dependency

These pair rows are private count evidence. No native relation, fallback graph edge, consumer weight field or publication was created. G11 consumer strength representation is still undecided. Pair computation rebuilds all active pairs and is approved here only for ten identities/one unit; no full-input scaling or production resource result follows. No model call, network request, paid work, nested agent, installation or shared-plan/input/training/integration edit occurred. Backup: Unprotected.

No blocker remains for this increment. Parent can review this hash-bound count receipt for E7 preparation or separately scoped E5 integration. A count does not establish a complete native-relation frontier.
