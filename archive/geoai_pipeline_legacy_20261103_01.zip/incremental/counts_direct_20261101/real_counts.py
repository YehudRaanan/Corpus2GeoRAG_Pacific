"""One real sealed unit -> existing internal page/pair counts; no relations/export."""
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
HANDOFF = ROOT / "integration_direct_20261101/real_handoff_0001"
PINNED_UNIT = "35d0edd3f0eb17aa0e468f25a25dbfd1daf257bec938f05bb510e848ec5ae0f6"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


# Trust the completed receipt only after every recorded byte hash matches. Example: a changed unit must stop here.
def run():
    receipt = json.loads((HANDOFF / "receipt.json").read_text())
    assert receipt["status"] == "PASS_REAL_FIRST_VERSION_E2_E4_HANDOFF"
    assert receipt["pinned_unit_sha256"] == PINNED_UNIT
    protected = dict(receipt["protected_sha256"])
    protected.update({str(HANDOFF / name): value for name, value in receipt["output_sha256"].items()})
    protected[str(HANDOFF / "receipt.json")] = digest(HANDOFF / "receipt.json")
    protected[str(HERE / "pair_counts.py")] = "6efcce0b21f8133b810aa616ab70ecb04c543f3d89db4ef7f197a891d44ec8ea"
    protected[str(ROOT / "integration_direct_20261101/handoff_first_real_unit.py")] = receipt["code_sha256"]
    assert all(digest(Path(name)) == value for name, value in protected.items())
    sys.path.insert(0, str(ROOT / "durable_units_direct_20261101"))
    from durable_unit import recover
    from pair_counts import aggregate_units, encoded, pair_counts, replace_unit
    loaded = recover(HANDOFF / "sealed_v1", PINNED_UNIT)
    assert loaded["status"] == "sealed"
    handoff = loaded["handoff"]
    source = (HANDOFF / "sealed_v1/source.private.bin").read_bytes()

    # Thirty accepted occurrences contribute; 106 pending do not become NONE or pair endpoints.
    state = {}
    assert replace_unit(state, handoff, source) is True
    original = deepcopy(state)
    aggregate = aggregate_units(state)
    pairs = pair_counts(state)
    pending = handoff["pending_evidence"]
    assert aggregate == json.loads((HANDOFF / "aggregate.json").read_text(encoding="utf-8"))
    assert len(handoff["occurrences"]) == 136 and len(handoff["decisions"]) == 30
    assert len(pending) == 106 and len(aggregate["identity_counts"]) == 10
    assert sum(row["mention_count"] for row in aggregate["identity_counts"]) == 30
    assert sum(bool(row["pending_supports"]) for row in aggregate["occurrences"]) == 106
    assert loaded["receipt"]["explicit_unmatched_occurrence_ids"] == []
    assert set(loaded["receipt"]["pending_occurrence_ids"]) == {row["occurrence_id"] for row in pending}

    # All ten accepted identities share this one physical page: 10 choose 2 = 45, each with integer count 1.
    assert aggregate["unique_physical_pages"] == 1 and len(pairs) == 45
    accepted_qids = {row["qid"] for row in aggregate["identity_counts"]}
    for pair in pairs:
        assert pair["source_qid"] in accepted_qids and pair["target_qid"] in accepted_qids
        assert all(type(pair[key]) is int and pair[key] == 1
                   for key in ("shared_page_count", "source_page_count", "target_page_count"))
        assert pair["source_strength"] == pair["target_strength"] == 1.0
    assert replace_unit(state, deepcopy(handoff), source) is False and state == original
    assert pair_counts(state) == pairs
    restarted = {}
    assert replace_unit(restarted, recover(HANDOFF / "sealed_v1", PINNED_UNIT)["handoff"], source) is True
    assert pair_counts(restarted) == pairs and restarted == state
    assert all(digest(Path(name)) == value for name, value in protected.items())

    # Private count evidence only. A shared page is not a native relation or permission to export a graph edge.
    output = HERE / ("real_counts_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    output.mkdir()
    payload = dict(scope=loaded["receipt"]["scope"], decision_version=handoff["version"],
                   pinned_unit_sha256=PINNED_UNIT, identity_counts=aggregate["identity_counts"],
                   typed_counts=aggregate["typed_counts"], pairs=pairs,
                   retained_occurrences=136, accepted_occurrences=30, pending_occurrences=106,
                   explicit_unmatched_occurrences=0, history_versions=1,
                   count_scope="Partial accepted exact identities on one declared retained unit; not corpus-wide counts")
    (output / "counts.json").write_bytes(encoded(payload))
    (output / "pending.json").write_bytes(encoded(pending))
    checks = ["completed_receipt_and_source_hashes", "sealed_membership_recovered", "existing_aggregate_equal",
              "30_accepted_106_pending_preserved", "45_integer_pair_counts", "exact_retry_noop", "restart_deterministic",
              "shared_inputs_unchanged"]
    verification = dict(status="PASS_REAL_COUNTS", checked_utc=datetime.now(timezone.utc).isoformat(), checks=checks,
                        input_receipt_sha256=protected[str(HANDOFF / "receipt.json")], protected_sha256=protected,
                        code_sha256=digest(Path(__file__)),
                        output_sha256={p.name: digest(p) for p in output.iterdir()},
                        consumer_export=False, relations_created=False, backup_status="Unprotected")
    (output / "verification.json").write_bytes(encoded(verification))
    print(json.dumps(dict(status=verification["status"], checks=len(checks), output=str(output),
                         code_sha256=verification["code_sha256"], output_sha256=verification["output_sha256"],
                         verification_sha256=digest(output / "verification.json"))))


if __name__ == "__main__":
    run()
