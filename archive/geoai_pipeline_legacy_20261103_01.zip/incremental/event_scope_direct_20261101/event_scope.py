"""Two-hop source discovery only. Callers supply anchors, predicates, types and geo decisions."""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, r'D:\Projects\GeoAI')
from GG_Data.pipeline.events import item_links


def expand(anchors, records, kinds, predicates, geo):
    candidates, opened, missing = [], set(), set()
    def links(qid):
        if qid not in records:
            missing.add(qid)
            return []  # Missing is recorded; this is not a complete negative source answer.
        opened.add(qid)
        return [link for link in item_links(records[qid]) if link['source_predicate'] in predicates]
    def collect(anchor, link, path):
        qid = link['object_qid']
        kind = kinds.get(qid)
        hop = len(path)
        apply_geo = kind == 'LOC'
        if hop == 2 and kind not in ('LOC', None):
            inclusion, reason = 'EXCLUDE', 'SECOND_HOP_NON_LOC'
        elif kind is None:
            inclusion, reason = 'PENDING_TYPE', 'SUPPLIED_TYPE_UNKNOWN'
        elif apply_geo:
            decision = geo.get(qid)
            inclusion = 'INCLUDE' if decision is True else 'EXCLUDE' if decision is False else 'PENDING_GEO'
            reason = 'SUPPLIED_LOC_GEO_DECISION' if decision is not None else 'G7_UNKNOWN_OR_UNAPPROVED_MASK'
        else:
            inclusion, reason = 'INCLUDE', 'DIRECT_NON_LOC_GEO_NOT_APPLIED'
        candidates.append(dict(anchor=anchor, qid=qid, type=kind, hop=hop, path=path,
                               geo_applied=apply_geo, inclusion=inclusion, reason=reason))
    for anchor in anchors:
        direct = links(anchor)
        for first in direct:
            collect(anchor, first, [first])
        # Open first-hop records once per discovery path, never second-hop LOC records.
        # Retained out-of-mask evidence is not deleted; the mask controls LOC inclusion only.
        for first in direct:
            for second in links(first['object_qid']):
                collect(anchor, second, [first, second])
    return dict(candidates=candidates, opened_records=sorted(opened), source_pending=sorted(missing))


if __name__ == '__main__':
    from test_scope import check
    here = Path(__file__).resolve().parent
    paths = [Path(r'D:\Projects\GeoAI\GG_Data\pipeline') / name for name in ('events.py','relations.py','test_events.py')]
    paths += [Path(__file__), here / 'test_scope.py']
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    protected = {str(p):sha(p) for p in paths}
    result = check()
    assert all(sha(Path(p)) == h for p,h in protected.items())
    output = here / 'fixture_0001'
    output.mkdir()
    (output / 'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    (output / 'verification.json').write_text(json.dumps(dict(status=result['status'],checks=result['checks'],
        protected_sha256=protected,result_sha256=sha(output/'result.json')),indent=2),encoding='utf-8')
    print(json.dumps(dict(status=result['status'],checks=result['checks'],candidates=len(result['result']['candidates']),
                         opened_records=result['result']['opened_records'])))
