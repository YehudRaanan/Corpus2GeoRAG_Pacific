"""Synthetic acceptance example; no real anchor, mask or predicate approval."""
from copy import deepcopy
from event_scope import expand


def record(qid, targets):
    return dict(id=qid, claims={'P710': [dict(id=qid+'$'+target, rank='normal',
                mainsnak=dict(property='P710', datatype='wikibase-item',
                              datavalue=dict(value={'entity-type': 'item', 'id': target}))) for target in targets]})


def check():
    records = {q: record(q, targets) for q, targets in {
        'Q1':['Q2','Q3','Q4','Q11'], 'Q2':['Q5','Q6','Q7','Q8'], 'Q3':['Q9'], 'Q4':['Q12'],
        'Q11':[], 'Q5':['Q10'], 'Q12':['Q13'], 'Q99':['Q98']}.items()}
    kinds = {'Q1':'event','Q2':'PER','Q3':'LOC','Q4':'event','Q5':'LOC','Q6':'ORG',
             'Q7':'LOC','Q8':'LOC','Q9':'LOC','Q11':'LOC','Q12':'LOC','Q10':'LOC','Q13':'LOC'}
    geo = {'Q1':False,'Q2':False,'Q3':False,'Q4':False,'Q5':True,'Q7':None,'Q8':False,'Q9':True,'Q11':None,'Q12':True}
    original = deepcopy(records)
    result = expand(['Q1'], records, kinds, {'wd:P710'}, geo)
    rows = {r['qid']:r for r in result['candidates']}
    assert set(result['opened_records']) == {'Q1','Q2','Q3','Q4','Q11'}
    assert not {'Q10','Q13','Q98','Q99'} & rows.keys()
    assert {q for q,r in rows.items() if r['inclusion']=='INCLUDE'} == {'Q2','Q4','Q5','Q9','Q12'}
    assert rows['Q6']['reason']=='SECOND_HOP_NON_LOC' and rows['Q6']['inclusion']=='EXCLUDE'
    assert rows['Q3']['inclusion']==rows['Q8']['inclusion']=='EXCLUDE'
    assert rows['Q7']['inclusion']==rows['Q11']['inclusion']=='PENDING_GEO'
    assert rows['Q2']['geo_applied'] is False and rows['Q4']['geo_applied'] is False
    assert all(r['anchor']=='Q1' and len(r['path'])==r['hop'] and r['hop'] in (1,2) for r in rows.values())
    assert records==original
    unknown=expand(['Q1'],records,kinds,{'wd:P710'}, {})
    assert all(r['inclusion']=='PENDING_GEO' for r in unknown['candidates'] if r['type']=='LOC')
    missing=deepcopy(records); del missing['Q2']
    assert expand(['Q1'],missing,kinds,{'wd:P710'},geo)['source_pending']==['Q2']
    return dict(status='PASS_BOUNDED_EVENT_SCOPE_FIXTURE',result=result,records=records,kinds=kinds,
                geo=geo,anchors=['Q1'],predicates=['wd:P710'],checks=9,
                real_anchor_selected=False,real_mask_selected=False,external_calls=False)
