"""Pure E7 cadence decision; no scheduler, publication, or automatic completion admission."""
import hashlib
import json
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path


# Inputs are upstream-verified, admitted completion receipts; a source custody seal alone does not admit completion.
# Example: one page/revision replayed 100 times still counts as one unit.
def checkpoint_decision(now, reference_time, completed_units, acknowledged_units=(),
                        approved_geometry_or_correction=False, final_flush=False, *, run_start=None, required_stages=()):
    # Owner-approved first interval begins at run start; later intervals use the last successful checkpoint.
    if reference_time is None:
        reference_time = run_start
    if now.utcoffset() is None or (reference_time is not None and reference_time.utcoffset() is None):
        raise ValueError("Use timezone-aware clock/reference values")
    elapsed = None if reference_time is None else (now - reference_time).total_seconds()
    if elapsed is not None and elapsed < 0:
        raise ValueError("Clock precedes the successful-checkpoint reference")
    bindings, versions, eligible = {}, {}, set()
    for completed in completed_units:
        if completed["status"] == "pending":
            continue  # An unsealed attempt is not an acknowledgment.
        if completed["status"] != "sealed":
            raise ValueError("Expected verified sealed completion or explicit pending")
        receipt = completed["receipt"]
        scope = receipt["scope"]
        key = (scope["wiki_site"], scope["page_id"], scope["support_revision_id"])
        if not key[0] or type(key[1]) is not int or key[1] < 0 or type(key[2]) is not int or key[2] <= 0:
            raise ValueError("Missing/invalid page-revision identity")
        binding = tuple(scope[field] for field in ("input_sha256", "source_sha256", "policy_version"))
        version = (key, receipt["decision_version"])
        if key in bindings and bindings[key] != binding:
            raise ValueError("Same unit has conflicting source/input/policy bindings")
        if version in versions and versions[version] != receipt["unit_sha256"]:
            raise ValueError("Same unit/version has conflicting content hashes")
        bindings[key], versions[version] = binding, receipt["unit_sha256"]
        if not required_stages:
            raise ValueError("Supply this run's required stages explicitly")
        # Existing inspect_chain fields bind finished stages and persisted artifact/receipt hashes.
        # Example: COMPLETED_PARTIAL with documented 106 pending identities qualifies; NOT_RUN never does.
        chain = completed.get("stage_chain", {})
        stages = chain.get("stages", {})
        finished = {"COMPLETED", "COMPLETED_SEALED", "COMPLETED_PARTIAL", "COMPLETED_SEALED_FIRST_VERSION",
                    "COMPLETED_PRIVATE_COUNTS", "COMPLETED_LOCAL_PARTIAL_READBACK"}
        if (chain.get("status") == "PASS_ONE_UNIT_RECEIPT_CHAIN"
                and (chain.get("page_id"), chain.get("processing_revision_id")) == key[1:]
                and chain.get("receipt_sha256") and chain.get("verified_artifact_sha256")
                and stages.get("handoff", {}).get("version") == receipt["decision_version"]
                and all(stages.get(name, {}).get("status") in finished for name in required_stages)):
            eligible.add(key)
    new_count = len(eligible - set(map(tuple, acknowledged_units)))
    # Example: successful publication advances the caller's baseline; failure leaves these inputs unchanged.
    if final_flush:
        due, reason = True, "final_flush"
    elif elapsed is None:
        raise ValueError("First-checkpoint reference time must be supplied explicitly")
    elif elapsed >= 3600 and approved_geometry_or_correction:
        due, reason = True, "approved_geometry_or_correction"
    elif elapsed >= 3600 and new_count >= 100:
        due, reason = True, "ordinary"
    else:
        due, reason = False, "waiting_for_time_or_unit_count"
    return dict(due=due, reason=reason, elapsed_seconds=elapsed, new_completed_units=new_count)


def self_check():
    start = datetime(2026, 11, 1, 10, tzinfo=timezone.utc)

    # Generated shape matches existing E2 recover output; no real source seal is promoted to completed here.
    def completion(page, revision=10, version="v1", content="a" * 64):
        return dict(status="sealed", receipt=dict(scope=dict(input_sha256="b" * 64, wiki_site="enwiki",
                    page_id=page, support_revision_id=revision, source_sha256="c" * 64, policy_version="test-v1"),
                    decision_version=version, unit_sha256=content),
                    stage_chain=dict(status="PASS_ONE_UNIT_RECEIPT_CHAIN", page_id=page, processing_revision_id=revision,
                        stages=dict(handoff=dict(status="COMPLETED_SEALED_FIRST_VERSION", version=version)),
                        receipt_sha256={"receipt":"d"*64}, verified_artifact_sha256={"artifact":"e"*64}))

    units = [completion(page) for page in range(100)]
    original = deepcopy(units)
    def due(minutes, records=units, **options):
        return checkpoint_decision(start + timedelta(minutes=minutes), start, records, required_stages=("handoff",), **options)["due"]

    # Both thresholds are inclusive. Example: 59m/100 -> wait; 60m/99 -> wait; 60m/100 -> due.
    assert due(59) is False
    assert due(60, units[:99]) is False
    assert due(60) is True
    assert due(120, [units[0]] * 100) is False
    assert due(60, acknowledged_units=[("enwiki", 0, 10)]) is False
    assert due(60, approved_geometry_or_correction=True, records=[]) is True
    assert due(59, approved_geometry_or_correction=True, records=[]) is False
    assert due(0, final_flush=True, records=[]) is True
    assert checkpoint_decision(start, None, [], final_flush=True)["due"] is True
    result = checkpoint_decision(start + timedelta(hours=1), start,
              [completion(1), completion(1, version="v2", content="d" * 64), completion(1, revision=11)], required_stages=("handoff",))
    assert result["new_completed_units"] == 2  # New decision version is not a new page/revision.
    assert checkpoint_decision(start + timedelta(hours=1), start, [dict(status="pending", reason="unsealed")])["new_completed_units"] == 0
    def rejects(operation):
        try:
            operation()
        except ValueError:
            return
        raise AssertionError("Expected explicit invalid-input failure")
    rejects(lambda: checkpoint_decision(start, None, units))
    rejects(lambda: checkpoint_decision(start - timedelta(seconds=1), start, units))
    rejects(lambda: checkpoint_decision(start, start, [completion(1), completion(1, content="e" * 64)]))
    assert units == original  # Deciding/failed publication never mutates acknowledgment or timer state.
    assert due(60) is True and due(60) is True
    assert due(60, acknowledged_units=[("enwiki", page, 10) for page in range(100)]) is False
    output = Path(__file__).parent / "verification.json"
    report = dict(status="PASS", checks=17, code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  boundaries="59m/100 wait;60m/99 wait;60m/100 due;approved geo/correction >=60m;final flush bypass",
                  unit_identity=["wiki_site", "page_id", "support_revision_id"], pure_function=True,
                  publication=False, scheduler=False,
                  initial_reference="owner-approved run_start", admission="all explicit run-required stages finished/persisted; documented unresolved identities allowed")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    self_check()
