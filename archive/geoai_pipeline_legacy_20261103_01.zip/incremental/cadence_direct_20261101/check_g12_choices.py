"""Approved G12 first-clock and completed-stage admission checks."""
import json
import sys
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.dont_write_bytecode = True
from checkpoint_cadence import checkpoint_decision


def check():
    start = datetime(2026, 11, 1, 10, tzinfo=timezone.utc)
    stages = {"exact": dict(status="COMPLETED_PARTIAL", pending_occurrences=106),
              "handoff": dict(status="COMPLETED_SEALED_FIRST_VERSION", version="v1"),
              "counts": dict(status="COMPLETED_PRIVATE_COUNTS", pending_occurrences=106)}
    record = dict(status="sealed", receipt=dict(scope=dict(wiki_site="enwiki", page_id=1, support_revision_id=10,
                  input_sha256="a"*64, source_sha256="b"*64, policy_version="test"), decision_version="v1", unit_sha256="c"*64),
                  stage_chain=dict(status="PASS_ONE_UNIT_RECEIPT_CHAIN", page_id=1, processing_revision_id=10,
                                   stages=stages, receipt_sha256={"receipt.json":"d"*64},
                                   verified_artifact_sha256={"counts.json":"e"*64}))
    required = ("exact", "handoff", "counts")
    def decide(minutes, records=None, **options):
        return checkpoint_decision(start+timedelta(minutes=minutes), None, [record] if records is None else records,
                                   run_start=start, required_stages=required, **options)
    assert decide(60)["elapsed_seconds"] == 3600
    assert decide(59)["due"] is False
    assert decide(60, approved_geometry_or_correction=True)["due"] is True
    assert decide(60)["new_completed_units"] == 1  # Documented pending identities do not veto a finished exact stage.
    units=[]
    for page in range(100):
        copy=deepcopy(record)
        copy["receipt"]["scope"]["page_id"]=copy["stage_chain"]["page_id"]=page
        units.append(copy)
    assert decide(60,units)["due"] is True
    for status in ("NOT_RUN","PENDING","RUNNING","FAILED"):
        invalid=deepcopy(record)
        invalid["stage_chain"]["stages"]["counts"]["status"]=status
        assert decide(60,[invalid])["new_completed_units"] == 0
    for field in ("receipt_sha256","verified_artifact_sha256"):
        invalid=deepcopy(record)
        invalid["stage_chain"][field]={}
        assert decide(60,[invalid])["new_completed_units"] == 0
    invalid=deepcopy(record)
    invalid["stage_chain"]["stages"].pop("counts")
    assert decide(60,[invalid])["new_completed_units"] == 0
    invalid=deepcopy(record)
    invalid["stage_chain"]["stages"]["handoff"]["version"]="other"
    assert decide(60,[invalid])["new_completed_units"] == 0
    later=start+timedelta(minutes=30)
    result=checkpoint_decision(start+timedelta(minutes=60),later,[record],run_start=start,required_stages=required)
    assert result["elapsed_seconds"] == 1800  # Successful checkpoint takes precedence over run start.
    assert decide(60,[record]*100)["new_completed_units"] == 1
    report=dict(status="PASS",checks=15,first_reference="run_start",completion="all caller-required stages completed with persisted/verified receipts",publication=False)
    (Path(__file__).parent/'g12_choices_verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    check()
