# Approved G12 choices implemented

2026-11-01 21:28 UTC: **PASS — 15 new checks plus 17 threshold/receipt checks**. Independent fresh-process schema exercise: four checks passed against an existing real first-unit receipt chain, without rerunning producer stages or admitting a real checkpoint.

The parent's verified owner approval resolves both questions in the earlier REPORT.md:

1. Before the first successful checkpoint, elapsed time starts at the persisted run start.
2. A page/revision counts only after all required stages of its run finished and their outputs were persisted. Documented unresolved identities are allowed; a stage not yet run is not completion.

## Minimal existing-interface binding

checkpoint_decision now accepts keyword-only run_start and required_stages. The existing reference_time is the last successful checkpoint, when present, and takes precedence over run_start. Missing both still raises for ordinary/exception decisions; final flush bypass remains unchanged.

Each candidate completion still carries the existing E2 recover-shaped status/receipt. It additionally supplies stage_chain: the unchanged result shape from orchestration_direct_20261101/check_one_unit.py / inspect_chain, with status PASS_ONE_UNIT_RECEIPT_CHAIN, stages, receipt_sha256 and verified_artifact_sha256. Its page_id/processing_revision_id must match the sealed unit and stages.handoff.version must match the decision_version. Every name in the explicit run-required stage list must have one of the existing finished statuses; absent/unrun/running/failed stages do not qualify. Receipt/artifact hash maps must be nonempty. These are existing verified-chain fields, not new fields in the consumer or shared receipt sources.

The caller must verify source receipts and artifact hashes before supplying the chain; the pure function does not read files or authenticate supplied data. The per-run required stage list is mandatory for sealed candidate records; no model stage is silently omitted by a default. Adding a required but unrun model stage leaves the unit uncounted. This explicit list is the minimal caller wiring still needed, not an unresolved owner policy.

COMPLETED_PARTIAL is accepted as the existing exact-stage status when its pending identities are documented in the verified chain/artifacts. It does not make a pending or NOT_RUN stage complete. A source custody seal without a complete stage_chain is not enough. No real unit was admitted by the test-only schema exercise.

## Examples and verification

- Run starts at 10:00, no successful checkpoint yet: 10:59 waits; at 11:00, 100 eligible new units satisfy ordinary cadence.
- A successful checkpoint at 10:30 becomes the baseline: at 11:00 only 30 minutes have elapsed, regardless of the earlier run start.
- Finished exact/count stages may preserve 106 unresolved identities and still qualify for the defined run. NOT_RUN, PENDING, RUNNING or FAILED required stages, empty persistence maps, missing stages or mismatched decision versions prevent counting.
- The same eligible page/revision replayed 100 times counts once. A required model_not_run entry makes the current real receipt-chain example ineligible.

TDD RED: the new first-clock test failed because run_start did not exist. GREEN: all 15 new and 17 existing checks passed. Fresh-process verification read the existing persisted receipt-chain shape and confirmed run-start baseline, duplicate counting, missing required model exclusion and successful-checkpoint precedence; producer checks were not rerun.

Code SHA256: 52694edec3dbe1e39a44fd8039633ad4a61e11f397d8ee4f8ea54b8591a0e7b6.
Evidence: verification.json, g12_choices_verification.json and g12_independent_verification.json.

No remaining G12 policy question from this increment. Parent/orchestrator still supplies the actual run's required stages, persisted run-start value and verified chain. No live scheduler, publication, VM change, shared-source/plan edit, installation or nested agent. Backup: Unprotected.
