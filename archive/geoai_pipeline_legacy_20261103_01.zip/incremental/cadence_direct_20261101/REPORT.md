Historical initial increment. Both G12 choices are now owner-approved and implemented; see REPORT_G12_APPROVED.md for the current interface, code hash and verification.

# E7 checkpoint cadence — deterministic decision only

2026-11-01 21:23 UTC: **PASS — 17 focused checks and six independent fresh-process checks**.

Owned file: checkpoint_cadence.py. No scheduler, automation, publication, resource/VM action or real completed-unit admission was performed. The function has no file/clock/state side effects; the self-check alone writes verification.json. independent_verification.json records the separate readback.

Read both current GEOAI_DEVELOPMENT_PLAN.md and GEOAI_RUNTIME_BATCH_PLAN.md. Followed the fixed one-hour AND 100-new-completions rule, approved geography/correction one-hour exception, and final flush. The parent's current owner instruction defines the counting unit as page+processing revision; wiki_site distinguishes page IDs across wikis. Earlier G12 text that did not yet equate a batch with this unit is historical for this bounded instructed calculation, not a reason to change thresholds.

## Inputs, results and examples

checkpoint_decision(now, reference_time, completed_units, acknowledged_units=(), approved_geometry_or_correction=False, final_flush=False).

Both times are explicit timezone-aware values. The reference is supplied by the caller from the last successful checkpoint; no wall clock is read. Completed inputs use the existing recover result shape: status=sealed, receipt.scope with source/input/policy/page/revision bindings, decision_version and unit_sha256. These must already be verified AND admitted as qualifying completions upstream. A custody seal alone does not select the completion stage. Explicit pending results are ignored.

- 59 minutes + 100 new units -> waiting.
- 60 minutes + 99 new units -> waiting.
- 60 minutes + 100 new units -> ordinary checkpoint due.
- Approved geography/correction + 60 minutes + zero new units -> due. At 59 minutes it still waits.
- Final flush -> due, even with zero new units or no first reference time.
- The same page/revision supplied 100 times -> one unit. A validated successor decision version on that same page/revision still counts once; another revision counts separately.
- Units already acknowledged by the last successful checkpoint are subtracted. Same unit/version with a conflicting content hash is rejected, as are conflicting source/input/policy bindings. The function does not authenticate a history chain; upstream E2 recovery remains responsible for validation.

Return fields are due, reason, elapsed_seconds and new_completed_units. Due means cadence eligibility only, not delivery approval. A failed actual publication must leave the caller's baseline unchanged. This function never advances timers, counters, history or acknowledgments. All technical/content and other existing delivery requirements remain separate.

TDD evidence: the initial empty implementation failed the first boundary check with missing due output. The completed implementation passed 17 assertions/negative checks, including duplicate and successor receipts, pending exclusion, hash conflict, exact threshold boundaries, final flush, acknowledgment subtraction and unchanged input state. Independent verification checked 3599/3600-second boundaries, 99/100 counts, duplicate counting, approved exception and no-reference final flush.

Code SHA256: 156b6fe464fc40e148a36b547c713ba17307ab486109bf5d980ab43994c9ff00.

## G12 decisions remaining for live wiring

The pure function is complete for explicit inputs. Two exact choices must be supplied before a live first-checkpoint scheduler is wired:

1. Before any successful checkpoint exists, which persisted event/time starts the first one-hour interval?
2. Which existing stage's verified receipt admits a page/revision as completed for cadence, including treatment of still-pending identity decisions?

No default was invented for either. Missing ordinary/exception reference time raises an explicit error. The caller supplies only already admitted completed receipts. These open integration choices do not block the deterministic threshold/count implementation and tests.

No shared plans/code/input/training/publisher artifacts were changed, no agents were spawned and no production durability is claimed. Backup: Unprotected. Parent owns plan updates and live integration.
