"""C2: one immutable source-only unit; independent output folders permit parallel calls."""
import gzip
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(r'D:\Projects\GeoAI-incremental-dev-20261101')
RUN = ROOT / 'orchestration_direct_20261101/cpu_trigram_full_5747_0001'
BUILDER = ROOT / 'runtime_model_inputs_direct_20261101/per_unit_builder_v1/prepare_unit.py'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def prepare_one(index, output):
    # Queue indices select a sealed source unit, never a historical learned decision.
    config = read(RUN / 'run_config_v3.json')
    assert digest(BUILDER) == 'c64f00e576c48921822ec52ee0698811d9e5fa988170f819da53dc7f926ea328'
    assert digest(RUN / 'queue.jsonl.gz') == 'b479639ea25ad27e37e215a1d85238f8b4fa1bff6d01af6ea9f06cead7edc7d2'
    with gzip.open(RUN / 'queue.jsonl.gz', 'rt', encoding='utf8') as stream:
        item = next(json.loads(line) for line in stream if json.loads(line)['order_index'] == index)
    unit = item['source_unit']
    spec = importlib.util.spec_from_file_location('source_only_builder', BUILDER)
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    output = Path(output)
    replay = output.exists()
    before = {str(p.relative_to(output)): digest(p) for p in output.rglob('*') if p.is_file()} if replay else {}
    if not replay:
        builder.prepare_source(unit, output)
    # Readback verifies IDs, authoritative surfaces, group membership and source custody.
    from durable_unit import recover
    from run_first_real_unit import mention_id, processing_record, group_mentions
    receipt = read(output / 'receipt.json')
    handoff = recover(output / 'sealed_pending', receipt['unit_sha256'])['handoff']
    rows = read(output / 'source_members.json')
    expected = {mention_id(unit['input_sha256'], i) for i in unit['expected_row_indices']}
    assert read(output / 'unit.json') == unit == handoff['manifest']
    assert digest(output / 'sealed_pending/source.private.bin') == unit['source_sha256']
    assert len(rows) == len(expected) == unit['retained_count']
    assert {r['occurrence_id'] for r in rows} == expected
    groups = read(output / 'groups.json')
    assert groups == group_mentions([processing_record(r) for r in rows])
    members = [m['occurrence_id'] for g in groups['groups'] for m in g['members']]
    assert len(members) == len(expected) and set(members) == expected
    assert not handoff['decisions'] and len(handoff['pending_evidence']) == len(rows)
    for name, value in receipt['output_sha256'].items():
        assert digest(output / name) == value
    ledger = read(output / 'candidate_inputs_0001/ledger.json')
    assert digest(output / 'candidate_inputs_0001/ledger.json') == read(output / 'candidate_inputs_0001/receipt.json')['ledger_sha256']
    candidates = {c['qid'] for c in ledger['active_cached_candidates']}
    backed = {q for t in ledger['all_raw_targets_with_inclusion_evidence'] if t['included_from_relevant_component'] for q in t['candidate_qids']}
    assert candidates == backed
    hashes = {str(p.relative_to(output)): digest(p) for p in output.rglob('*') if p.is_file()}
    if replay:
        assert before == hashes
    return dict(order_index=index, page_id=unit['page_id'], processing_revision_id=unit['processing_revision_id'],
                occurrences=len(rows), groups=len(groups['groups']), candidates=len(candidates),
                unresolved_targets=len(ledger['unresolved_relevant_targets']), source_sha256=unit['source_sha256'],
                output=str(output), file_sha256=hashes, replay_verified=replay,
                declared_scope_complete=True, candidate_coverage='UNKNOWN_NOT_GLOBAL_NONE',
                alias_policy='PRESERVE_EXISTING_CACHED_METADATA_ALIASES;NO_ENRICHMENT_OR_NETWORK',
                model_calls=0, identity_decisions=0, builder_sha256=digest(BUILDER), config_sha256=digest(RUN / 'run_config_v3.json'))


if __name__ == '__main__':
    print(json.dumps(prepare_one(int(sys.argv[1]), Path(sys.argv[2])), ensure_ascii=False, indent=2))
