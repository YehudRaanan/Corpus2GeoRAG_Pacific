"""Supplement a C2 pool with explicitly supplied same-source evidence, never learned decisions."""
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source_hold_reasons(evidence):
    # Carry recorded source uncertainty, not old model coverage or model outcomes.
    # Example: a known missing candidate in a mixed group remains held under a new scorer.
    return sorted({r for r in evidence.get('scope_hold_reasons', [])
                   if r.startswith(('KNOWN_', 'VERIFIED_OCCURRENCE_IN_UNRESOLVED_SOURCE_TARGET:'))})


def adopt_source_evidence(pool, descriptor):
    value = copy.deepcopy(pool)
    unit = value['source_unit']
    groups = read(Path(value['source_directory']) / 'groups.json')['groups']
    by_id = {m['occurrence_id']: (g, m) for g in groups for m in g['members']}
    pins = dict(value['source_sha256'])
    inventory = {e['id']: e for e in value['entities']}
    exact = {d['occurrence_id']: d for d in value['protected_exact']}
    resolved = set()
    prepared = descriptor.get('prepared_directory')
    if prepared:
        prepared = Path(prepared)
        manifest_path = prepared / 'manifest.json'
        assert sha(manifest_path) == descriptor['manifest_sha256']
        manifest = read(manifest_path)
        pins[str(manifest_path)] = sha(manifest_path)
        scope = manifest['scope']
        assert (scope['page_id'], scope['processing_revision_id'], scope['occurrences']) == (
            unit['page_id'], unit['processing_revision_id'], len(by_id))
        declared = manifest['output_sha256']
        for name in ['all_groups_and_members.json', 'exact_decision_patch.json', 'target_resolution_evidence.json']:
            path = prepared / name
            if name in declared:
                assert sha(path) == declared[name]
            else:
                assert name == 'all_groups_and_members.json'
            pins[str(path)] = sha(path)
        assert read(prepared / 'all_groups_and_members.json')['groups'] == groups
        for path, digest in manifest['protected_source_sha256'].items():
            # Verify the original sealed source, not formatter/model output files.
            if Path(path).name in ('unit.json', 'groups.json', 'source_members.json', 'seal.json', 'source.private.bin'):
                assert sha(path) == digest
                pins[path] = digest
                if Path(path).name == 'groups.json':
                    assert read(path)['groups'] == groups
        # Reuse saved public title/QID assertions only when they belong to this exact source.
        # Example: an already resolved linked battalion restores its missing candidate.
        for ev in read(prepared / 'target_resolution_evidence.json'):
            if not ev.get('resolved'):
                continue
            support = ev['source_component_evidence']
            assert support and all(t['included_from_relevant_component'] and t['target_title'] == ev['source_target'] for t in support)
            response = prepared / 'public_target_resolution.json'
            assert sha(response) == ev['response_sha256']
            pins[str(response)] = sha(response)
            qid = ev['qid']
            pages = read(response)['query']['pages'].values()
            assert any(p.get('pageprops', {}).get('wikibase_item') == qid and p['title'] == ev['current_title'] for p in pages)
            resolved.add(ev['source_target'])
            if qid not in inventory:
                inventory[qid] = dict(id=qid, name=ev['current_title'], aliases=[], source_evidence=copy.deepcopy(ev))
        # Preserve verified exact records verbatim; never copy ordinary model decisions.
        for decision in read(prepared / 'exact_decision_patch.json')['decisions']:
            oid = decision['occurrence_id']
            assert oid in by_id and decision['evidence']['method'] == 'APPROVED_UNIQUE_LITERAL_EXACT'
            ev = decision['evidence']; group, member = by_id[oid]
            assert (ev['page_id'], ev['processing_revision_id'], ev['source_sha256']) == (
                unit['page_id'], unit['processing_revision_id'], unit['source_sha256'])
            assert ev['source_seal_sha256'] in {digest for path,digest in pins.items() if Path(path).name == 'seal.json'}
            match = ev.get('match', ev)
            assert match['group_id'] == group['group_id']
            assert match.get('name', match.get('raw_name')) == group['key']['word']
            assert decision['qid'] in inventory or decision['qid'] in {e['qid'] for e in value['deferred_routes']['event_candidates']}
            if oid in exact:
                assert exact[oid]['qid'] == decision['qid']
            exact[oid] = copy.deepcopy(decision)
    holds = copy.deepcopy(value['occurrence_holds'])
    # Resolved source targets clear only their corresponding obsolete gap reason.
    for oid in list(holds):
        holds[oid] = [r for r in holds[oid] if not any(r == 'VERIFIED_OCCURRENCE_IN_UNRESOLVED_SOURCE_TARGET:' + t for t in resolved)]
        if not holds[oid]:
            del holds[oid]
    if descriptor.get('source_hold_file'):
        path = Path(descriptor['source_hold_file']); receipt_path = Path(descriptor['source_hold_receipt'])
        assert sha(receipt_path) == descriptor['source_hold_receipt_sha256']
        receipt = read(receipt_path)
        assert sha(path) == receipt['evidence_sha256']
        group_path = Path(descriptor['source_hold_groups'])
        assert sha(group_path) == receipt['protected_source_sha256'][str(group_path)]
        assert read(group_path)['groups'] == groups
        pins.update({str(path): sha(path), str(receipt_path): sha(receipt_path), str(group_path): sha(group_path)})
        for record in read(path):
            reasons = source_hold_reasons(record['evidence'])
            if not reasons:
                continue
            oid = record['occurrence_id']; group, member = by_id[oid]; ev = record['evidence']
            assert (ev['page_id'], ev['processing_revision_id'], ev['group_id']) == (
                unit['page_id'], unit['processing_revision_id'], group['group_id'])
            assert set(ev['source_occurrence_ids']) == {m['occurrence_id'] for m in group['members']}
            holds[oid] = sorted(set(holds.get(oid, []) + reasons))
    for row in value['all_occurrence_mapping']:
        oid = row['occurrence_id']
        if oid in exact:
            row.update(route='PROTECTED_EXACT', protected_exact_qid=exact[oid]['qid'])
    ordinary_ids = {m['group_id'] for m in value['all_occurrence_mapping'] if m['route'] == 'ORDINARY_MODEL_INPUT'}
    value.update(groups=[g for g in value['groups'] if g['id'] in ordinary_ids], entities=sorted(inventory.values(), key=lambda e:e['id']),
                 protected_exact=list(exact.values()), occurrence_holds=holds, source_sha256=pins,
                 unresolved_targets=[t for t in value['unresolved_targets'] if t not in resolved],
                 source_evidence_descriptor=copy.deepcopy(descriptor), active_promotion=False)
    value['route_counts'] = dict(Counter(m['route'] for m in value['all_occurrence_mapping']))
    return value
