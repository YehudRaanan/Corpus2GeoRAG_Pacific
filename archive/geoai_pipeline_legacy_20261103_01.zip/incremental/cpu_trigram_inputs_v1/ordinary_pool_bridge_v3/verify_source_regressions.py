"""Regression checks for the source-evidence bridge; no decisions persisted."""
import copy
import sys
from pathlib import Path
import adopt_source_evidence as a


def check(pools, core):
    all_ids = []
    totals = []
    # Source-hold extraction ignores old model conclusions and arbitrary model holds.
    ev = dict(scope_hold_reasons=['KNOWN_FIXTURE_SOURCE_GAP', 'OLD_MODEL_NOT_RUN'])
    assert a.source_hold_reasons(ev) == ['KNOWN_FIXTURE_SOURCE_GAP']
    assert a.source_hold_reasons(dict(ev, status='IDENTITY', qid='Q123')) == a.source_hold_reasons(ev)
    for pool in pools:
        before = copy.deepcopy(pool)
        for path, digest in pool['source_sha256'].items():
            assert a.sha(path) == digest
        proposed = core.decide_pool(pool['groups'], pool['entities'], complete=pool['complete'])
        result = core.merge_occurrences(pool['all_occurrence_mapping'], proposed['groups'], pool['protected_exact'], pool['occurrence_holds'])
        rows = result['results']
        ids = [r['occurrence_id'] for r in rows]
        assert len(ids) == len(set(ids)) == pool['source_unit']['retained_count']
        assert set(ids) == {r['occurrence_id'] for r in pool['all_occurrence_mapping']}
        exact = {r['occurrence_id']: r for r in pool['protected_exact']}
        for row in rows:
            oid = row['occurrence_id']
            if oid in exact:
                assert row['qid'] == exact[oid]['qid'] and row['evidence'] == exact[oid]['evidence']
            elif oid in pool['occurrence_holds']:
                assert row['status'] == 'PENDING'
        assert pool == before
        all_ids.extend(ids)
        totals.append(dict(page_id=pool['source_unit']['page_id'], occurrences=len(ids), protected_exact=len(exact),
                           ordinary_qids=len(pool['entities']), held_occurrences=len(pool['occurrence_holds'])))
    assert len(all_ids) == len(set(all_ids)) == 347
    first = pools[0]
    groups = a.read(Path(first['source_directory']) / 'groups.json')['groups']
    japan_ids = {m['occurrence_id'] for g in groups if g['key']['word'] == 'Japan' for m in g['members']}
    assert len(japan_ids) == 14 and japan_ids <= set(first['occurrence_holds'])
    merged = core.merge_occurrences(first['all_occurrence_mapping'], core.decide_pool(first['groups'], first['entities'], complete=True)['groups'], first['protected_exact'], first['occurrence_holds'])
    assert all(r['status'] == 'PENDING' for r in merged['results'] if r['occurrence_id'] in japan_ids)
    third = pools[2]
    assert len(third['protected_exact']) == 25
    battalion = [d for d in third['protected_exact'] if d['qid'] == 'Q107223385']
    assert len(battalion) == 1
    assert battalion[0]['evidence']['match']['name'] == '51st Defense Battalion'
    descriptor = third['source_evidence_descriptor']
    original = a.read(Path(descriptor['prepared_directory']) / 'exact_decision_patch.json')['decisions']
    assert {d['occurrence_id']:d for d in original} == {d['occurrence_id']:d for d in third['protected_exact']}
    # Wrong same-size page evidence must fail rather than silently transplant evidence.
    try:
        a.adopt_source_evidence(first, descriptor)
    except AssertionError:
        pass
    else:
        raise AssertionError('Cross-source transplant accepted')
    return dict(status='PASS_SOURCE_EVIDENCE_REGRESSIONS', occurrences=347, distinct_membership=True,
                japan_14_held_pending=True, battalion_verified_exact_restored=True, third_exact_records_verbatim=25,
                cross_source_transplant_rejected=True, old_model_conclusions_ignored=True, units=totals,
                canonical_state_written=False, active_promotion=False, thresholds_changed=False)
