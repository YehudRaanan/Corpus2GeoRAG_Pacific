"""C2 source-only bridge to E2 decide_pool; no model, fetch or canonical writes."""
import hashlib
import importlib.util
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(r'D:\Projects\GeoAI-incremental-dev-20261101')
BUILDER = ROOT / 'runtime_model_inputs_direct_20261101/per_unit_builder_v1/prepare_unit.py'
EVENT_QIDS = {'Q362', 'Q52418', 'Q713516', 'Q1645012'}


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def route_group(group, exact, event_names):
    # Exact is protected first; dates and known Event names keep separate frontiers.
    # Example: World War II is Event evidence, not an ordinary lexical identity.
    if group['group_id'] in exact:
        return 'PROTECTED_EXACT'
    if group['key']['entity_group'] == 'DATE':
        return 'DATE_DEFERRED'
    if group['key']['word'].casefold() in event_names:
        return 'EVENT_SEPARATE'
    # This legacy spelling is required by E2 merge_occurrences; no model is invoked.
    return 'ORDINARY_MODEL_INPUT'


def prepare_pool(source):
    source = Path(source)
    receipt = read(source / 'receipt.json')
    for name, digest in receipt['output_sha256'].items():
        assert sha(source / name) == digest
    assert sha(BUILDER) == 'c64f00e576c48921822ec52ee0698811d9e5fa988170f819da53dc7f926ea328'
    spec = importlib.util.spec_from_file_location('source_builder', BUILDER)
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    from GG_Data.entity_resolution.hundred_page_pilot.filter_qid_inventory import _types
    from GG_Data.entity_resolution.hundred_page_pilot.match_exact import exact_pairs
    unit = read(source / 'unit.json')
    groups = read(source / 'groups.json')['groups']
    ledger = read(source / 'candidate_inputs_0001/ledger.json')
    assert sha(source / 'candidate_inputs_0001/ledger.json') == read(source / 'candidate_inputs_0001/receipt.json')['ledger_sha256']
    metadata = builder.local_metadata()
    entities = []
    for candidate in ledger['active_cached_candidates']:
        qid = candidate['qid']
        evidence = candidate['cached_metadata']
        labels = sorted({m['assertion']['label'] for m in evidence if m['assertion'].get('label')})
        if not labels:
            labels = sorted({a['assertion']['canonical_target_title'] for t in ledger['all_raw_targets_with_inclusion_evidence']
                             if t['included_from_relevant_component'] and qid in t['candidate_qids']
                             for a in t['cached_title_assertions'] if a['assertion'].get('qid') == qid and a['assertion'].get('canonical_target_title')})
        # A source-backed title is retained when a cached entity label is missing.
        if not labels:
            labels = sorted({t['target_title'] for t in ledger['all_raw_targets_with_inclusion_evidence']
                             if t['included_from_relevant_component'] and qid in t['candidate_qids']})
        assert labels
        aliases = {a for m in evidence for a in (m['assertion'].get('aliases') or []) if a}
        native = sorted({p for m in evidence for p in m['assertion'].get('native_types', [])})
        entities.append(dict(qid=qid, label=labels[0], aliases=sorted(aliases | set(labels[1:])),
                             native_types=native, metadata_evidence=evidence, page_id=unit['page_id'],
                             revision_id=unit['processing_revision_id'], qid_source_status='KEEP', **_types(native, metadata)))
    flat = [dict(id=g['group_id'], page_id=unit['page_id'], revision_id=unit['processing_revision_id'],
                 name=g['key']['word'], type=g['key']['entity_group'],
                 repaired_source_row_indices=[m['source_row_index'] for m in g['members'] if m.get('word_original', m['word']) != m['word']],
                 source_review_statuses=['MISC_POLICY_PENDING'] if g['key']['entity_group'] == 'MISC' else []) for g in groups]
    # Reuse unique literal-label exact, never alias-exact or a new type rule.
    exact = {x['group_id']: x for x in exact_pairs(flat, entities)}
    event = [e for e in entities if e['qid'] in EVENT_QIDS]
    event_names = {n.casefold() for e in event for n in [e['label']] + e['aliases']}
    routes = {g['group_id']: route_group(g, exact, event_names) for g in groups}
    mapping, protected, holds = [], [], {}
    for group in groups:
        gid = group['group_id']
        for member in group['members']:
            oid = member['occurrence_id']
            mapping.append(dict(occurrence_id=oid, source_row_index=member['source_row_index'], group_id=gid,
                                protected_exact_qid=exact[gid]['qid'] if gid in exact else None,
                                route=routes[gid], page_id=unit['page_id'], processing_revision_id=unit['processing_revision_id']))
            if gid in exact:
                protected.append(dict(occurrence_id=oid, qid=exact[gid]['qid'], evidence=dict(
                    method='APPROVED_UNIQUE_LITERAL_EXACT', match=exact[gid], page_id=unit['page_id'],
                    processing_revision_id=unit['processing_revision_id'], source_sha256=unit['source_sha256'],
                    source_seal_sha256=sha(source / 'sealed_pending/seal.json'), canonical_state_not_written=True)))
            # Preserve C1's occurrence-specific holds; no global missing-data veto.
            why = []
            if routes[gid] == 'ORDINARY_MODEL_INPUT' and member.get('processing_surface_status') not in (
                    'VERIFIED_ORIGINAL_SPAN_ONLY', 'VERIFIED_EXPANDED_SOURCE_ANCHOR'):
                why.append('UNAPPROVED_SOURCE_CONTEXT_SURFACE')
            for link in re.finditer(r'\[\[([^\]\n]+)\]\]', member['Text']):
                target = link.group(1).split('|')[0].split('#')[0].strip()
                if target in ledger['unresolved_relevant_targets'] and link.start() <= member['start'] < member['end'] <= link.end():
                    why.append('VERIFIED_OCCURRENCE_IN_UNRESOLVED_SOURCE_TARGET:' + target)
            if why:
                holds[oid] = sorted(set(why))
    ids = [m['occurrence_id'] for m in mapping]
    assert len(ids) == len(set(ids)) == unit['retained_count']
    assert set(ids) == {m['occurrence_id'] for m in read(source / 'source_members.json')}
    ordinary = [dict(id=g['group_id'], name=g['key']['word']) for g in groups if routes[g['group_id']] == 'ORDINARY_MODEL_INPUT']
    wiki = [dict(id=e['qid'], name=e['label'], aliases=e['aliases']) for e in entities if e['qid'] not in EVENT_QIDS]
    return dict(status='C2_PURE_POOL_INPUT_ONLY', source_directory=str(source), source_unit=unit,
                groups=ordinary, entities=wiki, complete=True,
                completeness_scope='ENTIRE_DECLARED_ORDINARY_POOL_ONLY;NOT_GLOBAL_SOURCE_COVERAGE',
                all_occurrence_mapping=mapping, protected_exact=protected, occurrence_holds=holds,
                deferred_routes=dict(event_candidates=event, groups=[dict(group_id=g['group_id'], route=routes[g['group_id']],
                    name=g['key']['word'], occurrence_ids=[m['occurrence_id'] for m in g['members']]) for g in groups if routes[g['group_id']] not in ('ORDINARY_MODEL_INPUT', 'PROTECTED_EXACT')]),
                unresolved_targets=ledger['unresolved_relevant_targets'], global_candidate_coverage='UNKNOWN',
                event_routing_completeness='KNOWN_SUPPLIED_QID_ROUTES_ONLY;NOT_CERTIFIED_COMPLETE',
                source_sha256={str(p):sha(p) for p in [source/'receipt.json', source/'groups.json', source/'candidate_inputs_0001/ledger.json', BUILDER]},
                alias_policy='EXISTING_ATTRIBUTED_CACHED_ALIASES_ONLY_NO_ENRICHMENT',
                route_counts=dict(Counter(m['route'] for m in mapping)), model_calls=0, canonical_state_written=False)


def self_check():
    def group(name, typ='MISC', gid='g'):
        return dict(group_id=gid, key=dict(word=name, entity_group=typ))
    assert route_group(group('1945', 'DATE'), {}, set()) == 'DATE_DEFERRED'
    assert route_group(group('World War II'), {}, {'world war ii'}) == 'EVENT_SEPARATE'
    assert route_group(group('USAAF'), {}, set()) == 'ORDINARY_MODEL_INPUT'
    assert route_group(group('World War II'), {'g': {}}, {'world war ii'}) == 'PROTECTED_EXACT'


if __name__ == '__main__':
    self_check()
    print('4 route checks passed')
