# Nagoya existing selection verified; Oahu gap identified

PASS: Nagoya Q11751 has an existing source-supported Polygon, OSM relation:4576938, native version 13, timestamp 2021-04-11 08:56:32. Valid, nonempty, EPSG:4326; handoff shape WKB bytes exactly match both the raw OSM source geometry and the previously selected GeoParquet row. osm_bigquery.project confirms native object/QID with no conversion. Bound to Q11751::LOC, two accepted occurrences, page 48975579 / processing revision 1375061414 / first-unit-exact-v1.

No new ranking or coordinate winner is needed to hand off that recorded Polygon. Both original P625 statements remain intact:

| Statement | Longitude | Latitude | Precision | Rank | Imported-from reference |
|---|---:|---:|---:|---|---|
| q11751$E340CD81-5659-4DB1-B45B-092CA5900534 | 136.9063888888889 | 35.18138888888889 | 0.0002777777777777778 | normal | P143 Q177837 |
| Q11751$3C591D73-BEAF-4433-B085-5A48E196E824 | 136.90641 | 35.18147 | 0.010990834523045 | normal | P143 Q837615 |

Geodesic separation is 9.201943310815608 metres (WGS84 Geod). The verified native Polygon covers BOTH source points. Each statement has one preserved reference and no supplied temporal qualifiers. No averaging, precision repair, new proximity threshold, identity change or P625 preference was introduced. Record revision 2381979895 / modified 2025-07-20T10:30:11Z and source snapshot 2026-10-18T18:45:19.304197+00:00 remain separate from the unit processing revision and OSM version. Useful coverage is retained while enrichment stays pending; no WWII boundary is asserted.

Deliverables under geometry_direct_20261101/nagoya_handoff_0001:

- handoff.json: accepted-unit/source binding, original selection, both coordinate statements, distance/containment observations, Oahu summary-gap detail and one Geography fragment.
- model/geometries.parquet and model/geography.json.gz: ONE verified Q11751 source-shape row and its matching existing-contract pointer. Publisher must merge this addition with Tokyo/Mariana Islands/Saipan and regenerate the combined checksum/pointers; this is not a replacement full geometry view.
- private/: exact raw OSM row and original native/selection evidence.
- verification.json: pinned source/output hashes. Handoff SHA256 6b176601a22afd6c7adf718e80ef62231a89f9f1115f2eb148906ad2580036c3; verification SHA256 e82a6b24b89c5df9f8d77efc580ff50b6b0cec3a274f0f2ad57f1519f3195ca2.

Source cache is the same existing matching_penalty_poc_20261023/geography_retrieval/sources/osm_bigquery_cache/71bc6f34949a6bad69666609eb05c781cd4267786dce0b840b0a1e29755eae0e.json.gz and model_geography/geometries.parquet, recorded in ACTUAL_UNIT_GEOMETRY_INPUTS.json. No new acquisition occurred.

Consumer check: the copied ten-node graph remains byte-identical; existing load_geometries(required_crs='EPSG:4326') and GraphStore load exactly Q11751::LOC's geometry with zero edges in this isolated probe. Normal run and fresh-process --verify passed. A further independent process checked both exact source statements, recomputed distance, verified containment observations, and re-read/hash-checked the original Oahu summary.

## Q131347: exact bounded-lookup target

Cached label is Oahu; English Oahu, Japanese オアフ島; enwiki title Oʻahu. Existing aliases include O'ahu and Oʻahu. Summary item revision 2377713161, modified 2025-07-10T22:41:17Z, reference_source BIGQUERY, missing=false. Source C:/Users/User/.cache/geoai_bigquery_20261018/entity_metadata.json.gz, SHA256 0032e97cf9af90f56dae231071dbdd2bed8d9c379708a029c4a53b407a9378f8.

Available keys are id, label, labels, aliases, sitelinks, direct_types, parents, revision, modified, missing, reference_source. Missing summary keys: claims, P625, P276, P131, P17, P402, P3896, P1566, geometry, geometry_ref, osm_version and osm_timestamp. parents=[] and missing=false do not establish native-claim absence or geometry availability. The old full-record dictionary and historical Geography have no Q131347 entry in the inspected scope; earlier archive-prefix scan was not an exhaustive native-record lookup.

Smallest next step is an exact Q131347 native-item lookup in the existing local cache/archive, retaining record/revision/provenance and reporting source fields verbatim. Do not use an alias/name match or infer coordinates from Oahu's label. No external call is authorized by this report.

Only new owned files were written. No shared publisher/Tokyo files changed, new LOC/QID, external request, publication, paid work or nested session. No unresolved policy choice blocks the verified Nagoya Polygon. The remaining source-availability gap concerns Q131347. Backup: Unprotected.
