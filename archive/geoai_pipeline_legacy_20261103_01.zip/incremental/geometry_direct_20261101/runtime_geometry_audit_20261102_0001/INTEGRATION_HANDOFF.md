# READY: minimal active LOC integration handoff

Manifest: INTEGRATION_HANDOFF_0001.json
SHA256: 6c90a42677cea33ff41141cd96266a9dfba666a898d87fd437da7639061fde52
Callable file: active_loc_gate.py
SHA256: 8a329376f4dee33d7e8d8ab17dae37052fd646080d4cc4e868c73f579f763839

## Inputs and outputs

active_loc_gate(geometry, entity_type='LOC'|'location', crs='EPSG:4326') returns mask_result, allow_active_LOC, pending, retain_source and mask version/hash. LOC inside/boundary/intersection -> True; outside -> False; missing -> False plus pending=True. Non-LOC returns allow_active_LOC=None: preserve its prior routing, do not cast None to exclusion. The wrapper normalizes the consumer's location spelling to internal LOC. Source/provenance stays unchanged.

native_point_fallback(qid, original_P625_statements) returns (Point_or_None, full_candidates, unusable_statements). A single valid nondeprecated native Earth statement supplies the original unchanged Point; no polygon is required. None WITH candidates is position selection pending, NOT missing location. candidate_scope(candidates) computes scope without choosing a coordinate. All seven actual multi-point LOCs have INCLUDE for every candidate; do not turn them into outside/missing or choose a new arbitrary winner.

Verified source feed: orchestration_direct_20261101/geometry_backlog_current_v2.json, whose exact hash and native_registry descriptor are in the manifest. All 180 P625 statement lists/item revisions were independently matched to that pinned registry. Feed fields: qid, native_revision, native_P625_statements, source. Complete native records remain at native_registry.selected_references[qid].envelope.entity. Existing five verified shapes come from the pinned consumer/model/geometries.parquet descriptor in source_feed. Preserve native revisions separately from processing revisions.

Order: reuse already verified same-identity geometry; validate locally cached same-target source shapes when available/appropriate; otherwise native Point fallback is usable now. Apply the approved mask to resolved LOC geometry, then project active LOC nodes AND their active connections. Retain excluded/unknown records and prior generations privately. Rebuild complete active Geography/GeoParquet and both prior/root scope maps. No Event geography gate or new identity decision.

## Small actual-unit example

Pearl Harbor Q127091::LOC appears in page 64057715 / processing revision 1345484672. Cached native revision 2379060080 has one P625 at longitude -157.953611, latitude 21.361944. The unchanged-source fallback returns a Point; active_loc_gate(..., entity_type='location') returns INCLUDE/True. The preserved OSM relation:7378187 Polygon was separately source-QID/geometry validated and also intersects the mask. Full evidence/source hashes are in small_actual_unit_example. No network is needed for this first fix.

## The forty outside-point cases

Four cached polygons, each source-object/QID matched, exact shape checked, valid EPSG:4326 and still EXCLUDE:

- Q1223 Washington: OHM relation:2692780, Polygon.
- Q241 Cuba: OHM relation:2861549, MultiPolygon.
- Q796 Iraq: OHM relation:2839205, Polygon.
- Q99 California: OHM relation:2692755, MultiPolygon.

Q28513 Austria-Hungary has a cached Point, also outside. The manifest explicitly lists the other 35 QIDs/labels with no selected shape in this known historical cache. Other raw/provider area lookups are unrun, not proven absent. Known source Points are outside now; later validated intersecting source area may legitimately revise scope. Do not substitute a global bbox or invent an area.

Twenty LOCs lack native P625. One, Q184425 Pacific War, has an UNVERIFIED historical cached selection (OSM way:1225967145): availability is recorded, not automatically accepted as source-correct geometry. The other 19 have no selected shape in that cache. Asiatic-Pacific Theater Q12296445 lacks both native P625 and selected geometry here; retain pending, outside active graph under the new owner rule.

Readiness: five existing shapes +108 unambiguous inside Points =113 immediately resolved LOC placements; seven more are mask-eligible with multiple source positions retained. Forty single Points are outside; twenty lack P625. Source/area followup can change those latter availability/scope results. Current unfiltered consumer still has 180 LOC/175 null geometries; this handoff does NOT claim it was already corrected.

Nine active-gate tests, two actual single-Point examples, seven multi-candidate scope checks and source-exact polygon checks passed. Source claim lists remain unchanged; no shared INTEGRATION/publisher file or graph state was edited. INTEGRATION owns wiring and refreshed receipts. No external call or blocker. Backup: Unprotected.
