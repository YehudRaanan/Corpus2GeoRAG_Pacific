"""Owner-approved active LOC gate and native single-Point fallback; no integration writes."""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [r'D:\Projects\GeoAI',str(ROOT/'geometry_direct_20261101/pacific_loc_mask_v1')]
from GG_Data.pipeline.geography_coordinate_sample import coordinate,fallback_point
from pacific_loc_mask import classify_loc,MASK_VERSION,MASK_SHA256


def active_loc_gate(geometry, *, entity_type='LOC', crs='EPSG:4326'):
    mask_type='LOC' if entity_type in ('LOC','location') else entity_type
    result=classify_loc(geometry,entity_type=mask_type,crs=crs)
    return dict(mask_result=result,allow_active_LOC=(result=='INCLUDE') if mask_type=='LOC' else None,
                retain_source=True,pending=(result=='UNKNOWN'),mask_version=MASK_VERSION,mask_sha256=MASK_SHA256)


def native_point_fallback(qid,statements):
    """Single-statement placement only; None plus candidates means selection pending, NOT missing location.

    Check candidate_scope() before treating multi-point evidence as UNKNOWN.
    """
    candidates=[];unusable=[]
    for statement in statements:
        if statement.get('rank')=='deprecated':
            unusable.append(dict(statement=statement,reason='DEPRECATED'));continue
        try:evidence=coordinate(dict(id=qid,claims={'P625':[statement]}))
        except (ValueError,KeyError,TypeError) as error:
            unusable.append(dict(statement=statement,reason=str(error)));continue
        if evidence is not None:candidates.append(evidence)
    if len(candidates)==1:
        return fallback_point(candidates[0],has_geometry=False),candidates,unusable
    return None,candidates,unusable


def candidate_scope(candidates):
    """Determine scope without choosing a position; keep all source evidence."""
    from shapely.geometry import Point
    outcomes=[classify_loc(Point(*c['xy']),entity_type='LOC') for c in candidates]
    values=set(outcomes)
    result='INCLUDE' if values=={'INCLUDE'} else 'EXCLUDE' if values=={'EXCLUDE'} else 'UNKNOWN'
    return dict(mask_result=result,allow_active_LOC=(result=='INCLUDE'),source_candidate_results=outcomes,
                position_selection_required=len(candidates)>1,source_missing=not candidates)
