# Approved Pacific LOC mask: ready for parent integration handoff

Version: pacific-loc-mask-20261102-v1.
GeoJSON: pacific_loc_mask_v1.geojson.
SHA256: 8bb675894f9eca241517ba582960afe99e0be034e607906c3a77de1fee17f85f.
Callable: pacific_loc_mask.py::classify_loc(geometry, *, entity_type='LOC', crs='EPSG:4326').
Code SHA256: 14c48cc8d95a5835bd6abd879783a7c85310706fbe54498a0dfe3ed00dee9ea6.

The GeoJSON contains the exact owner-approved dateline-safe MultiPolygon coordinates. In continuous longitudes it equals the union of [95,230] x [-55,70] and [65,95] x [-15,55]. It does not use the global bounding rectangle as the geographic test. The module checks the versioned GeoJSON hash before loading.

Return values:

- INCLUDE: source Point is inside/on the boundary, or existing source geometry intersects/touches either mask component.
- EXCLUDE: a valid source geometry is disjoint from the actual mask.
- UNKNOWN: geometry is missing or empty. This is not an exclusion.
- NOT_APPLICABLE: entity_type is anything other than LOC. Event scope, persons and organisations are not filtered.

Input is existing validated source geometry in normalized EPSG:4326 coordinates, including existing split dateline shapes. Unsupported CRS, invalid geometry or out-of-domain coordinates raise ValueError rather than silently excluding or repairing the source. No reprojection, buffer, polygon fabrication, geometry replacement, new identity or source/provenance mutation occurs. The classifier returns only its internal filter decision; it adds no consumer JSON fields. The caller keeps the original geometry and source record.

Example use, after importing this owned module:

```python
from pacific_loc_mask import classify_loc, MASK_VERSION, MASK_SHA256
result = classify_loc(existing_geometry, entity_type=entity_type, crs='EPSG:4326')
# Keep source geometry/provenance intact. UNKNOWN is pending, never excluded.
```

Checks passed: 34 named spatial/missing cases, three non-LOC bypass cases, unsupported CRS rejection and unchanged source geometry/provenance. Tokyo, Oahu, Midway, both Aleutian sides, India and NZ are included; Europe and San Francisco excluded. Boundary points, crossing/touching polygons, +/-180, split dateline polygons and missing geometry are covered. The representative test coordinates are fixtures, not new geographic acquisitions.

TDD RED: placeholder UNKNOWN failed Tokyo's expected INCLUDE. GREEN: the minimal MultiPolygon intersection filter passed. Independent fresh-process readback verified exact approved coordinate arrays, GeoJSON/code hashes, equality to the continuous-longitude rectangle union, all four dateline corner cases and four extension corners. Europe/San Francisco false positives from a naive global bbox are explicitly rejected. Evidence: verification.json and independent_readback.json.

Only this owned pacific_loc_mask_v1 directory was created/modified. No integration state, accepted decision, publisher, shared plan, source artifact or Event scope changed; no external call, paid work or nested session. This is the handoff for parent coordination BEFORE integration-state changes. No blocker/denied/uncertain action. Backup: Unprotected.
