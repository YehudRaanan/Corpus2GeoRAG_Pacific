"""Owner-approved broad Pacific LOC mask; source geometry is never changed."""
import hashlib
import json
from copy import deepcopy
from pathlib import Path

from pyproj import CRS
from shapely.geometry import Point, MultiPolygon, box, shape

MASK_PATH = Path(__file__).with_name('pacific_loc_mask_v1.geojson')
MASK_VERSION = 'pacific-loc-mask-20261102-v1'
MASK_SHA256 = '8bb675894f9eca241517ba582960afe99e0be034e607906c3a77de1fee17f85f'
if hashlib.sha256(MASK_PATH.read_bytes()).hexdigest() != MASK_SHA256:
    raise ValueError('Versioned mask bytes differ from pinned hash')
_document = json.loads(MASK_PATH.read_bytes())
assert _document['properties']['version'] == MASK_VERSION
_MASK = shape(_document['geometry'])
assert _MASK.is_valid and not _MASK.is_empty and _MASK.geom_type == 'MultiPolygon'


def classify_loc(geometry, *, entity_type='LOC', crs='EPSG:4326'):
    """Return INCLUDE/EXCLUDE/UNKNOWN; non-LOC returns NOT_APPLICABLE.

    Input is an existing validated WGS84 source geometry, including split
    dateline shapes. Do not use this LOC filter to define Event scope.
    Intersection includes source polygons crossing or touching the boundary.
    """
    if entity_type != 'LOC':
        return 'NOT_APPLICABLE'
    if geometry is None:
        return 'UNKNOWN'
    if CRS(crs) != CRS.from_epsg(4326):
        raise ValueError('LOC mask requires EPSG:4326; source is never reprojected')
    if geometry.is_empty:
        return 'UNKNOWN'
    if not geometry.is_valid:
        raise ValueError('Invalid source geometry; do not repair or invent an area')
    west,south,east,north = geometry.bounds
    if west < -180 or east > 180 or south < -90 or north > 90:
        raise ValueError('Source geometry needs normalized WGS84 coordinates')
    return 'INCLUDE' if _MASK.intersects(geometry) else 'EXCLUDE'


def self_check():
    # Representative fixtures only; these are not new geographic acquisitions.
    cases = [
        ('Tokyo',Point(139.69166666666666,35.68944444444445),'INCLUDE'),
        ('Oahu',Point(-157.965,21.485),'INCLUDE'),
        ('Midway',Point(-177.376,28.207),'INCLUDE'),
        ('Aleutians_east',Point(-166.5,53.9),'INCLUDE'),
        ('Aleutians_west',Point(179.5,52),'INCLUDE'),
        ('India_extension',Point(77.2,28.6),'INCLUDE'),
        ('NZ',Point(174.8,-41.3),'INCLUDE'),
        ('NZ_dateline_side',Point(-176.5,-44),'INCLUDE'),
        ('Europe',Point(13.4,52.5),'EXCLUDE'),
        ('San_Francisco',Point(-122.42,37.77),'EXCLUDE'),
        ('east_boundary',Point(-130,40),'INCLUDE'),
        ('just_east_outside',Point(-129.999,40),'EXCLUDE'),
        ('north_boundary',Point(170,70),'INCLUDE'),
        ('north_outside',Point(170,70.001),'EXCLUDE'),
        ('south_boundary',Point(170,-55),'INCLUDE'),
        ('south_outside',Point(170,-55.001),'EXCLUDE'),
        ('extension_west_boundary',Point(65,0),'INCLUDE'),
        ('extension_west_outside',Point(64.999,0),'EXCLUDE'),
        ('extension_south_boundary',Point(80,-15),'INCLUDE'),
        ('extension_south_outside',Point(80,-15.001),'EXCLUDE'),
        ('extension_north_boundary',Point(80,55),'INCLUDE'),
        ('extension_north_outside',Point(80,55.001),'EXCLUDE'),
        ('main_west_south_corner',Point(95,-55),'INCLUDE'),
        ('main_west_south_outside',Point(94.999,-30),'EXCLUDE'),
        ('dateline_positive',Point(180,10),'INCLUDE'),
        ('dateline_negative',Point(-180,10),'INCLUDE'),
        ('dateline_north_corner',Point(-180,70),'INCLUDE'),
        ('dateline_north_outside',Point(180,70.001),'EXCLUDE'),
        ('crosses_east_boundary',box(-131,35,-127,38),'INCLUDE'),
        ('touches_east_boundary',box(-130,35,-129,38),'INCLUDE'),
        ('outside_polygon',box(-123,37,-122,38),'EXCLUDE'),
        ('split_dateline_polygon',MultiPolygon([box(179,10,180,12),box(-180,10,-179,12)]),'INCLUDE'),
        ('missing_geometry',None,'UNKNOWN'),
        ('empty_geometry',Point(),'UNKNOWN'),
    ]
    results=[]
    for name,geometry,expected in cases:
        before=None if geometry is None else geometry.wkb
        actual=classify_loc(geometry)
        assert actual==expected,(name,actual,expected)
        assert geometry is None or geometry.wkb==before
        results.append(dict(case=name,result=actual))
    assert classify_loc(Point(13.4,52.5),entity_type='event')=='NOT_APPLICABLE'
    assert classify_loc(None,entity_type='ORG')=='NOT_APPLICABLE'
    assert classify_loc(Point(0,0),entity_type='PER')=='NOT_APPLICABLE'
    try:classify_loc(Point(0,0),crs='EPSG:3857')
    except ValueError:pass
    else:raise AssertionError('Unsupported CRS silently accepted')
    record=dict(entity_type='LOC',geometry=Point(139.69166666666666,35.68944444444445),
                provenance=dict(source='original fixture evidence',revision=123))
    original=deepcopy(record)
    classify_loc(record['geometry'],entity_type=record['entity_type'])
    assert record==original
    result=dict(status='PASS',mask_version=MASK_VERSION,mask_sha256=MASK_SHA256,
        spatial_cases=len(cases),non_LOC_bypass_cases=3,unsupported_CRS_rejected=True,
        source_geometry_and_provenance_unchanged=True,decisions=results,
        integration_state_changed=False,external_calls=0,
        code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (Path(__file__).parent/'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='decisions'},indent=2))


if __name__=='__main__':
    self_check()
