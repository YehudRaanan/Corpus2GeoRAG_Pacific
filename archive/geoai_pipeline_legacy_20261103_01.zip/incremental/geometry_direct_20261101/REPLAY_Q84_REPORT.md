# One approved-selection replay: PASS

Replayed London Q84's existing OpenHistoricalMap Point, source object N2091040477. Original source: D:/Projects/GeoAI/GG_Data/pipeline/outputs/geography_coordinate_10_20261022_points_applied/audit.json, Q84 result RETAINED_ACCEPTED. Its original geometry_ref hashes the unchanged geometries.parquet as 856db4f61ff52b38d592083df009d8ca9f6e72c1407f2495c8db1b405aa87744.

Deliverables: replay_existing.py, replay_q84_0002/verification.json and replay_q84_0002/{graph.json,model/,private/}. The private original selection retains the entire historical record, including occurrence context, source ID, coordinate statement/references/precision and selection rationale. The native Q84 record and historical verification receipt are copied with pinned hashes. Unknown historical processing-revision fields remain unknown; this selection was not assigned to a new input/revision.

The local consumer fixture projects the EXACT original Q84::LOC node from matching_penalty_poc_20261023/graph_export_20261024/graph.json, without new node fields or edges. Model Geography uses the existing {file,place_id,sha256} pointer. The complete original 1.72 MB GeoParquet is copied byte-for-byte, retaining its other historical rows; only Q84 is joined in this fixture. This is a one-node projection, not a byte-identical copy of the full 10K graph.

Adding fixture-only ENRICHMENT_PENDING in private/pending.json leaves the existing selection intact and new_selection=null. All consumer files are byte-identical before/after adding that pending state. GraphStore loads Q84::LOC and the exact original Point through its unchanged model interface. No scorer, numeric weight, candidate selector or new geographic diagnosis ran. No 45/30/15/7/3 policy was generalized to a new choice.

Verification: replay check passed; --verify passed in a fresh Python process; another fresh process independently confirmed exact historical selection-row equality, exact original consumer-node equality, all source/artifact hashes, current code hash and repeated readback. First diagnostic replay_q84_0001 is NOT passing evidence: it exposed a fixture catalog list where the consumer requires an object. The isolated adapter was corrected to the existing contract and the failed directory was preserved. Only replay_q84_0002 is the accepted result.

Graph SHA256 before/after pending: ef2098b783494aeeaa07b6a556d65a56ea6b726f743c5b15c0ce9c007265f1b9
Geography SHA256 before/after pending: c5a08b3471ecd065ad14b4dd6ee316a41e7e9e40298d88af8b11f73e028d46c6
Stage SHA256: e9412d3bbe9fb2700d9380398b4f367dc7e50ddf8a08da27449f1f0ea3fe8937

Repeat readback command: contract_fixtures/.venv-bridge/Scripts/python.exe -B geometry_direct_20261101/replay_existing.py --verify, from the incremental workspace with the existing environment. Creation refuses an existing replay directory.

No external calls, new LOC/QID, source mutation, shared implementation/plan edits, publication, paid work, Git or child session. No remaining blocker or denied/uncertain action. G8-G10 choices remain open for their affected NEW-choice/retrieval/technical-LOC branches. Backup: Unprotected.
