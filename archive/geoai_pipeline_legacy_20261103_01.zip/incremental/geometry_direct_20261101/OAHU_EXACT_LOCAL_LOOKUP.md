# Oahu Q131347: bounded exact local search

Outcome: no full native entity record or Q131347 geometry pointer was found in the named local scope. This is not a claim of absence from every local file. Existing identity summary remains available: Oahu / オアフ島, enwiki Oʻahu, item revision 2377713161, modified 2025-07-10T22:41:17Z.

New exact checks:

| Artifact / index | Exact coverage and result |
|---|---|
| MAIN Data/external/wwii_task_force/wikidata_qids.txt | Exact membership in 53,857 declared requested QIDs: Q131347 absent. Avoided repeating the 133 MB archive scan. The archive wrapper uses requested_qid/entity, as confirmed from one row. |
| MAIN .../matching_penalty_poc_20261023/geography_retrieval/candidate_records.json.gz | All 391 top-level candidate native-record keys: no Q131347. |
| Same retrieval's osm_bigquery_cache/71bc6f34949a6bad69666609eb05c781cd4267786dce0b840b0a1e29755eae0e.json.gz | Exact wikidata tag equality across 1,144 native rows: zero Q131347 rows. No name/alias match used. |
| first_50_openhistoricalmap.json and three first_50_openstreetmap_batch_*.json | Q131347 absent from all declared request qids indexes; did not rescan response bodies. This proves no dedicated declared request, not absence from all conceivable source objects. |
| C:/Users/User/.cache/geoai_bigquery_20261018/*.sql | No exact Q131347 literal with numeric boundary. No literal is not proof of absent joined rows. Inspected metadata SELECTs produce summary fields, not a retained full native item result. |
| Four known entity_metadata.json.gz cache copies | Compressed file hashes differ because fixed gzip header timestamps differ; bytes after that header are IDENTICAL. One previously checked summary payload therefore covers all four. Avoided three repeated large JSON parses. |

Earlier exact checks reused rather than repeated: primary model full-record dictionary, historical Geography/place_id lookup, seven hashed Wikidata full-cache files and zero current-cache files. Current inventory confirms all seven compressed full-cache files are below the earlier 60 MB scan limit (maximum 28,637,350 bytes), so none was excluded by that limit. The old prefix-only archive scan is not presented as exhaustive; the declared QID index is the stronger new evidence.

Missing artifact is a FULL native Q131347 entity record with claims, original P625/P276/P131/P17/P402/P3896/P1566 statements when supplied, statement IDs/ranks/qualifiers/references and source revision/receipt. Summary keys also lack geometry/geometry_ref and OSM source version/timestamp. parents=[] and missing=false do not establish claim absence.

Concrete next lookup, NOT EXECUTED: one exact-QID native-item read for Q131347 through the existing approved source path, retaining the whole response and receipt. If an accessible original snapshot exists, use it; otherwise a current record must be explicitly labelled current, with the scoped source read authorized first. Candidate request: https://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q131347&format=json . After receiving the native record, inspect its direct coordinates and exact native external IDs; do not choose a geometry by Oahu's name or promote a country/nearby point. No assumption that the old time-travel snapshot is still accessible.

OAHU_EXACT_LOCAL_LOOKUP.json pins 14 source files and records exact coverage, cache deduplication, retained summary, missing fields and the unexecuted next request. JSON readback and metadata-body equality checks passed. No broad disk search, repeat full archive scan, external call, new coordinate/identity, geometry selection, shared-file edit, publication or nested session. Only owned reports were added. No denied or uncertain action; blocker is the missing native artifact in this bounded scope. Backup: Unprotected.
