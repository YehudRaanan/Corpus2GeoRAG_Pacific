# Tokyo Q1490: verified real-unit geometry handoff

PASS. Source-native MultiPolygon is valid, nonempty and EPSG:4326. The local one-row GeoParquet geometry is exactly equal to the original OSM WKB, including identical WKB bytes: no coordinate conversion, repair, buffer or new selection.

Source: OSM relation:1543125, native version 239, osm_timestamp 2021-09-29 22:18:10. Existing cache retrieval: 2026-10-23T08:16:26.259471+00:00. Original raw source file is matching_penalty_poc_20261023/geography_retrieval/sources/osm_bigquery_cache/71bc6f34949a6bad69666609eb05c781cd4267786dce0b840b0a1e29755eae0e.json.gz under MAIN pipeline outputs. Its unique row has wikidata=Q1490, and the existing osm_bigquery.project helper confirms source object/QID without conversion. Full raw tags, native WKB, source version/timestamp and original selection/P625/provenance are retained privately. Wikidata revision 2381634247, modified 2025-07-19T06:14:29Z, and snapshot 2026-10-18T18:45:19.304197+00:00 remain distinct from the unit processing revision.

Unit binding: page 48975579 / processing revision 1375061414 / first-unit-exact-v1 / Q1490::LOC / eight accepted occurrences. Source aggregate hash matches the sealed handoff receipt. This consumes the existing accepted identity and existing recorded source choice; it performs no reranking or new matching decision.

Publisher inputs are all under geometry_direct_20261101/tokyo_handoff_0001:

- handoff.json: internal identity/unit/source/version binding, original selection and new existing-contract geometry pointer.
- model/geometries.parquet: 245,276-byte ONE-row Q1490 artifact, keeping original GeoParquet columns and exact native geometry.
- model/geography.json.gz: existing five-LOC Geography view; Q1490 has its source-backed pointer and the other four retain null pointers. Replacing the full geometry artifact requires this matching Geography pointer/hash; do not use the old full-file hash.
- verification.json: pins handoff, consumer/model/private artifacts and all inputs. Handoff SHA256 358ed08c722aad72060a50eb694ac35955c84320c0f1a9ed6e054c7f9034da31. Verification SHA256 6abd5bf262bb7972acad0336d2370d3b817b7811c9a4f9f7eec6021bcde90bcd.

The isolated compatibility bundle copies the publisher's ten-node graph JSON byte-for-byte and its unchanged Entity/Event/Relation files. Existing load_geometries(required_crs='EPSG:4326') and GraphStore.from_json pass: ten nodes, zero edges, exactly Q1490::LOC has geometry. No geometry, geometry_ref or status enters graph-node JSON. The normal run and a separate fresh-process --verify both passed, including native-WKB equality, all source/output hashes and the accepted-QID join. Existing publisher files were only read.

ENRICHMENT_PENDING remains private and does not remove the useful shape. This administrative footprint is not asserted to be a WWII boundary or an Event extent. Nagoya's two P625 alternatives, Mariana Islands and Saipan's historical candidates/P276 target remain explicitly available but unvalidated/unexported in this handoff. Oahu Q131347 still lacks full source/shape evidence in the inspected cache scope. None is silently resolved or dropped.

Stage: validate_tokyo.py; repeat existing-environment readback with --verify. No external calls, paid work, new LOC/QID, shared-file/plan writes, publication or nested sessions. No denied/uncertain operation or blocker for consuming this verified Q1490 handoff. Backup: Unprotected.
