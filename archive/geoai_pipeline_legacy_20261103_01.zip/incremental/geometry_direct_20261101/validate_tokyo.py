"""Validate and hand off Tokyo's already selected native source shape; no ranking."""
import gzip
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
import geopandas as gpd
from pyproj import CRS
from shapely import from_wkb
from shapely.geometry import shape
from GG_Data.pipeline.final_package import digest, read_json
from GG_Data.pipeline.graph_contract import load_geometries
from GG_Data.pipeline.osm_bigquery import project
from geo_agent.graph_store import GraphStore

HERE = Path(__file__).parent
OUT = HERE / 'tokyo_handoff_0001'
PUBLISHER = ROOT / 'publisher_direct_20261101/snapshot_0001'


def verify():
    receipt = read_json(OUT / 'verification.json')
    assert all(digest(OUT / name) == sha for name, sha in receipt['files'].items())
    assert all(digest(Path(name)) == sha for name, sha in receipt['inputs'].items())
    handoff = read_json(OUT / 'handoff.json')
    assert handoff['qid'] == 'Q1490' and handoff['new_selection'] is False
    assert handoff['processing_revision_id'] == 1375061414
    assert digest(OUT / 'graph.json') == digest(PUBLISHER / 'graph.json')
    model = OUT / 'model'
    geography = read_json(model / 'geography.json.gz')
    pointers = [x['geometry_ref'] for x in geography if x['geometry_ref'] is not None]
    loaded = load_geometries(pointers, model, required_crs='EPSG:4326')
    assert set(loaded) == {'Q1490'}
    saved = gpd.read_parquet(model / 'geometries.parquet')
    assert CRS(saved.crs) == CRS.from_epsg(4326) and len(saved) == 1
    assert saved.iloc[0]['place_id'] == 'Q1490'
    raw = read_json(OUT / 'private/source_osm_row.json')
    original = from_wkb(bytes.fromhex(raw['geometry_wkb']))
    actual = loaded['Q1490']
    assert actual.is_valid and not actual.is_empty and actual.geom_type == 'MultiPolygon'
    assert actual.equals_exact(original, 0) and actual.wkb == original.wkb
    store = GraphStore.from_json(OUT / 'graph.json', model_dir=model)
    assert len(store.nodes) == 10 and len(store.edges) == 0
    assert set(store.geoms) == {'Q1490::LOC'}
    assert store.geoms['Q1490::LOC'].equals_exact(original, 0)
    assert all(not ({'geometry','geometry_ref','status'} & n.keys()) for n in read_json(OUT / 'graph.json')['nodes'])
    return receipt


def run():
    availability = read_json(HERE / 'ACTUAL_UNIT_GEOMETRY_INPUTS.json')
    tokyo = next(x for x in availability['records'] if x['qid'] == 'Q1490')
    old = tokyo['existing_geography'][0]
    base = Path(r'D:\Projects\GeoAI/GG_Data/pipeline/outputs/matching_penalty_poc_20261023')
    source = base / 'geography_retrieval/sources/osm_bigquery_cache/71bc6f34949a6bad69666609eb05c781cd4267786dce0b840b0a1e29755eae0e.json.gz'
    parcel = base / 'model_geography/geometries.parquet'
    assert digest(source) == availability['source_sha256'][str(source)]
    assert digest(parcel) == old['geometry_ref']['sha256']
    response = read_json(source)
    matches = [r for r in response['rows'] if str(r['osm_id']) == '1543125' and {t['key']:t['value'] for t in r['all_tags']}.get('wikidata') == 'Q1490']
    assert len(matches) == 1
    raw = matches[0]
    projected = project(raw, {'Q1490'}, str(source))
    assert projected['qid'] == 'Q1490' and projected['source_id'] == old['source_object_id']
    assert projected['geometry_conversion'] is None
    native = from_wkb(bytes.fromhex(raw['geometry_wkb']))
    assert shape(projected['geometry']).equals_exact(native, 0)
    selected = gpd.read_parquet(parcel, filters=[('place_id','=','Q1490')])
    assert len(selected) == 1 and CRS(selected.crs) == CRS.from_epsg(4326)
    assert selected.geometry.iloc[0].equals_exact(native, 0)
    assert native.is_valid and not native.is_empty
    handoff_source = ROOT / 'integration_direct_20261101/real_handoff_0001'
    unit = read_json(handoff_source / 'receipt.json')
    aggregate = read_json(handoff_source / 'aggregate.json')
    assert digest(handoff_source / 'aggregate.json') == unit['output_sha256']['aggregate.json']
    assert next(x for x in aggregate['typed_counts'] if x['qid']=='Q1490' and x['entity_group']=='LOC')['mention_count'] == 8
    OUT.mkdir()
    model, private = OUT / 'model', OUT / 'private'
    model.mkdir(); private.mkdir()
    shutil.copyfile(PUBLISHER / 'graph.json', OUT / 'graph.json')
    for name in ['entities.json.gz','events.json.gz','relations.json.gz']:
        shutil.copyfile(PUBLISHER / 'model' / name, model / name)
    selected.to_parquet(model / 'geometries.parquet', index=False)
    pointer = dict(file='geometries.parquet', place_id='Q1490', sha256=digest(model / 'geometries.parquet'))
    geography = read_json(PUBLISHER / 'model/geography.json.gz')
    assert [x for x in geography if x['place_id']=='Q1490'] == [dict(place_id='Q1490',geometry_ref=None)]
    geography = [dict(old, geometry_ref=pointer) if x['place_id']=='Q1490' else x for x in geography]
    (model / 'geography.json.gz').write_bytes(gzip.compress(json.dumps(geography).encode(),mtime=0))
    (private / 'source_osm_row.json').write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8')
    (private / 'original_selection_and_native_claims.json').write_text(json.dumps(tokyo,ensure_ascii=False,indent=2),encoding='utf-8')
    handoff = dict(qid='Q1490',type='LOC',node_id='Q1490::LOC',page_id=unit['page_id'],
        processing_revision_id=unit['processing_revision_id'],decision_version=unit['decision_version'],accepted_occurrences=8,
        original_geometry=old,geometry_ref=pointer,source_file=str(source),source_sha256=digest(source),
        source_object_id=old['source_object_id'],osm_version=raw.get('osm_version'),osm_timestamp=raw.get('osm_timestamp'),
        source_retrieved_at=response['retrieved_at'],native_wikidata_snapshot=availability['native_snapshot_at'],
        native_wikidata_revision=tokyo['source_lastrevid'],native_wikidata_modified=tokyo['source_modified'],
        new_selection=False,enrichment_status='ENRICHMENT_PENDING',
        caveat='Existing administrative source footprint; no assertion of WWII extent or Event boundary.',
        other_unit_geometry={'Q11751':'historical candidate available, not decoded here; preserve both P625 statements',
        'Q153732':'historical candidate available, not decoded here','Q51679':'historical candidate and P276 target available, not decoded here',
        'Q131347':'full source/geometry missing in inspected cache scope; no negative source assertion'})
    (OUT / 'handoff.json').write_text(json.dumps(handoff,ensure_ascii=False,indent=2),encoding='utf-8')
    paths = [source,parcel,HERE/'ACTUAL_UNIT_GEOMETRY_INPUTS.json',handoff_source/'receipt.json',handoff_source/'aggregate.json',
             PUBLISHER/'graph.json',PUBLISHER/'private/receipt.json',Path(__file__)]
    receipt = dict(status='VERIFIED_TOKYO_SOURCE_HANDOFF',qid='Q1490',geometry_type=native.geom_type,geometry_valid=True,
        geometry_crs='EPSG:4326',native_wkb_exact=True,new_selection=False,consumer_nodes=10,consumer_geometries=1,
        inputs={str(p):digest(p) for p in paths},files={p.relative_to(OUT).as_posix():digest(p) for p in OUT.rglob('*') if p.is_file()},
        scope='Read-only-source internal handoff; no publication or historical extent verification',backup_status='Unprotected')
    (OUT/'verification.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    verify()
    print(json.dumps({k:v for k,v in receipt.items() if k not in ['inputs','files']},indent=2))
    print('OSM_VERSION',raw.get('osm_version'),'OSM_TIMESTAMP',raw.get('osm_timestamp'))


if __name__ == '__main__':
    if '--verify' in sys.argv:
        verify(); print('PASS fresh Tokyo handoff readback: exact native WKB, valid MultiPolygon, EPSG:4326, source/version/accepted-QID pins, unchanged ten-node graph')
    else:
        run()
