# Mariana Islands and Saipan: verified source handoff

PASS in the normal run and fresh-process --verify. Both shapes are valid, nonempty EPSG:4326 and preserve identical native WKB bytes. No winner was selected, geometry repaired or coordinate introduced.

| Accepted identity | Original selected source | Native source version | Shape | Accepted unit occurrences |
|---|---|---|---|---:|
| Q153732::LOC, Mariana Islands | OSM relation:7811079 | 9; 2021-04-17 06:17:44 | MultiPolygon | 3 |
| Q51679::LOC, Saipan | OSM relation:3218318 | 10; 2021-04-17 06:17:44 | Polygon | 5 |

Unit: page 48975579 / processing revision 1375061414 / first-unit-exact-v1. Counts/QID/type bind to the hash-verified accepted aggregate. Original OSM tags identify the same QIDs; osm_bigquery.project verifies each source-object identity and reports no geometry conversion. Native source WKB, the existing selected GeoParquet rows and the new handoff GeoParquet rows are exactly equal, including WKB bytes. Each original source/selection record and P625/P276/context evidence is preserved privately.

Source: D:/Projects/GeoAI/GG_Data/pipeline/outputs/matching_penalty_poc_20261023/geography_retrieval/sources/osm_bigquery_cache/71bc6f34949a6bad69666609eb05c781cd4267786dce0b840b0a1e29755eae0e.json.gz. Cached retrieval timestamp: 2026-10-23T08:16:26.259471+00:00. Original full selected geometry artifact is sibling model_geography/geometries.parquet, SHA256 c79d836da965ef72aa2ff46c2dc687caf2052f42c15d83dc358f26dc23a938d8. These native versions and the separate Wikidata revisions/snapshot remain distinct from the unit processing revision.

Publisher handoff folder: geometry_direct_20261101/islands_handoff_0001.

- handoff.json: source versions, accepted-unit bindings and geography_fragment containing exactly the two verified existing-contract rows.
- model/geometries.parquet: two source-exact rows, SHA256 880b707fade11480b5ec9a2d66e900e71fc0270425be31ad7e353c97673bedba.
- model/geography.json.gz: matching two-row pointer fragment.
- private/Q153732_source_row.json and Q51679_source_row.json, plus each original-evidence record.
- verification.json: all source/output hashes; SHA256 99092abb618019d44ae802aa6a3e5a47cb8fa7cc8c034e0d50401903215b455f. Handoff SHA256 b794d28c48fb7127653d6152b4dd462dcda8fc108ffd19d24dfa9b3087b68440.

The isolated compatibility probe uses the unchanged ten-node publisher graph and existing load_geometries(required_crs='EPSG:4326') plus GraphStore.from_json. It loads exactly these two shapes with zero edges. This is a TWO-ROW ADDITION FRAGMENT, not a replacement of the publisher's current geometry view: preserve verified Tokyo, merge source-exact rows and recompute combined GeoParquet checksum/pointers. Tokyo handoff/receipt/code hashes were pinned and unchanged. Publisher files were only read.

ENRICHMENT_PENDING remains private without removing useful geometry. No WWII extent, Event-boundary or P276-derived geometry substitution is asserted. Nagoya's two original coordinates remain untouched and undecided; Oahu Q131347's source/geometry gap remains explicit in the inspected scope. No new unresolved winner was encountered for either selected source geometry.

Stage: validate_islands.py; existing-environment --verify rechecks both source handoffs. No external call, shared-file/plan edit, new LOC/QID, paid work, publication or nested agent. No remaining blocker or denied/uncertain operation. Backup: Unprotected.
