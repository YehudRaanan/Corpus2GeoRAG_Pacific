# E6 / Task 6 / R8 geometry fixture

PASS: one generated direct-P625 versus conflicting linked-place geometry fixture. This is development evidence, not real-world entity validation or full E6 implementation.

Stage: geometry_conflict.py. Evidence: case_0002/verification.json and case_0002/snapshot/model/evidence/{native_source,geometry_pending}.json.

The existing coordinate() interface retains the complete P625 statement (rank, qualifiers, references, precision and globe). The original raw record also retains the P276 linked-place statement. Both source evidences and page/processing-revision/identity/source-revision context survive JSON readback in the existing manifest-based internal model bundle. The supplied direct Point (130,30) is outside the saved linked-place polygon. The private pending record is ENRICHMENT_PENDING with proposed=null. The caller declares the conflict; this small fixture does not define a general disagreement threshold, source acquisition or automatic ranking policy.

Reused unchanged coordinate(), load_geometry(), graph_export.run(), export_snapshot(), verify_snapshot() and GraphStore. Consumer graph JSON and GeoParquet are byte-identical to the existing scaffold: four nodes, two views, no new technical LOC, no P625 projection or consumer fields. The existing synthetic graph scaffold uses its original generic wd:P1 relation catalog; the fixture's raw P276 evidence stays private and is not falsely relabelled or promoted into that catalog. Existing linked LOC geometry remains useful coverage; no Event boundary is inferred.

One assert-based check: RED failed on missing retained evidence; GREEN passed after adding the minimal retention stage. An intermediate integration attempt correctly rejected a stale producer manifest hash; case_0001 is preserved as an incomplete diagnostic input. The successful case_0002 regenerates producer receipts through the existing exporter before snapshot creation. A separate fresh Python process then verified statement/reference/qualifier/context equality, all snapshot hashes, unchanged consumer bytes, unchanged five MAIN implementation hashes and unchanged snapshot exporter hash. No broad test suite or production accuracy claim.

G8 selection, G9 enrichment sources/budgets/time roles and G10 technical-LOC population/projection remain OPEN. No new winner, point buffer, Event polygon, source request, paid work, external write, Git operation, publication, shared implementation edit or plan edit. No child agent or nested session was started. No denied or uncertain operation remains. Backup: Unprotected.

Stage SHA256: c97a574e5a0ad25a1c60d18bdba604765c9e58cae2f0c6151fa199249d616875
Pending evidence SHA256: 05a02da9521cf718be0593ab5942ab3354dabfd03d95b528d2468d46aa5dcc36
Raw source SHA256: faa9d3790645cab3d8fa4410c2a39c670fdeade98df7025b73ae9e6f073e63ee

This bounded task is complete; stop here. The stage intentionally refuses to overwrite case_0002. For independent re-verification, load the recorded snapshot using existing verify_snapshot(), then inspect both hash-pinned model/evidence JSON records.
