"""Nagoya source-native historical shape, checked without choosing new candidates."""
import sys
from pathlib import Path
import validate_tokyo as shared

HERE, ROOT = shared.HERE, shared.ROOT
OUT = HERE / 'nagoya_handoff_0001'
TARGETS = {'Q11751': ('relation:4576938', 2)}


def verify():
    receipt = shared.read_json(OUT / 'verification.json')
    assert all(shared.digest(OUT / p) == h for p, h in receipt['files'].items())
    assert all(shared.digest(Path(p)) == h for p, h in receipt['inputs'].items())
    assert shared.digest(OUT / 'graph.json') == shared.digest(shared.PUBLISHER / 'graph.json')
    geography = shared.read_json(OUT / 'model/geography.json.gz')
    shapes = shared.load_geometries([x['geometry_ref'] for x in geography], OUT / 'model', required_crs='EPSG:4326')
    assert set(shapes) == set(TARGETS)
    handoff = shared.read_json(OUT / 'handoff.json')
    assert handoff['new_selection'] is False
    assert handoff['page_id'] == 48975579 and handoff['processing_revision_id'] == 1375061414
    for qid, (source_id, mentions) in TARGETS.items():
        raw = shared.read_json(OUT / 'private' / (qid + '_source_row.json'))
        original = shared.from_wkb(bytes.fromhex(raw['geometry_wkb']))
        projected = shared.project(raw, {qid}, handoff['source_file'])
        assert projected['source_id'] == source_id and projected['geometry_conversion'] is None
        assert shapes[qid].is_valid and not shapes[qid].is_empty
        assert shapes[qid].wkb == original.wkb and shapes[qid].equals_exact(original, 0)
        item = next(x for x in handoff['identities'] if x['qid'] == qid)
        assert item['accepted_occurrences'] == mentions and item['osm_version'] == raw['osm_version']
        assert item['osm_timestamp'] == raw['osm_timestamp']
    store = shared.GraphStore.from_json(OUT / 'graph.json', model_dir=OUT / 'model')
    assert len(store.nodes) == 10 and not store.edges
    assert set(store.geoms) == {q + '::LOC' for q in TARGETS}
    return receipt


def run():
    availability_path = HERE / 'ACTUAL_UNIT_GEOMETRY_INPUTS.json'
    availability = shared.read_json(availability_path)
    records = {x['qid']: x for x in availability['records'] if x['qid'] in TARGETS}
    base = Path(r'D:\Projects\GeoAI/GG_Data/pipeline/outputs/matching_penalty_poc_20261023')
    source = base / 'geography_retrieval/sources/osm_bigquery_cache/71bc6f34949a6bad69666609eb05c781cd4267786dce0b840b0a1e29755eae0e.json.gz'
    parquet = base / 'model_geography/geometries.parquet'
    assert shared.digest(source) == availability['source_sha256'][str(source)]
    assert shared.digest(parquet) == availability['source_sha256'][str(parquet)]
    response = shared.read_json(source)
    frame = shared.gpd.read_parquet(parquet, filters=[('place_id', 'in', list(TARGETS))])
    assert len(frame) == 1 and shared.CRS(frame.crs) == shared.CRS.from_epsg(4326)
    unit_root = ROOT / 'integration_direct_20261101/real_handoff_0001'
    unit = shared.read_json(unit_root / 'receipt.json')
    assert shared.digest(unit_root / 'aggregate.json') == unit['output_sha256']['aggregate.json']
    counts = {(x['qid'], x['entity_group']): x['mention_count'] for x in shared.read_json(unit_root / 'aggregate.json')['typed_counts']}
    raw_rows, items = {}, []
    for qid, (source_id, mentions) in TARGETS.items():
        old = records[qid]['existing_geography'][0]
        assert old['source_object_id'] == source_id and counts[qid, 'LOC'] == mentions
        matches = [r for r in response['rows'] if str(r['osm_id']) == source_id.split(':')[1] and {t['key']: t['value'] for t in r['all_tags']}.get('wikidata') == qid]
        assert len(matches) == 1
        raw = matches[0]
        projected = shared.project(raw, {qid}, str(source))
        native = shared.from_wkb(bytes.fromhex(raw['geometry_wkb']))
        selected = frame.loc[frame.place_id == qid].geometry.iloc[0]
        assert projected['source_id'] == source_id and projected['geometry_conversion'] is None
        assert native.is_valid and not native.is_empty and selected.wkb == native.wkb
        assert selected.equals_exact(native, 0)
        raw_rows[qid] = raw
        items.append(dict(qid=qid,node_id=qid+'::LOC',accepted_occurrences=mentions,source_object_id=source_id,
            osm_version=raw['osm_version'],osm_timestamp=raw['osm_timestamp'],source_retrieved_at=response['retrieved_at'],
            original_selection=old,source_wikidata_revision=records[qid]['source_lastrevid'],
            source_wikidata_modified=records[qid]['source_modified'],geometry_type=native.geom_type,
            enrichment_status='ENRICHMENT_PENDING'))
    OUT.mkdir()
    model, private = OUT / 'model', OUT / 'private'
    model.mkdir()
    private.mkdir()
    shared.shutil.copyfile(shared.PUBLISHER / 'graph.json', OUT / 'graph.json')
    for name in ['entities.json.gz','events.json.gz','relations.json.gz']:
        shared.shutil.copyfile(shared.PUBLISHER / 'model' / name, model / name)
    frame.to_parquet(model / 'geometries.parquet', index=False)
    sha = shared.digest(model / 'geometries.parquet')
    geography = [dict(records[q]['existing_geography'][0], geometry_ref=dict(file='geometries.parquet',place_id=q,sha256=sha)) for q in TARGETS]
    (model / 'geography.json.gz').write_bytes(shared.gzip.compress(shared.json.dumps(geography).encode(),mtime=0))
    for qid, raw in raw_rows.items():
        (private / (qid+'_source_row.json')).write_text(shared.json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8')
        (private / (qid+'_original_evidence.json')).write_text(shared.json.dumps(records[qid],ensure_ascii=False,indent=2),encoding='utf-8')
    handoff = dict(page_id=unit['page_id'],processing_revision_id=unit['processing_revision_id'],decision_version=unit['decision_version'],
        source_file=str(source),native_wikidata_snapshot=availability['native_snapshot_at'],new_selection=False,identities=items,
        geography_fragment=geography,merge_semantics='One Nagoya row only; preserve Tokyo, Mariana Islands and Saipan; regenerate combined file hash/pointers.',
        unresolved={'Q131347':'Oahu: native claims/shape missing in inspected scope; summary exists'},
        caveat='Source-native modern footprints, no WWII extent or Event-boundary claim; no P276 export or linked-place substitution.')
    from pyproj import Geod
    from shapely.geometry import Point
    statements = records['Q11751']['P625_statements']
    assert len(statements) == 2
    a, b = [x['mainsnak']['datavalue']['value'] for x in statements]
    distance = Geod(ellps='WGS84').inv(a['longitude'],a['latitude'],b['longitude'],b['latitude'])[2]
    handoff['retained_coordinate_evidence'] = dict(statements=statements,distance_metres=distance,
        selected_coordinate=None,polygon_covers_each=[native.covers(Point(x['mainsnak']['datavalue']['value']['longitude'],x['mainsnak']['datavalue']['value']['latitude'])) for x in statements],
        explanation='Both source coordinates retained; existing polygon verified without choosing either coordinate.')
    metadata_path = Path(r'C:\Users\User\.cache\geoai_bigquery_20261018\entity_metadata.json.gz')
    assert shared.digest(metadata_path) == '0032e97cf9af90f56dae231071dbdd2bed8d9c379708a029c4a53b407a9378f8'
    oahu = shared.read_json(metadata_path)['Q131347']
    handoff['Oahu_summary_gap'] = dict(qid='Q131347',summary=oahu,source_file=str(metadata_path),source_sha256=shared.digest(metadata_path),
        absent_keys=[k for k in ['claims','P625','P276','P131','P17','P402','P3896','P1566','geometry','geometry_ref','osm_version','osm_timestamp'] if k not in oahu],
        interpretation='Missing summary keys do not prove absent native claims; parents=[] is not a raw P131 audit.',
        next_lookup='Exact Q131347 native-record lookup in existing local cache/archive by item ID; no external call.')
    (OUT / 'handoff.json').write_text(shared.json.dumps(handoff,ensure_ascii=False,indent=2),encoding='utf-8')
    paths = [source,parquet,availability_path,unit_root/'aggregate.json',unit_root/'receipt.json',shared.PUBLISHER/'graph.json',
        HERE/'tokyo_handoff_0001/handoff.json',HERE/'tokyo_handoff_0001/verification.json',HERE/'validate_tokyo.py',Path(__file__)]
    receipt = dict(status='VERIFIED_NAGOYA_SOURCE_HANDOFF',identities=1,geometry_crs='EPSG:4326',exact_native_WKB=True,
        new_selection=False,consumer_nodes=10,consumer_geometries=1,publication=False,
        inputs={str(p):shared.digest(p) for p in paths},files={p.relative_to(OUT).as_posix():shared.digest(p) for p in OUT.rglob('*') if p.is_file()},backup_status='Unprotected')
    (OUT/'verification.json').write_text(shared.json.dumps(receipt,indent=2),encoding='utf-8')
    verify()
    for item in items:print(shared.json.dumps({k:v for k,v in item.items() if k!='original_selection'},indent=2))
    print('PASS Nagoya exact source polygon and both retained coordinates, accepted-QID bindings, unchanged graph and Tokyo handoff')


if __name__ == '__main__':
    if '--verify' in sys.argv:
        verify()
        print('PASS fresh Nagoya handoff readback: native WKB, valid shapes, CRS, source versions, accepted identities and Tokyo hashes')
    else:
        run()
