"""One offline direct-coordinate/linked-place conflict fixture; no selection policy."""
import json
import shutil
import sys
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / 'snapshot_fixture'), str(ROOT / 'contract_fixtures'),
                 r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
from export_snapshot import export_snapshot, verify_snapshot, export_graph
from GG_Data.pipeline.final_package import digest, read_json
from GG_Data.pipeline.geography_coordinate_sample import coordinate
from GG_Data.pipeline.graph_contract import load_geometry
from geo_agent.graph_store import GraphStore
from shapely.geometry import Point


def retain_conflict(raw, linked, context):
    # A caller-declared conflict queues work; it authorizes no winner or retrieval.
    return deepcopy(dict(direct=coordinate(raw), linked=linked, context=context,
                         status='ENRICHMENT_PENDING', proposed=None))


def test_conflict_roundtrip():
    # Synthetic QIDs here belong only to the existing contract scaffold.
    claim = dict(id='Q2$fixture-coordinate', rank='normal',
        mainsnak=dict(snaktype='value', property='P625', datavalue=dict(
            type='globecoordinate', value=dict(longitude=130.0, latitude=30.0,
            altitude=None, precision=0.01, globe='http://www.wikidata.org/entity/Q2'))),
        qualifiers={'P585': [{'snaktype': 'value', 'datavalue': {'value': {'time': '+1942-01-01T00:00:00Z', 'precision': 9}}}]},
        references=[{'hash': 'fixture-coordinate-reference'}])
    place_claim = dict(id='Q2$fixture-place', rank='normal', mainsnak=dict(
        snaktype='value', property='P276', datavalue=dict(type='wikibase-entityid',
        value={'id': 'Q1', 'entity-type': 'item', 'numeric-id': 1})),
        references=[{'hash': 'fixture-place-reference'}])
    raw = dict(id='Q2', lastrevid=77, claims={'P625': [claim], 'P276': [place_claim]})
    base = ROOT / 'snapshot_fixture' / 'producer_fixture_0001'
    model = base / 'model'
    linked = dict(qid='Q1', statement=place_claim,
                  geometry_ref=read_json(model / 'geography.json.gz')[0]['geometry_ref'])
    context = dict(page_id=123, processing_revision_id=456, identity_version=1,
                   geometry_source_revision=77, fixture_only=True)
    before = deepcopy((raw, linked, context))
    evidence = retain_conflict(raw, linked, context)
    assert evidence is not None, 'Missing retained conflict evidence'
    assert evidence['direct'] == coordinate(raw)
    assert evidence['linked'] == linked and evidence['context'] == context
    assert evidence['status'] == 'ENRICHMENT_PENDING'
    assert evidence['proposed'] is None
    assert (raw, linked, context) == before
    direct_point = Point(*evidence['direct']['xy'])
    place_shape = load_geometry(linked['geometry_ref'], model)
    assert not place_shape.covers(direct_point), 'Fixture must disagree geometrically'

    output = Path(__file__).parent / 'case_0002'
    output.mkdir()  # Preserve previous runs; no overwrite or deletion.
    local_model = output / 'input_model'
    shutil.copytree(model, local_model)
    private = local_model / 'evidence'
    private.mkdir()
    for name, record in [('native_source.json', raw), ('geometry_pending.json', evidence)]:
        (private / name).write_text(json.dumps(record, indent=2), encoding='utf-8')
    manifest = read_json(local_model / 'manifest.json')
    for name in ['native_source.json', 'geometry_pending.json']:
        manifest['outputs']['evidence/' + name] = digest(private / name)
    (local_model / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    snapshot = output / 'snapshot'
    producer = output / 'producer'
    export_graph(local_model, read_json(base / 'producer/graph.json')['metadata'], producer)
    export_snapshot(producer, local_model, snapshot)
    assert verify_snapshot(snapshot)['fixture_only']
    restored = read_json(snapshot / 'model/evidence/geometry_pending.json')
    assert restored == evidence
    assert read_json(snapshot / 'model/evidence/native_source.json') == raw
    assert digest(snapshot / 'graph.json') == digest(base / 'producer/graph.json')
    assert digest(snapshot / 'model/geometries.parquet') == digest(model / 'geometries.parquet')
    store = GraphStore.from_json(snapshot / 'graph.json', model_dir=snapshot / 'model')
    assert set(store.nodes) == {'Q1::LOC', 'Q1::ORG', 'Q2::event', 'SYN_sample'}
    assert len(store.edges) == 2 and 'Q2::event' not in store.geoms
    assert store.geoms['Q1::LOC'].equals_exact(place_shape, 0)
    receipt = dict(status='PASS', fixture_cases=1, source_evidences=2,
        enrichment_status=restored['status'], new_technical_LOCs=0,
        consumer_graph_byte_identical=True, consumer_geoparquet_byte_identical=True,
        pending_sha256=digest(snapshot / 'model/evidence/geometry_pending.json'),
        source_sha256=digest(snapshot / 'model/evidence/native_source.json'),
        code_sha256=digest(Path(__file__)), backup_status='Unprotected')
    (output / 'verification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    test_conflict_roundtrip()


