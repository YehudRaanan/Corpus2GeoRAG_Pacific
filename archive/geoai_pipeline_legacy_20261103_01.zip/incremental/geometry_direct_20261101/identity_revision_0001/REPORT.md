# E6/R8 identity revision invalidation: bounded fixture PASS

One stage: check_invalidation.py; outputs evidence.json and verification.json in geometry_direct_20261101/identity_revision_0001. RED failed on the missing initial supported geometry; GREEN passed after adding the small identity/context support projection. No shared implementation was changed.

| Decision version | Synthetic decisions | Active source-owner geometry | Active support links | Retracted/pending links |
|---|---|---|---:|---:|
| geometry-test-v1 | o1=Q1, o2=Q1 | Q1 | 2 | 0 |
| geometry-test-v2 | o1=Q4, o2=Q1 | Q1 retained for unchanged o2 | 1 | 1 |
| geometry-test-v3 | o1=Q4, o2=Q4 | none in fixture active view | 0 | 2 |

Q4 never inherits the old geometry. Changed occurrence-to-geometry links are omitted from the active view and retained as RETRACTED_PENDING_REVALIDATION evidence. An unchanged supporting occurrence is revalidated only when its entire member record, unit scope and accepted decision/evidence equal the bound support; a new decision-frontier label alone does not erase useful geometry. When all Q1 support disappears, the fixture's active projection withdraws it while retaining original geometry evidence and prior views. This is support invalidation, not a new geography score/abstention policy.

Reused replace_unit(), active_occurrences(), aggregate_units() and existing source-membership validation read-only. The synthetic closed two-occurrence unit preserves raw member records across all decision replacements. The original accepted real unit and source decisions were not altered.

**Fixture identity boundary:** Q1/Q4 are synthetic owner labels in PRIVATE test state only. Geometry evidence is the existing REAL Tokyo handoff, tokyo_handoff_0001/handoff.json, kept byte-for-byte with qid=Q1490, node_id=Q1490::LOC and its original existing-contract geometry_ref. Its pointer was validated with load_geometries(required_crs='EPSG:4326'). Q1490 was never relabeled or exported as Q1/Q4; the fixture is testing invalidation behavior, not asserting a new geographic identity. No consumer output was produced.

All three decision versions, initial support bindings, full source handoff evidence, every projection and invalidation record survive JSON roundtrip. Exact retry returns False without changing state/views. Independent fresh-process replay loaded the SAVED handoffs/bindings, applied six attempts as three unique versions and reproduced every saved view and aggregate. Initial Q1 decisions remain in history. Code/evidence and seven protected fixture/handoff/helper/module hashes matched. No crash, power-loss or production integration claim.

Verification evidence SHA256 d13af9240dd174a12393a648f53fcdecb7a7b073338f2e41e721f0fff601c85c. Stage SHA256 d06af9a2e613bb7365fc4e24633741916f55a37765a42635693fee269661c6af. --verify reconstructs the bounded fixture without overwriting evidence.

No real geometry selection, shared-file/plan write, external request, publication, paid operation or nested session. No remaining blocker/denied/uncertain action. This establishes one isolated generated regression, not production revision invalidation wiring. Backup: Unprotected.
