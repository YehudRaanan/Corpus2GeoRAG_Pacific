"""Generated identity/context revision replay; real source handoff stays untouched."""
from copy import deepcopy
import hashlib
from pathlib import Path
import sys

HERE = Path(__file__).parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(HERE.parent),str(ROOT/'integration_direct_20261101')]
import validate_tokyo as shared
from occurrence_decisions import replace_unit,active_occurrences
from aggregate_occurrences import aggregate_units


def signature(row):
    # A new frontier can revalidate only exactly unchanged member/scope/decision evidence.
    return shared.json.dumps({k:row[k] for k in ['unit_scope','member','decision']},sort_keys=True)


def geometry_view(state,bindings):
    active, links, invalidated = {}, [], []
    for row in active_occurrences(state):
        occurrence = row['member']['occurrence_id']
        binding = bindings.get(occurrence)
        if binding is None:
            continue
        decision = row['decision']
        current = decision['qid'] if decision else None
        owner = binding['owner_qid']
        if current != owner or signature(row) != binding['support_signature']:
            invalidated.append(dict(occurrence_id=occurrence,prior_case_owner=owner,current_case_owner=current,
                decision_version=row['decision_version'],status='RETRACTED_PENDING_REVALIDATION'))
            continue
        active[owner] = deepcopy(binding['source_handoff'])
        links.append(dict(occurrence_id=occurrence,case_owner=owner,source_geometry_qid=binding['source_handoff']['qid'],
            decision_version=row['decision_version'],status='UNCHANGED_SUPPORT_REVALIDATED'))
    return dict(active_geometry=active,links=links,invalidated=invalidated)


def check(write=False):
    source_state = ROOT/'integration_direct_20261101/case_0003/state.json'
    real_path = HERE.parent/'tokyo_handoff_0001/handoff.json'
    real = shared.read_json(real_path)
    inputs = [source_state,real_path,HERE.parent/'tokyo_handoff_0001/verification.json',
        Path(shared.__file__),ROOT/'integration_direct_20261101/occurrence_decisions.py',
        ROOT/'integration_direct_20261101/aggregate_occurrences.py',ROOT/'source_custody/local_unit_contract.py']
    protected = {str(p):shared.digest(p) for p in inputs}
    handoff = deepcopy(shared.read_json(source_state)[0]['versions'][0])
    handoff['occurrences'] = [x for x in handoff['occurrences'] if x['occurrence_id'] in ['o1','o2']]
    assert [x['entity_group'] for x in handoff['occurrences']] == ['LOC','LOC']
    handoff['manifest']['expected_row_indices'] = [0,1]
    handoff['manifest']['input_sha256'] = hashlib.sha256(shared.json.dumps(handoff['occurrences'],sort_keys=True).encode()).hexdigest()
    handoff['shards'] = [dict((k,v) for k,v in handoff['manifest'].items() if k!='expected_row_indices') | dict(row_indices=[0,1])]
    handoff.update(version='geometry-test-v1',prior_version=None)
    handoff['decisions'] = [dict(occurrence_id=o,qid='Q1',evidence={'synthetic_fixture':True}) for o in ['o1','o2']]
    state = {}
    assert replace_unit(state,handoff,b'abc')
    bindings = {r['member']['occurrence_id']:dict(owner_qid='Q1',support_signature=signature(r),source_handoff=deepcopy(real)) for r in active_occurrences(state)}
    frozen_bindings = deepcopy(bindings)
    first = geometry_view(state,bindings)
    assert set(first['active_geometry']) == {'Q1'}, 'Initial supported Q1 geometry missing'
    assert len(first['links']) == 2 and not first['invalidated']
    views = [first]
    updates = [deepcopy(handoff)]
    for version,changed,prior in [('geometry-test-v2',['o1'],'geometry-test-v1'),('geometry-test-v3',['o1','o2'],'geometry-test-v2')]:
        update = deepcopy(handoff)
        update.update(version=version,prior_version=prior)
        for d in update['decisions']:
            if d['occurrence_id'] in changed:d['qid']='Q4'
        assert replace_unit(state,update,b'abc')
        view = geometry_view(state,bindings)
        assert 'Q4' not in view['active_geometry'], 'Old geometry must never follow the changed raw identity'
        assert len(view['invalidated']) == len(changed)
        assert len(view['links']) == 2-len(changed)
        assert set(view['active_geometry']) == ({'Q1'} if len(changed)==1 else set())
        before = deepcopy((state,view))
        assert replace_unit(state,deepcopy(update),b'abc') is False
        assert (state,geometry_view(state,bindings)) == before
        views.append(view)
        updates.append(update)
    assert bindings == frozen_bindings and len(next(iter(state.values()))) == 3
    assert [x['qid'] for x in handoff['decisions']] == ['Q1','Q1']
    replay = {}
    replay_views = []
    for update in updates:
        for _ in range(2):
            if replace_unit(replay,deepcopy(update),b'abc'):replay_views.append(geometry_view(replay,bindings))
    assert replay == state and replay_views == views
    assert aggregate_units(replay) == aggregate_units(state)
    source_geometry = shared.load_geometries([real['geometry_ref']],real_path.parent/'model',required_crs='EPSG:4326')
    assert set(source_geometry)=={'Q1490'} and real['qid']=='Q1490' and real['node_id']=='Q1490::LOC'
    assert protected == {p:shared.digest(Path(p)) for p in protected}
    result = dict(status='PASS',synthetic_versions=3,source_geometry_identity='Q1490',
        case_owner_labels=['Q1','Q4'],case_label_warning='Q1 is a synthetic test owner only. Real Q1490 handoff/pointer is never renamed or exported as Q1.',
        active_geometry_owner_counts=[len(v['active_geometry']) for v in views],active_support_links=[len(v['links']) for v in views],
        invalidated_links=[len(v['invalidated']) for v in views],idempotent_replay=True,real_decisions_changed=False,
        new_geometry_selection=False,consumer_export=False,inputs=protected,backup_status='Unprotected')
    if write:
        evidence=dict(handoffs=updates,original_bindings=bindings,geometry_history=views,aggregate=aggregate_units(state),fixture_source='abc')
        (HERE/'evidence.json').write_text(shared.json.dumps(evidence,indent=2),encoding='utf-8')
        assert shared.read_json(HERE/'evidence.json')==evidence
        result['evidence_sha256']=shared.digest(HERE/'evidence.json')
        result['code_sha256']=shared.digest(Path(__file__))
        (HERE/'verification.json').write_text(shared.json.dumps(result,indent=2),encoding='utf-8')
    else:
        saved = shared.read_json(HERE/'verification.json')
        assert saved['code_sha256']==shared.digest(Path(__file__)) and saved['evidence_sha256']==shared.digest(HERE/'evidence.json')
        assert shared.read_json(HERE/'evidence.json')['geometry_history']==views
    print(shared.json.dumps(result,indent=2))


if __name__=='__main__':
    check(write='--verify' not in sys.argv)
