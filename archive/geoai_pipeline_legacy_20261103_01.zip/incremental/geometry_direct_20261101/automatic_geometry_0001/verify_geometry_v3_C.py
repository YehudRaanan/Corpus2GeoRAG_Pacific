"""Verify the approved C root, unchanged implementation, and935 source/consumer equivalence."""
import ast,gzip,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from automatic_geometry_v3_C import validate_output_directory,APPROVED_C_GEOMETRY_ROOT,ROOT,prepare_geometry,descriptor,sha

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def check_paths():
 allowed=[APPROVED_C_GEOMETRY_ROOT/'verification935_C_0001',ROOT/'geometry_direct_20261101/future_generation']
 for p in allowed:assert validate_output_directory(p)==p.resolve()
 blocked=[APPROVED_C_GEOMETRY_ROOT,APPROVED_C_GEOMETRY_ROOT.parent,APPROVED_C_GEOMETRY_ROOT.parent/'counts/a',APPROVED_C_GEOMETRY_ROOT/'../ordinary/a',APPROVED_C_GEOMETRY_ROOT.with_name('geometry_evil')/'a',ROOT/'publisher_direct_20261101/a',ROOT/'geometry_direct_20261101',Path('C:/Windows/a')]
 for p in blocked:
  try:validate_output_directory(p)
  except ValueError:pass
  else:raise AssertionError('Disallowed output accepted: '+str(p))
 return dict(allowed=len(allowed),rejected=len(blocked),root_itself_siblings_prefix_escape_and_other_owners_rejected=True)

def main(handoff_path,golden_path):
 paths=check_paths()
 oldtree=ast.parse((HERE/'automatic_geometry_v2.py').read_text());newtree=ast.parse((HERE/'automatic_geometry_v3_C.py').read_text())
 oldfn=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=='prepare_geometry');newfn=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='prepare_geometry')
 # Only the initial output guard changes: preserve every remaining producer statement.
 assert [ast.dump(n) for n in oldfn.body[4:]]==[ast.dump(n) for n in newfn.body[2:]]
 h=read(handoff_path);old=read(golden_path)
 assert h['CPU_units']==old['CPU_units']==935
 assert h['producer']==descriptor(HERE/'automatic_geometry_v3_C.py')
 for k in ['decision_binding','decision_version','frontier_receipt','count_receipt','counts_snapshot','source_scope_qids','active_scope_qids','decisions','CPU_units','history_contributions','occurrences','source_typed_nodes','source_LOC','active_LOC','outside_LOC','unknown_LOC','position_selection_pending','active_typed_nodes','native_sources_found','native_source_gaps','exception_count','mask_version','mask_sha256']:
  assert h[k]==old[k],k
 for ref in [h['producer'],h['geometry_source_registry'],h['source_GEO_receipt'],*h['artifacts'].values()]:assert sha(ref['path'])==ref['sha256'],ref['path']
 for p,d in h['source_sha256'].items():assert sha(p)==d,p
 for k in ['active_nodes','active_endpoint_gate']:
  assert h['artifacts'][k]['sha256']==old['artifacts'][k]['sha256'],k
 import geopandas as gpd
 import pyarrow.parquet as pq
 byte_equal={k:h['artifacts'][k]['sha256']==old['artifacts'][k]['sha256'] for k in ['geography','geoparquet','full_source_geography','full_source_geoparquet']}
 for k in ['geoparquet','full_source_geoparquet']:
  a=gpd.read_parquet(h['artifacts'][k]['path']);b=gpd.read_parquet(old['artifacts'][k]['path'])
  assert list(a.columns)==list(b.columns) and list(a.place_id)==list(b.place_id)
  assert a.crs.equals(b.crs) and a.crs.to_epsg()==b.crs.to_epsg()==4326
  assert [g.wkb for g in a.geometry]==[g.wkb for g in b.geometry]
  am=pq.read_metadata(h['artifacts'][k]['path']).metadata;bm=pq.read_metadata(old['artifacts'][k]['path']).metadata
  assert {k:v for k,v in am.items() if k not in [b'geo',b'ARROW:schema']}=={k:v for k,v in bm.items() if k not in [b'geo',b'ARROW:schema']}
  ag=json.loads(am[b'geo']);bg=json.loads(bm[b'geo'])
  ag['columns']['geometry'].pop('crs');bg['columns']['geometry'].pop('crs');assert ag==bg
 for k in ['geography','full_source_geography']:
  a=json.loads(gzip.decompress(Path(h['artifacts'][k]['path']).read_bytes()));b=json.loads(gzip.decompress(Path(old['artifacts'][k]['path']).read_bytes()))
  source_k='geoparquet' if k=='geography' else 'full_source_geoparquet'
  for rows,hand in [(a,h),(b,old)]:
   for row in rows:
    if row.get('geometry_ref'):
     assert row['geometry_ref']['sha256']==hand['artifacts'][source_k]['sha256']
     row['geometry_ref']['sha256']='VERIFIED_ARTIFACT_CHECKSUM'
  assert a==b

 import geopandas as gpd
 from shapely.geometry import shape
 frame=gpd.read_parquet(h['artifacts']['geoparquet']['path'])
 assert len(frame)==619 and frame.place_id.nunique()==619 and frame.crs.to_epsg()==4326
 assert set(frame.place_id)==set(h['active_scope_qids']) and all(g.is_valid and not g.is_empty for g in frame.geometry)
 with gzip.open(h['artifacts']['geography']['path'],'rt',encoding='utf-8') as f:rows=json.load(f)
 assert {r['place_id'] for r in rows}==set(frame.place_id) and all(r['geometry_ref']['sha256']==h['artifacts']['geoparquet']['sha256'] for r in rows)
 assert read(h['artifacts']['exceptions']['path'])==read(old['artifacts']['exceptions']['path'])
 output=Path(handoff_path).parent
 before={str(p):(sha(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
 assert prepare_geometry(h['frontier_receipt'],h['publisher_count_input_receipt'],output)==h
 assert before=={str(p):(sha(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
 result=dict(status='PASS_C_ROOT_935_EQUIVALENCE',producer=descriptor(HERE/'automatic_geometry_v3_C.py'),handoff=descriptor(handoff_path),baseline=descriptor(golden_path),path_guards=paths,producer_geometry_body_unchanged=True,all_source_hashes_verified=True,consumer_geometry_WKB_and_CRS_equivalent=True,consumer_artifact_byte_equality=byte_equal,metadata_difference='Equivalent EPSG4326 datum versus datum_ensemble serialization; geometry checksums updated consistently',all_decisions_and_provenance_identical=True,exceptions_identical=True,idempotent_replay_no_writes=True,CPU_units=935,source_LOC=h['source_LOC'],active_LOC=h['active_LOC'],outside_LOC=h['outside_LOC'],unknown_LOC=h['unknown_LOC'],position_pending=h['position_selection_pending'],CRS='EPSG:4326',live_CPU_store_opened=False,publication=False)
 out=output/'C_ROOT_VERIFICATION.json';out.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))

if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--handoff',required=True);p.add_argument('--golden',required=True);a=p.parse_args();main(a.handoff,a.golden)
