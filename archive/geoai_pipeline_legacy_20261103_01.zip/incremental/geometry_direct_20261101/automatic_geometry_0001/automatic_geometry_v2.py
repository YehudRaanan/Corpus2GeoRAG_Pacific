"""Parameterized immutable ordinary LOC source/gate handoff; no live database or Event writes."""
import gzip,json,hashlib,sys
from pathlib import Path
from collections import Counter
import ijson
import geopandas as gpd

HERE=Path(__file__).parent
ROOT=HERE.parents[1]
RUN=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001'
sys.path[:0]=[str(HERE),str(RUN),str(ROOT/'orchestration_direct_20261101'),str(ROOT/'geometry_direct_20261101/runtime_geometry_audit_20261102_0001')]
from capture_cpu_frontier import read_active_units,encoded,SCOPE_FIELDS
from source_projection import prepare
from active_loc_gate import active_loc_gate

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def descriptor(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def save(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def prepare_geometry(frontier_descriptor, count_preparation_descriptor, output_dir, *, source_resources_descriptor=None):
 """Build only ordinary GEO from immutable pinned inputs; never advance CPU or publish."""
 output=Path(output_dir).resolve()
 ownership=ROOT/'geometry_direct_20261101'
 if not output.is_relative_to(ownership.resolve()) or output==ownership.resolve():raise ValueError('Use a unique GEO-owned generation directory')
 resources_ref=source_resources_descriptor or descriptor(HERE/'SOURCE_RESOURCES.json')
 request=dict(frontier=frontier_descriptor,count_preparation=count_preparation_descriptor,resources=resources_ref,code=descriptor(Path(__file__)),source_projection_code=descriptor(HERE/'source_projection.py'),reader=descriptor(RUN/'capture_cpu_frontier.py'))
 PINS={}
 def read(path,expected=None):
  path=Path(path);value=sha(path)
  if expected is not None and value!=expected:raise ValueError('Pinned input changed: '+str(path))
  PINS[str(path)]=value
  return json.loads(path.read_text(encoding='utf-8-sig'))
 def pinned(d):return read(d['path'],d['sha256'])
 frontier=pinned(frontier_descriptor);pub=pinned(count_preparation_descriptor);resources=pinned(resources_ref)
 if frontier.get('schema')!='geoai-immutable-cpu-frontier-v1' or frontier.get('status')!='READY_CPU_ONLY' or frontier.get('canonical_store_write_allowed') is not False:raise ValueError('Immutable CPU frontier required')
 if Path(frontier['database']['path']).resolve()==Path(frontier['canonical_source_store']).resolve():raise ValueError('Live CPU database refused')
 if frontier['reader']!=request['reader']:raise ValueError('Unexpected immutable frontier reader')
 if hashlib.sha256(encoded(frontier['frontier'])).hexdigest()!=frontier['frontier_sha256']:raise ValueError('Frozen frontier digest differs')
 if pub['frontier_receipt']!=frontier_descriptor or pub['CPU_units']!=frontier['active_units']:raise ValueError('Count preparation belongs to another frontier')
 if output.exists():
  previous=json.loads((output/'PUBLISHER_HANDOFF.json').read_text(encoding='utf-8'))
  if previous.get('request')!=request:raise ValueError('Changed generation cannot overwrite existing output')
  for p,d in previous['source_sha256'].items():
   if sha(p)!=d:raise ValueError('Replay source changed: '+p)
  for d in [*previous['artifacts'].values(),previous['geometry_source_registry'],previous['source_GEO_receipt']]:
   if sha(d['path'])!=d['sha256']:raise ValueError('Replay artifact changed: '+d['path'])
  return previous
 frontier_path=Path(frontier_descriptor['path']);pubpath=Path(count_preparation_descriptor['path'])
 counts_path=Path(pub['counts_snapshot']['path']);counts=read(counts_path,pub['counts_snapshot']['sha256'])
 count_ref=pub['consumer_inputs']['count_receipt'];count_receipt=read(count_ref['path'],count_ref['sha256'])
 assert count_receipt['projection']['typed_counts']==counts['typed_counts']
 assert counts['frontier_sha256']==pub['C3_counts_frontier_sha256']
 units=read_active_units(frontier_path)
 expected={tuple(x['scope'][k] for k in SCOPE_FIELDS):(x['decision_version'],x['contribution_sha256']) for x in counts['frontier']}
 assert set(units)==set(expected) and len(units)==frontier['active_units']
 for scope,versions in units.items():
  assert versions[-1]['version']==expected[scope][0] and hashlib.sha256(encoded(versions[-1])).hexdigest()==expected[scope][1]
 del units
 typed=counts['typed_counts'];wanted={r['qid'] for r in typed if r['entity_group']=='LOC'}
 assert len(typed)==pub['typed_nodes'] and counts['unique_occurrences']==pub['occurrences']
 assert pub['history_contributions']==frontier['history_contributions']
 assert expected=={tuple(r['scope']):(r['active_head']['version'],r['active_head']['sha256']) for r in frontier['frontier']}
 binding=[dict(scope=list(scope),decision_version=v,decision_content_sha256=d) for scope,(v,d) in sorted(expected.items())]
 assert binding==count_receipt['decision_binding']
 assert count_receipt['upstream_counts']==pub['counts_snapshot']
 assert count_receipt['projection']['decision_version']==pub['consumer_inputs']['decision_version']=='sha256:'+counts['frontier_sha256']
 assert hashlib.sha256(encoded(counts['frontier'])).hexdigest()==counts['frontier_sha256']
 assert hashlib.sha256(encoded(count_receipt['projection'])).hexdigest()==count_receipt['projection_sha256']
 output.mkdir(parents=True,exist_ok=False)
 PINS[frontier['database']['path']]=frontier['database']['sha256']
 print('VERIFIED frozen frontier:'+str(frontier['active_units'])+' units; '+str(len(typed))+' typed identities; '+str(len(wanted))+' LOC',flush=True)
 # Existing approved source precedence: already selected native cache, exact snapshot records, archive for remaining IDs only.
 registry_path=Path(resources['registry']['path']);assert sha(registry_path)==resources['registry']['sha256'];PINS[str(registry_path)]=resources['registry']['sha256']
 chosen={}
 with registry_path.open('rb') as f:
  for q,ref in ijson.kvitems(f,'selected_references',use_float=True):
   if q in wanted and ref['envelope']['entity'].get('id')==q and 'claims' in ref['envelope']['entity']:chosen[q]=ref
 print('Existing pinned native registry LOC records:'+str(len(chosen)),flush=True)
 snapshot=Path(resources['snapshot']['path']);manifest=Path(resources['manifest']['path']);metadata=pinned(resources['manifest']);PINS[str(snapshot)]=sha(snapshot);assert PINS[str(snapshot)]==resources['snapshot']['sha256']
 with gzip.open(snapshot,'rb') as f:
  for q,envelope in ijson.kvitems(f,'',use_float=True):
   if q not in wanted or q in chosen:continue
   entity=envelope.get('entity',{})
   if entity.get('id')!=q or 'claims' not in entity:continue
   chosen[q]=dict(envelope=envelope,provenance=dict(provider='PINNED_EXISTING_SNAPSHOT_RECORD',file=str(snapshot),sha256=PINS[str(snapshot)],record_id=q,
    native_revision=entity.get('lastrevid'),native_modified=entity.get('modified'),snapshot_at=metadata.get('snapshot_at'),
    source_manifest=descriptor(manifest),original_provenance_locator='provenance.'+q))
 print('After exact snapshot cache LOC records:'+str(len(chosen)),flush=True)
 archive=Path(resources['archive']['path']);index=Path(resources['archive_index']['path']);PINS[str(index)]=sha(index);assert PINS[str(index)]==resources['archive_index']['sha256']
 to_find=(wanted-set(chosen)) & set(index.read_text(encoding='utf-8').splitlines())
 archive_requested=sorted(to_find)
 if to_find:
  PINS[str(archive)]=sha(archive);assert PINS[str(archive)]==resources['archive']['sha256']
  with gzip.open(archive,'rt',encoding='utf-8') as f:
   for line_number,line in enumerate(f,1):
    envelope=json.loads(line);q=envelope.get('requested_qid')
    if q not in to_find:continue
    entity=envelope.get('entity',{})
    if entity.get('id')==q and 'claims' in entity:
     chosen[q]=dict(envelope=envelope,provenance=dict(provider='WIKIDATA_EXISTING_ARCHIVE',file=str(archive),sha256=PINS[str(archive)],line=line_number,record_id=q,native_revision=entity.get('lastrevid'),native_modified=entity.get('modified')));to_find.remove(q)
    if not to_find:break
 source_registry=output/'geometry_native_sources.json';save(source_registry,dict(status='CACHED_GEO_SOURCE_FRONTIER_NOT_RELATION_EVENT_REGISTRY',selected_references=chosen,
  requested_LOC_qids=sorted(wanted),source_gaps=sorted(wanted-set(chosen)),source_precedence=['existing pinned registry','exact original snapshot','existing archive for missing exact IDs'],source_sha256=PINS))
 print('GEO sources ready:'+str(len(chosen))+';source gaps:'+str(len(wanted-set(chosen))),flush=True)
 source_dir=output/'source_projection';source_dir.mkdir()
 source_result=prepare(counts_path,descriptor(source_registry),source_dir)
 gh=read(source_result['GEO_handoff']['path'],source_result['GEO_handoff']['sha256'])
 for key in ['code','audit','verification']:
  d=gh[key];PINS[d['path']]=d['sha256']
 d=gh['source_feed']['existing_verified_shapes'];PINS[d['path']]=d['sha256']
 PINS.update(gh['polygon_source_pins'])
 # Keep the original full source/gate projection, then produce safe active-only artifacts.
 raw_receipt=source_dir/'geometry_source_receipt.json';PINS[str(raw_receipt)]=sha(raw_receipt)
 geometry=gpd.read_parquet(source_dir/'geometries.parquet');rows=json.loads(gzip.decompress((source_dir/'geography.json.gz').read_bytes()))
 has_shape=set(geometry.place_id);decisions=[];exceptions=[]
 for original in source_result['decisions']:
  d=dict(original);d['scope_eligible']=original['allow_active_LOC']
  d['allow_active_LOC']=bool(original['allow_active_LOC'] and original['qid'] in has_shape)
  if not d['allow_active_LOC']:
   reason='OUTSIDE_APPROVED_MASK' if original['mask_result']=='EXCLUDE' else 'POSITION_SELECTION_PENDING_WITH_SCOPE_EVIDENCE' if original['source_coordinate_candidates'] else 'MISSING_NATIVE_SOURCE_RECORD' if original['method']=='MISSING_NATIVE_SOURCE_RECORD' else 'NO_SUPPORTED_SOURCE_LOCATION'
   exceptions.append(dict(qid=d['qid'],reason=reason,mask_result=d['mask_result'],scope_eligible=d['scope_eligible'],retain_source=True,decision=d))
  decisions.append(d)
 active={d['qid'] for d in decisions if d['allow_active_LOC']}
 active_dir=output/'active_projection';active_dir.mkdir()
 active_frame=geometry.loc[geometry.place_id.isin(active)].copy();assert set(active_frame.place_id)==active and not active_frame.place_id.duplicated().any()
 assert active_frame.crs.to_epsg()==4326 and all(g.is_valid and not g.is_empty for g in active_frame.geometry)
 active_frame.to_parquet(active_dir/'geometries.parquet',index=False);geometry_sha=sha(active_dir/'geometries.parquet')
 active_rows=[dict(r,geometry_ref=dict(file='geometries.parquet',place_id=r['place_id'],sha256=geometry_sha)) for r in rows if r['place_id'] in active]
 (active_dir/'geography.json.gz').write_bytes(gzip.compress(json.dumps(active_rows,ensure_ascii=False).encode(),mtime=0))
 active_nodes=[dict(qid=r['qid'],entity_group=r['entity_group'],node_id=r['qid']+'::'+r['entity_group']) for r in typed if r['entity_group']!='LOC' or r['qid'] in active]
 assert [r for r in active_nodes if r['entity_group']!='LOC']==[dict(qid=r['qid'],entity_group=r['entity_group'],node_id=r['qid']+'::'+r['entity_group']) for r in typed if r['entity_group']!='LOC']
 save(output/'exceptions.json',dict(frontier=pub['frontier_receipt'],count_receipt=count_ref,exceptions=exceptions,source_retention=True,global_source_absence_claimed=False))
 save(output/'active_nodes.json',active_nodes)
 active_qids={r['qid'] for r in active_nodes};save(output/'active_endpoint_gate.json',dict(active_node_ids=[r['node_id'] for r in active_nodes],active_qids=sorted(active_qids),
  excluded_LOC_node_ids=[q+'::LOC' for q in sorted(wanted-active)],rule='Explicit typed endpoint must be in active_node_ids; raw QID endpoint must resolve to at least one retained active role. Drop dangling/unsupported edges; never reassign an excluded LOC endpoint to an invented role.',ordinary_only=True,Event_selection_performed=False))
 artifacts=dict(geography=descriptor(active_dir/'geography.json.gz'),geoparquet=descriptor(active_dir/'geometries.parquet'),full_source_geography=descriptor(source_dir/'geography.json.gz'),full_source_geoparquet=descriptor(source_dir/'geometries.parquet'),exceptions=descriptor(output/'exceptions.json'),active_nodes=descriptor(output/'active_nodes.json'),active_endpoint_gate=descriptor(output/'active_endpoint_gate.json'))
 result=dict(status='VERIFIED_FROZEN_ORDINARY_GEO_ACTIVE_HANDOFF',frontier_receipt=pub['frontier_receipt'],publisher_count_input_receipt=descriptor(pubpath),count_receipt=count_ref,
  counts_snapshot=descriptor(counts_path),decision_binding=count_receipt['decision_binding'],decision_version=pub['consumer_inputs']['decision_version'],
  source_scope_kind='FULL_ACCEPTED_ORDINARY_LOC_POPULATION',source_scope_qids=sorted(wanted),active_scope_kind='FULL_ACTIVE_LOC_POPULATION',active_scope_qids=sorted(active),
  scope_kind='FULL_LOC_POPULATION',scope_qids=sorted(wanted),decisions=decisions,CPU_units=frontier['active_units'],history_contributions=frontier['history_contributions'],occurrences=counts['unique_occurrences'],source_typed_nodes=len(typed),
  source_LOC=len(wanted),active_LOC=len(active),outside_LOC=sum(d['mask_result']=='EXCLUDE' for d in decisions),unknown_LOC=sum(d['mask_result']=='UNKNOWN' for d in decisions),
  position_selection_pending=sum(d['scope_eligible'] and not d['allow_active_LOC'] for d in decisions),active_typed_nodes=len(active_nodes),
  native_sources_found=len(chosen),native_source_gaps=len(wanted-set(chosen)),exception_count=len(exceptions),
  geometry_source_registry=descriptor(source_registry),relation_Event_registry_not_asserted=True,source_GEO_receipt=descriptor(raw_receipt),mask_version=source_result['mask_version'],mask_sha256=source_result['mask_sha256'],
  artifacts=artifacts,source_sha256=PINS,non_LOC_unchanged=True,unknown_outside_active=True,unsafe_edge_handling='PUBLISHER must apply the bound active_endpoint_gate to the matching ordinary relation frontier; no unverified edge file is emitted here.',
  Event_output_computed=False,live_CPU_store_opened=False,publication=False,full_units_complete_claimed=False,code_sha256=sha(Path(__file__)),backup_status='Unprotected')
 result['producer']=descriptor(Path(__file__))
 result['request']=request
 for d in request.values():
  if isinstance(d,dict) and 'path' in d:PINS[d['path']]=d['sha256']
 for p,d in PINS.items():
  if sha(p)!=d:raise ValueError('Source changed during geometry preparation: '+p)
 save(output/'PUBLISHER_HANDOFF.json',result)
 print('HANDOFF_READY '+json.dumps({k:result[k] for k in ['source_LOC','active_LOC','outside_LOC','unknown_LOC','position_selection_pending','native_sources_found','native_source_gaps','active_typed_nodes','exception_count']})+' SHA256='+sha(output/'PUBLISHER_HANDOFF.json'),flush=True)


 return result

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--frontier',required=True);parser.add_argument('--count-preparation',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
 prepare_geometry(descriptor(args.frontier),descriptor(args.count_preparation),args.output)
