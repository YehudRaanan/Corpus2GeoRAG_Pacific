# Immutable ordinary GEO producer

Final callable: `automatic_geometry_v2.py::prepare_geometry(frontier_descriptor, count_preparation_descriptor, output_dir, *, source_resources_descriptor=None)`.

Both required inputs are `{path, sha256}` descriptors. The first is an immutable CPU snapshot receipt (`READY_CPU_ONLY`); the second is the exact PUBLISHER count preparation receipt bound to that frontier. GEO consumes its exact count receipt and preserves its decision binding. Never pass the advancing canonical database. Use a new absolute output directory within `geometry_direct_20261101`.

The return value is the existing GEO handoff dictionary, also written to `output_dir/PUBLISHER_HANDOFF.json`. It includes explicit `producer: {path, sha256}`, count and frontier bindings, all source hashes, complete source projection, active-only JSON/GeoParquet, active endpoint gate, and durable exceptions. The source registry is GEO provenance; it does not assert relation/Event registry equivalence.

Load the file using `importlib.util.spec_from_file_location` and call `prepare_geometry` synchronously. Use the pinned bridge Python runtime already used by downstream stages. The producer adds its local helper paths itself. Default resources are the same existing approved registry, exact snapshot and missing-ID archive used by frozen90; no retrieval occurs. Do not change resource manifests as an implicit source-policy update.

Identical replay verifies all pinned inputs/artifacts and returns without writing. A changed generation or incomplete existing output is rejected; inspect it and assign a new directory. No daemon, CPU state change, Event computation or publication occurs. INTEGRATION remains the sole chain/journal writer.

Approved policy is unchanged: reuse verified historical geometry, then single supported P625 point; retain conflicting point evidence without choosing a winner. Apply the approved Pacific LOC mask, including boundaries/intersections/dateline cases through the existing gate. Outside, unknown and position-pending LOCs have durable exceptions and stay outside active output. Non-LOC roles stay unchanged; PUBLISHER applies the endpoint gate to matching ordinary relations.

`INTEGRATION_HANDOFF.json` pins the final code, resources, verified90 equivalence and independent269 readback. Earlier `_0001` outputs remain preserved for audit; consume the `_0002` handoffs listed in that manifest.
