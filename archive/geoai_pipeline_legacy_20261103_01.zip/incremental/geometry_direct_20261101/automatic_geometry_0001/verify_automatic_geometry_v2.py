"""Independent consumer-contract readback, golden replay comparison, and input isolation checks."""
import gzip,json,sys,hashlib
from pathlib import Path
from collections import Counter
import geopandas as gpd
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(HERE),r'D:/Projects/GeoAI',str(ROOT/'geometry_direct_20261101/runtime_geometry_audit_20261102_0001')]
from automatic_geometry_v2 import prepare_geometry,descriptor,sha
from active_loc_gate import active_loc_gate,native_point_fallback
from GG_Data.pipeline.graph_contract import load_geometries

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def verify(path,golden=None):
 h=read(path);assert h['producer']==descriptor(HERE/'automatic_geometry_v2.py') and h['producer']['sha256']==h['code_sha256'];counts=read(h['counts_snapshot']['path']);count=read(h['count_receipt']['path'])
 assert h['decision_binding']==count['decision_binding'] and count['projection']['typed_counts']==counts['typed_counts']
 for d in [h['frontier_receipt'],h['publisher_count_input_receipt'],h['count_receipt'],h['counts_snapshot'],h['geometry_source_registry'],h['source_GEO_receipt'],*h['artifacts'].values()]:assert sha(d['path'])==d['sha256'],d['path']
 for p,d in h['source_sha256'].items():assert sha(p)==d,p
 locs={r['qid'] for r in counts['typed_counts'] if r['entity_group']=='LOC'}
 decisions=h['decisions'];assert len(decisions)==len({d['qid'] for d in decisions})==len(locs) and {d['qid'] for d in decisions}==locs
 active={d['qid'] for d in decisions if d['allow_active_LOC']};assert active==set(h['active_scope_qids'])
 with gzip.open(h['artifacts']['geography']['path'],'rt',encoding='utf-8') as f:rows=json.load(f)
 assert len(rows)==len(active) and {r['place_id'] for r in rows}==active
 shapes=load_geometries([r['geometry_ref'] for r in rows],Path(h['artifacts']['geoparquet']['path']).parent,required_crs='EPSG:4326')
 assert set(shapes)==active
 registry=read(h['geometry_source_registry']['path'])['selected_references']
 for d in decisions:
  q=d['qid']
  if q in active:
   assert shapes[q].is_valid and not shapes[q].is_empty and active_loc_gate(shapes[q])['allow_active_LOC']
   if d['method']=='VERIFIED_NATIVE_P625_SINGLE_POINT_FALLBACK':
    point,candidates,_=native_point_fallback(q,registry[q]['envelope']['entity']['claims'].get('P625',[]))
    assert point.wkb==shapes[q].wkb and candidates==d['source_coordinate_candidates']
  else:assert q not in shapes
 exceptions=read(h['artifacts']['exceptions']['path'])['exceptions'];assert {r['qid'] for r in exceptions}==locs-active and all(r['retain_source'] for r in exceptions)
 nodes=read(h['artifacts']['active_nodes']['path'])
 assert {(r['qid'],r['entity_group']) for r in nodes if r['entity_group']!='LOC'}=={(r['qid'],r['entity_group']) for r in counts['typed_counts'] if r['entity_group']!='LOC'}
 gate=read(h['artifacts']['active_endpoint_gate']['path']);assert set(gate['active_node_ids'])=={r['node_id'] for r in nodes}
 assert not set(gate['excluded_LOC_node_ids'])&set(gate['active_node_ids'])
 proof=dict(status='PASS_INDEPENDENT_IMMUTABLE_GEO_READBACK',handoff=descriptor(path),CPU_units=h['CPU_units'],source_LOC=len(locs),active_LOC=len(active),outside_LOC=h['outside_LOC'],unknown_LOC=h['unknown_LOC'],position_selection_pending=h['position_selection_pending'],exception_count=len(exceptions),active_typed_nodes=len(nodes),shape_types=dict(Counter(g.geom_type for g in shapes.values())),consumer_JSON_GeoParquet_contract=True,P625_WKB_and_provenance_preserved=True,non_LOC_unchanged=True,source_hashes_verified=True)
 if golden:
  old=read(golden)
  for key in ['decision_binding','decision_version','source_scope_qids','active_scope_qids','decisions','CPU_units','history_contributions','occurrences','source_typed_nodes','source_LOC','active_LOC','outside_LOC','unknown_LOC','position_selection_pending','active_typed_nodes','native_sources_found','native_source_gaps','exception_count','mask_version','mask_sha256']:assert h[key]==old[key],key
  for key in ['active_nodes','active_endpoint_gate','geoparquet','geography']:assert h['artifacts'][key]['sha256']==old['artifacts'][key]['sha256'],key
  assert read(h['geometry_source_registry']['path'])['selected_references']==read(old['geometry_source_registry']['path'])['selected_references']
  proof['frozen90_equivalent_decisions_provenance_and_consumer_bytes']=True
 # Successful replay must not change a single output file or timestamp.
 output=Path(path).parent
 before={str(p):(sha(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
 assert prepare_geometry(h['frontier_receipt'],h['publisher_count_input_receipt'],output)==h
 assert before=={str(p):(sha(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
 proof['idempotent_replay_no_writes']=True
 for title,frontier,prep,target in [
  ('bad_input_hash',dict(h['frontier_receipt'],sha256='0'*64),h['publisher_count_input_receipt'],HERE/'rejected_hash'),
  ('ownership_escape',h['frontier_receipt'],h['publisher_count_input_receipt'],ROOT/'invalid_geo_target')]:
  try:prepare_geometry(frontier,prep,target)
  except (ValueError,AssertionError):pass
  else:raise AssertionError('Expected rejection: '+title)
  assert not target.exists()
 proof['bad_hash_and_ownership_rejected_before_write']=True
 other=ROOT/('publisher_direct_20261101/frozen_catchup_0001/automatic_count_inputs/b6573dceb1b8df69_autochain-v1/receipt.json' if h['CPU_units']==90 else 'publisher_direct_20261101/frozen_catchup_0001/frontier90_0001/receipt.json')
 target=HERE/('rejected_mixed_frontier_'+str(h['CPU_units']))
 try:prepare_geometry(h['frontier_receipt'],descriptor(other),target)
 except ValueError:pass
 else:raise AssertionError('Mixed frontier must fail')
 assert not target.exists()
 proof['different_frontier_count_preparation_rejected_before_write']=True
 return proof
if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('handoff',type=Path);parser.add_argument('--golden',type=Path);args=parser.parse_args()
 result=verify(args.handoff,args.golden)
 (args.handoff.parent/'independent_readback.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps(result,indent=2))
