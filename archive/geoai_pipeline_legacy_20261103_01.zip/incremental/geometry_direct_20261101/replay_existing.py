"""Replay one historical selected LOC unchanged while enrichment is pending."""
import gzip
import json
import shutil
import sys
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
from GG_Data.pipeline.final_package import digest, read_json
from GG_Data.pipeline.graph_contract import load_geometry
from geo_agent.graph_store import GraphStore

HISTORY = Path(r'D:\Projects\GeoAI\GG_Data\pipeline\outputs')
SOURCE = HISTORY / 'geography_coordinate_10_20261022_points_applied'
GRAPH = HISTORY / 'matching_penalty_poc_20261023/graph_export_20261024/graph.json'


def verify(output):
    receipt = read_json(output / 'verification.json')
    assert all(digest(output / name) == sha for name, sha in receipt['files'].items())
    pending = read_json(output / 'private/pending.json')
    original = read_json(output / 'private/selected_original.json')
    assert pending['selection'] == original
    assert pending['enrichment_status'] == 'ENRICHMENT_PENDING'
    assert pending['new_selection'] is None
    assert original['input']['place_id'] == 'Q84'
    assert original['source_dataset'] == 'OpenHistoricalMap'
    assert original['source_object_id'] == 'N2091040477'
    graph = read_json(output / 'graph.json')
    store = GraphStore.from_json(output / 'graph.json', model_dir=output / 'model')
    assert set(store.nodes) == {'Q84::LOC'} and not store.edges
    assert set(graph['nodes'][0]) == set(receipt['original_node_fields'])
    assert store.geoms['Q84::LOC'].equals_exact(load_geometry(original['geometry_ref'], SOURCE), 0)
    assert store.geoms['Q84::LOC'].geom_type == 'Point'
    assert digest(output / 'model/geometries.parquet') == original['geometry_ref']['sha256']
    assert digest(output / 'graph.json') == receipt['graph_before_pending_sha256']
    assert digest(output / 'model/geography.json.gz') == receipt['geography_before_pending_sha256']
    assert all(digest(Path(name)) == sha for name, sha in receipt['source_sha256'].items())
    return receipt


def replay(output):
    verification = read_json(SOURCE / 'verification.json')
    assert digest(SOURCE / 'audit.json') == verification['outputs']['audit.json']
    assert digest(SOURCE / 'geometries.parquet') == verification['outputs']['geometries.parquet']
    selected = next(x for x in read_json(SOURCE / 'audit.json')['results'] if x['input']['place_id'] == 'Q84')
    assert selected['result'] == 'RETAINED_ACCEPTED'
    original = deepcopy(selected)
    source_graph = read_json(GRAPH)
    node = next(n for n in source_graph['nodes'] if n['id'] == 'Q84::LOC')
    # This is a one-node projection of an existing identity, with no new fields.
    graph = dict(source_graph, nodes=[node], edges=[], relation_catalog={})
    output.mkdir()
    model, private = output / 'model', output / 'private'
    model.mkdir()
    private.mkdir()
    sources = [SOURCE / 'verification.json', SOURCE / 'audit.json', SOURCE / 'geometries.parquet',
               SOURCE / 'sources/Q84_Q84.json', GRAPH]
    source_hashes = {str(p): digest(p) for p in sources}
    assert source_hashes[str(sources[3])] == verification['outputs']['sources\\Q84_Q84.json']
    shutil.copyfile(SOURCE / 'geometries.parquet', model / 'geometries.parquet')
    shutil.copyfile(SOURCE / 'sources/Q84_Q84.json', private / 'native_Q84.json')
    shutil.copyfile(SOURCE / 'verification.json', private / 'historical_verification.json')
    (private / 'selected_original.json').write_text(json.dumps(original, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / 'graph.json').write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding='utf-8')
    geography = [dict(place_id='Q84', geometry_ref=original['geometry_ref'])]
    (model / 'geography.json.gz').write_bytes(gzip.compress(json.dumps(geography).encode(), mtime=0))
    # The pending request is fixture scheduling state, not a geographic diagnosis.
    before = {str(p.relative_to(output)): digest(p) for p in [output / 'graph.json', model / 'geography.json.gz', model / 'geometries.parquet']}
    pending = dict(selection=deepcopy(selected), enrichment_status='ENRICHMENT_PENDING',
                   new_selection=None, fixture_only=True)
    (private / 'pending.json').write_text(json.dumps(pending, ensure_ascii=False, indent=2), encoding='utf-8')
    assert selected == original
    assert all(digest(output / name) == sha for name, sha in before.items())
    receipt = dict(status='PASS', cases=1, place_id='Q84', source_object_id='N2091040477',
        source_dataset='OpenHistoricalMap', recorded_result=selected['result'], new_selections=0,
        graph_before_pending_sha256=before['graph.json'], geography_before_pending_sha256=before[str(Path('model/geography.json.gz'))],
        original_node_fields=sorted(node), source_sha256=source_hashes,
        files={str(p.relative_to(output)): digest(p) for p in output.rglob('*') if p.is_file()},
        code_sha256=digest(Path(__file__)), backup_status='Unprotected')
    (output / 'verification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    verify(output)
    print('PASS Q84 historical OHM Point retained with complete selection/context/P625 evidence; pending enrichment changes zero consumer bytes; no new selection')


if __name__ == '__main__':
    target = Path(__file__).parent / 'replay_q84_0002'
    if '--verify' in sys.argv:
        verify(target)
        print('PASS fresh readback: source hashes, selection provenance, pending status, exact Point and consumer bytes')
    else:
        replay(target)

