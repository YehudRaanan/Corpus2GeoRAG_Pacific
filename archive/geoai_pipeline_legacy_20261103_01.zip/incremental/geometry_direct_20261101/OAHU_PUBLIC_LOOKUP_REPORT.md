# Oahu Q131347: one public native-record lookup completed

HTTP 200 from the official Wikidata API, one request, no authentication/paid API/retry. Requested 2026-11-01T20:41:37.959758+00:00; completed 20:41:38.942597+00:00. Source URL: https://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q131347&format=json . Item lastrevid 2555305862, modified 2026-10-09T11:12:44Z. The current item response is not the older cached snapshot or this unit's Wikipedia processing revision.

Raw response: oahu_public_0001/raw_response.json, 55,524 exact received bytes, SHA256 d2db952ad2c59676c7a5f5c121f27afa125388b05ea1774ca2611aced6adec74. receipt.json retains URL, retrieval times, HTTP headers and revision. No source response was normalized before saving.

Available geographic evidence:

- P625: one normal-rank Earth coordinate, longitude -157.965, latitude 21.485, precision 0.0002777777777777778; altitude=null. Statement q131347$3A32AB34-7E69-49A6-BEF7-42E807006450, one preserved P143 reference, no supplied temporal qualifiers.
- P131 -> Q487704; P17 -> Q30; P361 -> Q192626; P206 and P706 -> Q98.
- P402 -> OSM relation ID 3489649; P1566 -> GeoNames ID 5851609. These are source identifiers, not retrieved geometries.
- No P276 or P3896 statements in this exact response. This statement is bounded to the retrieved item/version.

The existing coordinate() validator accepts the original single Earth coordinate without changing it. Under the approved direct-coordinate/Point policy, this is usable Point evidence for the ALREADY ACCEPTED Q131347::LOC (one occurrence, page 48975579 / processing revision 1375061414 / first-unit-exact-v1). No competing coordinate, new identity, technical LOC or ranking choice is required. Its source revision is explicitly distinct from the processing revision. No geometry artifact or consumer output was created in this source-investigation task; no WWII boundary, Event extent or historical coordinate validity is asserted.

native_item_claims.json preserves ALL 18 item-valued outgoing native statements verbatim, including mainsnaks, IDs, ranks, qualifiers and references, with subject/property/target and source-version wrappers. Zero targets match the ten represented unit identities. This is only Oahu's outgoing coverage: incoming statements, other entities and a complete native pair frontier are NOT established, and no neither-native/co-occurrence decision follows.

geographic_claims.json preserves the complete geographic statements; coordinate_evidence.json retains the unchanged coordinate-helper representation. evidence_report.json binds source hashes, accepted-unit counts, source versions, missing properties and usability assessment. Its SHA256 is b47aba48ab4a222113acf05068d91ac3d38c921a0f4f6cd3f0a41717b680b80c. Roundtrip plus a fresh independent process verified raw-response hash, all 18 exact statements, original coordinate equality and item revision/timestamp.

Next bounded step is the existing Point-to-GeoParquet handoff for Q131347::LOC if assigned. Do not retrieve OSM/GeoNames shapes, follow native relation targets or infer a P276 edge from this read. Other source/consumer files remain unchanged. No access denial, blocker, broad crawl, new provider, security change or nested session. Backup: Unprotected.
