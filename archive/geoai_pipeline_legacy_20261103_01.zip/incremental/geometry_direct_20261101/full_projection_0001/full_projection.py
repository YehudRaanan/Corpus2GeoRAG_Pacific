"""Merge one current scoped fragment into a full, source-backed LOC projection."""
from copy import deepcopy
from pathlib import Path
import sys
import pandas as pd

HERE = Path(__file__).parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(HERE.parent),str(ROOT/'orchestration_direct_20261101'),str(ROOT/'integration_direct_20261101'),str(HERE.parent/'identity_revision_0001')]
import validate_tokyo as shared
from decision_revision_hook import decision_binding,require_current,content_hash
from occurrence_decisions import replace_unit,active_occurrences
from aggregate_occurrences import aggregate_units
from check_invalidation import signature


def merge_projection(output,baseline,fragment,state,fragment_sha256):
    output = Path(output)
    if content_hash(fragment) != fragment_sha256:
        raise ValueError('Fragment differs from caller-pinned content')
    scope = fragment.get('scope_qids')
    if not isinstance(scope,list) or not scope or len(scope)!=len(set(scope)):
        raise ValueError('Missing or duplicate fragment scope')
    require_current(fragment,state)
    if baseline['scope'].get('kind')!='FULL_LOC_POPULATION':
        raise ValueError('Baseline is not a full LOC projection')
    original_ids = baseline['scope']['place_ids']
    if len(original_ids)!=len(set(original_ids)) or not set(scope)<=set(original_ids):
        raise ValueError('Duplicate baseline scope or unowned update scope')
    sources = {str(Path(p)):baseline['artifact_sha256'][name] for name,p in baseline['artifacts'].items()}
    origin_receipt = baseline['source_receipt']
    sources[origin_receipt['path']] = origin_receipt['sha256']
    if any(shared.digest(Path(p))!=h for p,h in sources.items()):
        raise ValueError('Changed baseline source')
    prior_receipt = shared.read_json(Path(origin_receipt['path']))
    artifact_root = Path(origin_receipt['artifact_root'])
    for path,expected in sources.items():
        if path==origin_receipt['path']:continue
        if not any((artifact_root/relative).resolve()==Path(path).resolve() and h==expected
                   for relative,h in prior_receipt['artifact_sha256'].items()):
            raise ValueError('Baseline artifact absent from verified source receipt')
    rows = shared.read_json(Path(baseline['artifacts']['geography']))
    by_id = {r['place_id']:r for r in rows}
    if len(by_id)!=len(rows) or set(by_id)!=set(original_ids):
        raise ValueError('Baseline Geography differs from complete scope')
    frame = shared.gpd.read_parquet(baseline['artifacts']['geoparquet'])
    nonnull = {q for q,r in by_id.items() if r.get('geometry_ref') is not None}
    if frame.place_id.duplicated().any() or set(frame.place_id)!=nonnull or shared.CRS(frame.crs)!=shared.CRS.from_epsg(4326):
        raise ValueError('Baseline GeoParquet identity/CRS mismatch')
    shared.load_geometries([r['geometry_ref'] for r in rows if r.get('geometry_ref')],Path(baseline['artifacts']['geography']).parent,required_crs='EPSG:4326')
    current_ids = {r['qid'] for r in aggregate_units(state)['typed_counts'] if r['entity_group']=='LOC'}
    valid = set()
    for row in active_occurrences(state):
        old = baseline['support_bindings'].get(row['member']['occurrence_id'])
        if old and old['owner_qid'] in original_ids and row['decision'] and row['decision']['qid']==old['owner_qid'] and signature(row)==old['support_signature']:
            valid.add(old['owner_qid'])
    selected = {q:frame.loc[frame.place_id==q].copy() for q in sorted((current_ids & valid & nonnull)-set(scope))}
    metadata = {q:deepcopy(by_id[q]) for q in selected}
    active = fragment['projection']['active_geometry']
    if not set(active)<=set(scope) or not set(active)<=current_ids:
        raise ValueError('Active fragment leaves declared current scope')
    root = Path(fragment['artifact_root'])
    for q,handoff in active.items():
        if handoff['qid']!=q or handoff['geometry_ref']['place_id']!=q:
            raise ValueError('Geometry source identity was relabelled')
        shared.load_geometries([handoff['geometry_ref']],root,required_crs='EPSG:4326')
        source_file = root/handoff['geometry_ref']['file']
        sources[str(source_file)] = handoff['geometry_ref']['sha256']
        fragment_rows = shared.read_json(root/'geography.json.gz')
        matching = [r for r in fragment_rows if r['place_id']==q and r.get('geometry_ref')==handoff['geometry_ref']]
        if len(matching)!=1:raise ValueError('Fragment Geography/pointer differs')
        sources[str(root/'geography.json.gz')] = shared.digest(root/'geography.json.gz')
        selected[q] = shared.gpd.read_parquet(source_file,filters=[('place_id','=',q)])
        metadata[q] = deepcopy(matching[0])
    request = content_hash(dict(baseline=baseline,fragment=fragment,decision_binding=decision_binding(state)))
    if output.exists():
        receipt = shared.read_json(output/'receipt.json')
        if receipt['request_sha256']!=request:raise ValueError('Different request cannot overwrite projection')
        require_current(receipt,state)
        if any(shared.digest(Path(p))!=h for p,h in receipt['artifact_sha256'].items()):
            raise ValueError('Saved projection changed')
        return receipt
    output.mkdir()
    combined = shared.gpd.GeoDataFrame(pd.concat([selected[q] for q in sorted(selected)],ignore_index=True),crs=frame.crs) if selected else frame.iloc[:0].copy()
    if combined.place_id.duplicated().any() or not all(g.is_valid and not g.is_empty for g in combined.geometry):
        raise ValueError('Duplicate or invalid selected source shape')
    combined.to_parquet(output/'geometries.parquet',index=False)
    geometry_hash = shared.digest(output/'geometries.parquet')
    complete = [dict(metadata[q],geometry_ref=dict(file='geometries.parquet',place_id=q,sha256=geometry_hash)) if q in selected
                else dict(place_id=q,geometry_ref=None) for q in sorted(current_ids)]
    (output/'geography.json.gz').write_bytes(shared.gzip.compress(shared.json.dumps(complete,ensure_ascii=False).encode(),mtime=0))
    loaded = shared.load_geometries([r['geometry_ref'] for r in complete if r['geometry_ref']],output,required_crs='EPSG:4326')
    assert set(loaded)==set(selected) and len(complete)==len(current_ids)
    assert all(loaded[q].wkb==selected[q].geometry.iloc[0].wkb for q in selected)
    projection = dict(scope=dict(kind='FULL_LOC_POPULATION',place_ids=sorted(current_ids)),selected_qids=sorted(selected),
        null_qids=sorted(current_ids-set(selected)),retracted_previous_qids=sorted(nonnull-set(selected)),
        artifacts={name:str(output/file) for name,file in [('geography','geography.json.gz'),('geoparquet','geometries.parquet')]})
    binding = decision_binding(state)
    receipt = dict(decision_binding=binding,decision_version=binding[0]['decision_version'],projection=projection,
        projection_sha256=content_hash(projection),scope=projection['scope'],artifacts=projection['artifacts'],version='sha256:'+geometry_hash,
        request_sha256=request,source_sha256=sources,artifact_sha256={str(output/name):shared.digest(output/name) for name in ['geography.json.gz','geometries.parquet']},
        publication=False,consumer_fields_added=False)
    require_current(receipt,state)
    (output/'receipt.json').write_text(shared.json.dumps(receipt,indent=2),encoding='utf-8')
    return receipt


def check():
    manifest_path = ROOT/'publisher_direct_20261101/publisher_refresh_0001/simulation_0002/baseline_inputs.json'
    params = shared.read_json(manifest_path)
    chain_path = ROOT/'orchestration_direct_20261101/geometry_chain_0001/result.json'
    proof = shared.read_json(chain_path.parent/'verification.json')
    assert shared.digest(chain_path)==proof['result_sha256']
    chain = shared.read_json(chain_path)
    source = (ROOT/'integration_direct_20261101/real_handoff_0001/sealed_v1/source.private.bin').read_bytes()
    state = {}
    replace_unit(state,chain['versions'][0],source)
    baseline = dict(scope=params['geometries']['scope'],decision_binding=decision_binding(state),artifacts=params['geometries']['artifacts'],
        artifact_sha256={k:shared.digest(Path(p)) for k,p in params['geometries']['artifacts'].items()},
        support_bindings={r['member']['occurrence_id']:dict(owner_qid=r['decision']['qid'],support_signature=signature(r))
            for r in active_occurrences(state) if r['member']['entity_group']=='LOC' and r['decision'] and r['decision']['qid']},
        source_receipt=params['source_receipts']['geometries'])
    frame = shared.gpd.read_parquet(baseline['artifacts']['geoparquet'])
    assert len(frame)==5 and len(params['geometries']['scope']['place_ids'])==5
    protected_paths=[manifest_path,chain_path,chain_path.parent/'verification.json',Path(baseline['artifacts']['geography']),Path(baseline['artifacts']['geoparquet'])]
    protected={str(p):shared.digest(p) for p in protected_paths}
    summaries=[]
    requests=[]
    for index,update in enumerate(chain['versions']):
        if index:replace_unit(state,update,source)
        fragment=deepcopy(chain['contexts'][index]['geometry_receipt'])
        fragment['artifact_root']=str(HERE.parent/'tokyo_handoff_0001/model')
        output=HERE/('version_'+str(index+1))
        result=merge_projection(output,baseline,fragment,state,content_hash(fragment))
        assert result is not None,'Full projection merger returned no receipt'
        rows=shared.read_json(output/'geography.json.gz')
        current={r['qid'] for r in aggregate_units(state)['typed_counts'] if r['entity_group']=='LOC'}
        assert {r['place_id'] for r in rows}==current and len(rows)==len(current)
        restored=shared.gpd.read_parquet(output/'geometries.parquet')
        assert len(restored)==[5,5,4][index]
        for q in ['Q11751','Q131347','Q153732','Q51679']:
            assert restored.loc[restored.place_id==q].geometry.iloc[0].wkb==frame.loc[frame.place_id==q].geometry.iloc[0].wkb
        assert 'Q999999991' not in set(restored.place_id)
        if index:assert next(r for r in rows if r['place_id']=='Q999999991')['geometry_ref'] is None
        if index==2:assert 'Q1490' not in {r['place_id'] for r in rows}
        before={str(p):(shared.digest(p),p.stat().st_mtime_ns) for p in output.iterdir() if p.is_file()}
        assert merge_projection(output,baseline,fragment,state,content_hash(fragment))==result
        assert before=={str(p):(shared.digest(p),p.stat().st_mtime_ns) for p in output.iterdir() if p.is_file()}
        summaries.append(result)
        requests.append(dict(baseline=baseline,fragment=fragment,state_handoffs=chain['versions'][:index+1],fixture_source_hex=source.hex()))
    for label,change in [('missing_scope',lambda f:f.pop('scope_qids')),('duplicate_scope',lambda f:f['scope_qids'].append('Q1490')),
        ('stale_version',lambda f:f['decision_binding'][0].update(decision_version='STALE'))]:
        bad=deepcopy(fragment);change(bad);target=HERE/label
        try:merge_projection(target,baseline,bad,state,content_hash(bad))
        except ValueError:pass
        else:raise AssertionError('Invalid '+label+' accepted')
        assert not target.exists()
    assert protected=={p:shared.digest(Path(p)) for p in protected}
    (HERE/'requests.json').write_text(shared.json.dumps(requests,indent=2),encoding='utf-8')
    result=dict(status='PASS_FULL_GEOMETRY_PROJECTION',selected_shapes=[5,5,4],complete_LOC_rows=[5,6,5],
        rejected=['missing_scope','duplicate_scope','stale_version'],unaffected_shapes_exact=4,idempotent_replay=True,
        source_sha256=protected,requests_sha256=shared.digest(HERE/'requests.json'),code_sha256=shared.digest(Path(__file__)),
        output_receipts=summaries,real_decisions_changed=False,new_geometry_selection=False,publication=False,backup_status='Unprotected')
    (HERE/'verification.json').write_text(shared.json.dumps(result,indent=2),encoding='utf-8')
    print('PASS full views: LOC rows 5/6/5, shapes 5/5/4; four unchanged exact WKB; stale Tokyo removed; new LOC explicit null; replay stable; three invalid inputs rejected')


if __name__=='__main__':
    check()
