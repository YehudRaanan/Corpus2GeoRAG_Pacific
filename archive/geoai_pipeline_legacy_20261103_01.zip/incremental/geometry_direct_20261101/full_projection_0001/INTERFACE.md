# Full R8 geometry projection merger: READY

Callable: full_projection.py::merge_projection(output, baseline, fragment, state, fragment_sha256). The output is a complete Geography + separate GeoParquet projection, not a Tokyo replacement fragment. No shared module or real accepted decision was changed.

Inputs:

- baseline: scope={kind: FULL_LOC_POPULATION, place_ids:[...]}, existing artifact paths/hashes, source_receipt={path,sha256,artifact_root}, decision_binding and per-occurrence support_bindings. The exact ready example is requests.json[0].baseline. It uses the verified FIVE-shape proposed_strength_0001/snapshot_0007_retry_0001 baseline from the publisher's simulation_0002/baseline_inputs.json.
- fragment: the existing advance_geometry receipt, including current decision_binding, projection/projection_sha256 and unique nonempty scope_qids. Add artifact_root pointing to the selected fragment's model directory. The test uses the already verified Tokyo source handoff; no source shape is chosen here.
- state: existing replace_unit-compatible current accepted decision state. Its complete decision_binding is checked against the fragment. Caller pins the WHOLE fragment with fragment_sha256=content_hash(fragment).

Behavior: validate source receipt/hash coverage, full baseline scope, unique identities, valid shapes/CRS and source pointers. Revalidate unchanged baseline support by exact member/scope/decision signature. Retain only currently represented LOCs with valid support; apply only the fragment's owned current scope. Removed/stale identities cannot carry their old geometry to a new QID. Produce exactly one Geography row for EVERY current accepted LOC, using explicit geometry_ref=null where no verified shape exists. New pointers all bind the complete combined artifact's checksum. Existing source metadata/WKB remains intact. No new geometry score, source selection or consumer JSON field.

Returned receipt exposes scope, artifacts, version=sha256:<combined GeoParquet hash>, decision_version, decision_binding, projection/projection_sha256, pinned sources, output hashes and request fingerprint. require_current accepts it for the exact tested state. An exact repeat verifies inputs and returns the existing receipt without touching bytes or mtimes; a different request cannot overwrite that output.

| Isolated decision frontier | Full LOC rows | Selected shapes | Explicit nulls |
|---|---:|---:|---:|
| Actual first-unit baseline | 5 | 5 | 0 |
| Synthetic: one Tokyo support reassigned | 6 | 5 | 1 |
| Synthetic: all Tokyo supports reassigned | 5 | 4 | 1 |

Nagoya, Oahu, Mariana Islands and Saipan preserve identical original WKB in every version. Tokyo stays when seven supports remain and is withdrawn when all eight change. Q999999991 is synthetic only; it receives no inherited geometry. Old artifacts are retained, not deleted.

Evidence: version_1/, version_2/, version_3/ each contain geography.json.gz, geometries.parquet and receipt.json. requests.json records exact replay inputs; verification.json pins code/requests/sources and all results. RED failed on the stub's absent receipt. GREEN passed normal/replay cases and rejected missing scope, duplicate scope and stale decision version before creating directories. A separate fresh Python process reconstructed state from SAVED requests, verified every source/output hash and full current LOC membership, loaded the existing-contract pointers with required CRS EPSG:4326, compared all four unaffected WKBs, and repeated callable replay while checking unchanged bytes/mtimes. PASS.

Ready scope is the existing single-unit frontier and the retained support signatures demonstrated here. This is not an authenticated multi-writer registry, full multi-unit revision-version naming policy, consumer snapshot materialization or publication. The callable does not invoke advance_geometry or the publisher; INTEGRATION owns that wiring. No blocking test or tool action remains. No external call, shared-file/plan write, real new decision, new geometry choice, paid work or nested session. Backup: Unprotected.
