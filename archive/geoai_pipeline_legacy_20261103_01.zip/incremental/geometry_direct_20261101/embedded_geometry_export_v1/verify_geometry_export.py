"""Read the isolated935 export through the actual consumer; exercise bounded adapter failures."""
import copy,json,sys
from pathlib import Path
from unittest.mock import patch
import geopandas as gpd
from shapely.geometry import shape
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import geometry_export as adapter
from geometry_export import load,pinned,descriptor,add_geojson_geometry,prepare_export
r=load(descriptor(HERE/'verified935_0001/receipt.json'));consumer=load(r['request']['consumer']);before=load(consumer['graph']);after=load(r['graph']);proof=load(r['proof']);geo=load(r['request']['GEO'])
frame=gpd.read_parquet(pinned(proof['geoparquet']));by=dict(zip(frame.place_id,frame.geometry))
locs=[n for n in after['nodes'] if n['type']=='location']
assert len(locs)==len({n['id'] for n in locs})==619
assert after['edges']==before['edges'] and len(after['nodes'])==len(before['nodes'])
for old,new in zip(before['nodes'],after['nodes']):
 assert {k:v for k,v in old.items() if k!='geometry'}=={k:v for k,v in new.items() if k!='geometry'}
 if new['type']=='location':assert shape(new['geometry']).wkb==by[new['wikidata_id']].wkb
 else:assert new==old
excluded=set(proof['excluded_scope']['unknown_qids']+proof['excluded_scope']['outside_qids']+proof['excluded_scope']['inside_position_pending_qids']);assert not excluded&{n['wikidata_id'] for n in locs}
assert (len(proof['excluded_scope']['unknown_qids']),len(proof['excluded_scope']['outside_qids']),len(proof['excluded_scope']['inside_position_pending_qids']))==(2748,291,27)
# Exercise an already available consumer, without writing or changing its code.
sys.path[:0]=[consumer['request']['consumer_root'],r'D:/Projects/GeoAI']
from geo_agent.graph_store import GraphStore
store=GraphStore.from_json(r['graph']['path'],model_dir=Path(consumer['graph']['path']).parent/'model')
assert len(store.nodes)==1756 and len(store.edges)==18562 and len(store.geoms)==619
assert all(store.geoms[n['id']].wkb==by[n['wikidata_id']].wkb for n in locs)
# A small graph fixture uses an actual source identity; its citation sentinel stays in memory.
sample=copy.deepcopy(next(n for n in before['nodes'] if n['type']=='location'));sample['citations']=[{'test_only':True}];sample['page_ids']=['test-only-sentinel']
mini=dict(metadata={'test_only':True},nodes=[sample],edges=[])
out,_=add_geojson_geometry(mini,r['request']['GEO']);assert out['nodes'][0]['citations']==sample['citations'] and out['nodes'][0]['page_ids']==sample['page_ids'] and 'geometry' not in sample
again,_=add_geojson_geometry(out,r['request']['GEO']);assert again==out
failures=[]
def rejects(label,graph,ref=None):
 try:add_geojson_geometry(graph,ref or r['request']['GEO'])
 except ValueError:failures.append(label)
 else:raise AssertionError('Expected rejection: '+label)
rejects('duplicate_node',dict(mini,nodes=[sample,sample]))
q=proof['excluded_scope']['unknown_qids'][0];missing=dict(sample,id=q+'::LOC',wikidata_id=q);rejects('unknown_active_LOC',dict(mini,nodes=[missing]))
conflict=dict(sample,geometry={'type':'Point','coordinates':[0,0]});rejects('conflicting_existing_geometry',dict(mini,nodes=[conflict]))
rejects('bad_source_hash',mini,dict(r['request']['GEO'],sha256='0'*64))
with patch.object(adapter.gpd,'read_parquet',return_value=frame.set_crs('EPSG:3857',allow_override=True)):rejects('wrong_CRS',mini)
# A complete replay must not touch the isolated generation.
before_files={str(p):(adapter.sha(p),p.stat().st_mtime_ns) for p in (HERE/'verified935_0001').iterdir() if p.is_file()}
assert prepare_export(r['request']['consumer'],HERE/'verified935_0001')==r
assert before_files=={str(p):(adapter.sha(p),p.stat().st_mtime_ns) for p in (HERE/'verified935_0001').iterdir() if p.is_file()}
result=dict(status='PASS_VERIFIED935_INLINE_GEOMETRY_ADAPTER',producer=descriptor(HERE/'geometry_export.py'),export_receipt=descriptor(HERE/'verified935_0001/receipt.json'),graph=r['graph'],CPU_units=935,nodes=len(store.nodes),edges=len(store.edges),embedded_LOC_geometries=len(store.geoms),exact_WKB_roundtrip=True,EPSG4326_and_longitude_latitude=True,non_geometry_fields_and_citations_preserved=True,actual_consumer_readback=True,idempotent_replay_no_writes=True,failures_rejected=failures,excluded_unknown=2748,excluded_outside=291,excluded_position_pending=27,source_model_and_live_outputs_unchanged=True)
(HERE/'VERIFICATION.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
