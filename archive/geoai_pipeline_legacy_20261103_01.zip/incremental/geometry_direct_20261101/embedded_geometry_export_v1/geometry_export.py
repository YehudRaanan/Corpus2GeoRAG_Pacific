"""Add verified ordinary LOC GeoJSON to an export; preserve the source model and all other fields."""
import gzip,hashlib,json
from pathlib import Path
from collections import Counter
import geopandas as gpd
from shapely.geometry import mapping,shape

HERE=Path(__file__).resolve().parent

def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def descriptor(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def pinned(ref):
 if sha(ref['path'])!=ref['sha256']:raise ValueError('Pinned input hash differs: '+ref['path'])
 return Path(ref['path'])
def load(ref):return json.loads(pinned(ref).read_text(encoding='utf-8-sig'))

def add_geojson_geometry(graph, geo_handoff_descriptor):
 """Return (new_graph, proof); safe before or after the citation adapter, with no writes."""
 handoff=load(geo_handoff_descriptor)
 if handoff.get('unknown_outside_active') is not True:raise ValueError('Approved active LOC policy required')
 ref=handoff['artifacts']['geoparquet'];frame=gpd.read_parquet(pinned(ref))
 if frame.crs is None or frame.crs.to_epsg()!=4326:raise ValueError('EPSG:4326 source required; no coordinate conversion')
 if frame.place_id.duplicated().any():raise ValueError('Duplicate source place_id')
 by=dict(zip(frame.place_id,frame.geometry));active=set(handoff['active_scope_qids'])
 if set(by)!=active:raise ValueError('Active geometry frontier differs')
 ids=[n['id'] for n in graph['nodes']]
 if len(ids)!=len(set(ids)):raise ValueError('Duplicate graph node id')
 nodes=[];used=[];types=Counter()
 for original in graph['nodes']:
  node=dict(original)
  if original.get('type')=='location':
   qid=original.get('wikidata_id')
   if not qid or original['id']!=qid+'::LOC':raise ValueError('Expected exact typed LOC identity')
   if qid not in active:raise ValueError('Active LOC has no verified in-scope geometry: '+qid)
   geometry=by[qid]
   if geometry is None or geometry.is_empty or not geometry.is_valid:raise ValueError('Invalid or empty geometry: '+qid)
   if original.get('geometry') is not None and shape(original['geometry']).wkb!=geometry.wkb:raise ValueError('Existing inline geometry conflicts with verified source: '+qid)
   encoded=json.dumps(mapping(geometry),allow_nan=False,separators=(',',':'))
   node['geometry']=json.loads(encoded)
   if shape(node['geometry']).wkb!=geometry.wkb:raise ValueError('Geometry changed during JSON roundtrip: '+qid)
   used.append(qid);types[geometry.geom_type]+=1
  nodes.append(node)
 if len(used)!=len(set(used)):raise ValueError('Duplicate LOC identity')
 result=dict(graph,nodes=nodes)
 decisions=handoff['decisions']
 proof=dict(schema='geoai-inline-geometry-export-v1',geo_handoff=geo_handoff_descriptor,geoparquet=ref,CRS='EPSG:4326',coordinate_order='longitude,latitude',field='nodes[type=location].geometry',join='node.wikidata_id == GeoParquet.place_id; node.id == place_id + ::LOC',geometry_format='GeoJSON Geometry',graph_LOC=len(used),embedded_geometries=len(used),shape_types=dict(types),all_active_graph_LOC_covered=True,exact_source_WKB_roundtrip=True,non_geometry_fields_preserved=True,excluded_scope=dict(unknown_qids=sorted(d['qid'] for d in decisions if d['mask_result']=='UNKNOWN'),outside_qids=sorted(d['qid'] for d in decisions if d['mask_result']=='EXCLUDE'),inside_position_pending_qids=sorted(d['qid'] for d in decisions if d.get('scope_eligible') and not d['allow_active_LOC'])),missing_active_LOC_policy='Reject export; retain unknown locations only in source/pending exceptions, outside the active graph',source_exceptions=handoff['artifacts']['exceptions'])
 return result,proof

def prepare_export(consumer_handoff_descriptor, output_dir):
 """Owned demonstration/export wrapper; PUBLISHER may call add_geojson_geometry in its own final writer."""
 output=Path(output_dir).resolve()
 if not output.is_relative_to(HERE) or output==HERE:raise ValueError('Use a new adapter-owned output directory')
 consumer=load(consumer_handoff_descriptor);graph_ref=consumer['graph'];graph=load(graph_ref)
 geo_ref=consumer['request']['geo_handoff'];geo=load(geo_ref)
 if consumer['CPU_units']!=geo['CPU_units']:raise ValueError('Consumer/GEO frontier differs')
 request=dict(consumer=consumer_handoff_descriptor,graph=graph_ref,GEO=geo_ref,producer=descriptor(__file__))
 if output.exists():
  prior=json.loads((output/'receipt.json').read_text(encoding='utf-8'))
  if prior['request']!=request:raise ValueError('Changed export cannot overwrite a generation')
  for ref in [prior['graph'],prior['proof'],prior['proof_source']['geoparquet']]:pinned(ref)
  return prior
 result,proof=add_geojson_geometry(graph,geo_ref)
 # Compact output keeps the complete original coordinates, including all polygon vertices.
 payload=json.dumps(result,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
 decoded=json.loads(payload)
 if decoded['edges']!=graph['edges'] or decoded.get('metadata')!=graph.get('metadata'):raise ValueError('Unrelated export content changed')
 for before,after in zip(graph['nodes'],decoded['nodes']):
  if {k:v for k,v in before.items() if k!='geometry'}!={k:v for k,v in after.items() if k!='geometry'}:raise ValueError('Non-geometry node field changed')
 output.mkdir(parents=True,exist_ok=False);(output/'graph.json').write_bytes(payload)
 (output/'geometry_proof.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
 receipt=dict(status='VERIFIED_ADDITIVE_INLINE_GEOMETRY_EXPORT',request=request,CPU_units=consumer['CPU_units'],graph=descriptor(output/'graph.json'),proof=descriptor(output/'geometry_proof.json'),proof_source=dict(geoparquet=proof['geoparquet'],exceptions=proof['source_exceptions']),input_graph_bytes=Path(graph_ref['path']).stat().st_size,output_graph_bytes=len(payload),output_gzip_bytes=len(gzip.compress(payload,mtime=0)),embedded_geometries=proof['embedded_geometries'],source_model_unchanged=True,identity_rerun=False,citations_added_by_this_adapter=False,publication=False)
 (output/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');return receipt

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--consumer',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
 print(json.dumps(prepare_export(descriptor(args.consumer),args.output),indent=2))
