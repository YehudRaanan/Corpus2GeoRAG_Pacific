# GeoJSON geometry export adapter v1

Pure callable: `add_geojson_geometry(graph_dict, geo_handoff_descriptor) -> (new_graph_dict, geometry_proof)` from `geometry_export.py`. The GEO descriptor is the exact pinned `consumer_handoff.request.geo_handoff`. PUBLISHER verifies that consumer binding and supplies its graph, either before or after E2's citation/page-ID adapter. The function writes nothing and preserves every existing non-geometry field, all edges, source identities and node order.

Add only `nodes[type=location].geometry`, a GeoJSON Geometry object with `type` and `coordinates`; the enclosing node `type` remains `location`. Join `node.wikidata_id == GeoParquet.place_id` and require `node.id == place_id + "::LOC"`. Example from verified935: `Q10393::LOC` (Bogor) receives `{"type":"Point","coordinates":[106.79926333333333,-6.597802777777778]}`. Existing same-QID ORG/PER/MISC nodes do not inherit geometry.

Source CRS must be EPSG:4326, with stored longitude/latitude coordinates. Every point and polygon coordinate is preserved; no reprojection, simplification, new retrieval or geometry selection occurs. GeoJSON roundtrip must reproduce exact source WKB. The GeoParquet and Geography model remain authoritative, unchanged and hash-pinned.

Every active location node must have a verified in-scope geometry. Missing/unknown geometry is an export error rather than a null active location. Unknown, outside and inside-position-pending identities remain explicitly listed in the separate geometry proof and referenced durable source exceptions; they are not introduced into the active graph. Duplicate identities, conflicting inline geometry, wrong CRS and changed source hashes are rejected.

`prepare_export(verified_consumer_descriptor, unique_adapter_owned_output_dir)` demonstrates an isolated complete geometry export. It emits compact JSON and receipts under this adapter directory. Verified935 preserves1756nodes/18562edges and embeds619geometries. Its geometry-only graph is7,486,111bytes, gzip1,633,310bytes; citations will add their own size.

Integration: after materialization of each verified immutable consumer, PUBLISHER composes E2 citation/page-ID enrichment and `add_geojson_geometry`, writes one new versioned final graph, and regenerates the final artifact hashes/consumer receipt. Apply the same call to935without rerunning identity resolution. This module does not add citations, alter live outputs, publish, or start a pipeline; INTEGRATION owns recurring wiring and PUBLISHER owns the final combined export.
