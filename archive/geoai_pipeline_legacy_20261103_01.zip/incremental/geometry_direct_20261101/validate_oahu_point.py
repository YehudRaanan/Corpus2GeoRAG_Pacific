"""Existing native-Point adapter for the accepted Oahu LOC; no network access."""
from pathlib import Path
import sys
import validate_tokyo as shared
from GG_Data.pipeline.geography_coordinate_sample import coordinate, fallback_point

HERE, ROOT = shared.HERE, shared.ROOT
SOURCE = HERE / 'oahu_public_0001'
OUT = HERE / 'oahu_point_handoff_0001'


def verify():
    receipt = shared.read_json(OUT / 'verification.json')
    assert all(shared.digest(OUT / name) == sha for name, sha in receipt['files'].items())
    assert all(shared.digest(Path(name)) == sha for name, sha in receipt['inputs'].items())
    handoff = shared.read_json(OUT / 'handoff.json')
    native = shared.read_json(SOURCE / 'raw_response.json')['entities']['Q131347']
    evidence = coordinate(native)
    point = fallback_point(evidence, has_geometry=False)
    assert evidence['xy'] == [-157.965,21.485] and native['lastrevid'] == 2555305862
    assert handoff['coordinate_evidence'] == evidence
    assert handoff['source_item_revision'] != handoff['processing_revision_id']
    assert handoff['source_item_revision'] == native['lastrevid']
    frame = shared.gpd.read_parquet(OUT / 'model/geometries.parquet')
    assert len(frame) == 1 and frame.iloc[0]['place_id'] == 'Q131347'
    assert shared.CRS(frame.crs) == shared.CRS.from_epsg(4326)
    actual = frame.geometry.iloc[0]
    assert actual.is_valid and not actual.is_empty and actual.geom_type == 'Point'
    assert actual.wkb == point.wkb and actual.x == -157.965 and actual.y == 21.485
    rows = shared.read_json(OUT / 'model/geography.json.gz')
    geometries = shared.load_geometries([rows[0]['geometry_ref']], OUT / 'model', required_crs='EPSG:4326')
    assert set(geometries) == {'Q131347'} and geometries['Q131347'].wkb == point.wkb
    assert shared.digest(OUT / 'graph.json') == shared.digest(shared.PUBLISHER / 'graph.json')
    store = shared.GraphStore.from_json(OUT / 'graph.json', model_dir=OUT / 'model')
    assert len(store.nodes) == 10 and not store.edges and set(store.geoms) == {'Q131347::LOC'}
    assert store.geoms['Q131347::LOC'].wkb == point.wkb
    return receipt


def run():
    source_receipt = shared.read_json(SOURCE / 'receipt.json')
    assert source_receipt['requests_attempted'] == 1 and source_receipt['http_status'] == 200
    assert shared.digest(SOURCE / 'raw_response.json') == source_receipt['raw_response_sha256']
    native = shared.read_json(SOURCE / 'raw_response.json')['entities']['Q131347']
    evidence = coordinate(native)
    assert evidence == shared.read_json(SOURCE / 'coordinate_evidence.json')
    point = fallback_point(evidence, has_geometry=False)
    assert point.x == -157.965 and point.y == 21.485
    unit_root = ROOT / 'integration_direct_20261101/real_handoff_0001'
    unit = shared.read_json(unit_root / 'receipt.json')
    assert shared.digest(unit_root / 'aggregate.json') == unit['output_sha256']['aggregate.json']
    aggregate = shared.read_json(unit_root / 'aggregate.json')
    members = [x for x in aggregate['occurrences'] if x['decision_values'] == ['Q131347']]
    assert len(members) == 1 and not members[0]['identity_conflict']
    assert next(x for x in aggregate['typed_counts'] if x['qid']=='Q131347' and x['entity_group']=='LOC')['mention_count'] == 1
    OUT.mkdir()
    model, private = OUT / 'model', OUT / 'private'
    model.mkdir()
    private.mkdir()
    shared.shutil.copyfile(shared.PUBLISHER / 'graph.json', OUT / 'graph.json')
    for name in ['entities.json.gz','events.json.gz','relations.json.gz']:
        shared.shutil.copyfile(shared.PUBLISHER / 'model' / name, model / name)
    reason = shared.json.dumps(dict(source_item_revision=native['lastrevid'],source_modified=native['modified'],
        source_response_sha256=source_receipt['raw_response_sha256'],statement_id=evidence['statement']['id'],
        source_is_current=True,historical_extent_verified=False,policy='Original native Point for existing accepted LOC; no ranking or new identity.'))
    record = dict(place_id='Q131347',name=native['labels']['en']['value'],place_type='LOC',source_dataset='Wikidata',
        source_object_id=evidence['statement']['id'],source_url=source_receipt['source_url'],match_method='WIKIDATA_POINT_FALLBACK',
        selection_policy_version=None,retrieved_at=source_receipt['completed_at'],review_status='ACCEPTED_AUTO',decision_reason=reason)
    row = dict(record,selection_date=None,geometry=point)
    columns=['place_id','name','place_type','selection_date','source_dataset','source_object_id','source_url',
             'match_method','selection_policy_version','retrieved_at','review_status','decision_reason','geometry']
    frame = shared.gpd.GeoDataFrame([row],geometry='geometry',crs='EPSG:4326')[columns]
    frame.to_parquet(model / 'geometries.parquet',index=False)
    pointer = dict(file='geometries.parquet',place_id='Q131347',sha256=shared.digest(model / 'geometries.parquet'))
    geography = dict(record,geometry_ref=pointer)
    (model / 'geography.json.gz').write_bytes(shared.gzip.compress(shared.json.dumps([geography]).encode(),mtime=0))
    for name in ['receipt.json','raw_response.json','coordinate_evidence.json','native_item_claims.json']:
        shared.shutil.copyfile(SOURCE / name,private / name)
    handoff = dict(qid='Q131347',node_id='Q131347::LOC',type='LOC',page_id=unit['page_id'],processing_revision_id=unit['processing_revision_id'],
        decision_version=unit['decision_version'],accepted_occurrences=1,original_identity=members[0]['original_identity'],
        source_item_revision=native['lastrevid'],source_modified=native['modified'],source_url=source_receipt['source_url'],
        source_retrieved_at=source_receipt['completed_at'],source_response_sha256=source_receipt['raw_response_sha256'],
        source_is_current_not_historical_processing_revision=True,coordinate_evidence=evidence,geography_fragment=[geography],
        full_native_entity_artifact=str(SOURCE/'raw_response.json'),full_native_item_claims_artifact=str(SOURCE/'native_item_claims.json'),
        full_claims_receipt=str(SOURCE/'receipt.json'),geometry_type='Point',geometry_crs='EPSG:4326',new_identity=False,
        new_ranking=False,enrichment_status='ENRICHMENT_PENDING',
        merge_semantics='One Oahu Point addition only; preserve four prior verified LOC shapes and regenerate combined checksum/pointers.',
        caveat='Source position only; no historical footprint, Event extent or P625-to-P276 assertion. No historical selection date or numeric ranking version supplied.')
    (OUT / 'handoff.json').write_text(shared.json.dumps(handoff,ensure_ascii=False,indent=2),encoding='utf-8')
    paths = [SOURCE/name for name in ['raw_response.json','receipt.json','coordinate_evidence.json','native_item_claims.json','evidence_report.json']]
    paths += [unit_root/'receipt.json',unit_root/'aggregate.json',shared.PUBLISHER/'graph.json',HERE/'validate_tokyo.py',Path(__file__)]
    receipt = dict(status='VERIFIED_OAHU_NATIVE_POINT_HANDOFF',qid='Q131347',source_item_revision=2555305862,
        source_is_current=True,geometry_crs='EPSG:4326',xy=[-157.965,21.485],accepted_occurrences=1,source_exact_point_WKB=True,
        consumer_nodes=10,consumer_geometries=1,publication=False,
        inputs={str(p):shared.digest(p) for p in paths},files={p.relative_to(OUT).as_posix():shared.digest(p) for p in OUT.rglob('*') if p.is_file()},backup_status='Unprotected')
    (OUT/'verification.json').write_text(shared.json.dumps(receipt,indent=2),encoding='utf-8')
    verify()
    print(shared.json.dumps({k:v for k,v in receipt.items() if k not in ['inputs','files']},indent=2))


if __name__ == '__main__':
    if '--verify' in sys.argv:
        verify()
        print('PASS fresh Oahu readback: exact native Point, EPSG:4326, accepted original occurrence, current source revision/receipt and unchanged graph')
    else:
        run()
