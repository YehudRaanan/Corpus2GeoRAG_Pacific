# Actual first-unit geometry inputs: 4/5 found, no selection

Page 48975579 / processing revision 1375061414. The five LOC QIDs are derived from exact_unit_0001/decisions.json and independently reconciled with real_handoff_0001/aggregate.json. Both file hashes match the existing sealed handoff receipt. This is an input-availability report; no historical geometry decision was activated for this new unit.

| Actual identity | Saved direct P625 | Native P276 | Existing historical shape |
|---|---|---|---|
| Q1490 Tokyo | 1: longitude 139.69166666666666, latitude 35.68944444444445 | absent in this record | OSM relation:1543125, MultiPolygon |
| Q153732 Mariana Islands | 1: longitude 145.78, latitude 16.7 | absent | OSM relation:7811079, MultiPolygon |
| Q51679 Saipan | 1: longitude 145.75, latitude 15.183333333333; precision=null | Q159183 | OSM relation:3218318, Polygon |
| Q11751 Nagoya | 2: (136.9063888888889,35.18138888888889) and (136.90641,35.18147) | absent | OSM relation:4576938, Polygon |
| Q131347 | full native record not found in inspected lookup scope | unknown, not asserted absent | no row in inspected historical Geography/GeoParquet |

Existing local source files, under D:/Projects/GeoAI/GG_Data/pipeline/outputs/matching_penalty_poc_20261023/:

- entities/full_records.json.gz: all original native coordinate statements, ranks, precision, globe, references, P131/P17 and available P402/P3896/P1566 source IDs for the four found identities. SHA256 d8dd0f1dac81b66b45147acebb6138ed9e6e264722bd9ef8b45be9d6da21097f.
- entities/manifest.json: source provenance and snapshot_at 2026-10-18T18:45:19.304197+00:00. Native record lastrevid/modified are retained separately: they are Wikidata revisions, NOT this unit's Wikipedia processing revision.
- model_geography/geography.json.gz and geometries.parquet: four existing source selections with original source IDs, retrieval timestamp, recorded policy, source receipt and unchanged geometry pointer. GeoParquet SHA256 c79d836da965ef72aa2ff46c2dc687caf2052f42c15d83dc358f26dc23a938d8. Full-file hash and exactly one row for each found QID were checked using its place_id column; full shape decoding/validity was not run.
- geography_retrieval/sources/osm_bigquery_cache/71bc6f34949a6bad69666609eb05c781cd4267786dce0b840b0a1e29755eae0e.json.gz: existing source receipt named by all four selections; file exists and is hashed in the JSON report. Its complete source response was not decoded in this increment.
- recovery_20261024_workflow_v2/geography_ranked_v6/results.csv: existing saved per-QID shape type and recorded score. No scores were recalculated or generalized.

ACTUAL_UNIT_GEOMETRY_INPUTS.json contains ten exact source-file SHA256 values, complete P625/P276/context statements, original Geography rows, saved rank rows, snapshot/revision details, per-identity missing fields and linked-P276 target Geography lookup. Its JSON roundtrip was checked. No Q84 evidence is used for this actual unit.

Explicit gaps: Q131347 lacks a native record in the old model dictionary and no id/qid/QID-key hit was found in the local hashed full/current caches examined. The broader 53,857-line native archive had no Q131347 line-prefix hit; this is a bounded prefix check, NOT an exhaustive nested-record lookup or proof no local evidence exists. The four saved P625 records provide no temporal qualifiers establishing historical validity. Saipan's precision is null and Nagoya has two preserved alternatives; neither was repaired or collapsed. Linked-place geometry availability is recorded separately, not inferred from direct P625 or administrative parents. P3896 being present does not authorize its shape provider.

Next bounded step: read/decode only Tokyo Q1490's existing source-backed geometry and original P625, verify exact source receipt/object/QID and readback, and bind a PRIVATE evidence bundle to the actual accepted identity/unit while retaining historical source/context versions. Preserve its recorded shape and pending enrichment; do not select a new winner or equate the historical context with this processing revision. Q131347 can receive a separate exact native-record cache/archive lookup; it does not erase the four available inputs.

No external request, new geometry selection, technical LOC/QID, consumer export, source/shared-plan edit or nested session. Only owned reports written. No denied/uncertain operation. Remaining availability blocker is Q131347 in the inspected scope; full source-shape decoding is a next check, not claimed complete. Backup: Unprotected.
