# Oahu native Point handoff: verified

PASS in the creation run and independent fresh-process --verify. One valid nonempty Point is handed off for the existing Q131347::LOC: longitude -157.965, latitude 21.485, EPSG:4326. Existing coordinate() and fallback_point(has_geometry=False) use the unchanged official P625 statement. GeoParquet WKB exactly matches the Point created by that existing helper; the source is coordinate-valued JSON, not a source WKB file. No new coordinate, identity, technical LOC or ranking was introduced.

Source item revision 2555305862, modified 2026-10-09T11:12:44Z. Official URL: https://www.wikidata.org/w/api.php?action=wbgetentities&ids=Q131347&format=json . Saved response retrieval completed 2026-11-01T20:41:38.942597+00:00. Raw-response SHA256 d2db952ad2c59676c7a5f5c121f27afa125388b05ea1774ca2611aced6adec74. This is explicitly CURRENT Wikidata evidence, not the older snapshot or Wikipedia processing revision 1375061414. No additional network call occurred.

Unit binding: page 48975579 / processing revision 1375061414 / first-unit-exact-v1 / one accepted LOC occurrence. Original identity is source input SHA256 47141678ff0f67ef16c070b4beb58bb8b1273a1635d25fea875e241e48bdd006, original row index 97. The accepted aggregate matches the sealed handoff's pinned hash; the original occurrence identity is retained in handoff.json.

Publisher consumes the ADDITION FRAGMENT under geometry_direct_20261101/oahu_point_handoff_0001:

- handoff.json: identity/unit/current-source binding, complete coordinate evidence, source paths and Geography fragment. SHA256 fff219df514f6c50fda521c807015cc4d3cee55b0178113807db140609a674a3.
- model/geometries.parquet: one Q131347 row with existing legacy Geography columns. SHA256 53bc4e346d1a0dc3c8b94bc811bc1069741766b26b2600aa4c722f2848868ed5.
- model/geography.json.gz: matching existing {file,place_id,sha256} pointer; source/retrieval fields preserved. No historical selection date or numeric ranking-version claim is invented (nullable fields remain null).
- verification.json: all source/output hashes. SHA256 be2e11616e2775f5b3692f840b8d134652d5f47d343043325fac060f13b54c1c.
- private/: exact copies of official raw response, receipt, coordinate evidence and all 18 item-valued outgoing native claims.

Preserve the four previously verified LOC shapes during publisher merge and recompute the combined file hash/pointers. The isolated compatibility probe copies the unchanged original ten-node graph and Entity/Event/Relation files, then loads this one Point through load_geometries(required_crs='EPSG:4326') and GraphStore. Ten nodes, zero probe edges, exactly Q131347::LOC has geometry. This is adapter compatibility evidence, not replacement or validation of the publisher's newer relation frontier. Shared publisher files were not modified.

## Exact RELATIONS source paths

Full native entity/all claims: D:/Projects/GeoAI-incremental-dev-20261101/geometry_direct_20261101/oahu_public_0001/raw_response.json . The entity is at entities.Q131347; all native claims remain intact.

Complete extracted item-valued outgoing claims: D:/Projects/GeoAI-incremental-dev-20261101/geometry_direct_20261101/oahu_public_0001/native_item_claims.json . SHA256 a3bef85881e188a7764863525faf7b95e18a8ee71cdb79368f7d97810d1a47ca. All 18 preserve original statement IDs/ranks/qualifiers/references; no targets match the ten represented unit identities. Receipt: same folder/receipt.json; source evidence summary: same folder/evidence_report.json. This is Oahu outgoing coverage only, not an incoming/whole-unit complete native frontier or permission to infer fallback absence.

Enrichment remains pending privately while the Point supplies useful location. No historical footprint, Event extent or P625-to-P276 link is asserted. No external request, shared-file/plan write, consumer field, paid operation, publication or nested session. No remaining blocker/denied/uncertain action. Stage validate_oahu_point.py supports --verify. Backup: Unprotected.
