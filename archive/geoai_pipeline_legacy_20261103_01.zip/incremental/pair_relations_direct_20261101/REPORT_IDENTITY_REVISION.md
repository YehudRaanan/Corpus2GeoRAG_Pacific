# E5 / R7 - identity-decision revision invalidation fixture

2026-11-01: PASS for the isolated synthetic semantic/replay fixture. Eleven focused checks and eight independent fresh-process checks. Current real-unit pair views are explicitly a versioned interim projection of first-unit-exact-v1, not final relations.

Code: identity_revision_fixture.py. Evidence: identity_revision_20261101T203747075758Z/{revision_history.json,verification.json,independent_readback.json}.
No actual model call or real accepted-decision change occurred. The fixture supplies an explicit accepted revision labelled SIMULATED_POST_MODEL_ACCEPTED_REVISION, rather than inventing inference results or acceptance policy.

## Concrete before/after

Two original members of one unchanged raw group on page 1 explicitly change Q1 -> Q4 in decision v2, with prior_version pointing to v1. The page also contains Q2. A second unchanged page contains Q1 and Q3. The existing group helper retains the group ID, original source members/words/types and source scope; both per-occurrence decision updates are explicit. A raw group remains a unit of work, not a new rule that all group members must always share an identity.

| Identity | Mentions before -> after | Pages before -> after |
|---|---|---|
| Q1 | 3 -> 1 | 2 -> 1 |
| Q2 | 1 -> 1 | 1 -> 1 |
| Q3 | 1 -> 1 | 1 -> 1 |
| Q4 | 0 -> 2 | 0 -> 1 |

Old Q1/page1 contributions disappear while Q1/page2 remains. Pair Q1-Q2 shared-page count changes 1 -> 0 and its two active default views are removed. Pair Q2-Q4 changes 0 -> 1 and gets two default views. Pair Q1-Q3 retains one shared page but Q1's denominator changes 2 -> 1, so its copied outgoing weight changes 0.5 -> 1.0; both directional records update their denominator evidence. Native Q2-Q3 and its existing catalog inverse stay identical and reuse their old Python objects. The unchanged zero-count Q2-Q3 count row is likewise reused.

Both before and after have six active views: two old defaults are removed, two new defaults added, two denominator-bearing defaults updated, and the two native/inverse views remain unchanged. This is identity-decision reassignment, distinctly different from late arrival of a native assertion for unchanged identities. Native assertion endpoints are not rewritten to a different QID.

## Reused interfaces and evidence

The fixture calls existing group_mentions, fixture_unit closed source/membership inputs, E4 replace_unit/aggregate_units, the existing pair_counts formula, existing graph producer/catalog fixture, weighted_fallback and pair_frontier. Shared E2/custody/E4/count/group/selector files remain read-only. This uses their existing in-memory closed-handoff validation; it does not add a new E2 sealing/recovery implementation.

Original source members stay exact in every decision version. There are five unique original occurrences, five active support records, two physical pages, three decision versions across two units, and two pair-history versions. Before/after projections carry the exact supplied decision frontier. Both pair snapshots retain their original native/fallback/active evidence. Exact revision/unit/pair replay adds no version or count contribution. A complete synthetic rebuild is byte-identical.

RED baseline deliberately kept the old projection after replace_unit; it failed the stale Q1-Q2 fallback assertion. The explicit refresh then passed all eleven checks. A separate Python process replayed saved initial/revised handoffs, compared both projections/histories, independently counted mentions/page sets from latest raw decisions without pair_counts, checked literal pair/denominator deltas, validated raw-group identity/member preservation, and verified code/payload/shared-code/real-input hashes. It confirmed exact replay and all five original occurrences.

## Missing invalidation hooks - not claimed complete

1. The current real-unit run_real_pair_views.py reads a fixed first-unit-exact-v1 count artifact; it has NO automatic notification/subscription from a newer accepted identity/count receipt. Its current results must remain labelled interim and version-bound. A new accepted decision frontier needs to invalidate/rebuild its dependent pair projection, using a consistent new count/native frontier.
2. The fixture's refresh_projection is an EXPLICIT call. It computes reference counts with the existing full-rebuild counter, then replaces only differing output rows, preserving unchanged pair/native objects. This verifies affected-output semantics; it does NOT implement recomputation only for affected dependencies. A durable affected-identity/page/denominator/pair index and production trigger are still missing. No performance or bounded-production-computation claim is made.
3. In a real QID reassignment, availability/source selection/linkability must be refreshed for newly represented IDs; missing full native coverage must stay pending. A raw-group QID change must never blindly relabel an old QID's native statement. This fixture uses a declared synthetic available-native frontier and an unaffected Q2-Q3 assertion; it does not prove model-to-native-acquisition invalidation.
4. Decision/pair snapshots are JSON inspection artifacts and in-memory history, not an atomic durable cross-stage transaction or production recovery protocol.

The next concrete implementation step is a separately scoped, version-keyed local dispatcher from a validated newer E2/E4/count receipt to an affected-pair refresh, retaining the old projection and rejecting mixed frontiers. Targeted dependency recomputation can then be verified against this existing full reference fixture. Consumer contracts and weight serialization remain unchanged.

Only pair_relations_direct_20261101 was written. Hashes confirm the real sealed accepted decisions and actual pair_views artifact are unchanged. No external calls, training, paid work, nested agents, installation, publication or security changes. Backup: Unprotected.
