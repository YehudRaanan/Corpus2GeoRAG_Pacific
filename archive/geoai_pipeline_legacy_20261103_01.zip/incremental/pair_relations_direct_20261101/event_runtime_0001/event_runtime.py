"""Versioned source-bound Event scope and model-row wiring; caller supplies policy values."""
import hashlib,importlib.util,json,sys
from copy import deepcopy
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
sys.path.insert(0,r'D:\Projects\GeoAI')
from GG_Data.pipeline.event_model import event_rows
SCOPE_PATH=ROOT/'event_scope_direct_20261101/event_scope.py'
spec=importlib.util.spec_from_file_location('approved_event_scope',SCOPE_PATH);scope_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(scope_module)
def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def pinned(descriptor):
 if sha(descriptor['path'])!=descriptor['sha256']:raise ValueError('Input hash differs: '+descriptor['path'])
 return read(descriptor['path'])
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf8')
def verified_result(receipt):
 for descriptor in receipt['result']['input_pins'].values():
  if sha(descriptor['path'])!=descriptor['sha256']:raise ValueError('Historical input hash differs')
 for descriptor in receipt['result']['artifacts'].values():
  if sha(descriptor['path'])!=descriptor['sha256']:raise ValueError('Prior artifact hash differs')
 return receipt['result']

def materialize_event_route(*,native_evidence,identity_projection,native_registry,output_dir,scope_config=None,event_selection=None,previous=None):
 """Connect existing pure processors. Neither configured anchors nor Event selection is inferred."""
 output=Path(output_dir).resolve()
 if not output.is_relative_to(HERE):raise ValueError('Output leaves ownership')
 inputs=dict(native_evidence=native_evidence,identity_projection=identity_projection,native_registry=native_registry)
 loaded={name:pinned(descriptor) for name,descriptor in inputs.items()}
 binding={name:descriptor['sha256'] for name,descriptor in inputs.items()}
 supplied={}
 for name,descriptor in [('scope_config',scope_config),('event_selection',event_selection)]:
  if descriptor is None:continue
  value=pinned(descriptor)
  if not value.get('version') or value.get('input_binding')!=binding:raise ValueError(name+' version/input binding differs')
  supplied[name]=value
 if previous is not None:verified_result(pinned(previous))
 request=dict(inputs=inputs,scope_config=scope_config,event_selection=event_selection,previous=previous,code_sha256=sha(__file__),
  dependencies={str(SCOPE_PATH):sha(SCOPE_PATH),str(Path(sys.modules[event_rows.__module__].__file__)):sha(Path(sys.modules[event_rows.__module__].__file__))})
 marker=output/'receipt.json'
 if output.exists():
  if not marker.exists():raise ValueError('Incomplete generation exists; use a new output')
  receipt=read(marker)
  if receipt['request']!=request:raise ValueError('Changed request cannot overwrite generation')
  return verified_result(receipt)
 records={q:deepcopy(row['envelope']['entity']) for q,row in loaded['native_registry']['selected_references'].items()}
 sources={q:deepcopy(row['provenance']) for q,row in loaded['native_registry']['selected_references'].items()}
 for q,row in loaded['native_evidence'].items():
  record=deepcopy(row['raw_record'])
  if record.get('id')!=q or 'claims' not in record:raise ValueError('Native Event source identity differs')
  if record.get('lastrevid')!=row['revision'] or record.get('modified')!=row['modified']:raise ValueError('Native Event revision metadata differs')
  if q in records and records[q]!=record:raise ValueError('Conflicting source records for '+q)
  records[q]=record
  sources[q]=dict(provider='WIKIDATA',file=row['source']['path'],sha256=row['source']['sha256'],line=row['source']['line'],record_id=q,revision=row['revision'],modified=row['modified'])
 config=supplied.get('scope_config');missing=[]
 if config is None or any(key not in config for key in ('anchors','predicates')):
  scope_status='PENDING_CONFIGURATION';missing=['G6 anchor_qids','G6 allowed_direct_predicates']
  scope=dict(candidates=[],opened_records=[],source_pending=[],configuration_pending=missing)
 else:
  geo=config.get('geo',{})
  if any(type(value) not in (bool,type(None)) for value in geo.values()):raise ValueError('Expected explicit LOC inclusion booleans/unknowns')
  scope=scope_module.expand(config['anchors'],records,config.get('kinds',{}),config['predicates'],geo)
  scope_status='EXECUTED_CONFIGURED_SCOPE'
  if any(row['inclusion']=='PENDING_GEO' for row in scope['candidates']):missing.append('G7 LOC mask/type/boundary/unknown decisions')
 selection=supplied.get('event_selection');entities=[];events=[];pending=[];decisions=[]
 if selection is None:population_status='PENDING_SELECTION';missing.append('Event selection/WWII scope evidence')
 else:
  decisions=selection['decisions'];seen=set()
  for decision in decisions:
   q=decision['qid']
   if q in seen or type(decision.get('keep_event')) is not bool:raise ValueError('Expected unique explicit Event selection decisions')
   seen.add(q)
   if not decision['keep_event']:continue
   if q not in records:pending.append(dict(qid=q,reason='MISSING_SELECTED_EVENT_NATIVE_RECORD'));continue
   entity,event=event_rows(records[q],sources[q],deepcopy(decision))
   # The existing serializer's frozen-POC default says BIGQUERY; preserve actual supplied provenance.
   entity['reference_source']=sources[q]['provider']
   entities.append(entity);events.append(event)
  population_status='PARTIAL_SOURCE_PENDING' if pending else 'MATERIALIZED_SUPPLIED_SELECTION'
 output.mkdir(parents=True)
 values=dict(scope=scope,entities=entities,events=events,selection=dict(decisions=decisions,source_pending=pending))
 artifacts={}
 for name,value in values.items():
  path=output/(name+'.json');write(path,value);artifacts[name]=dict(path=str(path),sha256=sha(path))
 result=dict(status='EVENT_ADAPTER_BRANCHES_EXECUTED' if scope_status=='EXECUTED_CONFIGURED_SCOPE' or selection is not None else 'PENDING_SUPPLIED_EVENT_INPUTS',scope_status=scope_status,event_population_status=population_status,
  input_binding=binding,scope_config_version=config.get('version') if config else None,event_selection_version=selection.get('version') if selection else None,
  input_pins=inputs,artifacts=artifacts,previous=previous,pending_inputs=missing,
  policy_authority='SUPPLIED_VALUES_ONLY_NO_APPROVAL_INFERRED',purposes={k:v.get('purpose') for k,v in supplied.items()},
  identity_decisions_changed=False,consumer_materialized=False,publication=False)
 write(marker,dict(request=request,result=result));return result
