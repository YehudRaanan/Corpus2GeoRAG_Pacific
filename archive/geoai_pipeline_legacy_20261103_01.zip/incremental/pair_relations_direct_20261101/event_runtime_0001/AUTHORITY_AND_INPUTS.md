# Authority and exact remaining Event configuration

The trusted owner transcript approves implementation and the structure: scoped Events anchor direct entities, plus one more hop only when it leads to a relevant place; broad geography applies only to LOC. Import Events belonging to supplied WIKI pages and those completed from previous revisions, preserving their source/revision lineage, with WWII relevance handled by the appropriate supplied Event-scope evidence. The plan approval authorizes implementing this wiring. It does not provide concrete anchor QIDs, predicate configuration, numeric mask or a period/type allowlist.

Exact local-plan labels (GEOAI_DEVELOPMENT_PLAN.md, lines199-200):
- G6 - Event anchor list and native expansion predicates: before Event/entity scope inclusion.
- G7 - Pacific LOC mask, eligible LOC types and boundary/unknown treatment: before LOC inclusion filtering.

G6 missing concrete values: an approved/versioned anchor_qids list, allowed_direct_predicates in wd:P... spelling, and supplied endpoint type evidence. Traversal depth is already fixed and requires no new architectural decision. The four previously separate-route QIDs are candidate evidence, not an approved anchor configuration. Do not confuse a selected scope anchor with automatic acceptance of a raw mention.

Smallest concrete G6 review example remains a single bounded native path: proposed Q713516 plus wd:P276 only. Actual source revision2554046065 contains statement Q713516$01B63485-132B-48B7-84B3-425F1BD5C12C -> Q328121. This is a source-backed decision example, not a selected or applied runtime policy. A larger wd:P710 scope would expose20 native participants and is a separate choice. The tests parameterize the existing processor without recording runtime approval.

G7 missing concrete values: a versioned broad-Pacific mask artifact/hash or exact numeric boundaries and reference system; eligible LOC type evidence; boundary/island/dateline handling; unknown-coordinate treatment. No numeric region was supplied. Current source discovery may retain unknowns as pending; it may not invent geographic inclusion or use a LOC mask to filter Event/PER scope.

Other precise missing inputs are independent of G6/G7: complete native Event ancestry at the first missing cached classes Q198/Q2380335/Q645883/Q6982012; a supplied existing-policy Event selection/WWII relevance artifact bound to the actual source/decision frontier; and PUBLISHER's remaining Event component connection. The callable now wires approved processors and preserves these pending cases. It does not pretend that supplied page names, raw dates, cooccurrence or an old frozen selection establish the missing decisions.

No routine approval question is issued to the sleeping owner. Parent can present the concrete choices in the morning. No implementation permission is being requested again, and no unrelated entity/source work is held back.
