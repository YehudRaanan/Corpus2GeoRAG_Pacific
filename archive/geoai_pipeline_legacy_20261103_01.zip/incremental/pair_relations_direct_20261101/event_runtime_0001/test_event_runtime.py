import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from event_runtime import materialize_event_route,sha
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
NATIVE=ROOT/'pair_relations_direct_20261101/event_execution_0001/generation_001/native_event_evidence.json'
PROJECTION=ROOT/'orchestration_direct_20261101/consumer_unit9_registry194_v1/unit9/projection.json'
REGISTRY=ROOT/'pair_relations_direct_20261101/unit9_sources_0001/generation_003/native_registry.json'
def desc(path):return dict(path=str(path),sha256=sha(path))
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
class RuntimeTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(dir=HERE);self.base=Path(self.temp.name)
  self.inputs=dict(native_evidence=desc(NATIVE),identity_projection=desc(PROJECTION),native_registry=desc(REGISTRY))
  self.binding={k:v['sha256'] for k,v in self.inputs.items()}
 def tearDown(self):
  assert self.base.resolve().is_relative_to(HERE.resolve());self.temp.cleanup()
 def config(self,name,**values):
  path=self.base/(name+'.json');path.write_text(json.dumps(dict(version=name,input_binding=self.binding,purpose='DEVELOPMENT_PARAMETERIZATION_ONLY_NOT_RUNTIME_APPROVAL',**values)),encoding='utf8');return desc(path)
 def run_route(self,name,**extra):
  with patch('urllib.request.urlopen',side_effect=AssertionError('No network')),patch('requests.get',side_effect=AssertionError('No network')):
   return materialize_event_route(output_dir=self.base/name,**self.inputs,**extra)
 def test_missing_inputs_retain_pending_without_expansion(self):
  result=self.run_route('missing');self.assertEqual(result['status'],'PENDING_SUPPLIED_EVENT_INPUTS');self.assertEqual(result['scope_status'],'PENDING_CONFIGURATION');self.assertEqual(result['event_population_status'],'PENDING_SELECTION');self.assertEqual(read(result['artifacts']['events']['path']),[])
  incomplete=self.run_route('incomplete',scope_config=self.config('incomplete'));self.assertEqual(incomplete['status'],'PENDING_SUPPLIED_EVENT_INPUTS')
 def test_real_native_one_predicate_loc_unknown_remains_pending(self):
  config=self.config('one',anchors=['Q713516'],predicates=['wd:P276'],kinds={'Q328121':'LOC'},geo={})
  result=self.run_route('one',scope_config=config);scope=read(result['artifacts']['scope']['path'])
  self.assertEqual(len(scope['candidates']),1);self.assertEqual(scope['candidates'][0]['qid'],'Q328121');self.assertEqual(scope['candidates'][0]['inclusion'],'PENDING_GEO');self.assertTrue(scope['candidates'][0]['path'][0]['source_record_id'].startswith('Q713516$'))
 def test_real_loc_exclusion_retains_native_path(self):
  config=self.config('outside',anchors=['Q713516'],predicates=['wd:P276'],kinds={'Q328121':'LOC'},geo={'Q328121':False})
  row=read(self.run_route('outside',scope_config=config)['artifacts']['scope']['path'])['candidates'][0]
  self.assertEqual(row['inclusion'],'EXCLUDE');self.assertIn('raw_statement',row['path'][0])
 def test_existing_event_serializer_independent_of_missing_scope_config(self):
  selection=self.config('selection',decisions=[{'qid':'Q713516','keep_event':True}])
  result=self.run_route('selected',event_selection=selection);events=read(result['artifacts']['events']['path']);entities=read(result['artifacts']['entities']['path'])
  self.assertEqual([r['event_id'] for r in events],['Q713516']);self.assertEqual(entities[0]['type'],'event');self.assertEqual(entities[0]['reference_source'],'WIKIDATA');self.assertEqual(entities[0]['attributes']['mention_ids'],[]);self.assertEqual(result['scope_status'],'PENDING_CONFIGURATION')
  original=read(NATIVE)['Q713516']['raw_record'];self.assertEqual(events[0]['temporal_evidence']['claims']['P585'],original['claims'].get('P585',[]))
 def test_stale_configuration_and_bad_source_hash_rejected(self):
  config=self.config('stale',anchors=[],predicates=[],kinds={},geo={});value=read(config['path']);value['input_binding']['identity_projection']='stale';Path(config['path']).write_text(json.dumps(value));config=desc(Path(config['path']))
  with self.assertRaisesRegex(ValueError,'binding'):self.run_route('stale',scope_config=config)
  self.inputs['native_evidence']['sha256']='wrong'
  with self.assertRaisesRegex(ValueError,'hash'):self.run_route('bad')
 def test_replay_does_not_rewrite_and_changed_request_rejected(self):
  result=self.run_route('replay');directory=self.base/'replay';before={p.name:(sha(p),p.stat().st_mtime_ns) for p in directory.iterdir()}
  self.assertEqual(self.run_route('replay'),result);self.assertEqual(before,{p.name:(sha(p),p.stat().st_mtime_ns) for p in directory.iterdir()})
  config=self.config('different',anchors=[],predicates=[],kinds={},geo={})
  with self.assertRaisesRegex(ValueError,'request'):self.run_route('replay',scope_config=config)
 def test_previous_generation_preserved_as_hash_bound_history(self):
  first=self.run_route('first');previous=desc(self.base/'first/receipt.json');second=self.run_route('second',previous=previous)
  self.assertEqual(second['previous'],previous);self.assertEqual(first,read(previous['path'])['result'])
 def test_native_revision_mismatch_rejected(self):
  value=read(NATIVE);value['Q713516']['revision']='wrong';path=self.base/'wrong_revision.json';path.write_text(json.dumps(value),encoding='utf8');self.inputs['native_evidence']=desc(path)
  with self.assertRaisesRegex(ValueError,'revision'):self.run_route('wrong_revision')
 def test_changed_historical_input_hash_rejected(self):
  self.run_route('history');value=read(self.base/'history/receipt.json');value['result']['input_pins']['identity_projection']['sha256']='wrong';path=self.base/'bad_history.json';path.write_text(json.dumps(value),encoding='utf8')
  with self.assertRaisesRegex(ValueError,'hash'):self.run_route('new_history',previous=desc(path))
if __name__=='__main__':unittest.main()
