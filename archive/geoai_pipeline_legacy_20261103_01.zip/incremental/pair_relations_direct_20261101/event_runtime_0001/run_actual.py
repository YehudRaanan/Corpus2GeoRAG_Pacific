"""Read-only actual firstnine v2 decision frontier -> pending-input Event wiring receipt."""
import json
from pathlib import Path
from unittest.mock import patch
from event_runtime import materialize_event_route,sha,read,write,HERE,ROOT

def descriptor(path,expected=None):
 path=Path(path);value=sha(path)
 if expected is not None:assert value==expected
 return dict(path=str(path),sha256=value)
def main():
 projection=ROOT/'orchestration_direct_20261101/policy_v2_sources_0276_0001/unit_10/projection.json'
 registry=ROOT/'pair_relations_direct_20261101/accepted11_20_sources_0001/generation_014/native_registry.json'
 inputs=dict(native_evidence=descriptor(ROOT/'pair_relations_direct_20261101/event_execution_0001/generation_001/native_event_evidence.json'),
  identity_projection=descriptor(projection,'8d3a407f9010c5488fed0346259a7237a9305078f297b8454077209ee75473dd'),
  native_registry=descriptor(registry,'f1bf0d890542e63557d18af13e6067e3e8da3768e0a50543432516c0db5fb0dc'))
 before={d['path']:(sha(d['path']),Path(d['path']).stat().st_mtime_ns) for d in inputs.values()};output=HERE/'actual_firstnine_v2_0001'
 with patch('urllib.request.urlopen',side_effect=AssertionError('No network')),patch('requests.get',side_effect=AssertionError('No network')):
  result=materialize_event_route(output_dir=output,**inputs)
  hashes={p.name:(sha(p),p.stat().st_mtime_ns) for p in output.iterdir()}
  assert materialize_event_route(output_dir=output,**inputs)==result
  assert hashes=={p.name:(sha(p),p.stat().st_mtime_ns) for p in output.iterdir()}
 assert result['status']=='PENDING_SUPPLIED_EVENT_INPUTS' and result['scope_status']=='PENDING_CONFIGURATION' and result['event_population_status']=='PENDING_SELECTION'
 assert read(result['artifacts']['events']['path'])==[] and read(result['artifacts']['entities']['path'])==[]
 assert before=={p:(sha(p),Path(p).stat().st_mtime_ns) for p in before}
 data=read(projection);active=[v[-1] for v in data['count_state']]
 proof=dict(status='PASS_ACTUAL_EVENT_WIRING_PENDING_INPUTS',processor=descriptor(HERE/'event_runtime.py'),receipt=descriptor(output/'receipt.json'),
  source_units=len(active),source_occurrences=sum(len(v['occurrences']) for v in active),actual_inputs=inputs,
  scope_status=result['scope_status'],event_population_status=result['event_population_status'],
  tests_passed=9,test_output=descriptor(HERE/'tests.log'),replay_network_forbidden=True,replay_files_unchanged=True,external_inputs_unchanged=True,
  approved_structure_wired=True,anchors_invented=False,LOC_mask_invented=False,period_type_allowlist_invented=False,
  full_Event_route_complete=False,identity_or_integration_state_changed=False,publication=False)
 write(HERE/'verification.json',proof);print(json.dumps(proof))
if __name__=='__main__':main()
