# Event runtime wiring interface

Entry point: event_runtime.py::materialize_event_route. All arguments are keyword-only:

- native_evidence: {path,sha256}, the existing native_event_evidence.json with whole Event records and original source lineage.
- identity_projection: {path,sha256}, the exact current decision/count frontier JSON.
- native_registry: {path,sha256}, an existing source-only native registry. Accepted entity source work can continue independently of missing Event configuration.
- output_dir: a NEW directory under event_runtime_0001. Identical replay of an existing request reads only; changed requests cannot overwrite it.
- scope_config: optional {path,sha256}; omitted/unprovided values yield PENDING_CONFIGURATION.
- event_selection: optional {path,sha256}; omitted yields PENDING_SELECTION. This is supplied existing-policy selection, not an adapter-produced acceptance decision.
- previous: optional {path,sha256} pointing to an earlier receipt.json. Earlier artifacts and input hashes are verified; history is linked without copying or rewriting earlier generations.

The configuration/selection JSONs each require a nonempty version and input_binding={native_evidence:SHA,identity_projection:SHA,native_registry:SHA} matching those inputs. Configuration supplies anchors, predicates, and optional kinds/geo maps for the unchanged event_scope.expand function. Missing endpoint types and missing LOC geographic decisions remain PENDING_TYPE/PENDING_GEO. Geographic decisions never filter direct non-LOC candidates. The existing fixed two-hop implementation is imported read-only; no third hop is added.

Selection supplies the existing decisions list, including qid and explicit boolean keep_event. Only supplied keep_event=true records call GG_Data.pipeline.event_model.event_rows. No legacy POC relevance threshold, period type allowlist, inferred anchor or native ancestry success is manufactured here. Missing selected native records remain explicit source_pending while other selected records can be formatted. Supplied selection must already have the appropriate Event/WWII scope authority/evidence; hashes alone are not a semantic approval. The adapter does not claim otherwise. Its purpose fields preserve development-only test labels.

Scope expansion and native Event-row formatting are independent branches. A missing scope config does not stop a supplied valid selection from being formatted. Missing selection does not stop explicitly configured source discovery. Neither branch changes raw occurrence/QID decisions or global counts. The serializer's frozen BIGQUERY reference_source default is corrected to the actual supplied source provider; raw native dates and derivation stay with the existing serializer unchanged. No fake Event mentions or location geometries are added.

Outputs: receipt.json binds request, dependencies, sources, previous history and artifact hashes. artifacts.entities is standard event-typed Entity additions, artifacts.events is the existing Events table format, artifacts.scope preserves native paths/inclusion outcomes, artifacts.selection preserves supplied decisions and source gaps. Consumer materialization/publication are explicitly false. These artifacts are producer inputs, not evidence that PUBLISHER or full Event processing ran.

Actual call/readback: run_actual.py pins the actual firstnine v2 projection SHA8d3a407f9010c5488fed0346259a7237a9305078f297b8454077209ee75473dd and final registry340 SHAf1bf0d890542e63557d18af13e6067e3e8da3768e0a50543432516c0db5fb0dc. No concrete approved scope config or Event selection was supplied. Its actual_firstnine_v2_0001 outputs therefore retain PENDING_SUPPLIED_EVENT_INPUTS, with zero invented Event business rows. This is different from the nine unit tests, whose positive real-record parameterization is explicitly DEVELOPMENT_PARAMETERIZATION_ONLY_NOT_RUNTIME_APPROVAL and is kept in temporary test directories.

Downstream owned seam: PUBLISHER's component_materializer_0001/materialize_components.py currently calls build_graph(entities,[],...) and writes events.json.gz as an empty list. That owner can feed the supplied selection's typed Event additions/Events into the existing graph export path after scope/selection sources are available, preserving its original count/decision frontier. This adapter does not silently change that consumer or invent count support for source-only Events.
