"""One real-unit local source selection -> existing relation scan -> private pair views."""
import csv
import gzip
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import ijson

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MAIN = Path(r"D:\Projects\GeoAI")
sys.path.insert(0, str(MAIN))
from GG_Data.pipeline.entities import select_reference, choose_name
from GG_Data.pipeline.relations import scan, populate
from GG_Data.pipeline.graph_export import build_graph
from combined_pair_fixture import weighted_fallback
from pair_relations import pair_frontier, digest, encoded


def run():
    audit_path = HERE / "real_native_cache_audit_0001.json"
    audit = json.loads(audit_path.read_text())
    readiness = json.loads((HERE / "real_pair_readiness_0001.json").read_text())
    assert digest(audit_path) == readiness["audit_sha256"]
    protected = dict(audit["protected_sha256"])
    protected.update({str(HERE / name): digest(HERE / name) for name in
                      ("real_native_cache_audit_0001.json", "real_pair_readiness_0001.json", "pair_relations.py", "combined_pair_fixture.py")})
    for path in (MAIN / "GG_Data/pipeline/entities.py", MAIN / "GG_Data/pipeline/relations.py",
                 MAIN / "GG_Data/pipeline/graph_export.py", MAIN / "GG_Data/mapping/ASSERTION_EXCLUSIONS.csv",
                 MAIN / "GG_Data/mapping/assertion_exclusions.py"):
        protected[str(path)] = digest(path)
    assert all(digest(Path(path)) == expected for path, expected in protected.items())
    coverage = {row["qid"]: row for row in audit["coverage"] if row["full_claims_record_available"]}
    qids = set(coverage)
    assert len(qids) == 9 and "Q131347" not in qids
    available = {qid: [] for qid in qids}
    query_meta = {row["file"]: row for row in readiness["query_cache_provenance"]}
    for file in sorted({v["file"] for row in coverage.values() for v in row["full_record_versions"]}):
        path = Path(file)
        if file in query_meta:
            with gzip.open(path, "rb") as stream:
                for index, row in enumerate(ijson.items(stream, "rows.item")):
                    if row["id"] in qids:
                        envelope = dict(requested_qid=row["id"], entity=json.loads(row["item"].rstrip(",\n\r ")))
                        provenance = dict(provider="BIGQUERY", file=file, sha256=protected[file], row_index=index,
                            snapshot_at=readiness["table_snapshot_at"], retrieved_at=query_meta[file]["retrieved_at"], record_id=row["id"])
                        available[row["id"]].append((envelope, provenance))
        else:
            lines = {v["locator"]["line"] for row in coverage.values() for v in row["full_record_versions"] if v["file"] == file}
            with gzip.open(path, "rt", encoding="utf-8") as stream:
                for line, text in enumerate(stream, 1):
                    if line in lines:
                        envelope = json.loads(text)
                        qid = envelope["requested_qid"]
                        available[qid].append((envelope, dict(provider="WIKIDATA", file=file, sha256=protected[file], line=line, record_id=qid)))
                    if line >= max(lines):
                        break
    selected = {}
    for qid in sorted(qids):
        pinned = [pair for pair in available[qid] if pair[1]["provider"] == "BIGQUERY"]
        assert not pinned or all(pair[0] == pinned[0][0] for pair in pinned)
        envelope, provenance = select_reference(qid, pinned[0] if pinned else None, available[qid])
        selected[qid] = dict(envelope=envelope, provenance=provenance,
                             policy="SNAPSHOT_FIRST" if pinned else "LATEST_AVAILABLE_COMPLETE_SAME_ID",
                             entity_revision=envelope["entity"].get("lastrevid"), entity_modified=envelope["entity"].get("modified"))
    counts_path = ROOT / "counts_direct_20261101/real_counts_20261101T202248289937Z/counts.json"
    counts = json.loads(counts_path.read_text())
    entities = []
    for row in counts["typed_counts"]:
        qid = row["qid"]
        if qid in selected:
            reference = selected[qid]
            name = choose_name(qid, reference["envelope"]["entity"], {}, [])
            entities.append(dict(entity_id=qid, type=row["entity_group"], name=name["value"], aliases=[],
                                 name_selection=name, raw_reference=dict(full=reference["envelope"]), sources=[reference["provenance"]]))
    def read_csv(path):
        with path.open(encoding="utf-8-sig", newline="") as stream:
            return list(csv.DictReader(stream))
    mapping = read_csv(MAIN / "GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv")
    directions = read_csv(MAIN / "GG_Data/mapping/RELATION_DIRECTION_LOOKUP_v2.1.1.csv")
    by_key = {(row["source"], row["source_predicate"]): row for row in mapping}
    inputs_before = deepcopy((entities, counts))
    retained, excluded, scan_counts = scan(entities, qids, by_key)
    relations = populate(retained, by_key)
    graph, graph_report = build_graph(entities, [], relations, mapping, directions,
        dict(schema_version="private-real-pair-readiness-v1", relation_map_version="relation-map-v2.1.1",
             release_status="PRIVATE_DEVELOPMENT", scope="Nine cached accepted identities in one retained unit; nine Q131347 pairs pending"))
    covered_pairs = [pair for pair in counts["pairs"] if {pair["source_qid"], pair["target_qid"]} <= qids]
    pending_pairs = [dict(pair, pending_reason="NO_FULL_Q131347_RECORD_IN_INSPECTED_CACHES") for pair in counts["pairs"] if pair not in covered_pairs]
    fallback = weighted_fallback(covered_pairs)  # Existing counter values copied; no formula or consumer fields.
    history = []
    active = pair_frontier(graph["edges"], fallback, history)
    frozen = deepcopy(history)
    assert pair_frontier(graph["edges"], fallback, history) == active and history == frozen
    assert (entities, counts) == inputs_before
    native = [e for e in active if "kind" not in e and not e.get("derived")]
    inverse = [e for e in active if e.get("derived")]
    defaults = [e for e in active if e.get("kind") == "CO_MENTIONED"]
    native_pairs = {frozenset((e["source"], e["target"])) for e in native}
    assert len(counts["pairs"]) == 45 and len(covered_pairs) == 36 and len(pending_pairs) == 9
    assert all(e["source"] in qids and e["target"] in qids for e in active)
    assert all(frozenset((e["source"], e["target"])) not in native_pairs for e in defaults)
    assert len(defaults) == 2 * (36 - len(native_pairs))
    assert all(pair["shared_page_count"] == pair["source_page_count"] == pair["target_page_count"] == 1 for pair in counts["pairs"])
    assert all(digest(Path(path)) == expected for path, expected in protected.items())
    summary = dict(native=len(native), inverse=len(inverse), default=len(defaults), active_total=len(active),
                   covered_pairs=36, pending_pairs=9, input_count_pairs=45, accepted_occurrences=30, pending_identity_occurrences=106,
                   selected_snapshot_records=sum(v["policy"] == "SNAPSHOT_FIRST" for v in selected.values()),
                   selected_archive_records=sum(v["policy"] != "SNAPSHOT_FIRST" for v in selected.values()),
                   excluded_statements=len(excluded), pair_history_versions=len(history))
    output = HERE / ("real_pair_views_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    output.mkdir()
    payload = dict(summary=summary, selected_references=selected, entities=entities, retained=retained, excluded=excluded,
                   scan_counts=dict(scan_counts), relations=relations, native_producer_graph=graph, graph_report=graph_report,
                   active_pair_views=active, pair_history=history, counts=counts, pending_pairs=pending_pairs,
                   source_scope=dict(covered_accepted_qids=sorted(qids), pending_native_coverage_qids=["Q131347"], native_frontier="Available/linkable assertions from nine selected cached whole records only", live_wikidata_completeness_claim=False), consumer_export=False, publication=False)
    (output / "pair_views.json").write_bytes(encoded(payload))
    assert json.loads((output / "pair_views.json").read_text()) == payload
    (output / "verification.json").write_bytes(encoded(dict(status="PASS_REAL_PARTIAL_PAIR_VIEWS", summary=summary,
        code_sha256=digest(Path(__file__)), output_sha256=digest(output / "pair_views.json"), protected_sha256=protected,
        complete_scope="Only the nine selected cached accepted IDs; Q131347 directions remain pending", backup_status="Unprotected")))
    print(json.dumps(dict(status="PASS", output=str(output), **summary)))


if __name__ == "__main__":
    run()

