"""One generated combined counts/E5 fixture. No consumer fields or export."""
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "counts_direct_20261101"))
from pair_counts import pair_counts, fixture_unit, replace_unit, aggregate_units, SCOPE_FIELDS
from pair_relations import pair_frontier, build_graph, fixture, digest, encoded


def weighted_fallback(count_rows):
    """Copy the existing counter's values into two private directional views."""
    views = []
    for row in count_rows:
        if row["shared_page_count"] == 0:
            continue  # Zero-count rows stay in private count diagnostics.
        a, b = row["source_qid"], row["target_qid"]
        for source, target, denominator, other, strength in (
                (a, b, row["source_page_count"], row["target_page_count"], row["source_strength"]),
                (b, a, row["target_page_count"], row["source_page_count"], row["target_strength"])):
            views.append(dict(id=f"fallback:{source}:{target}", source=source, target=target,
                              kind="CO_MENTIONED", shared_page_count=row["shared_page_count"],
                              source_page_count=denominator, target_page_count=other, directional_strength=strength))
    return views


def combined_case():
    first, source1 = fixture_unit(1, [0, 1], ["Q1", "Q2"])
    second, source2 = fixture_unit(2, [2, 3], ["Q1", "Q3"])
    state = {}
    replace_unit(state, first, source1)
    replace_unit(state, second, source2)
    source = fixture()
    source["entities"].append(dict(source["entities"][0], entity_id="Q3", name="Generated C"))
    base = source["relations"][0]
    source["relations"] = [dict(base, observation_id="native-ac", object_entity_id="Q3")]
    correction = deepcopy(second)
    correction.update(version="page-2-v2", prior_version="page-2-v1")
    correction["decisions"][0]["qid"] = None
    history, phases = [], []
    original_members = [deepcopy(unit["occurrences"]) for unit in (first, second)]
    for phase in range(3):
        if phase == 1:
            assert replace_unit(state, correction, source2) is True
        if phase == 2:
            source["relations"].append(dict(base, observation_id="native-ab"))
        before = deepcopy((state, source))
        counts = pair_counts(state)
        fallback = weighted_fallback(counts)
        ab = [edge for edge in fallback if (edge["source"], edge["target"]) == ("Q1", "Q2")]
        expected_ab = dict(id="fallback:Q1:Q2", source="Q1", target="Q2", kind="CO_MENTIONED",
                           shared_page_count=1, source_page_count=2 if phase == 0 else 1,
                           target_page_count=1, directional_strength=0.5 if phase == 0 else 1.0)
        assert ab == [expected_ab], "Existing count weights must propagate to private A->B view"
        ba = next(edge for edge in fallback if (edge["source"], edge["target"]) == ("Q2", "Q1"))
        assert ba == dict(id="fallback:Q2:Q1", source="Q2", target="Q1", kind="CO_MENTIONED",
                          shared_page_count=1, source_page_count=1, target_page_count=2 if phase == 0 else 1,
                          directional_strength=1.0)
        graph, _ = build_graph(**source)
        active = pair_frontier(graph["edges"], fallback, history)
        assert len(history) == phase + 1
        assert {edge["id"] for edge in active} == ({"native-ac", "native-ac::REVERSE", "fallback:Q1:Q2", "fallback:Q2:Q1"}
                if phase < 2 else {"native-ac", "native-ac::REVERSE", "native-ab", "native-ab::REVERSE"})
        ac = [edge for edge in active if edge["id"].startswith("native-ac")]
        if phases:
            assert ac == phases[0]["native_ac"], "A-B changes must leave native A-C unchanged"
        assert (state, source) == before
        aggregate = aggregate_units(state)
        assert aggregate["unique_occurrences"] == 4 and aggregate["support_records"] == 4
        assert aggregate["unique_physical_pages"] == 2
        registry = {row["qid"]: row for row in aggregate["identity_counts"]}
        assert registry["Q1"]["page_count"] == (2 if phase == 0 else 1)
        assert registry["Q2"]["page_count"] == registry["Q3"]["page_count"] == 1
        assert sum(len(versions) for versions in state.values()) == (2 if phase == 0 else 3)
        for versions in state.values():
            assert all(version["occurrences"] == versions[0]["occurrences"] for version in versions)
        frozen_state, frozen_history = deepcopy(state), deepcopy(history)
        assert replace_unit(state, first, source1) is False
        assert replace_unit(state, second if phase == 0 else correction, source2) is False
        assert pair_frontier(graph["edges"], weighted_fallback(pair_counts(state)), history) == active
        assert state == frozen_state and history == frozen_history
        phases.append(dict(phase=phase, counts=counts, fallback=fallback, active=deepcopy(active), native_ac=ac,
                           aggregate=aggregate, decision_history_versions=sum(len(v) for v in state.values())))
    assert history[0]["active"] != history[1]["active"]  # Same links, updated denominator/strength.
    assert history[0]["fallback_views"][0]["directional_strength"] == 0.5
    assert history[1]["fallback_views"][0]["directional_strength"] == 1.0
    assert history[2]["fallback_views"] == history[1]["fallback_views"]  # Retained after native replacement.
    assert [versions[0]["occurrences"] for versions in state.values()] == original_members
    return dict(phases=phases, pair_history=history,
                units=[dict(scope=dict(zip(SCOPE_FIELDS, key)), versions=versions) for key, versions in state.items()],
                generated_only=True, consumer_export=False)


if __name__ == "__main__":
    protected_paths = [ROOT / "counts_direct_20261101/pair_counts.py",
                       ROOT / "integration_direct_20261101/aggregate_occurrences.py",
                       ROOT / "integration_direct_20261101/occurrence_decisions.py",
                       ROOT / "source_custody/local_unit_contract.py", HERE / "pair_relations.py",
                       ROOT / "relations/native_pair_views.py",
                       Path(r"D:\Projects\GeoAI\GG_Data\pipeline\graph_export.py"),
                       Path(r"D:\Projects\GeoAI\GG_Data\pipeline\test_graph_export.py")]
    protected = {str(path): digest(path) for path in protected_paths}
    payload = combined_case()
    assert encoded(combined_case()) == encoded(payload), "A complete rerun must be byte-deterministic"
    assert protected == {str(path): digest(path) for path in protected_paths}
    output = HERE / ("combined_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    output.mkdir()
    data_path = output / "combined_history.json"
    data_path.write_bytes(encoded(payload))
    assert json.loads(data_path.read_text()) == payload
    verification = dict(status="PASS", checks=["counter_values_copied_both_directions", "denominator_only_weight_change",
        "native_replaces_only_its_pair", "unrelated_native_unchanged", "fallback_history_retained",
        "four_occurrences_four_supports_two_pages", "exact_retry_no_duplicate_counts_or_history",
        "three_pair_history_versions", "original_members_preserved", "deterministic_full_rerun", "shared_hashes_unchanged"],
        code_sha256=digest(Path(__file__)), protected_sha256=protected, output_sha256=digest(data_path),
        consumer_export=False, backup_status="Unprotected")
    (output / "verification.json").write_bytes(encoded(verification))
    print(json.dumps(dict(status="PASS", checks=len(verification["checks"]), output=str(output), code_sha256=verification["code_sha256"])))


