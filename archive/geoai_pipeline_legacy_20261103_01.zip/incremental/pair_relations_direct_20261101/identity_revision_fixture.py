"""Synthetic identity reassignment invalidation; real accepted decisions stay read-only."""
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'grouping'))
from group_mentions import group_mentions
from combined_pair_fixture import fixture_unit, replace_unit, aggregate_units, pair_counts, weighted_fallback, SCOPE_FIELDS
from pair_relations import pair_frontier, fixture, build_graph, digest, encoded


def refresh_projection(state, previous, history):
    counts=pair_counts(state)
    source=fixture()
    template=source['entities'][0]
    identities={row['qid'] for row in aggregate_units(state)['identity_counts']}
    source['entities']=[dict(template,entity_id=qid,type='LOC',name=qid) for qid in sorted(identities)]
    source['events']=[]
    source['relations']=[dict(source['relations'][0],observation_id='native-unaffected',subject_entity_id='Q2',object_entity_id='Q3')]
    graph,_=build_graph(**source)
    views=pair_frontier(graph['edges'],weighted_fallback(counts),history)
    count_rows={row['source_qid']+'|'+row['target_qid']:row for row in counts}
    view_rows={row['id']:row for row in views}
    # Existing counter recomputes this tiny fixture; apply changes only to differing rows.
    # ponytail: full reference computation; a dependency index is still needed for targeted production recomputation.
    if previous is not None:
        for key,row in list(count_rows.items()):
            if previous['pair_counts'].get(key)==row:
                count_rows[key]=previous['pair_counts'][key]
        for key,row in list(view_rows.items()):
            if previous['active_views'].get(key)==row:
                view_rows[key]=previous['active_views'][key]
    return dict(decision_frontier=[dict(scope=dict(zip(SCOPE_FIELDS,key)),version=versions[-1]['version']) for key,versions in state.items()],
                identity_counts=aggregate_units(state)['identity_counts'],
                pair_counts=count_rows, active_views=view_rows)


def check():
    first,source1=fixture_unit(1,[0,1,2],['Q1','Q1','Q2'])
    second,source2=fixture_unit(2,[3,4],['Q1','Q3'])
    grouped=group_mentions(first['occurrences'])
    raw_group=next(g for g in grouped['groups'] if len(g['members'])==2)
    members={m['occurrence_id'] for m in raw_group['members']}
    revised=deepcopy(first)
    revised.update(version='page-1-model-revision-v2',prior_version=first['version'])
    for decision in revised['decisions']:
        if decision['occurrence_id'] in members:
            decision.update(qid='Q4',evidence=dict(source='SIMULATED_POST_MODEL_ACCEPTED_REVISION',group_id=raw_group['group_id']))
    state={}
    replace_unit(state,first,source1)
    replace_unit(state,second,source2)
    history=[]
    before=refresh_projection(state,None,history)
    old_state=deepcopy(state)
    assert replace_unit(state,revised,source1) is True
    after=refresh_projection(state,before,history)
    assert 'fallback:Q1:Q2' not in after['active_views'], 'Identity revision must retract the old Q1-Q2 fallback'
    assert before['identity_counts']==[dict(qid='Q1',mention_count=3,page_count=2),dict(qid='Q2',mention_count=1,page_count=1),dict(qid='Q3',mention_count=1,page_count=1)]
    assert after['identity_counts']==[dict(qid='Q1',mention_count=1,page_count=1),dict(qid='Q2',mention_count=1,page_count=1),dict(qid='Q3',mention_count=1,page_count=1),dict(qid='Q4',mention_count=2,page_count=1)]
    assert after['pair_counts']['Q1|Q2']['shared_page_count']==0
    assert before['pair_counts']['Q1|Q3']['source_strength']==0.5
    assert after['pair_counts']['Q1|Q3']['source_strength']==1.0
    assert after['pair_counts']['Q2|Q4']['shared_page_count']==1
    assert after['pair_counts']['Q2|Q3'] is before['pair_counts']['Q2|Q3']
    assert set(before['active_views'])=={'native-unaffected','native-unaffected::REVERSE','fallback:Q1:Q2','fallback:Q2:Q1','fallback:Q1:Q3','fallback:Q3:Q1'}
    assert set(after['active_views'])=={'native-unaffected','native-unaffected::REVERSE','fallback:Q1:Q3','fallback:Q3:Q1','fallback:Q2:Q4','fallback:Q4:Q2'}
    for key in ('native-unaffected','native-unaffected::REVERSE'):
        assert after['active_views'][key] is before['active_views'][key]
    removed=sorted(set(before['active_views'])-set(after['active_views']))
    added=sorted(set(after['active_views'])-set(before['active_views']))
    changed=sorted(key for key in before['active_views'].keys() & after['active_views'].keys() if before['active_views'][key]!=after['active_views'][key])
    assert removed==['fallback:Q1:Q2','fallback:Q2:Q1']
    assert added==['fallback:Q2:Q4','fallback:Q4:Q2']
    assert changed==['fallback:Q1:Q3','fallback:Q3:Q1']
    assert revised['occurrences']==first['occurrences'] and group_mentions(revised['occurrences'])==grouped
    assert len(history)==2 and {e['id'] for e in history[0]['active']}==set(before['active_views'])
    assert {e['id'] for e in history[1]['active']}==set(after['active_views'])
    assert sum(len(v) for v in state.values())==3
    assert all(state[key][:len(versions)]==versions for key,versions in old_state.items())
    for versions in state.values():
        assert all(v['occurrences']==versions[0]['occurrences'] for v in versions)
    aggregate=aggregate_units(state)
    assert (aggregate['unique_occurrences'],aggregate['support_records'],aggregate['unique_physical_pages'])==(5,5,2)
    frozen_state,frozen_history=deepcopy(state),deepcopy(history)
    assert replace_unit(state,revised,source1) is False
    assert replace_unit(state,second,source2) is False
    replay=refresh_projection(state,after,history)
    assert state==frozen_state and history==frozen_history and replay==after
    assert all(replay['active_views'][key] is row for key,row in after['active_views'].items())
    return dict(before=before,after=after,delta=dict(removed=removed,added=added,changed=changed,
        unchanged_native=['native-unaffected','native-unaffected::REVERSE']),pair_history=history,
        raw_group=raw_group,units=[dict(scope=dict(zip(SCOPE_FIELDS,key)),versions=versions) for key,versions in state.items()],
        source_texts={'1':source1.decode(),'2':source2.decode()},aggregate_after=aggregate,
        simulated_model_revision=True,actual_model_called=False,real_accepted_decisions_changed=False,
        invalidation_limits='Explicit refresh call in this fixture; existing real-unit runner has no automatic decision-revision hook. Full reference counts are recomputed; only differing output rows are replaced. Targeted dependency-index recomputation is not implemented.')


if __name__=='__main__':
    protected_paths=[ROOT/'counts_direct_20261101/pair_counts.py',ROOT/'integration_direct_20261101/occurrence_decisions.py',
        ROOT/'integration_direct_20261101/aggregate_occurrences.py',ROOT/'source_custody/local_unit_contract.py',ROOT/'grouping/group_mentions.py',
        HERE/'pair_relations.py',HERE/'combined_pair_fixture.py',HERE/'run_real_pair_views.py',
        ROOT/'integration_direct_20261101/real_handoff_0001/sealed_v1/unit.private.json',
        HERE/'real_pair_views_20261101T203117785273Z/pair_views.json']
    protected={str(path):digest(path) for path in protected_paths}
    payload=check()
    assert encoded(check())==encoded(payload)
    assert all(digest(Path(path))==expected for path,expected in protected.items())
    output=HERE/('identity_revision_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    output.mkdir()
    (output/'revision_history.json').write_bytes(encoded(payload))
    assert json.loads((output/'revision_history.json').read_text())==payload
    verification=dict(status='PASS_SYNTHETIC_IDENTITY_REASSIGNMENT',checks=['same_raw_group_two_members_Q1_to_Q4',
        'old_identity_contributions_withdrawn','literal_identity_and_page_counts','pair_counts_and_denominators_updated',
        'two_old_views_removed_two_new_added_two_updated','unaffected_native_and_zero_pair_rows_reused',
        'original_members_and_both_histories_preserved','exact_replay_noop','five_originals_five_supports_two_pages',
        'deterministic_full_rebuild','real_inputs_and_shared_code_unchanged'],code_sha256=digest(Path(__file__)),
        output_sha256=digest(output/'revision_history.json'),protected_sha256=protected,backup_status='Unprotected')
    (output/'verification.json').write_bytes(encoded(verification))
    print(json.dumps(dict(status='PASS',checks=len(verification['checks']),output=str(output),delta=payload['delta'],
        pair_history_versions=len(payload['pair_history']),unit_history_versions=sum(len(v['versions']) for v in payload['units']))))


