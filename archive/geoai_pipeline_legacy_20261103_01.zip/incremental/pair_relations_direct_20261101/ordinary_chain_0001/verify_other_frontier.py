"""A second immutable frontier, restart/replay, mismatch rejection and old producer oracle."""
import copy,json,sqlite3,sys,zlib
from pathlib import Path
from ordinary_relations import produce_ordinary_relations,ROOT,HERE,read,pin,write,desc,require_current,content_hash,decision_binding,covered_pair_counts
from capture_cpu_frontier import read_active_units
sys.path.insert(0,str(ROOT/'pair_relations_direct_20261101/compact_unit_store_0001'))
from contribution_store import ContributionStore
from relation_revision import dispatch_relations

def main():
 # Frozen90 data only. Copy the historically verified subset's existing contributions
 # to a separate fixture DB; the live canonical DB and original snapshots stay untouched.
 source=read(ROOT/'pair_relations_direct_20261101/event_current_frontier_0001/frozen90_0001/HANDOFF.json')['frozen_frontier']
 frozen=pin(source);before=desc(frozen['database']['path']);old13=read(ROOT/'pair_relations_direct_20261101/event_current_frontier_0001/HANDOFF_GEO_SORT_0003.json');counts13=pin(old13['count_receipt'])
 wanted={tuple(row['scope']) for row in counts13['decision_binding']}
 subset=HERE/'fixture_other_frontier';subset.mkdir()
 database=subset/'corpus.sqlite';store=ContributionStore(database)
 origin=sqlite3.connect(Path(frozen['database']['path']).resolve().as_uri()+'?mode=ro',uri=True)
 with store.db:
  for row in origin.execute('SELECT seq,scope,version,sha256,payload FROM contributions ORDER BY seq'):
   if tuple(json.loads(row[1])) in wanted:store.db.execute('INSERT INTO contributions VALUES(?,?,?,?,?)',row)
  for row in origin.execute('SELECT scope,seq FROM active'):
   if tuple(json.loads(row[0])) in wanted:store.db.execute('INSERT INTO active VALUES(?,?)',row)
 origin.close();stats=store.stats();store.close()
 receipt=dict(frozen,database=desc(database),active_units=len(wanted),history_contributions=stats['contributions'],frontier=[r for r in frozen['frontier'] if tuple(r['scope']) in wanted],fixture=True,fixture_scope='Read-only-source subset of the existing frozen90 snapshot; not a new CPU run')
 receipt['frontier_sha256']=content_hash(receipt['frontier'])
 fixture_receipt=subset/'receipt.json';write(fixture_receipt,receipt)
 state13=read_active_units(fixture_receipt);require_current(counts13,state13)
 # Direct Event route input exercises the second supported handoff form.
 other=produce_ordinary_relations(desc(fixture_receipt),old13['route'],HERE/'other_frontier_0001')
 assert other['units']==len(wanted) and other['units']!=90
 new13=pin(other['relation_receipt']);require_current(new13,state13)
 # Actual legacy relation entrypoint remains an independent small-frontier oracle.
 inventory=pin(read(ROOT/'pair_relations_direct_20261101/event_current_frontier_0001/config_actual13.json')['active_units'])
 byscope={tuple(pin(e['unit'])['manifest'][k] for k in ('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')):e for e in inventory['units']}
 key=next(iter(state13));unit=state13[key][-1];source_bytes=(Path(byscope[key]['unit']['path']).parent/'source.private.bin').read_bytes()
 old=dispatch_relations(copy.deepcopy(state13),unit,source_bytes,counts13,None,[],old13['native_registry']['path'],old13['native_registry']['sha256'])
 for field in ['relations','active_views','covered_qids','missing_qids','counts','excluded','scan_counts']:assert old['projection'][field]==new13['projection'][field],field
 # Replay exact request: no history/output bytes or mtimes change.
 hand90=read(HERE/'equivalence90_0001/HANDOFF.json');event90=desc(ROOT/'pair_relations_direct_20261101/event_current_frontier_0001/frozen90_0001/HANDOFF.json')
 paths=[Path(hand90[k]['path']) for k in ['relation_receipt','pending_pair_scope','join_compatibility']]+[HERE/'equivalence90_0001/HANDOFF.json']
 prior={str(p):(desc(p)['sha256'],p.stat().st_mtime_ns) for p in paths}
 assert produce_ordinary_relations(source,event90,HERE/'equivalence90_0001')==hand90
 assert prior=={str(p):(desc(p)['sha256'],p.stat().st_mtime_ns) for p in paths}
 try:produce_ordinary_relations(desc(fixture_receipt),event90,HERE/'rejected_stale_frontier')
 except ValueError as error:assert 'frontier descriptor differs' in str(error)
 else:raise AssertionError('Mismatched Event frontier accepted')
 assert not (HERE/'rejected_stale_frontier').exists()
 try:produce_ordinary_relations(source,event90,HERE/'other_frontier_0001')
 except ValueError as error:assert 'Changed ordinary request' in str(error)
 else:raise AssertionError('Different request overwrote existing generation')
 assert desc(frozen['database']['path'])==before
 proof=dict(status='PASS_GENERIC_ORDINARY_CHAIN_CALLABLE',entrypoint=desc(HERE/'ordinary_relations.py'),function='produce_ordinary_relations(frontier_descriptor, event_handoff_descriptor, output_dir)',
 frozen90=desc(HERE/'equivalence90_0001/HANDOFF.json'),other_immutable_frontier=desc(fixture_receipt),other_handoff=desc(HERE/'other_frontier_0001/HANDOFF.json'),
 tests=['frozen90 exact native/count/active-view equivalence and identical pending scope','different immutable subset frontier positive (existing13 heads, no hard-coded production count)','summary Event handoff and direct Event route accepted','second frontier matches unchanged legacy relation dispatcher','exact replay keeps bytes/mtimes','mismatched Event/frontier rejected before output creation','changed request cannot overwrite completed output','original frozen snapshot bytes unchanged'],
 counts=dict(frozen90_units=hand90['units'],frozen90_native=hand90['native_assertions'],frozen90_views=hand90['active_directional_views'],other_units=other['units'],other_native=other['native_assertions'],other_views=other['active_directional_views']),
 no_live_store_opened=True,external_requests=0,no_policy_change=True,consumer_materialized=False)
 write(HERE/'verification.json',proof);print(json.dumps(proof,indent=2),flush=True)
if __name__=='__main__':main()
