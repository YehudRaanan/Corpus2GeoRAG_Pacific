from ordinary_relations import produce_ordinary_relations
from pathlib import Path
from current_event_refresh import read,desc
root=Path.cwd();here=Path('pair_relations_direct_20261101/ordinary_chain_0001').resolve()
old=read(root/'pair_relations_direct_20261101/ordinary_frozen90_0001/HANDOFF.json')
event=root/'pair_relations_direct_20261101/event_current_frontier_0001/frozen90_0001/HANDOFF.json'
r=produce_ordinary_relations(old['frozen_frontier'],desc(event),here/'equivalence90_0001')
new=read(r['relation_receipt']['path']);baseline=read(old['relation_receipt']['path'])
for key in ['decision_binding']:assert new[key]==baseline[key]
for key in ['input_binding','decision_version','count_unit_sha256','count_frontier_sha256','covered_qids','missing_qids','counts','relations','scan_counts','excluded','active_views','pending_pairs','pending_pairs_materialized','pending_pair_count','native_registry_path','interim','consumer_export']:assert new['projection'][key]==baseline['projection'][key],key
assert read(r['pending_pair_scope']['path'])==read(old['pending_pair_scope']['path'])
print('PASS_GENERIC_FROZEN90_EQUIVALENCE',r['units'],r['native_assertions'],r['active_directional_views'],r['measured_stages_seconds'],flush=True)
