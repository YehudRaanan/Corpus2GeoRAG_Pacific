"""Bounded ordinary relation producer for any verified immutable CPU frontier."""
import csv,inspect,json,sys,time
from collections import defaultdict
from itertools import combinations
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001'),str(ROOT/'pair_relations_direct_20261101/revision_dispatch_0001'),str(ROOT/'pair_relations_direct_20261101/event_current_frontier_0001'),str(ROOT/'counts_direct_20261101')]
from capture_cpu_frontier import read_active_units
from current_event_refresh import read,write,desc,pin
from relation_revision import scan,populate,build_graph,weighted_fallback,pair_frontier,choose_name,require_current,content_hash,decision_binding
from pair_counts import aggregate_units,pair_counts,fixture_unit,replace_unit


def covered_pair_counts(state,available):
 """Exact existing pair_counts formula restricted to output QIDs with full source.

 Full-state original-row/revision/conflict eligibility runs first, unchanged. Missing
 source QIDs remain in the original count receipt and compact pending-pair manifest.
 """
 pages=defaultdict(set)
 for row in aggregate_units(state)['occurrences']:
  if row['not_counted_reasons']:continue
  q=row['decision_values'][0]
  if q not in available:continue
  for support in row['supports']:
   scope=support['unit_scope'];pages[q].add((scope['wiki_site'],scope['page_id']))
 result=[]
 for source,target in combinations(sorted(pages),2):
  shared=len(pages[source]&pages[target])
  result.append(dict(source_qid=source,target_qid=target,shared_page_count=shared,source_page_count=len(pages[source]),target_page_count=len(pages[target]),source_strength=shared/len(pages[source]),target_strength=shared/len(pages[target])))
 return result


def produce_ordinary_relations(frontier_descriptor,event_handoff_descriptor,output_dir):
 """One synchronous owned generation. Replays validate bytes and do not rewrite outputs."""
 frontier=frontier_descriptor;snapshot=pin(frontier);event_document=pin(event_handoff_descriptor)
 output=Path(output_dir).resolve()
 if not output.is_relative_to(HERE):raise ValueError('Ordinary output leaves assigned RELATIONS ownership')
 if snapshot.get('schema')!='geoai-immutable-cpu-frontier-v1' or snapshot.get('status')!='READY_CPU_ONLY':raise ValueError('Expected verified immutable CPU frontier')
 if Path(snapshot['database']['path']).resolve()==Path(snapshot.get('canonical_source_store',snapshot['database']['path'])).resolve():raise ValueError('Never read the live canonical CPU database')
 if event_document.get('schema')=='geoai-current-frontier-event-route-v1':
  route_descriptor=event_handoff_descriptor;route=event_document;config=pin(route['config'])
  event_hand=dict(route=route_descriptor,count_receipt=route['artifacts']['count_receipt'],native_registry=config['native_registry'])
  if config.get('frozen_cpu_frontier') is not None and config['frozen_cpu_frontier']!=frontier:raise ValueError('Event/frozen frontier descriptor differs')
 else:
  event_hand=event_document;route_descriptor=event_hand['route'];route=pin(route_descriptor)
  if event_hand.get('frozen_frontier') is not None and event_hand['frozen_frontier']!=frontier:raise ValueError('Event/frozen frontier descriptor differs')
 counts=pin(event_hand['count_receipt'])
 if route['decision_binding']!=counts['decision_binding'] or route['current_count_receipt_sha256']!=content_hash(counts) or route['native_registry_sha256']!=event_hand['native_registry']['sha256']:raise ValueError('Event count/registry binding differs')
 registry=pin(event_hand['native_registry'])
 dependency_functions=[read_active_units,scan,populate,build_graph,weighted_fallback,pair_frontier,choose_name,aggregate_units]
 dependencies={str(Path(inspect.getfile(f)).resolve()):desc(inspect.getfile(f))['sha256'] for f in dependency_functions}
 request=dict(frontier=frontier,event_handoff=event_handoff_descriptor,processor=desc(__file__),dependencies=dependencies)
 database_before=desc(snapshot['database']['path'])
 if database_before!=snapshot['database']:raise ValueError('Frozen database hash differs')
 marker=output/'HANDOFF.json'
 if output.exists():
  if not marker.exists():raise ValueError('Incomplete ordinary generation: preserve it and use a new directory')
  saved=read(marker)
  if saved['request']!=request:raise ValueError('Changed ordinary request cannot overwrite generation')
  for key in ['relation_receipt','pending_pair_scope','join_compatibility']:pin(saved[key])
  return saved

 start=time.perf_counter();state=read_active_units(frontier['path']);read_seconds=time.perf_counter()-start
 require_current(counts,state)
 heads={tuple(row['scope']):row['active_head'] for row in snapshot['frontier']}
 if len(heads)!=len(state) or any(heads.get(key)!=dict(version=versions[-1]['version'],sha256=content_hash(versions[-1])) for key,versions in state.items()):raise ValueError('Frozen active heads differ')
 output.mkdir(parents=True)
 registry=pin(event_hand['native_registry']);qids={r['qid'] for r in counts['projection']['identity_counts']}
 available=qids&set(registry['selected_references']);entities=[];quarantine=[]
 for row in counts['projection']['typed_counts']:
  q=row['qid']
  if q not in available:continue
  selected=registry['selected_references'][q];envelope=selected['envelope'];raw=envelope['entity']
  if envelope['requested_qid']!=q or raw.get('id')!=q or 'claims' not in raw:raise ValueError('Systemic whole-record identity/claims failure')
  try:name=choose_name(q,raw,{},[])['value']
  except ValueError as error:
   quarantine.append(dict(qid=q,entity_group=row['entity_group'],reason='MISSING_SUPPORTED_SOURCE_NAME',needed_remedy=str(error)));continue
  entities.append(dict(entity_id=q,type=row['entity_group'],name=name,aliases=[],raw_reference=dict(full=envelope),sources=[selected['provenance']]))
 unavailable_names={r['qid'] for r in quarantine};available-=unavailable_names
 entities=[e for e in entities if e['entity_id'] in available]
 missing=sorted(qids-available)
 mapping=Path('D:/Projects/GeoAI/GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv');directions=mapping.with_name('RELATION_DIRECTION_LOOKUP_v2.1.1.csv')
 assert desc(mapping)['sha256']=='8ecdc0095d10ec1fc24dfb82510473faef42b896c126b76cb0daeb233b301821'
 assert desc(directions)['sha256']=='94084138d9af8a7d297830c25b31d1995e9ef7eec20ad23ceb3702a224699b3b'
 def rows(p):
  with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
 catalog,direction_rows=rows(mapping),rows(directions);rules={(r['source'],r['source_predicate']):r for r in catalog}
 start=time.perf_counter();retained,excluded,scan_counts=scan(entities,available,rules);relations=populate(retained,rules)
 graph,_=build_graph(entities,[],relations,catalog,direction_rows,dict(registry['native_producer_graph']['metadata'],scope='Frozen CPU ordinary source-covered native relation checkpoint; missing sources explicitly pending'))
 native_seconds=time.perf_counter()-start
 start=time.perf_counter();pairs=covered_pair_counts(state,available);pair_seconds=time.perf_counter()-start
 start=time.perf_counter();active=pair_frontier(graph['edges'],weighted_fallback(pairs),[]);views_seconds=time.perf_counter()-start
 assert len({r['observation_id'] for r in relations})==len(relations)
 assert len({r['id'] for r in active})==len(active)
 assert all({r['source'],r['target']}<=available for r in active)
 # Validate all covered page denominators against the unchanged full count population.
 byqid={r['qid']:r for r in counts['projection']['identity_counts']}
 assert len(pairs)==len(available)*(len(available)-1)//2
 for row in pairs:
  assert row['source_page_count']==byqid[row['source_qid']]['page_count']
  assert row['target_page_count']==byqid[row['target_qid']]['page_count']
 # Compact, exact logical representation of all unknown-source pair combinations.
 pending_count=len(qids)*(len(qids)-1)//2-len(available)*(len(available)-1)//2
 pending=dict(schema='geoai-missing-native-pair-scope-v1',reason='MISSING_FULL_NATIVE_RECORD_OR_SUPPORTED_SOURCE_NAME',all_qids=sorted(qids),missing_qids=missing,covered_qids=sorted(available),unordered_pair_count=pending_count,
  exact_membership='All unordered pairs of distinct all_qids with at least one endpoint in missing_qids',pair_rows_materialized=False,absence_is_not_no_native_relation=True,frozen_frontier=frontier,count_receipt=event_hand['count_receipt'],quarantine=quarantine)
 pending_path=output/'pending_pair_scope.json';write(pending_path,pending)
 binding=dict(count_receipt_sha256=content_hash(counts),native_registry_sha256=event_hand['native_registry']['sha256'],mapping_sha256=desc(mapping)['sha256'],direction_sha256=desc(directions)['sha256'])
 projection=dict(input_binding=binding,decision_version=counts['projection']['decision_version'],count_unit_sha256=None,count_frontier_sha256=content_hash(counts['decision_binding']),covered_qids=sorted(available),missing_qids=missing,counts=counts['projection'],relations=relations,scan_counts=dict(scan_counts),excluded=excluded,active_views=active,pending_pairs=[],pending_pairs_materialized=False,pending_pair_count=pending_count,pending_pair_scope=desc(pending_path),native_registry_path=event_hand['native_registry']['path'],interim=True,consumer_export=False)
 receipt=dict(decision_binding=counts['decision_binding'],projection=projection,projection_sha256=content_hash(projection),consumer_export=False,recomputation='FROZEN_ACTIVE_STATE_NATIVE_AND_EXISTING_PHYSICAL_PAGE_FORMULA_WITH_COMPACT_MISSING_PAIR_SCOPE')
 require_current(receipt,state)
 receipt_path=output/'relation_receipt.json';write(receipt_path,receipt)
 loaded=read(receipt_path);assert loaded==receipt;require_current(loaded,state)
 assert desc(snapshot['database']['path'])==database_before
 # Existing pair-local selector must not activate default rows for native-backed pairs.
 native_pairs={frozenset((r['source'],r['target'])) for r in active if r.get('kind')!='CO_MENTIONED'}
 assert all(frozenset((r['source'],r['target'])) not in native_pairs for r in active if r.get('kind')=='CO_MENTIONED')
 defaults=sum(r.get('kind')=='CO_MENTIONED' for r in active)
 result=dict(status='PASS_IMMUTABLE_FRONTIER_ORDINARY_RELATIONS_RECEIPT',relation_receipt=desc(receipt_path),count_receipt=event_hand['count_receipt'],native_registry=event_hand['native_registry'],frozen_frontier=frontier,processor=desc(__file__),
 units=len(state),occurrences=counts['projection']['retained_occurrences'],identity_QIDs=len(qids),covered_QIDs=len(available),missing_QIDs=len(missing),native_assertions=len(relations),active_directional_views=len(active),default_directional_views=defaults,native_inverse_directional_views=len(active)-defaults,covered_pair_rows=len(pairs),pending_pair_count=pending_count,pending_pair_scope=desc(pending_path),quarantine=quarantine,
 timings_seconds=dict(read_frozen=read_seconds,native_scan_graph=native_seconds,covered_pair_counts=pair_seconds,pair_local_views=views_seconds),
 checks=['exact pinned immutable frontier receipt/hash','reader opens frozen database only','exact Event count/registry/frontier bindings','unchanged native catalog SHA pins','ordinary native observations and directional view IDs unique','all covered pair page denominators equal full counts','pair-local native/default mutual exclusion','serialized receipt independent reload/content hash','snapshot DB hash unchanged'],
 request=request,event_handoff=event_handoff_descriptor,event_route=route_descriptor,
 pending_scope_note='pending_pairs is deliberately not enumerated; pending_pairs_materialized=false and pending_pair_scope exactly retain all unknown-source pair combinations. Empty row array is NOT an all-resolved claim.',
 publisher_next='Use this exact ordinary/count/registry/Event frontier tuple with the existing strict observation_id join. PUBLISHER owns union and consumer readback.',
 canonical_store_opened=False,canonical_state_modified=False,external_requests=0,consumer_materialized=False,full_process_completion=False,publication=False)
 event_rows=pin(route['artifacts']['relations']);ordinary={r['observation_id']:r for r in relations};events={r['observation_id']:r for r in event_rows}
 if len(events)!=len(event_rows):raise ValueError('Repeated Event observation identity')
 common=sorted(ordinary.keys()&events.keys())
 if any(ordinary[oid]!=events[oid] for oid in common):raise ValueError('Conflicting ordinary/Event native observation')
 join_path=output/'join_compatibility.json'
 write(join_path,dict(status='PASS_ORDINARY_EVENT_JOIN_COMPATIBILITY',relation_receipt=result['relation_receipt'],Event_route=route_descriptor,shared_observation_ids=common,exact_shared_observations=len(common),conflicting_observations=0,unique_observations_expected_after_publisher_union=len(ordinary)+len(events)-len(common),same_count_registry_and_heads=True))
 result.update(join_compatibility=desc(join_path),exact_Event_overlap=len(common),Event_conflicts=0,measured_stages_seconds=sum(result['timings_seconds'].values()))
 write(marker,result)
 return result

