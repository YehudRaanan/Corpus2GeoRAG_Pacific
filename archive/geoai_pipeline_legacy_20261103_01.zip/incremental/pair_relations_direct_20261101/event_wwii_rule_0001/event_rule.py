"""Approved WWII P361 membership and all-explicit first hop / place-only second hop."""
import sys
from collections import defaultdict,deque
from copy import deepcopy
sys.path.insert(0,r'D:\Projects\GeoAI')
from GG_Data.pipeline.events import item_links
from GG_Data.mapping.assertion_exclusions import exclusion_reason,load_exclusions
ROOT='Q362'
RULE_VERSION='owner-approved-event-wwii-p361-v1'
HOP_VERSION='owner-approved-all-explicit-first-place-second-v1'
CLASS_METADATA={'wd:P31','wd:P279'}

def native_links(qid,node):
 record=node['record']
 if record.get('id')!=qid or 'claims' not in record:raise ValueError('Native record identity/coverage differs')
 exclusions=load_exclusions();result=[]
 for link in item_links(record):
  case=dict(link,source=deepcopy(node['source']))
  reason=exclusion_reason('Wikidata',dict(case,predicate=case['source_predicate']),exclusions)
  if reason:case['existing_exclusion_reason']=reason
  result.append(case)
 return result

def evaluate_wwii(qid,records):
 """No temporal shortcut, no depth cutoff and no negative classification from missing cache."""
 if qid==ROOT:
  return dict(qid=qid,status='UNRESOLVED',keep_event=False,reason='ROOT_CANDIDATE_HAS_NO_APPROVED_ZERO_HOP_EXCEPTION',p361_chain=[],source_pending=[])
 pending=deque([(qid,[])]);seen=set();missing=set()
 while pending:
  current,path=pending.popleft()
  if current in seen:continue
  seen.add(current)
  if current not in records:missing.add(current);continue
  for edge in native_links(current,records[current]):
   if edge['source_predicate']!='wd:P361' or 'existing_exclusion_reason' in edge:continue
   route=path+[edge];target=edge['object_qid']
   if target==ROOT:return dict(qid=qid,status='ACCEPTED_WWII_SCOPE',keep_event=True,reason='PROVENANCE_BACKED_NATIVE_P361_CHAIN_TO_Q362',p361_chain=route,source_pending=sorted(missing))
   pending.append((target,route))
 return dict(qid=qid,status='UNRESOLVED',keep_event=False,reason='NO_VERIFIED_P361_CHAIN_AT_DECLARED_SOURCE_FRONTIER',p361_chain=[],source_pending=sorted(missing))

def discover_scope(anchors,records,kinds):
 """Both native directions at the passed source frontier; geometry remains unapproved."""
 adjacency=defaultdict(list);metadata=[];excluded=[]
 for qid,node in records.items():
  for edge in native_links(qid,node):
   if 'existing_exclusion_reason' in edge:excluded.append(edge);continue
   if edge['source_predicate'] in CLASS_METADATA:metadata.append(edge);continue
   subject,target=edge['subject_qid'],edge['object_qid']
   adjacency[subject].append((target,dict(edge,walk_direction='OUTGOING')))
   if target!=subject:adjacency[target].append((subject,dict(edge,walk_direction='INCOMING')))
 candidates=[];missing=set()
 def collect(anchor,target,path):
  roles=kinds.get(target,[]) or [None]
  for role in roles:
   hop=len(path)
   if role is None:inclusion,reason='PENDING_TYPE','NO_SUPPLIED_ELIGIBLE_ENTITY_TYPE'
   elif hop==2 and role!='LOC':inclusion,reason='EXCLUDE','SECOND_HOP_NON_LOC'
   elif role=='LOC':inclusion,reason='PENDING_GEO','NO_APPROVED_GEOGRAPHIC_MASK_APPLIED'
   else:inclusion,reason='INCLUDE','DIRECT_ENTITY_GEOGRAPHY_NOT_APPLIED'
   candidates.append(dict(anchor=anchor,qid=target,type=role,hop=hop,path=path,inclusion=inclusion,reason=reason))
 for anchor in anchors:
  if anchor not in records:missing.add(anchor)
  for target,edge in adjacency[anchor]:
   first=dict(edge,walk_from=anchor,walk_to=target);collect(anchor,target,[first])
   if target not in records or records[target].get('coverage','FULL')!='FULL':missing.add(target)
   for second_target,second in adjacency[target]:
    collect(anchor,second_target,[first,dict(second,walk_from=target,walk_to=second_target)])
 return dict(anchors=sorted(anchors),candidates=candidates,structural_metadata=metadata,excluded_native_assertions=excluded,
  source_pending=sorted(missing),geometry_policy='UNAPPROVED_NOT_APPLIED',hop_policy=HOP_VERSION,
  structural_policy='P31_P279_REFERENCE_CLASSIFICATION_METADATA_RETAINED',incoming_coverage='PASSED_CACHE_FRONTIER_ONLY_NOT_GLOBAL_COMPLETENESS')
