"""Bounded independent policy release: exact positive chains, native Event rows and25 outcomes."""
import gzip,json,sys
from pathlib import Path
from event_rule import evaluate_wwii,RULE_VERSION
from run_actual import HERE,read,write,desc,sha,ARCHIVE,ARCHIVE_SHA
from GG_Data.pipeline.event_model import event_rows

def main():
 out=HERE/'generation_001';hand=read(out/'handoff.json');selection=read(out/'event_selection.json');graph=read(out/'p361_source_evidence.json');registry=read(hand['inputs']['native_registry']['path'])['selected_references']
 assert sha(ARCHIVE)==ARCHIVE_SHA
 for d in hand['inputs'].values():assert sha(d['path'])==d['sha256']
 rows={r['qid']:r for r in selection['decisions']};accepted=sorted(q for q,r in rows.items() if r['keep_event'])
 assert accepted==['Q1645012','Q52418','Q713516'] and not rows['Q362']['keep_event']
 subjects=set(accepted)|{'Q362'}
 for q,r in rows.items():
  result=evaluate_wwii(q,graph)
  assert all(result[k]==r[k] for k in ('status','keep_event','reason','p361_chain','source_pending'))
  subjects.update(e['subject_qid'] for e in r['p361_chain'])
 expected_lines={}
 for q in subjects:
  node=graph[q]
  if q in registry:assert node['record']==registry[q]['envelope']['entity'] and node['source']==registry[q]['provenance']
  else:
   assert node['source']['file']==str(ARCHIVE) and node['source']['sha256']==ARCHIVE_SHA
   expected_lines[node['source']['line']]=q
 checked=set()
 with gzip.open(ARCHIVE,'rt',encoding='utf8') as stream:
  for number,line in enumerate(stream,1):
   if number not in expected_lines:continue
   q=expected_lines[number];raw=json.loads(line)['entity'];node=graph[q]
   assert raw['id']==q and raw['lastrevid']==node['record']['lastrevid']
   assert node['record']['claims'].get('P361',[])==raw['claims'].get('P361',[])
   if q in accepted or q=='Q362':assert node['record']==raw
   checked.add(q)
 assert checked==set(expected_lines.values())
 entities=read(out/'event_entities.json');events=read(out/'events.json')
 for q in accepted:
  node=graph[q];entity,event=event_rows(node['record'],node['source'],rows[q]);entity['reference_source']=node['source']['provider']
  assert entity==next(x for x in entities if x['entity_id']==q) and event==next(x for x in events if x['event_id']==q)
 assert {x['event_id'] for x in events}==set(accepted) and all(x['attributes']['mention_ids']==[] for x in entities)
 names=('candidate_inputs.json','event_selection.json','p361_source_evidence.json','event_entities.json','events.json')
 artifacts=[desc(out/n) for n in names];per_unit=[];seen=set();resolved=0
 for page in hand['per_unit_receipts']:
  original=read(page['event_route']['path'])
  for row in original['outcomes']:
   assert row['occurrence_id'] not in seen;seen.add(row['occurrence_id']);resolved+=row['status']=='RESOLVED'
  bounded=dict(original,artifacts=artifacts,stage_scope='WWII_ACCEPTANCE_RULE_ONLY_HOP_AND_GEO_OUTPUTS_SEPARATE')
  target=out/f'page_{page["page"]}_policy_receipt_0001.json';write(target,bounded);per_unit.append(dict(page=page['page'],event_route=desc(target)))
 assert len(seen)==25 and resolved==4
 proof=dict(status='PASS_BOUNDED_REAL_WWII_POLICY',accepted_event_qids=accepted,unresolved_event_qids=['Q362'],resolved_occurrences=4,unresolved_occurrences=21,
  chain_subject_records_verified=len(subjects),archive_records_checked=len(checked),classification_uncertainty_preserved=True,tests=11,
  dates_alone_do_not_accept=True,root_zero_hop_not_invented=True,ordinary_identity_decisions_changed=False,consumer_materialized=False)
 write(HERE/'policy_independent_readback_0001.json',proof)
 release=dict(status='VERIFIED_EVENT_POLICY_HANDOFF_0001',version=RULE_VERSION,selection=desc(out/'event_selection.json'),entities=desc(out/'event_entities.json'),events=desc(out/'events.json'),
  accepted_event_qids=accepted,unresolved_event_qids=['Q362'],resolved_occurrences=4,unresolved_occurrences=21,per_unit_receipts=per_unit,
  input_binding=selection['input_binding'],processor=hand['processor'],rule=hand['rule'],verification=desc(HERE/'policy_independent_readback_0001.json'),
  rule_config=desc(HERE/'APPROVED_CONFIG.json'),scope_output=desc(out/'scope_discovery.json'),
  scope_note='Owner approved all explicit firsthop/place-only secondhop. Scope artifact exists; full raw-source audit is separate and not required to consume this bounded Event acceptance handoff.',
  geometry_note='This generation applied no mask; use the newer parent/GEO pacific_mask_integration_0001 receipt separately. No guessed mask was activated.',
  remaining=['Q362 itself has no approved zero-hop/self-anchor exception','Parent/PUBLISHER Event population and supplied GEO receipt connection'],publication=False)
 write(HERE/'POLICY_HANDOFF_0001.json',release);print(json.dumps({k:v for k,v in release.items() if k!='per_unit_receipts'}))
if __name__=='__main__':main()
