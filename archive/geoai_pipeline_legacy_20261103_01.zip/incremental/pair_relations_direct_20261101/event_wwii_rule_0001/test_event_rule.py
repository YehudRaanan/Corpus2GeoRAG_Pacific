import unittest
from event_rule import evaluate_wwii,discover_scope

def node(q,links=()):
 claims={}
 for prop,target in links:
  claims.setdefault(prop,[]).append(dict(id=q+'$'+prop+'-'+target,rank='normal',mainsnak=dict(property=prop,snaktype='value',datatype='wikibase-item',datavalue={'value':{'entity-type':'item','id':target,'numeric-id':int(target[1:])}})))
 return dict(record=dict(id=q,lastrevid=int(q[1:]),claims=claims),source=dict(file='fixture',sha256='fixture-hash',record_id=q,revision=int(q[1:])))
class RuleTests(unittest.TestCase):
 def test_direct_chain_and_provenance(self):
  r=evaluate_wwii('Q1',{'Q1':node('Q1',[('P361','Q362')])})
  self.assertTrue(r['keep_event']);self.assertEqual(r['p361_chain'][0]['source']['revision'],1)
 def test_intermediate_chain_cycle_and_missing_branch(self):
  r=evaluate_wwii('Q1',{'Q1':node('Q1',[('P361','Q2'),('P361','Q9')]),'Q2':node('Q2',[('P361','Q1'),('P361','Q362')])})
  self.assertTrue(r['keep_event']);self.assertEqual(len(r['p361_chain']),2)
 def test_date_alone_and_missing_chain_remain_unresolved(self):
  records={'Q1':node('Q1')};records['Q1']['record']['claims']['P585']=[{'mainsnak':{'datavalue':{'value':{'time':'+1942-01-01T00:00:00Z'}}}}]
  r=evaluate_wwii('Q1',records);self.assertFalse(r['keep_event']);self.assertEqual(r['status'],'UNRESOLVED')
  r=evaluate_wwii('Q2',records);self.assertEqual(r['source_pending'],['Q2'])
 def test_root_is_not_given_an_unapproved_zero_hop_exception(self):
  self.assertFalse(evaluate_wwii('Q362',{'Q362':node('Q362')})['keep_event'])
 def test_cycle_without_root_terminates_unresolved(self):
  r=evaluate_wwii('Q1',{'Q1':node('Q1',[('P361','Q2')]),'Q2':node('Q2',[('P361','Q1')])})
  self.assertEqual(r['status'],'UNRESOLVED')
 def test_all_first_hop_properties_second_hop_only_places(self):
  records={'Q1':node('Q1',[('P99999','Q2')]),'Q2':node('Q2',[('P131','Q3'),('P99998','Q4')]),'Q3':node('Q3',[('P276','Q5')]),'Q4':node('Q4'),'Q5':node('Q5')}
  r=discover_scope(['Q1'],records,{'Q2':['PER'],'Q3':['LOC'],'Q4':['ORG'],'Q5':['LOC']})
  rows=r['candidates'];self.assertTrue(any(x['hop']==1 and x['qid']=='Q2' and x['inclusion']=='INCLUDE' for x in rows))
  self.assertTrue(any(x['hop']==2 and x['qid']=='Q3' and x['inclusion']=='PENDING_GEO' for x in rows))
  self.assertTrue(all(x['inclusion']!='INCLUDE' for x in rows if x['hop']==2 and x['qid']=='Q4'));self.assertFalse(any(x['qid']=='Q5' for x in rows))
 def test_incoming_walk_keeps_native_orientation(self):
  records={'Q1':node('Q1'),'Q2':node('Q2',[('P99999','Q1')])};r=discover_scope(['Q1'],records,{'Q2':['PER']})
  row=next(x for x in r['candidates'] if x['qid']=='Q2');edge=row['path'][0]
  self.assertEqual((edge['subject_qid'],edge['object_qid']),('Q2','Q1'));self.assertEqual(edge['walk_direction'],'INCOMING')
 def test_class_metadata_retained_separately_not_imported_as_business_entity(self):
  r=discover_scope(['Q1'],{'Q1':node('Q1',[('P31','Q2'),('P279','Q3'),('P910','Q4')])},{})
  self.assertEqual(len(r['structural_metadata']),2);self.assertFalse(any(x['qid'] in ('Q2','Q3') for x in r['candidates']))
  self.assertTrue(any(x['qid']=='Q4' and x['inclusion']=='PENDING_TYPE' for x in r['candidates']))
 def test_loc_unknown_and_nonloc_geography_does_not_filter(self):
  r=discover_scope(['Q1'],{'Q1':node('Q1',[('P276','Q2'),('P710','Q3')])},{'Q2':['LOC'],'Q3':['PER']})
  rows={x['qid']:x for x in r['candidates'] if x['hop']==1};self.assertEqual(rows['Q2']['inclusion'],'PENDING_GEO');self.assertEqual(rows['Q3']['inclusion'],'INCLUDE')
 def test_incoming_reader_keeps_no_value_and_literals_as_raw_metadata(self):
  from run_actual import filtered_incoming
  record=node('Q2',[('P710','Q1')])['record'];record['claims']['P585']=[{'mainsnak':{'snaktype':'somevalue'}},{'mainsnak':{'datavalue':{'value':'1942'}}}]
  self.assertEqual(list(filtered_incoming(record,{'Q1'})['claims']),['P710'])
 def test_first_neighbors_include_native_incoming_from_selected_records(self):
  import run_actual
  records={'Q1':node('Q1'),'Q2':node('Q2',[('P99999','Q1')])}
  self.assertIn('Q2',run_actual.first_neighbors(['Q1'],records,[]))
if __name__=='__main__':unittest.main()
