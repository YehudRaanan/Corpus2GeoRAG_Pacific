"""Execute the approved Event rules on the25 existing page/revision-bound candidates, cache only."""
import csv,gzip,hashlib,json,sys
from pathlib import Path
from collections import deque
HERE=Path(__file__).resolve().parent;PAIR=HERE.parent;ROOT=PAIR.parent
sys.path[:0]=[str(PAIR/'event_runtime_0001'),str(ROOT/'orchestration_direct_20261101')]
from event_runtime import sha,read,write
from event_rule import evaluate_wwii,discover_scope,native_links,RULE_VERSION,HOP_VERSION,CLASS_METADATA
from GG_Data.pipeline.event_model import event_rows
from decision_revision_hook import content_hash
ARCHIVE=Path(r'D:\Projects\GeoAI\Data\external\wwii_task_force\wikidata_entities.jsonl.gz')
ARCHIVE_SHA='95c6a8aa5ab803d904a0f5e85bfc5d2dade97b5b5f18c0c33ea48a54fc217277'
FIELDS=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
def desc(path,expected=None):
 value=sha(path)
 if expected and value!=expected:raise ValueError('Input hash differs: '+str(path))
 return dict(path=str(Path(path).resolve()),sha256=value)
def source_node(q,record,source,coverage='FULL'):
 if record.get('id')!=q or 'claims' not in record:raise ValueError('Native source identity/coverage differs: '+q)
 return dict(record=record,source=source,coverage=coverage)
def filtered_incoming(record,targets):
 claims={}
 for prop,statements in record.get('claims',{}).items():
  rows=[s for s in statements if s.get('mainsnak',{}).get('datavalue',{}).get('value',{}).__class__ is dict and s['mainsnak']['datavalue']['value'].get('entity-type')=='item' and s['mainsnak']['datavalue']['value'].get('id') in targets]
  if rows:claims[prop]=rows
 return dict(id=record['id'],lastrevid=record.get('lastrevid'),modified=record.get('modified'),claims=claims)
def run(output):
 output=Path(output).resolve()
 if not output.is_relative_to(HERE) or output.exists():raise ValueError('Use a new owned generation')
 native_path=PAIR/'event_execution_0001/generation_001/native_event_evidence.json';native=read(native_path)
 projection_path=ROOT/'orchestration_direct_20261101/policy_v2_all17_sources_0340_0001/unit/projection.json'
 registry_path=PAIR/'accepted11_20_sources_0001/generation_014/native_registry.json'
 inputs=dict(native_evidence=desc(native_path),identity_projection=desc(projection_path,'8b3580fcda04efe4cdc32098326194fd62cce1c0d02c49d2b9e6dd4b1040ec73'),native_registry=desc(registry_path,'f1bf0d890542e63557d18af13e6067e3e8da3768e0a50543432516c0db5fb0dc'))
 archive=desc(ARCHIVE,ARCHIVE_SHA);projection=read(projection_path);registry=read(registry_path)
 units={versions[-1]['manifest']['page_id']:versions[-1] for versions in projection['count_state']}
 inventory_path=ROOT/'orchestration_direct_20261101/completion_semantics_audit_v1/route_inventory.json';inventory=read(inventory_path)
 candidate_rows=[];candidate_pins=[]
 for entry in inventory['units']:
  old=PAIR/f'event_execution_0001/generation_001/page_{entry["page"]}'
  prior_receipt=read(old/'event_route_receipt.json');artifact=prior_receipt['artifacts'][0]
  desc(artifact['path'],artifact['sha256']);candidate_pins.append(artifact)
  current={r['occurrence_id']:r for r in units[entry['page']]['occurrences']}
  for row in read(artifact['path']):
   oid=row['occurrence']['occurrence_id']
   if oid not in entry['event_ids'] or current.get(oid)!=row['occurrence']:raise ValueError('Candidate source row differs from current sealed frontier')
   candidate_rows.append(row)
 if len(candidate_rows)!=25 or len({r['occurrence']['occurrence_id'] for r in candidate_rows})!=25:raise ValueError('Event inventory differs')
 candidates=sorted({q for r in candidate_rows for q in r['candidate_qids']});targets=set(candidates)-{'Q362'}
 selected={q:source_node(q,row['envelope']['entity'],row['provenance']) for q,row in registry['selected_references'].items()}
 for q,row in native.items():
  selected[q]=source_node(q,row['raw_record'],dict(provider='WIKIDATA',file=row['source']['path'],sha256=row['source']['sha256'],line=row['source']['line'],record_id=q,revision=row['revision'],modified=row['modified']))
 graph={};incoming=[];cache_records=0
 with gzip.open(ARCHIVE,'rt',encoding='utf8') as stream:
  for number,line in enumerate(stream,1):
   envelope=json.loads(line);q=envelope['requested_qid'];record=envelope['entity']
   if record.get('id')!=q or 'claims' not in record:continue
   cache_records+=1;source=dict(provider='WIKIDATA',file=str(ARCHIVE),sha256=ARCHIVE_SHA,line=number,record_id=q,revision=record.get('lastrevid'),modified=record.get('modified'))
   graph[q]=source_node(q,dict(id=q,lastrevid=record.get('lastrevid'),modified=record.get('modified'),labels={'en':record.get('labels',{}).get('en',{})},claims={'P361':record['claims'].get('P361',[])}),source,'P361_COMPLETE_ONLY')
   if q not in selected:
    subset=filtered_incoming(record,targets)
    if subset['claims']:incoming.extend(native_links(q,source_node(q,subset,source,'FILTERED_INCOMING_ONLY')))
 for q,node in selected.items():graph[q]=node
 decisions=[]
 for q in candidates:
  result=evaluate_wwii(q,graph);result['classification_uncertainty']=native.get(q,{}).get('classification',dict(status='UNVERIFIED'))
  result['rule_version']=RULE_VERSION;decisions.append(result)
 accepted=sorted(r['qid'] for r in decisions if r['keep_event']);byqid={r['qid']:r for r in decisions}
 output.mkdir();write(output/'candidate_inputs.json',candidate_rows)
 selection=dict(version=RULE_VERSION,input_binding={k:v['sha256'] for k,v in inputs.items()},decisions=decisions,
  approval_source='Sentinel_7297d5ca301481918011ffbe6827a63c owner thumbs-up; parent verified2026-11-02T05:56:11Z',
  scope='SUPPLIED_FIRST_NINE_PAGE_REVISION_CANDIDATES_NOT_ALL17_EVENT_DISCOVERY',date_only_acceptance=False)
 write(output/'event_selection.json',selection)
 # Save the exact P361 closure used as evidence. This is classification custody, not extra graph hops.
 reachable=set();queue=deque(candidates)
 while queue:
  q=queue.popleft()
  if q in reachable or q not in graph:continue
  reachable.add(q)
  if q=='Q362':continue
  queue.extend(e['object_qid'] for e in native_links(q,graph[q]) if e['source_predicate']=='wd:P361' and 'existing_exclusion_reason' not in e)
 write(output/'p361_source_evidence.json',{q:graph[q] for q in sorted(reachable)})
 entities=[];events=[]
 for q in accepted:
  node=selected[q];entity,event=event_rows(node['record'],node['source'],byqid[q]);entity['reference_source']=node['source']['provider'];entities.append(entity);events.append(event)
 write(output/'event_entities.json',entities);write(output/'events.json',events)
 print(json.dumps(dict(stage='WWII_RULE_EXECUTED',accepted_event_qids=accepted,unresolved_event_qids=[r['qid'] for r in decisions if not r['keep_event']])),flush=True)
 # All item-valued source relations except retained classification metadata, no predicate allowlist.
 frontier=dict(selected);first=set()
 for q in accepted:
  for edge in native_links(q,selected[q]):
   if edge['source_predicate'] not in CLASS_METADATA and 'existing_exclusion_reason' not in edge:first.add(edge['object_qid'])
 for edge in incoming:
  if edge['object_qid'] in accepted and edge['source_predicate'] not in CLASS_METADATA and 'existing_exclusion_reason' not in edge:first.add(edge['subject_qid'])
 with gzip.open(ARCHIVE,'rt',encoding='utf8') as stream:
  for number,line in enumerate(stream,1):
   envelope=json.loads(line);q=envelope['requested_qid'];record=envelope['entity']
   if q in selected or record.get('id')!=q or 'claims' not in record:continue
   source=dict(provider='WIKIDATA',file=str(ARCHIVE),sha256=ARCHIVE_SHA,line=number,record_id=q,revision=record.get('lastrevid'),modified=record.get('modified'))
   if q in first:frontier[q]=source_node(q,record,source)
   else:
    subset=filtered_incoming(record,first)
    if subset['claims']:frontier[q]=source_node(q,subset,source,'FILTERED_INCOMING_ONLY')
 kinds={}
 for row in projection['count_receipt']['projection']['typed_counts']:kinds.setdefault(row['qid'],set()).add(row['entity_group'])
 for q in accepted:kinds.setdefault(q,set()).add('Event')
 kinds={q:sorted(v) for q,v in kinds.items()}
 scope=discover_scope(accepted,frontier,kinds);write(output/'scope_discovery.json',scope)
 write(output/'scope_source_evidence.json',frontier)
 artifacts={p.name:desc(p) for p in output.iterdir() if p.is_file()}
 per_unit=[];resolved=0
 for entry in inventory['units']:
  rows=[r for r in candidate_rows if r['occurrence']['occurrence_id'] in entry['event_ids']];outcomes=[]
  for row in rows:
   qualified=[q for q in row['candidate_qids'] if byqid[q]['keep_event']]
   status='RESOLVED' if len(qualified)==1 else 'UNRESOLVED';resolved+=status=='RESOLVED'
   outcomes.append(dict(occurrence_id=row['occurrence']['occurrence_id'],status=status,method=RULE_VERSION,reason='NATIVE_P361_CHAIN_TO_Q362' if status=='RESOLVED' else 'NO_UNIQUE_APPROVED_P361_CHAIN_AT_THIS_FRONTIER',accepted_event_qids=qualified))
  source_scope={k:units[entry['page']]['manifest'][k] for k in FIELDS};raw=sorted((r['occurrence'] for r in rows),key=lambda x:x['occurrence_id'])
  receipt=dict(status='COMPLETED' if all(r['status']=='RESOLVED' for r in outcomes) else 'COMPLETED_UNRESOLVED',execution='EXECUTED',route='event_route',source_scope=source_scope,input_occurrences_sha256=content_hash(raw),processor=desc(HERE/'run_actual.py'),rule=desc(HERE/'event_rule.py'),artifacts=list(artifacts.values()),outcomes=outcomes,
   stage_scope='WWII_MEMBERSHIP_AND_CACHE_ONLY_APPROVED_HOPS_NOT_FINAL_GEOGRAPHIC_OR_CONSUMER_COMPLETION')
  path=output/f'page_{entry["page"]}_event_route.json';write(path,receipt);per_unit.append(dict(page=entry['page'],event_route=desc(path)))
 result=dict(status='VERSIONED_APPROVED_EVENT_RULE_AND_HOPS_EXECUTED',rule_version=RULE_VERSION,hop_version=HOP_VERSION,inputs=inputs,archive=archive,inventory=desc(inventory_path),candidate_sources=candidate_pins,
  candidates=len(candidates),accepted_event_qids=accepted,unresolved_event_qids=[r['qid'] for r in decisions if not r['keep_event']],resolved_occurrences=resolved,unresolved_occurrences=25-resolved,
  raw_source_versions_preserved=True,classification_uncertainty_preserved=True,structural_reference_metadata='P31_P279_RETAINED_SEPARATELY',
  scope_candidates=len(scope['candidates']),scope_source_records=len(frontier),archive_record_coverage=cache_records,geometry_policy='NOT_APPROVED_NOT_APPLIED',
  per_unit_receipts=per_unit,artifacts=artifacts,processor=desc(HERE/'run_actual.py'),rule=desc(HERE/'event_rule.py'),
  scope_status='APPROVED_HOPS_EXECUTED_AT_DECLARED_CACHE_FRONTIER',consumer_materialized=False,raw_identity_decisions_changed=False,publication=False)
 write(output/'handoff.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ('inputs','candidate_sources','artifacts','per_unit_receipts')},ensure_ascii=True),flush=True)
 return result
if __name__=='__main__':run(HERE/'generation_001')
