"""Independent raw-source readback for approved Event membership and source-oriented hop outputs."""
import gzip,json,sys
from pathlib import Path
from collections import Counter
import ijson
from event_rule import evaluate_wwii,native_links,CLASS_METADATA,RULE_VERSION,HOP_VERSION
from run_actual import HERE,sha,read,write,desc,ARCHIVE,ARCHIVE_SHA,FIELDS
from decision_revision_hook import content_hash

def digest(value):
 import hashlib
 return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def main():
 output=HERE/'generation_001';hand=read(output/'handoff.json');config=read(HERE/'APPROVED_CONFIG.json')
 assert config['version']==RULE_VERSION and config['hops']['version']==HOP_VERSION and config['geography']['mask'] is None
 for descriptor in [*hand['inputs'].values(),hand['archive'],hand['inventory'],*hand['candidate_sources'],*hand['artifacts'].values(),hand['processor'],hand['rule']]:assert sha(descriptor['path'])==descriptor['sha256']
 graph=read(output/'p361_source_evidence.json');selection=read(output/'event_selection.json');byqid={r['qid']:r for r in selection['decisions']}
 for q,row in byqid.items():
  check=evaluate_wwii(q,graph)
  for key in ('status','keep_event','reason','p361_chain','source_pending'):assert check[key]==row[key]
 accepted={q for q,r in byqid.items() if r['keep_event']};assert accepted=={'Q713516','Q52418','Q1645012'} and not byqid['Q362']['keep_event']
 for q in accepted:
  current=q
  for edge in byqid[q]['p361_chain']:
   assert edge['subject_qid']==current and edge['source_predicate']=='wd:P361';current=edge['object_qid']
  assert current=='Q362'
  assert byqid[q]['classification_uncertainty']['status']=='UNRESOLVED_INCOMPLETE_CACHED_HIERARCHY'
 registry=read(hand['inputs']['native_registry']['path'])['selected_references'];facts={};edge_index={};metadata_ids=set()
 def add(q,node):
  expected=facts.setdefault(q,dict(source=node['source'],revision=node['record'].get('lastrevid'),claims={}))
  assert expected['source']==node['source'] and expected['revision']==node['record'].get('lastrevid')
  for prop,rows in node['record']['claims'].items():expected['claims'].setdefault(prop,set()).update(digest(s) for s in rows)
  for edge in native_links(q,node):edge_index[(edge['subject_qid'],edge['object_qid'],edge['source_predicate'],edge['source_record_id'])]=digest(edge['raw_statement'])
 for q,node in graph.items():add(q,node)
 with (output/'scope_source_evidence.json').open('rb') as stream:
  for q,node in ijson.kvitems(stream,'',use_float=True):
   if q in registry:assert node['record']==registry[q]['envelope']['entity'] and node['source']==registry[q]['provenance']
   add(q,node)
 checked_archive=set()
 with gzip.open(ARCHIVE,'rt',encoding='utf8') as stream:
  for number,line in enumerate(stream,1):
   envelope=json.loads(line);q=envelope['requested_qid']
   if q not in facts or facts[q]['source'].get('file')!=str(ARCHIVE):continue
   expected=facts[q];raw=envelope['entity'];assert expected['source']['line']==number and raw['id']==q and raw.get('lastrevid')==expected['revision']
   for prop,hashes in expected['claims'].items():assert hashes<={digest(s) for s in raw['claims'].get(prop,[])}
   checked_archive.add(q)
 assert checked_archive=={q for q,x in facts.items() if x['source'].get('file')==str(ARCHIVE)}
 counts=Counter();first_seen=set();all_scope_count=0
 with (output/'scope_discovery.json').open('rb') as stream:
  for row in ijson.items(stream,'candidates.item',use_float=True):
   assert row['anchor'] in accepted and row['hop']==len(row['path']) and row['hop'] in (1,2);walk=row['anchor']
   for edge in row['path']:
    key=tuple(edge[k] for k in ('subject_qid','object_qid','source_predicate','source_record_id'))
    assert key in edge_index and edge_index[key]==digest(edge['raw_statement']) and edge['source_predicate'] not in CLASS_METADATA
    assert edge['walk_from']==walk
    assert (edge['walk_from'],edge['walk_to'])==((edge['subject_qid'],edge['object_qid']) if edge['walk_direction']=='OUTGOING' else (edge['object_qid'],edge['subject_qid']))
    walk=edge['walk_to']
   assert walk==row['qid']
   if row['type']=='LOC':assert row['inclusion']=='PENDING_GEO'
   if row['hop']==2 and row['type'] not in (None,'LOC'):assert row['inclusion']=='EXCLUDE'
   if row['type'] is None:assert row['inclusion']=='PENDING_TYPE'
   if row['hop']==1:
    edge=row['path'][0];first_seen.add((row['anchor'],edge['subject_qid'],edge['object_qid'],edge['source_record_id']))
   counts[(row['hop'],row['inclusion'])]+=1;all_scope_count+=1
 expected_first=set()
 for subject,target,prop,sid in edge_index:
  if prop in CLASS_METADATA:continue
  if subject in accepted:expected_first.add((subject,subject,target,sid))
  if target in accepted:expected_first.add((target,subject,target,sid))
 assert first_seen==expected_first and all_scope_count==hand['scope_candidates']
 projection=read(hand['inputs']['identity_projection']['path']);units={v[-1]['manifest']['page_id']:v[-1] for v in projection['count_state']};inventory=read(hand['inventory']['path']);seen=set();resolved=0
 for entry,descriptor in zip(inventory['units'],hand['per_unit_receipts']):
  assert sha(descriptor['event_route']['path'])==descriptor['event_route']['sha256'];receipt=read(descriptor['event_route']['path'])
  rows=sorted([r for r in units[entry['page']]['occurrences'] if r['occurrence_id'] in entry['event_ids']],key=lambda r:r['occurrence_id'])
  assert receipt['source_scope']=={k:units[entry['page']]['manifest'][k] for k in FIELDS} and receipt['input_occurrences_sha256']==content_hash(rows)
  assert {r['occurrence_id'] for r in receipt['outcomes']}==set(entry['event_ids'])
  for row in receipt['outcomes']:
   assert row['occurrence_id'] not in seen;seen.add(row['occurrence_id']);resolved+=row['status']=='RESOLVED'
 assert len(seen)==25 and resolved==4
 entities=read(output/'event_entities.json');events=read(output/'events.json')
 assert {r['event_id'] for r in events}==accepted=={r['entity_id'] for r in entities}
 assert all(r['attributes']['mention_ids']==[] for r in entities)
 result=dict(status='PASS_INDEPENDENT_APPROVED_EVENT_RULE_AND_HOPS',accepted_event_qids=sorted(accepted),unresolved_event_qids=['Q362'],resolved_occurrences=4,unresolved_occurrences=21,
  exact_native_archive_records_verified=len(checked_archive),scope_paths_verified=all_scope_count,scope_counts={str(k):v for k,v in counts.items()},
  first_hop_all_properties_verified=True,native_directions_and_raw_statements_verified=True,classification_uncertainty_retained=True,
  geometry_mask_not_applied=True,root_zero_hop_exception_not_invented=True,ordinary_identity_decisions_unchanged=True,
  config=desc(HERE/'APPROVED_CONFIG.json'),handoff=desc(output/'handoff.json'),tests=11,consumer_materialized=False,publication=False)
 write(HERE/'independent_readback.json',result);print(json.dumps(result))
if __name__=='__main__':main()
