"""Explicit version-aware real-relation entrypoint; no inference, acquisition or publication."""
import csv
import json
import sys
from copy import deepcopy
from pathlib import Path

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
MAIN=Path(r'D:\Projects\GeoAI')
sys.path[:0]=[str(ROOT/'orchestration_direct_20261101'),str(ROOT/'pair_relations_direct_20261101'),str(ROOT/'durable_units_direct_20261101')]
from decision_revision_hook import refresh_for_decision,require_current,content_hash,replace_unit,decision_binding
from real_counts_revision import recompute_counts,pair_counts
from extend_oahu_pair_views import scan,populate,build_graph,weighted_fallback,pair_frontier,digest,encoded
sys.path.insert(0,str(ROOT/'pair_relations_direct_20261101/registry_completion_0001'))
from registry_completion import choose_name


def dispatch_relations(state,handoff,source_bytes,count_receipt,previous,history,native_path,native_sha256):
    """Caller supplies validated accepted decisions, matching counts and pinned native registry."""
    prospective=deepcopy(state)
    replace_unit(prospective,handoff,source_bytes)
    require_current(count_receipt,prospective)  # Reject stale/tampered counts before any caller mutation.
    native_path=Path(native_path)
    if digest(native_path)!=native_sha256:
        raise ValueError('Native registry differs from caller-pinned source hash')
    registry=json.loads(native_path.read_text())
    mapping_path=MAIN/'GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv'
    direction_path=MAIN/'GG_Data/mapping/RELATION_DIRECTION_LOOKUP_v2.1.1.csv'
    expected={mapping_path:'8ecdc0095d10ec1fc24dfb82510473faef42b896c126b76cb0daeb233b301821',direction_path:'94084138d9af8a7d297830c25b31d1995e9ef7eec20ad23ceb3702a224699b3b'}
    if any(digest(path)!=value for path,value in expected.items()):
        raise ValueError('Pinned native catalog changed')
    binding=dict(count_receipt_sha256=content_hash(count_receipt),native_registry_sha256=native_sha256,
                 mapping_sha256=expected[mapping_path],direction_sha256=expected[direction_path])
    def recompute(current,prior,versions):
        require_current(count_receipt,current)
        counts=count_receipt['projection']
        qids={row['qid'] for row in counts['identity_counts']}
        available=qids & set(registry['selected_references'])
        entities=[]
        for row in counts['typed_counts']:
            qid=row['qid']
            if qid not in available:
                continue
            reference=registry['selected_references'][qid]
            envelope=reference['envelope']
            if envelope['requested_qid']!=qid or envelope['entity'].get('id')!=qid or 'claims' not in envelope['entity']:
                raise ValueError('Native whole-record identity or claims missing')
            name=choose_name(qid,envelope['entity'],{},[])
            entities.append(dict(entity_id=qid,type=row['entity_group'],name=name['value'],aliases=[],
                                 raw_reference=dict(full=envelope),sources=[reference['provenance']]))
        def read_csv(path):
            with path.open(encoding='utf-8-sig',newline='') as stream:
                return list(csv.DictReader(stream))
        mapping,directions=read_csv(mapping_path),read_csv(direction_path)
        retained,excluded,scan_counts=scan(entities,available,{(row['source'],row['source_predicate']):row for row in mapping})
        relations=populate(retained,{(row['source'],row['source_predicate']):row for row in mapping})
        graph,_=build_graph(entities,[],relations,mapping,directions,dict(registry['native_producer_graph']['metadata'],
            scope='Interim relation revision bound to supplied accepted decisions/counts and available pinned native records'))
        # Compact C4 counts may omit pair rows; reuse the existing physical-page reducer.
        pairs=counts['pairs'] if 'pairs' in counts else pair_counts(current)
        covered=[row for row in pairs if {row['source_qid'],row['target_qid']}<=available]
        pending=[dict(row,reason='MISSING_FULL_NATIVE_RECORD',missing_qids=sorted({row['source_qid'],row['target_qid']}-available))
                 for row in pairs if not {row['source_qid'],row['target_qid']}<=available]
        active=pair_frontier(graph['edges'],weighted_fallback(covered),[])
        result=dict(input_binding=binding,decision_version=counts['decision_version'],count_unit_sha256=counts.get('pinned_unit_sha256') if len(count_receipt['decision_binding'])==1 else None,
                    count_frontier_sha256=content_hash(count_receipt['decision_binding']),
                    covered_qids=sorted(available),missing_qids=sorted(qids-available),counts=counts,
                    relations=relations,scan_counts=dict(scan_counts),excluded=excluded,active_views=active,pending_pairs=pending,
                    native_registry_path=str(native_path),interim=True,consumer_export=False)
        versions.append(dict(decision_version=counts['decision_version'],input_binding=deepcopy(binding),
                             projection_sha256=content_hash(result),active_views=deepcopy(active),pending_pairs=deepcopy(pending)))
        return result
    # The tested hook keys decision dependencies. Source/count-only changes also need explicit refresh.
    hook_previous=previous
    if previous is not None and previous['decision_binding']==decision_binding(prospective) and previous['projection']['input_binding']!=binding:
        hook_previous=None
    return refresh_for_decision(state,handoff,source_bytes,hook_previous,history,recompute)



