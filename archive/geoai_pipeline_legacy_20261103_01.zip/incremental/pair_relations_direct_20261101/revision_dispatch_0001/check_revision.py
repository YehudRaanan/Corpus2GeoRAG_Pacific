"""Sandbox copy of the real first unit and its real ten-record relation frontier."""
import json
from copy import deepcopy
from pathlib import Path
from shutil import copyfile
from relation_revision import *
from durable_unit import recover,seal_unit,sha,encoded as seal_encoded


def check(output):
    original=ROOT/'integration_direct_20261101/real_handoff_0001'
    old_pair=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    old_verify=json.loads(old_pair.with_name('verification.json').read_text())
    assert digest(old_pair)==old_verify['output_sha256']
    source_receipt=json.loads((original/'receipt.json').read_text())
    protected=dict(old_verify['protected_sha256'])
    protected.update({str(old_pair):digest(old_pair),str(original/'receipt.json'):digest(original/'receipt.json')})
    for lane,names in [('orchestration_direct_20261101',['decision_revision_hook.py','real_counts_revision.py']),
                       ('durable_units_direct_20261101',['durable_unit.py'])]:
        protected.update({str(ROOT/lane/name):digest(ROOT/lane/name) for name in names})
    assert all(digest(Path(path))==expected for path,expected in protected.items())
    copied=output/'copied_v1'
    copied.mkdir()
    for name in ('seal.json','unit.private.json','source.private.bin'):
        copyfile(original/'sealed_v1'/name,copied/name)
    first=recover(copied,source_receipt['pinned_unit_sha256'])['handoff']
    source=(copied/'source.private.bin').read_bytes()
    count_state,count_history,relation_state,relation_history={},[],{},[]
    c1=refresh_for_decision(count_state,first,source,None,count_history,recompute_counts)
    r1=dispatch_relations(relation_state,first,source,c1,None,relation_history,old_pair,old_verify['output_sha256'])
    baseline=json.loads(old_pair.read_text())
    assert r1['projection']['active_views']==baseline['active_pair_views']
    assert len(r1['projection']['active_views'])==90 and not r1['projection']['pending_pairs']
    assert dispatch_relations(relation_state,first,source,c1,r1,relation_history,old_pair,old_verify['output_sha256']) is r1
    assert len(relation_history)==1
    second=deepcopy(first)
    second.update(version='SANDBOX_RELATIONS_VERSION_ONLY_v2',prior_version=first['version'])
    second_hash=sha(seal_encoded(second))
    seal_unit(output/'shadow_v2',second,source,second_hash,prior_history=[first])
    second=recover(output/'shadow_v2',second_hash,prior_history=[first])['handoff']
    c2=refresh_for_decision(count_state,second,source,c1,count_history,recompute_counts)
    r2=dispatch_relations(relation_state,second,source,c2,r1,relation_history,old_pair,old_verify['output_sha256'])
    assert r2['projection']['active_views']==r1['projection']['active_views'] and len(relation_history)==2
    assert r2['stale_previous_projection_rejected']
    assert r2['projection']['decision_version']==second['version'] and r2['decision_binding']!=r1['decision_binding']
    third=deepcopy(second)
    third.update(version='SANDBOX_MISSING_NATIVE_QID_v3',prior_version=second['version'])
    changed=[]
    for decision in third['decisions']:
        if decision['qid']=='Q131347':
            changed.append(decision['occurrence_id'])
            decision.update(qid='Q999999991',evidence=dict(simulation='New QID without source, not real model output',prior=deepcopy(decision['evidence'])))
    assert len(changed)==1
    third_hash=sha(seal_encoded(third))
    seal_unit(output/'shadow_v3',third,source,third_hash,prior_history=[first,second])
    third=recover(output/'shadow_v3',third_hash,prior_history=[first,second])['handoff']
    before_failed=deepcopy((relation_state,relation_history))
    try:
        dispatch_relations(relation_state,third,source,c2,r2,relation_history,old_pair,old_verify['output_sha256'])
    except ValueError as error:
        assert 'Stale projection' in str(error)
    else:
        raise AssertionError('Stale decision/count dependency accepted')
    assert (relation_state,relation_history)==before_failed
    c3=refresh_for_decision(count_state,third,source,c2,count_history,recompute_counts)
    r3=dispatch_relations(relation_state,third,source,c3,r2,relation_history,old_pair,old_verify['output_sha256'])
    assert r3['stale_previous_projection_rejected']
    p3=r3['projection']
    assert p3['missing_qids']==['Q999999991'] and len(p3['pending_pairs'])==9
    assert all('Q999999991' not in (e['source'],e['target']) for e in p3['active_views'])
    assert len(p3['active_views'])==72 and len(p3['relations'])==4
    assert len(relation_history)==3 and relation_history[:2][0]['active_views']==r1['projection']['active_views']
    assert all(r['missing_qids']==['Q999999991'] and r['reason']=='MISSING_FULL_NATIVE_RECORD' for r in p3['pending_pairs'])
    assert dispatch_relations(relation_state,third,source,c3,r3,relation_history,old_pair,old_verify['output_sha256']) is r3
    assert len(relation_history)==3 and len(count_history)==3
    assert len(next(iter(relation_state.values())))==3
    for receipt in (r1,r2,r3):
        c=receipt['projection']['counts']
        assert (c['retained_occurrences'],c['accepted_occurrences'],c['pending_occurrences'],len(c['pairs']))==(136,30,106,45)
        assert all(p['shared_page_count']==p['source_page_count']==p['target_page_count']==1 for p in c['pairs'])
    assert first['occurrences']==second['occurrences']==third['occurrences']
    assert first['pending_evidence']==second['pending_evidence']==third['pending_evidence']
    try:
        dispatch_relations(relation_state,third,source,c3,r3,relation_history,old_pair,'0'*64)
    except ValueError as error:
        assert 'Native registry' in str(error)
    else:
        raise AssertionError('Wrong native source binding accepted')
    assert len(relation_history)==3
    assert all(digest(Path(path))==expected for path,expected in protected.items())
    return dict(status='PASS_REAL_RELATION_REVISION_SANDBOX',receipts=[r1,r2,r3],count_receipts=[c1,c2,c3],
        relation_history=relation_history,count_history=count_history,units=[first,second,third],changed_occurrence_ids=changed,
        protected_sha256=protected,real_decisions_changed=False,simulated_new_qid='Q999999991',consumer_export=False)


if __name__=='__main__':
    output=HERE/'run_0002'
    output.mkdir()
    payload=check(output)
    (output/'result.json').write_bytes(encoded(payload))
    proof=dict(status=payload['status'],checks=9,code_sha256=digest(HERE/'relation_revision.py'),
               check_sha256=digest(Path(__file__)),output_sha256=digest(output/'result.json'),
               active_counts=[len(r['projection']['active_views']) for r in payload['receipts']],
               pending_pair_counts=[len(r['projection']['pending_pairs']) for r in payload['receipts']],
               versions=[r['projection']['decision_version'] for r in payload['receipts']])
    (output/'verification.json').write_bytes(encoded(proof))
    print(json.dumps(proof))

