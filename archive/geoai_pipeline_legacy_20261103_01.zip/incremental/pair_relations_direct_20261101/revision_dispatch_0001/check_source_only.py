"""Same real decisions/count receipt; verified native-source frontier changes 9 -> 10 records."""
import json
from copy import deepcopy
from pathlib import Path
from relation_revision import dispatch_relations,replace_unit,content_hash,digest,encoded,ROOT,HERE


def check():
    baseline=json.loads((HERE/'run_0002/result.json').read_text())
    proof=json.loads((HERE/'run_0002/verification.json').read_text())
    assert digest(HERE/'run_0002/result.json')==proof['output_sha256']
    assert digest(HERE/'relation_revision.py')==proof['code_sha256']
    first=baseline['units'][0]
    counts=baseline['count_receipts'][0]
    source=(HERE/'run_0002/copied_v1/source.private.bin').read_bytes()
    prior=ROOT/'pair_relations_direct_20261101/real_pair_views_20261101T203117785273Z/pair_views.json'
    later=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    protected={str(path):digest(path) for path in (prior,later,HERE/'relation_revision.py',HERE/'run_0002/result.json')}
    for path in (prior,later):
        verification=json.loads(path.with_name('verification.json').read_text())
        assert digest(path)==verification['output_sha256']
        protected.update(verification['protected_sha256'])
    assert all(digest(Path(path))==expected for path,expected in protected.items())
    state,history={},[]
    initial=dispatch_relations(state,first,source,counts,None,history,prior,protected[str(prior)])
    assert len(initial['projection']['active_views'])==72 and len(initial['projection']['pending_pairs'])==9
    assert dispatch_relations(state,first,source,counts,initial,history,prior,protected[str(prior)]) is initial
    assert len(history)==1
    original_state,original_counts,old_history=deepcopy(state),deepcopy(counts),deepcopy(history)
    revised=dispatch_relations(state,first,source,counts,initial,history,later,protected[str(later)])
    assert revised is not initial and revised['decision_binding']==initial['decision_binding']
    assert revised['projection']['input_binding']['count_receipt_sha256']==initial['projection']['input_binding']['count_receipt_sha256']
    assert revised['projection']['input_binding']['native_registry_sha256']!=initial['projection']['input_binding']['native_registry_sha256']
    assert revised['projection']['counts']==initial['projection']['counts']
    assert state==original_state and counts==original_counts
    assert len(history)==2 and history[:1]==old_history
    before={edge['id']:edge for edge in initial['projection']['active_views']}
    after={edge['id']:edge for edge in revised['projection']['active_views']}
    assert all(after[key]==edge for key,edge in before.items())
    added=[edge for key,edge in after.items() if key not in before]
    assert len(after)==90 and len(added)==18 and revised['projection']['pending_pairs']==[]
    assert all(edge.get('kind')=='CO_MENTIONED' and 'Q131347' in (edge['source'],edge['target']) for edge in added)
    assert initial['projection']['relations']==revised['projection']['relations'] and len(revised['projection']['relations'])==4
    frozen=deepcopy(history)
    assert dispatch_relations(state,first,source,counts,revised,history,later,protected[str(later)]) is revised
    assert history==frozen and len(history)==2
    assert len(next(iter(state.values())))==1  # No decision revision was manufactured for a source change.
    assert all(digest(Path(path))==expected for path,expected in protected.items())
    return dict(status='PASS_SOURCE_ONLY_REAL_FRONTIER_REFRESH',before=initial,after=revised,history=history,
                added_views=added,protected_sha256=protected,identity_history_versions=1,actual_decisions_changed=False)


if __name__=='__main__':
    output=HERE/'source_only_0001'
    output.mkdir()
    payload=check()
    (output/'result.json').write_bytes(encoded(payload))
    receipt=dict(status=payload['status'],checks=['verified_actual_source_v1_to_v2','same_decision_and_count_binding',
        'source_change_refreshes','old_72_preserved_18_added','two_projection_histories_one_decision_version','both_exact_replays_skip','real_inputs_unchanged'],
        code_sha256=digest(HERE/'relation_revision.py'),check_sha256=digest(Path(__file__)),output_sha256=digest(output/'result.json'),
        active_counts=[72,90],pending_pair_counts=[9,0])
    (output/'verification.json').write_bytes(encoded(receipt))
    print(json.dumps(receipt))
