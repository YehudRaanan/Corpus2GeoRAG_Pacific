# Source-only revision branch - PASS

Seven focused checks and six independent fresh-process checks passed. No adapter implementation changed.

Inputs: actual first-unit-exact-v1 decisions and their identical count receipt throughout; verified real_pair_views_20261101T203117785273Z native registry (nine records) then verified real_pair_views_v2_20261101T205143791359Z registry (ten records including Oahu). Both artifact hashes and recorded protected-source hashes were checked.

Result: 72 ->90 active views, nine ->zero pending native-source pairs. The count receipt and complete active decision binding remain identical. Only the native-registry hash changes. This forces the source-only branch to recompute despite the decision-only hook's otherwise valid cached result. Four native/four inverse assertions stay unchanged; exactly18 Oahu default directions are added, with all72 original views unchanged.

History: two private relation-projection versions; one identity-decision version. Exact replay of BOTH frontiers returns the same previous receipt object and adds no computation/history. No real decisions/counts or prior source artifacts were changed. The fresh-process rebuild is byte-identical to source_only_0001/result.json.

Evidence: source_only_0001/result.json, verification.json, independent_readback.json. Check: check_source_only.py. Adapter relation_revision.py SHA256 remains ae41d13af1833cf3040fce27bde75c428aaae0888ada64d8eb411553ca6e5af1. Result SHA256 9000293092f393637714bbe103398b08b78159258f5258b09ec62da48a8ba2f0.

The remaining branch-test gap in REPORT.md is closed by this check. The entrypoint remains explicit: the orchestrator must supply validated current decisions/counts and the intended caller-pinned native frontier. Actual model acceptance, source acquisition, geometry/publisher successor wiring, targeted recomputation and durable cross-stage recovery remain outside this test. No new logic, external calls, consumer fields or publication. Worker stops here and awaits orchestrator integration. Backup: Unprotected.
