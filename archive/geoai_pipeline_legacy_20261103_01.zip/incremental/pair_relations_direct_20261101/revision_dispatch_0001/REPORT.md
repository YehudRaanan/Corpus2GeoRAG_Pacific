# E5/R7 real-relation revision adapter - bounded sandbox PASS

Entrypoint: relation_revision.py::dispatch_relations(state, handoff, source_bytes, count_receipt, previous, history, native_path, native_sha256).

Connection: existing E2 seal/recover -> accepted occurrence handoff -> tested refresh_for_decision + real_counts_revision.recompute_counts -> matching count receipt -> dispatch_relations -> existing relations.scan/populate/build_graph -> existing weighted_fallback/pair_frontier -> version-bound private relation receipt/history. Shared implementations are imported read-only. Caller must supply the validated handoff, matching counts and independently pinned native source artifact. No automatic model acceptance or latest-version discovery was added.

Source is the actual verified first unit and actual ten-record mixed frontier real_pair_views_v2_20261101T205143791359Z/pair_views.json, SHA256 1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4. This is real-data replay in sandbox copies, with explicitly synthetic successor decisions. Original accepted decisions/artifacts remain unchanged.

| Sandbox version | Active native/inverse/default | Active total | Source-pending pairs |
|---|---|---:|---:|
| Actual first-unit-exact-v1 replay | 4 / 4 / 82 | 90 | 0 |
| Synthetic version-only v2 | 4 / 4 / 82 | 90 | 0 |
| Synthetic v3: one Oahu occurrence changes to Q999999991 without a native record | 4 / 4 / 64 | 72 | 9 |

The new unsupported QID stays an accepted sandbox count endpoint but its nine relation pairs stay MISSING_FULL_NATIVE_RECORD. No fallback/native endpoint is manufactured or relabelled for it. All old 72 non-Oahu views remain exact. Counts retain 136 originals, 30 accepted occurrences, 106 pending identities, ten identities, one physical page and 45 internal pairs. The nine relation-source pending pairs are distinct from the 106 pending identity records.

The adapter rejects stale decision/count receipts and wrong caller-pinned native hashes before caller-state mutation. A decision/count successor invokes the existing tested hook and rejects the old active frontier. A changed native/count binding at the same decision frontier explicitly forces refresh rather than allowing the decision-only hook to reuse stale evidence. This latter source-only branch is implemented but not separately exercised in this increment. Exact replay returns the previous receipt and adds no history. Three E2-validated shadow decision versions and three relation projection versions remain preserved; unchanged source rows/pending evidence are exact.

Verification: nine focused checks passed; run_0002/independent_readback.json records eight fresh-process checks. Independent replay reproduced all three receipts/histories, rejected old count frontier, independently recounted original decisions, checked 90/90/72 active and 0/0/9 pending, and verified real/shared hashes. run_0001 is retained earlier passing evidence; run_0002 is authoritative after preserving the hook's explicit stale-frontier flag.

Code SHA256 ae41d13af1833cf3040fce27bde75c428aaae0888ada64d8eb411553ca6e5af1.
Result SHA256 8261dc62668200263b9712d79c7ecaaee2af1208b7695e9222ab042d155c3948.
Evidence: run_0002/{result.json,verification.json,independent_readback.json}; copied_v1, shadow_v2, shadow_v3 retain sealed custody evidence.

Remaining gap: the entrypoint is connected and tested for explicit caller invocation. A real model lane must first supply ACCEPTED occurrence decisions and an appropriate new count receipt; the orchestrator must call this entrypoint, then feed its bound output to geometry/publisher successor adapters. Unknown new-QID source retrieval remains pending and needs its scoped owner; no external acquisition occurs here. No background watcher, targeted dependency index, durable cross-stage transaction, geometry/publisher refresh or production dispatch was added. Full reference computation is retained for this one-unit scope. Source-only refresh negative tests can be a later small increment if needed.

Only revision_dispatch_0001 was written. No actual identity changes, model calls, external calls, consumer fields, shared-plan edits, publication or nested agents. Backup: Unprotected.
