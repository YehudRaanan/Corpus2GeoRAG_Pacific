# E5 / R7 first real-unit native-cache readiness

2026-11-01: bounded read-only local audit complete. No active relation/fallback edges were manufactured.

Input: verified counts for enwiki page 48975579 / processing revision 1375061414, decision first-unit-exact-v1: 30 accepted occurrences, ten accepted identities, 45 pairs; 106 pending occurrences remain outside the endpoints. All recorded protected/output hashes in the real-count receipt were checked before inspection, and the ten identity IDs were reconciled with the sealed real_handoff_0001 decisions.

## Coverage actually inspected

- The existing projected entity_metadata.json.gz covers all ten identity names/types, but has no claims field. It establishes zero full native-claims coverage.
- All SIX saved BigQuery full-item query files under D:/Projects/GeoAI/GG_Data/pipeline/outputs/wikidata_full_cache were scanned. Seven of the accepted identities have full records there. The pinned table snapshot is 2026-10-18T18:45:19.304197+00:00; per-query retrieved_at values and file hashes are in real_pair_readiness_0001.json. Supplied entity revisions are older than the query retrieval dates; they were not relabelled as current.
- The entire local Data/external/wwii_task_force/wikidata_entities.jsonl.gz archive was streamed. It adds full records for Q5687462 and Q8042652 and additional versions for Q741723/Q8042593. Archive line locators, full entity revision/modified values, and its full file hash are retained.
- Total: nine identities with full claims records; Q131347 has no full record in these inspected sources. Other local caches were not exhaustively searched. This is no claim that a Q131347 record does not exist elsewhere.

The selected source records have NOT yet been materialized. The existing entities.select_reference policy selects a whole snapshot record first, otherwise the latest available complete same-ID record. No fields should be blended across these versions.

## Positive native evidence

Nine repeated cache observations collapse to FOUR unique statement IDs, on four unordered pairs. All are normal-rank statements. Full raw statements/qualifiers/references, source file, hash, row/line locator, revision, catalog mapping and inverse row are preserved in real_native_cache_audit_0001.json.

| Source | Property | Target | Existing v2.1.1 inverse |
|---|---|---|---|
| Q51679 | wd:P706 | Q153732 | inverse:wd:P706 |
| Q8042593 | wd:P241 | Q741723 | inverse:wd:P241 |
| Q8042652 | wd:P241 | Q741723 | inverse:wd:P241 |
| Q8042652 | wd:P361 | Q2505636 | wd:P527 |

These are positive raw source assertions, not yet populated/export-ready relation rows. In particular, P361's existing inverse is P527; there is no invented numerical or predicate transformation.

## Per-pair readiness and exact next step

36 pairs have full records for both endpoints and are ready for the next entirely local selection/scan increment. Four contain observed raw native statements; 32 contain no matching statements observed in the inspected versions. Nine pairs involving Q131347 have incomplete directional source coverage and remain pending. Absence in projected/incomplete caches is never encoded as verified no-WIKI-relation. Zero active pair frontiers have been certified in this audit; no edges were created.

Exact ready next increment: materialize the nine selected whole records with their existing provenance using snapshot-first/otherwise latest available complete same-ID selection; call the existing relations.scan against those nine accepted IDs, with its native statement-shape checks, 14 guarded exclusions and temporal rules, then existing populate/pinned mapping if it passes. Declare this partial nine-identity available/linkable frontier explicitly; retain the nine Q131347 pairs pending. Only then feed the resulting producer views plus corresponding internal count evidence to the verified pair-local selector. Do not silently claim complete ten-identity or whole-page native coverage. Q131347 needs an approved full-record source (or another bounded local cache search) before its nine pairs can establish two-direction availability. No network acquisition is authorized here.

Mapping/inverse availability is verified for all four observed raw assertions, but exclusions/time checks and producer-ready relation rows have not been run. These are the concrete remaining prerequisites, rather than an assumption that zero currently prepared rows means no native relations. G11 consumer-weight serialization remains unchanged.

## Evidence and limits

Code: audit_real_native_cache.py. Audit: real_native_cache_audit_0001.json. All-45-pair readiness/source retrieval metadata: real_pair_readiness_0001.json. Fresh-process hash/coverage readback: real_native_cache_verification_0001.json.

The first read encountered the existing BigQuery dump trailing-comma convention; the audit now uses the exact rstrip handling already in entities.py, retaining raw cached source bytes unchanged. No shared source, plans, counts, handoff, credentials, environment, input/training files or consumer contracts were changed. All writes are in pair_relations_direct_20261101. No external calls, paid work, agents, consumer export or publication. Backup: Unprotected.
