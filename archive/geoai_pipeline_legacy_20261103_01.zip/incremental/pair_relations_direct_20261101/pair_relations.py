"""Generated E5/R7 pair frontier, not a production reducer or consumer export."""
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT / "relations"), r"D:\Projects\GeoAI"]
from native_pair_views import select_native_views
from GG_Data.pipeline.graph_export import build_graph
from GG_Data.pipeline.test_graph_export import fixture


def pair_frontier(native_views, fallback_views, history):
    """Caller supplies one complete linkable native frontier and internal fallback."""
    selected = select_native_views(native_views)
    native_pairs = {frozenset((edge["source"], edge["target"])) for edge in native_views
                    if not edge.get("derived") and edge.get("source_edge_id") is None}
    active = selected + [edge for edge in fallback_views
                         if frozenset((edge["source"], edge["target"])) not in native_pairs]
    # Small fixture snapshot history; exact replay does not add another version.
    # ponytail: full snapshots for tiny fixtures; durable affected-pair history is a later integration.
    snapshot = dict(native_views=deepcopy(native_views), fallback_views=deepcopy(fallback_views), active=deepcopy(active))
    if not history or history[-1] != snapshot:
        history.append(snapshot)
    return active


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def self_check():
    protected_paths = [ROOT / "relations/native_pair_views.py",
                       Path(r"D:\Projects\GeoAI\GG_Data\pipeline\graph_export.py"),
                       Path(r"D:\Projects\GeoAI\GG_Data\pipeline\test_graph_export.py"),
                       ROOT / "contract_fixtures/test_native_pair_consumer.py"]
    protected = {str(path): digest(path) for path in protected_paths}
    source = fixture()  # Existing generated catalog v2.1.2 supplies the inverse.
    source["entities"].append(dict(source["entities"][0], entity_id="Q3", name="Generated C"))
    base = source["relations"][0]
    source["relations"] = [dict(base, observation_id="native-ac", object_entity_id="Q3")]
    # Supplied internal connectivity only; no new formula or consumer weight field.
    fallback = [dict(id="fallback-ab", source="Q1", target="Q2", kind="CO_MENTIONED", shared_page_count=1),
                dict(id="fallback-ba", source="Q2", target="Q1", kind="CO_MENTIONED", shared_page_count=1)]
    fallback_before = deepcopy(fallback)
    history = []
    graphs = []
    for phase in range(3):
        if phase == 1:
            source["relations"].append(dict(base, observation_id="native-ab"))
        if phase == 2:
            source["relations"].append(dict(base, observation_id="native-ba", subject_entity_id="Q2", object_entity_id="Q1", time_from="+1943-00-00T00:00:00Z"))
            source["relations"].append(dict(base, observation_id="native-ab-independent", time_from="+1944-00-00T00:00:00Z"))
        source_before = deepcopy(source)
        graph, _ = build_graph(**source)
        graphs.append(deepcopy(graph))
        prior = deepcopy(history)
        active = pair_frontier(graph["edges"], fallback, history)
        by_id = {row["id"]: row for row in active}
        expected = [{"native-ac", "native-ac::REVERSE", "fallback-ab", "fallback-ba"},
                    {"native-ac", "native-ac::REVERSE", "native-ab", "native-ab::REVERSE"},
                    {"native-ac", "native-ac::REVERSE", "native-ab", "native-ba", "native-ab-independent"}][phase]
        assert set(by_id) == expected, f"phase {phase}: incorrect active views"
        assert history[:-1] == prior and len(history) == phase + 1
        assert source == source_before and graph == graphs[-1] and fallback == fallback_before
        if phase == 1:
            native, inverse = by_id["native-ab"], by_id["native-ab::REVERSE"]
            assert inverse["type"] == "inverse:wd:P1" and inverse["source_edge_id"] == native["id"]
            assert inverse["derived"] is True and inverse["derived_direction"] == "REVERSE"
            for field in ("count", "start_date", "end_date"):
                assert inverse.get(field) == native.get(field)
            assert inverse["type"] in graph["relation_catalog"]
        if phase == 2:
            assert by_id["native-ba"]["start_date"] == "+1943-00-00T00:00:00Z"
            assert by_id["native-ab-independent"]["start_date"] == "+1944-00-00T00:00:00Z"
        frozen = deepcopy(history)
        assert pair_frontier(graph["edges"], fallback, history) == active and history == frozen
    assert {row["id"] for row in history[0]["active"]} >= {"fallback-ab", "fallback-ba"}
    assert all(row["kind"] == "CO_MENTIONED" for version in history for row in version["fallback_views"])
    # Caller mutation cannot rewrite a stored historical snapshot.
    isolated = deepcopy(history)
    original = deepcopy(isolated)
    copied_fallback = deepcopy(fallback)
    pair_frontier(graphs[0]["edges"], copied_fallback, isolated)
    copied_fallback[0]["shared_page_count"] = 99
    assert isolated[-1]["fallback_views"] == fallback_before and isolated[:3] == original
    assert protected == {str(path): digest(path) for path in protected_paths}
    output = HERE / ("case_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    output.mkdir()
    payload = dict(history=history, producer_graphs=graphs, generated_only=True, consumer_export=False)
    data_path = output / "transitions_and_history.json"
    data_path.write_bytes(encoded(payload))
    assert json.loads(data_path.read_text()) == payload
    checks = ["unrelated_ac_does_not_suppress_ab", "fallback_both_directions", "late_native_replaces_active_fallback",
              "old_fallback_retained", "one_native_catalog_inverse", "both_native_no_redundant_inverse",
              "independent_assertion_dates_preserved", "exact_replay_noop", "inputs_unchanged",
              "history_copied", "output_readback", "shared_sources_unchanged"]
    verification = dict(status="PASS", checks=checks, code_sha256=digest(Path(__file__)),
                        protected_sha256=protected, output_sha256=digest(data_path), history_versions=len(history),
                        active_counts=[len(version["active"]) for version in history], backup_status="Unprotected")
    (output / "verification.json").write_bytes(encoded(verification))
    print(json.dumps(dict(status="PASS", checks=len(checks), history_versions=len(history),
                         active_counts=verification["active_counts"], output=str(output), code_sha256=verification["code_sha256"])))


if __name__ == "__main__":
    self_check()
