# E5 / R7 - first real-unit partial native/default pair views

2026-11-01: PASS. Existing whole-record selection, relation scan/exclusion/time rules, population, producer and verified pair selector ran locally. Independent fresh-process readback passed ten checks. No external calls, consumer export or publication.

Authoritative output: real_pair_views_20261101T203117785273Z/pair_views.json.
Code: run_real_pair_views.py, SHA256 3ed7106ba91609ef48ba539623265e3edbab62e51aacb874bd5bbd3965939142.
Payload SHA256: 60638fb16df6e2814896a1ca0e94e7b56dbb5b8ec85f6f8c226af5df3ecde83f.
Verification: verification.json and independent_readback.json in that output directory.
The earlier real_pair_views_20261101T203030243472Z output is retained; the later output supersedes its historical-audit scope description with an explicit selected nine-identity frontier. The active counts are identical.

## Scope and source policy

One retained unit: enwiki page 48975579 / processing revision 1375061414; decision first-unit-exact-v1. The existing count receipt/source hashes remain unchanged. All 136 original occurrences remain in the sealed handoff: 30 accepted occurrences across ten QIDs, 106 pending identity records, zero explicit unmatched. All 45 pair counts remain one shared page with integer source/target denominators of one and existing directional strengths 1.0. This stage does not append or duplicate occurrence/page contributions.

Nine accepted identities have complete native source records in the inspected caches. Existing entities.select_reference selected seven whole BigQuery snapshot records (snapshot 2026-10-18T18:45:19.304197+00:00); duplicate pinned versions were checked equal. For Q5687462 and Q8042652, which lack those snapshot records, it selected the latest available complete same-ID archive record. No fields were mixed across versions. Selected raw envelopes, provider/file SHA256, row or archive line, query retrieval timestamp when supplied, entity lastrevid/modified and explicit selection route are retained in selected_references and entity sources. Archive retrieval time is not invented where absent. Existing choose_name supplied source names; original accepted types were copied from typed_counts.

The declared relation frontier is the available/linkable assertions in these nine selected cached records. It is not complete current/live Wikidata, whole-page or full-corpus relation coverage. Q131347 remains an accepted identity/count endpoint; its nine pair relations are separately pending because no full record was found in the inspected sources. The 106 pending identity records are a different category and were not promoted.

## Measured result

| View class | Active views | Evidence |
|---|---:|---|
| Native | 4 | Four independent native statement IDs |
| Catalog inverse | 4 | Existing v2.1.1 directional lookup; copied base count/dates |
| Default | 64 | Two private co-occurrence directions for each of the remaining 32 covered pairs |
| Total | 72 | All 36 covered unordered pairs, two directions each |
| Pending pairs | 9 | Every pair involving Q131347; no views manufactured |

Existing relations.scan examined nine full source identities and 1,013 raw claims: four in-scope statements, 508 item claims outside the declared identity set and 501 non-item claims. All four in-scope statements passed statement-shape, rank, existing 14-record guarded exclusion table and temporal rules. None were excluded. Temporal status was DIRECT for one assertion and NONE for three; missing dates stayed missing.

| Source | Native predicate | Target | Catalog inverse |
|---|---|---|---|
| Q51679 | wd:P706 | Q153732 | inverse:wd:P706 |
| Q8042593 | wd:P241 | Q741723 | inverse:wd:P241 |
| Q8042652 | wd:P241 | Q741723 | inverse:wd:P241 |
| Q8042652 | wd:P361 | Q2505636 | wd:P527 |

Four native pairs suppress only their own active default views. Native links involving Q51679/Q8042593/Q8042652 do not suppress those identities' defaults with other covered endpoints. All 72 supplied private fallback directions remain in the single private pair snapshot as evidence, while only 64 are active. Inverses share the base assertion evidence; they do not become extra native assertions or extra occurrence/page contributions. No new strength formula or consumer weight field was added; the existing internal weighted_fallback adapter copies existing count values.

## Independent verification and remaining work

A new Python process checked code/payload/shared-source hashes; recounted accepted occurrences directly from the sealed occurrence decisions without pair_counts; checked all 45 unique identity pairs and integer denominators; checked selected reference revisions against snapshot-first/otherwise latest available policy; replayed existing scan, exclusion/time rules, populate and build_graph from saved whole records; compared the producer graph and active views; checked four literal native endpoint/predicate triples and catalog inverses with equal dates/counts; checked exactly two private default directions for each of 32 other pairs; confirmed all nine Q131347 pairs remain pending; and repeated pair selection with unchanged single-version history.

No blocker remains for this bounded partial-frontier increment. To finish the ten-identity relation frontier, recover a full Q131347 record through an independently scoped local search or approved acquisition, select its version with the same existing source policy, scan its directions and refresh only affected pair views/history. Absent/incomplete cache evidence is never a verified statement that no native relation exists. Consumer strength serialization, production publication, durable multi-version recovery and larger input/resource scope remain outside this increment.

Only pair_relations_direct_20261101 was written. Counts, handoff, input/training files, existing implementations, catalogs, exclusions and shared plans were read-only. No agents, external calls, paid work, installation, deletion or security changes. Backup: Unprotected.

## Owner clarification: versioned interim identity-dependent projection

The above actual-unit result is an interim projection of accepted decision version first-unit-exact-v1, not final relations. Later model-based accepted identity changes require withdrawal/recalculation of affected identity/page/pair contributions and refresh of dependent native availability and pair views, with the old frontier retained in history. See REPORT_IDENTITY_REVISION.md for the separate synthetic Q1 -> Q4 regression and the explicitly missing automatic revision hook/targeted dependency index. No real accepted decisions or actual pair-view output bytes were changed by that fixture.
