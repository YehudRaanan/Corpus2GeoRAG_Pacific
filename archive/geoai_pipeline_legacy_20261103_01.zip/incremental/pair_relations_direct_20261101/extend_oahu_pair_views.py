"""Versioned interim pair projection: add one verified Oahu record to the cached frontier."""
import csv
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from run_real_pair_views import select_reference, choose_name, scan, populate, build_graph, weighted_fallback, pair_frontier, digest, encoded

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
MAIN=Path(r'D:\Projects\GeoAI')
OLD=HERE/'real_pair_views_20261101T203117785273Z'
SOURCE=ROOT/'geometry_direct_20261101/oahu_public_0001'


def run():
    old=json.loads((OLD/'pair_views.json').read_text())
    old_receipt=json.loads((OLD/'verification.json').read_text())
    assert digest(OLD/'pair_views.json')==old_receipt['output_sha256']
    protected=dict(old_receipt['protected_sha256'])
    protected.update({str(OLD/name):digest(OLD/name) for name in ('pair_views.json','verification.json','independent_readback.json')})
    report=json.loads((SOURCE/'evidence_report.json').read_text())
    assert report['status']=='VERIFIED_PUBLIC_NATIVE_EVIDENCE'
    protected.update(report['input_hashes'])
    protected.update({str(SOURCE/name):value for name,value in report['files'].items()})
    protected[str(SOURCE/'evidence_report.json')]=digest(SOURCE/'evidence_report.json')
    assert all(digest(Path(path))==expected for path,expected in protected.items())
    response=json.loads((SOURCE/'raw_response.json').read_text())
    receipt=json.loads((SOURCE/'receipt.json').read_text())
    entity=response['entities']['Q131347']
    assert response['success']==1 and entity['id']=='Q131347' and entity['lastrevid']==2555305862
    assert receipt['http_status']==200 and digest(SOURCE/'raw_response.json')==receipt['raw_response_sha256']
    native_items=[]
    for prop,statements in entity['claims'].items():
        for statement in statements:
            value=statement.get('mainsnak',{}).get('datavalue',{}).get('value')
            if isinstance(value,dict) and value.get('entity-type')=='item':
                native_items.append(dict(subject_qid='Q131347',property=prop,object_qid=value['id'],statement=statement))
    saved_items=json.loads((SOURCE/'native_item_claims.json').read_text())
    assert native_items==[{key:row[key] for key in ('subject_qid','property','object_qid','statement')} for row in saved_items]
    represented={row['qid'] for row in old['counts']['identity_counts']}
    assert all(row['source_item_revision']==2555305862 and row['source_response_sha256']==digest(SOURCE/'raw_response.json')
               and row['target_in_represented_unit']==(row['object_qid'] in represented) for row in saved_items)
    envelope=dict(requested_qid='Q131347',entity=entity)
    provenance=dict(provider='WIKIDATA',file=str(SOURCE/'raw_response.json'),sha256=digest(SOURCE/'raw_response.json'),
                    source_url=receipt['source_url'],retrieved_at=receipt['completed_at'],record_id='Q131347')
    chosen,chosen_source=select_reference('Q131347',None,[(envelope,provenance)])
    selected=deepcopy(old['selected_references'])
    selected['Q131347']=dict(envelope=chosen,provenance=chosen_source,policy='LATEST_AVAILABLE_COMPLETE_SAME_ID',
                             entity_revision=entity['lastrevid'],entity_modified=entity['modified'])
    counts=deepcopy(old['counts'])
    assert counts['decision_version']=='first-unit-exact-v1'
    qids={row['qid'] for row in counts['identity_counts']}
    assert set(selected)==qids and len(qids)==10
    entities=deepcopy(old['entities'])
    role=next(row['entity_group'] for row in counts['typed_counts'] if row['qid']=='Q131347')
    name=choose_name('Q131347',entity,{},[])
    entities.append(dict(entity_id='Q131347',type=role,name=name['value'],aliases=[],name_selection=name,
                         raw_reference=dict(full=chosen),sources=[chosen_source]))
    def read_csv(name):
        with (MAIN/'GG_Data/mapping'/name).open(encoding='utf-8-sig',newline='') as stream:
            return list(csv.DictReader(stream))
    mapping=read_csv('RELATION_MAPPING_TABLE_v2.1.1.csv')
    directions=read_csv('RELATION_DIRECTION_LOOKUP_v2.1.1.csv')
    retained,excluded,scan_counts=scan(entities,qids,{(row['source'],row['source_predicate']):row for row in mapping})
    relations=populate(retained,{(row['source'],row['source_predicate']):row for row in mapping})
    involving=[case for case in retained if 'Q131347' in (case['subject_qid'],case['object_qid'])]
    graph,graph_report=build_graph(entities,[],relations,mapping,directions,dict(old['native_producer_graph']['metadata'],
        scope='Version 2 interim: ten accepted identities; seven snapshot, two archive, one current public Oahu record; first-unit-exact-v1'))
    history=deepcopy(old['pair_history'])
    active=pair_frontier(graph['edges'],weighted_fallback(counts['pairs']),history)
    by_id={edge['id']:edge for edge in active}
    assert history[:-1]==old['pair_history'] and len(history)==2
    old_views={edge['id']:edge for edge in old['active_pair_views']}
    assert all(by_id[key]==edge for key,edge in old_views.items())
    oahu_views=[edge for edge in active if 'Q131347' in (edge['source'],edge['target'])]
    assert len(oahu_views)==18 and len({frozenset((edge['source'],edge['target'])) for edge in oahu_views})==9
    assert involving==[] and all(edge.get('kind')=='CO_MENTIONED' for edge in oahu_views)
    assert retained==old['retained'] and relations==old['relations'] and graph['edges']==old['native_producer_graph']['edges']
    assert counts==old['counts'] and len(counts['pairs'])==45
    frozen=deepcopy(history)
    assert pair_frontier(graph['edges'],weighted_fallback(counts['pairs']),history)==active and history==frozen
    native=[edge for edge in active if 'kind' not in edge and not edge.get('derived')]
    inverse=[edge for edge in active if edge.get('derived')]
    defaults=[edge for edge in active if edge.get('kind')=='CO_MENTIONED']
    summary=dict(native=len(native),inverse=len(inverse),default=len(defaults),active_total=len(active),covered_pairs=45,
                 pending_pairs=0,new_oahu_default_views=len(oahu_views),new_oahu_native_assertions=len(involving),
                 accepted_occurrences=30,pending_identity_occurrences=106,decision_version=counts['decision_version'],
                 pair_history_versions=len(history),source_records=10)
    assert (summary['native'],summary['inverse'],summary['default'],summary['active_total'])==(4,4,82,90)
    payload=dict(projection_version='real-pair-source-v2',prior_projection=str(OLD),summary=summary,
        selected_references=selected,entities=entities,retained=retained,excluded=excluded,scan_counts=dict(scan_counts),relations=relations,
        native_producer_graph=graph,graph_report=graph_report,active_pair_views=active,pair_history=history,counts=counts,pending_pairs=[],
        oahu_pair_outcomes=[dict(pair,outcome='TWO_DEFAULT_DIRECTIONS_AT_DECLARED_MIXED_SOURCE_FRONTIER',native_outgoing=0,native_incoming=0)
                            for pair in counts['pairs'] if 'Q131347' in (pair['source_qid'],pair['target_qid'])],
        source_scope=dict(identity_decision_version=counts['decision_version'],snapshot_records=7,archive_records=2,current_public_records=1,
            public_record_retrieved_at=receipt['completed_at'],public_item_revision=entity['lastrevid'],public_item_modified=entity['modified'],
            live_wikidata_completeness_claim=False,interim_identity_dependent=True,
            note='Pair availability at this explicit mixed-version source frontier only; nine other sources were not refreshed to current Wikidata'),
        consumer_export=False,publication=False)
    assert all(digest(Path(path))==expected for path,expected in protected.items())
    output=HERE/('real_pair_views_v2_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    output.mkdir()
    (output/'pair_views.json').write_bytes(encoded(payload))
    assert json.loads((output/'pair_views.json').read_text())==payload
    (output/'verification.json').write_bytes(encoded(dict(status='PASS_MIXED_SOURCE_PAIR_V2',summary=summary,
        code_sha256=digest(Path(__file__)),output_sha256=digest(output/'pair_views.json'),protected_sha256=protected,backup_status='Unprotected')))
    print(json.dumps(dict(status='PASS',output=str(output),**summary)))


if __name__=='__main__':
    run()

