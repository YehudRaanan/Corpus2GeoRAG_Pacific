# Combined E5 / R7 counts and pair-frontier fixture

2026-11-01 20:12 UTC: PASS. Eleven combined checks and seven independent fresh-process checks. No production data, consumer serialization, new formulas, or shared-file changes.

Code: combined_pair_fixture.py. Evidence: combined_20261101T201128406623Z/{combined_history.json,verification.json,independent_readback.json}.
Code SHA256: 91163afcee5697b430217f1191ab6b1b1f114455746449def9ddfa6aa633017d.
Payload SHA256: f43f486925f5860ae60043db2c9001ee31bd4eea506192b3c36d589ba8a643b6.

The small weighted_fallback adapter imports pair_counts.py read-only. It copies the existing shared count, source/target denominators and existing source/target strengths into two PRIVATE directional views. There is no division or other new strength formula. Zero-count rows remain count diagnostics and supply no connectivity in this generated fixture; this selects no consumer-edge policy. The existing pair_frontier then selects native versus fallback per pair, with supplied fallback retained in private snapshot history.

Three generated phases reuse the count owner's two units: page 1 has Q1/Q2; page 2 has Q1/Q3. Native Q1-Q3 is initially available throughout.

| Phase | Q1-Q2 shared pages | Q1 denominator | Q1 to Q2 weight | Q2 to Q1 weight | Active Q1-Q2 |
|---|---|---|---|---|---|
| Initial | 1 | 2 | 0.5 | 1.0 | Two fallback directions |
| Q1/page2 corrected to unmatched | 1 | 1 | 1.0 | 1.0 | Same fallback directions, updated internal weight |
| Native Q1-Q2 arrives | 1 | 1 | 1.0 | 1.0 | Native plus existing catalog inverse |

All Q1-Q3 native views remain byte-equal through the two changes. Native arrival does not change counts or unit history. All three pair snapshots retain their supplied fallback evidence, including the old 0.5 weight. Two source units retain three decision versions, with every original occurrence member unchanged. Each phase has four unique occurrences, four support records and two physical pages; final identity counts are one mention and one page each for Q1/Q2/Q3, with the fourth occurrence explicitly unmatched. Exact unit and pair replay adds neither contributions nor history versions.

Verification: RED first failed the named missing-weight-propagation assertion. A test-only field-name mistake (registry/pages_count instead of identity_counts/page_count) was corrected against the existing aggregation schema. GREEN passed all eleven checks. A complete fresh rebuild was byte-identical. A separate Python process verified code/payload/eight dependency hashes, rebuilt the entire fixture byte-identically, replayed saved initial/corrected handoffs through replace_unit, verified before/after counts, literal final identity/page counts, both weights, native replacement and both histories. Evidence is saved in independent_readback.json. The previous increment's 20 existing exporter/consumer checks remain documented; they were not rerun for this copy-only combined adapter.

Limits: generated three-identity, two-page, single-writer complete-frontier fixture; full pair snapshots in memory, JSON inspection evidence only. No durable/distributed recovery, production completeness proof or sizing result. Caller must supply a consistent complete native frontier and represented identities. G11 consumer strength serialization remains unresolved and no consumer weight fields were added. Only pair_relations_direct_20261101 was written; counts, shared implementations and plans were read-only. No agents, paid work, network writes, external export, publication, deletion or security changes. Backup: Unprotected. No blocker remains for this bounded increment.
