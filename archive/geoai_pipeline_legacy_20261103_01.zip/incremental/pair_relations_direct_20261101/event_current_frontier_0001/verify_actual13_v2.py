"""One bounded actual13 CPU Event refresh + replay/stale/tamper readback."""
import copy,json,sys,time
from pathlib import Path
from current_event_refresh import ROOT,HERE,read,write,desc,refresh,compute,admit_current_event_route,content_hash
RUN=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001'
def main():
 verify=read(RUN/'actual_progress_0013/verification.json');state=read(RUN/'next_batch_0004_0013_v1/state.json');three=read(RUN/'three_unit_v3_0001/verification.json')
 entries=[]
 for u in three['units']:
  folder=Path(u['sealed_unit']['unit_directory']);entries.append(dict(unit=desc(folder/'unit.private.json'),outcomes=desc(folder.parent/'occurrence_outcomes.json')))
 for u in state['unit_statuses'].values():
  folder=Path(u['sealed_unit']['unit_directory']);entries.append(dict(unit=desc(folder/'unit.private.json'),outcomes=desc(folder.parent/'occurrence_outcomes.json')))
 assert len(entries)==13
 active_path=HERE/'active_units_13.json';write(active_path,dict(units=entries,CPU_stage_verification=desc(RUN/'actual_progress_0013/verification.json')))
 root=read(ROOT/'pair_relations_direct_20261101/event_root_fix_0001/RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001.json')
 expansion=read(ROOT/'pair_relations_direct_20261101/root_relation_expansion_0001/ROOT_EXPANSION_HANDOFF_0001.json')
 policy=dict(membership_version='owner-approved-event-wwii-p361-v2-root-identity',hop_version='owner-approved-all-explicit-first-place-second-v1',
  processors=dict(membership=root['rule'],traversal=desc(ROOT/'pair_relations_direct_20261101/event_wwii_rule_0001/event_rule.py'),mask=desc(ROOT/'geometry_direct_20261101/pacific_loc_mask_v1/pacific_loc_mask.py'),mask_artifact=desc(ROOT/'geometry_direct_20261101/pacific_loc_mask_v1/pacific_loc_mask_v1.geojson')),
  scope_sources=expansion['sources'],membership_sources=root['source_graph'],native_event_evidence=desc(ROOT/'pair_relations_direct_20261101/event_execution_0001/generation_001/native_event_evidence.json'),
  evidence_only='Existing records/approved rule reused; prior17 identity decisions/types, route receipts and scope outcomes are NOT reused')
 policy_path=HERE/'source_policy.json';write(policy_path,policy)
 registry=read(verify['consumer_receipt']['path'])['entity_source_registry']
 config=dict(counts_snapshot=state['counts_snapshot'],active_units=desc(active_path),native_registry=registry,source_policy=desc(policy_path),geometry_source=desc(Path(verify['consumer_receipt']['path']).parent.parent/'model/geometries.parquet'))
 config_path=HERE/'config_actual13.json';write(config_path,config)
 start=time.perf_counter();hand=refresh(desc(config_path),HERE/'actual13_0002');seconds=time.perf_counter()-start
 route=desc(HERE/'actual13_0002/handoff.json');counts=read(hand['artifacts']['count_receipt']['path'])
 assert len(hand['decision_binding'])==13
 assert counts['projection']['retained_occurrences']==2313 and counts['projection']['accepted_occurrences']==1040
 print('ACTUAL13_EVENT_READY',json.dumps({k:hand[k] for k in ['accepted_event_qids','resolved_occurrences','unresolved_occurrences']}),flush=True)
 # Exact replay leaves every output byte and mtime untouched.
 paths=[Path(d['path']) for d in hand['artifacts'].values()]+[Path(route['path'])]
 before={str(p):(desc(p)['sha256'],p.stat().st_mtime_ns) for p in paths}
 assert refresh(desc(config_path),HERE/'actual13_0002')==hand
 assert before=={str(p):(desc(p)['sha256'],p.stat().st_mtime_ns) for p in paths}
 normalized=admit_current_event_route(route,count_receipt=counts,native_registry=registry)
 assert normalized['event_route_complete'] and normalized['decision_binding']==counts['decision_binding']
 stale=copy.deepcopy(counts);stale['decision_binding']=stale['decision_binding'][:-1]
 try:admit_current_event_route(route,count_receipt=stale,native_registry=registry)
 except ValueError as e:assert 'frontier differs' in str(e)
 else:raise AssertionError('Stale count frontier accepted')
 wrong_registry=dict(registry,sha256='0'*64)
 try:admit_current_event_route(route,count_receipt=counts,native_registry=wrong_registry)
 except ValueError as e:assert 'frontier differs' in str(e)
 else:raise AssertionError('Stale source registry accepted')
 per=read(hand['artifacts']['per_unit']['path']);assert len(per)==13
 ids=[o['occurrence_id'] for unit in per for o in unit['outcomes']];assert len(ids)==len(set(ids))
 assert len(ids)==hand['resolved_occurrences']+hand['unresolved_occurrences']
 claims=read(hand['artifacts']['selection']['path'])['decisions']
 for row in claims:
  if row['qid']=='Q362' and row['keep_event']:assert row['reason']=='ROOT_EVENT_IDENTITY' and row['p361_chain']==[]
  elif row['keep_event']:assert row['p361_chain'] and row['p361_chain'][-1]['object_qid']=='Q362'
 # Admission recomputes artifacts; on-disk claims are never relabelled as a new frontier.
 proof=dict(status='PASS_ACTUAL13_CURRENT_EVENT_REFRESH',route=route,count_receipt=hand['artifacts']['count_receipt'],native_registry=registry,
  refresh_seconds=seconds,CPU_units=13,occurrences=2313,assigned=1040,resolved_Event_occurrences=hand['resolved_occurrences'],unresolved_Event_occurrences=hand['unresolved_occurrences'],accepted_event_qids=hand['accepted_event_qids'],
  event_entities=len(normalized['entities']),native_Event_relations=len(normalized['relations']),source_gaps=len(hand['source_gaps']),quarantine=len(normalized['data_exceptions']),
  checks=['actual current13 heads and CPU route members','approved root/P361 membership re-execution','approved all-first/LOC-second with current typed counts','mask re-executed on pinned existing source geometries, missing stays unknown','strict admission reproduced every artifact','exact replay preserved hashes/mtimes','stale count frontier rejected','different registry rejected','13 per-unit source/version receipts, no duplicate occurrences'],
  external_requests=0,canonical_state_modified=False,consumer_materialized=False,
  publisher_connection_needed='Add a strict branch for geoai-current-frontier-event-route-v1 that calls current_event_refresh.admit_current_event_route with actual count_receipt/native_registry; keep existing validation unchanged. The returned object is normalized event-consumer-input-v1. No old17 route is admitted as current.',
  processor=desc(HERE/'current_event_refresh.py'))
 write(HERE/'verification_v2.json',proof);print(json.dumps(proof,indent=2),flush=True)
if __name__=='__main__':main()

