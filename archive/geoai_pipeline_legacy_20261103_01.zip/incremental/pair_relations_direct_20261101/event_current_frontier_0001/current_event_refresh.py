"""Re-execute approved Event source policy against a pinned current CPU frontier."""
import hashlib,importlib.util,json,sys
from collections import Counter
from copy import deepcopy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'orchestration_direct_20261101'),str(ROOT/'publisher_direct_20261101/compact_checkpoint_0001'),str(ROOT/'pair_relations_direct_20261101/event_root_fix_0001'),str(ROOT/'pair_relations_direct_20261101/event_wwii_rule_0001'),str(ROOT/'pair_relations_direct_20261101/registry_completion_0001'),'D:/Projects/GeoAI']
from decision_revision_hook import content_hash,decision_binding
from compact_checkpoint import _translate_c3
from event_rule_v2 import evaluate_wwii,RULE_VERSION
from event_rule import discover_scope,HOP_VERSION
from registry_completion import choose_name
from GG_Data.pipeline.event_model import event_rows
FIELDS=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def desc(p):return dict(path=str(Path(p).resolve()),sha256=sha(p))
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False),encoding='utf-8')
def pin(d):
 if sha(d['path'])!=d['sha256']:raise ValueError('Event refresh input hash differs: '+d['path'])
 return read(d['path'])

def compute(config):
 """Pure current-frontier computation; neither historical decisions nor receipts are reused."""
 counts=pin(config['counts_snapshot']);binding,projection=_translate_c3(counts)
 receipt=dict(decision_binding=binding,projection=projection,projection_sha256=content_hash(projection),upstream_counts=config['counts_snapshot'])
 if config.get('count_receipt') is not None and pin(config['count_receipt'])!=receipt:raise ValueError('Supplied current count receipt differs')
 inventory=pin(config['active_units']);state={};routed=[];unit_rows=[]
 for entry in inventory['units']:
  unit=pin(entry['unit']);outcomes=pin(entry['outcomes']);key=tuple(unit['manifest'][k] for k in FIELDS)
  if key in state:raise ValueError('Repeated source unit')
  state[key]=[unit];members={r['occurrence_id']:r for r in unit['occurrences']}
  if set(members)!={r['occurrence_id'] for r in outcomes} or len(outcomes)!=len(members):raise ValueError('CPU route membership differs')
  ids={r['occurrence_id'] for r in outcomes if 'EVENT_SEPARATE' in r.get('reason',[])}
  unit_rows.append((entry,unit,sorted(ids)))
  routed.extend(dict(occurrence=members[oid],unit=entry['unit'],policy_outcome=next(r for r in outcomes if r['occurrence_id']==oid)) for oid in sorted(ids))
 if decision_binding(state)!=binding:raise ValueError('Current unit frontier differs from counts')
 policy=pin(config['source_policy'])
 for d in policy['processors'].values():pin_code(d)
 if policy['membership_version']!=RULE_VERSION or policy['hop_version']!=HOP_VERSION:raise ValueError('Approved Event rule version differs')
 registry=pin(config['native_registry']);records=pin(policy['scope_sources']);membership_sources=pin(policy['membership_sources']);native=pin(policy['native_event_evidence'])
 # Cached old source statements are reusable evidence, never current identity decisions/types.
 records=deepcopy(records)
 for q,node in membership_sources.items():records.setdefault(q,node)
 for q,row in registry['selected_references'].items():records[q]=dict(record=row['envelope']['entity'],source=row['provenance'],coverage='FULL')
 for q,node in native.items():records.setdefault(q,dict(record=node['raw_record'],source=dict(provider='WIKIDATA',file=node['source']['path'],sha256=node['source']['sha256'],line=node['source']['line'],record_id=q,revision=node['revision'],modified=node['modified']),coverage='FULL'))
 # Exact source label/alias binding is the existing Event execution contract.
 names={}
 for q in native:
  record=records[q]['record'];values=[r.get('value','') for r in record.get('labels',{}).values()]+[r.get('value','') for rows in record.get('aliases',{}).values() for r in rows]
  names[q]={v.casefold() for v in values if v}
 decisions={};candidate_rows=[]
 for candidate in routed:
  occurrence=candidate['occurrence'];word=occurrence.get('prepared_word',occurrence['word'])
  qids=sorted(q for q in names if word.casefold() in names[q])
  for q in qids:
   if q not in decisions:decisions[q]=evaluate_wwii(q,records)
  accepted=[q for q in qids if decisions[q]['keep_event'] and q in records and records[q].get('coverage','FULL')=='FULL']
  candidate_rows.append(dict(candidate,candidate_qids=qids,accepted_event_qids=accepted,status='RESOLVED' if len(accepted)==1 else 'UNRESOLVED',reason=decisions[accepted[0]]['reason'] if len(accepted)==1 else 'NO_UNIQUE_PROVENANCE_BACKED_EVENT_AT_DECLARED_SOURCE_FRONTIER'))
 accepted=sorted({row['accepted_event_qids'][0] for row in candidate_rows if row['status']=='RESOLVED'})
 entities=[];events=[];quarantine=[]
 for q in accepted:
  node=records[q]
  try:
   choose_name(q,node['record'],{},[])
   entity,event=event_rows(node['record'],node['source'],decisions[q]);entity['reference_source']=node['source']['provider']
  except ValueError as error:
   quarantine.append(dict(qid=q,reason='MISSING_SUPPORTED_EVENT_NATIVE_NAME_OR_MODEL',needed_remedy=str(error)));continue
  entities.append(entity);events.append(event)
 active_events={e['entity_id'] for e in entities}
 kinds={}
 for row in projection['typed_counts']:kinds.setdefault(row['qid'],set()).add(row['entity_group'])
 for q in active_events:kinds.setdefault(q,set()).add('Event')
 kinds={q:sorted(v) for q,v in kinds.items()}
 scope=discover_scope(sorted(active_events),records,kinds)
 # Re-evaluate approved LOC mask on supplied existing geometry; all missing geometry stays unknown.
 import geopandas as gpd
 from wire_pacific_mask import scope_geo_map
 geometry=config.get('geometry_source');geometries={}
 if geometry:
  pin_code(geometry);frame=gpd.read_parquet(geometry['path'])
  if frame.crs.to_epsg()!=4326:raise ValueError('Expected verified EPSG:4326 geometry')
  if frame.place_id.duplicated().any():raise ValueError('Ambiguous geometry source')
  geometries=dict(zip(frame.place_id,frame.geometry))
 locs=sorted({r['qid'] for r in scope['candidates'] if r['type']=='LOC'})
 fallback=config['native_registry']
 geo=scope_geo_map({q:'LOC' for q in locs},geometries,{q:geometry if geometry and q in geometries else fallback for q in locs})
 geo['decisions'].sort(key=lambda row:row['qid'])
 for row in scope['candidates']:
  if row['type']=='LOC' and not(row['hop']==2 and row['type']!='LOC'):
   value=geo['geo'].get(row['qid']);row['inclusion']='INCLUDE' if value is True else 'EXCLUDE' if value is False else 'PENDING_GEO'
   row['reason']='APPROVED_PACIFIC_MASK' if value is not None else 'MISSING_VALIDATED_GEOMETRY_RETAINED_UNKNOWN'
 scope['geometry_policy']='APPROVED_PACIFIC_MASK_LOC_ONLY';scope['mask_binding']={k:geo[k] for k in ['mask_version','mask_sha256','mask_code_sha256']}
 active=set(active_events);edges={}
 for row in scope['candidates']:
  if row['inclusion']=='INCLUDE':active.add(row['qid'])
 for row in scope['candidates']:
  if row['inclusion']!='INCLUDE':continue
  for edge in row['path']:
   if {edge['subject_qid'],edge['object_qid']}<=active:edges[edge['source_record_id']]={k:edge[k] for k in ['subject_qid','object_qid','source_predicate','source_record_id','raw_statement','source']}
 # Existing normalization only, preserving native endpoints and raw statements.
 import csv
 from GG_Data.pipeline.relations import scan,populate
 mapping=Path('D:/Projects/GeoAI/GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv')
 with mapping.open(encoding='utf-8-sig',newline='') as f:rules={(r['source'],r['source_predicate']):r for r in csv.DictReader(f)}
 usable=set(active)
 for q in sorted({v for edge in edges.values() for v in [edge['subject_qid'],edge['object_qid']]}):
  if q not in records or records[q].get('coverage','FULL')!='FULL':usable.discard(q);quarantine.append(dict(qid=q,reason='MISSING_WHOLE_NATIVE_SOURCE'));continue
  try:choose_name(q,records[q]['record'],{},[])
  except ValueError:usable.discard(q);quarantine.append(dict(qid=q,reason='MISSING_SUPPORTED_SOURCE_NAME'))
 replay=[]
 for q in sorted({v for edge in edges.values() if {edge['subject_qid'],edge['object_qid']}<=usable for v in [edge['subject_qid'],edge['object_qid']]}):
  node=records[q];raw=deepcopy(node['record']);original=raw['claims'];raw['claims']={}
  for edge in edges.values():
   if edge['subject_qid']!=q or not {edge['subject_qid'],edge['object_qid']}<=usable:continue
   prop=edge['source_predicate'].removeprefix('wd:')
   if edge['raw_statement'] not in original.get(prop,[]) or edge['source']!=node['source']:raise ValueError('Native Event scope direction/claim/source differs')
   raw['claims'].setdefault(prop,[]).append(edge['raw_statement'])
  replay.append(dict(entity_id=q,name=choose_name(q,node['record'],{},[])['value'],sources=[node['source']],raw_reference=dict(full=dict(requested_qid=q,entity=raw))))
 retained,excluded,_=scan(replay,{r['entity_id'] for r in replay},rules)
 if excluded:raise ValueError('Existing native assertion exclusions differ')
 relations=populate(retained,rules)
 per_unit=[]
 for entry,unit,ids in unit_rows:
  rows=[r for r in candidate_rows if r['occurrence']['occurrence_id'] in set(ids)]
  per_unit.append(dict(status='COMPLETED_UNRESOLVED' if any(r['status']=='UNRESOLVED' for r in rows) else 'COMPLETED',execution='EXECUTED',route='event_route',source_scope={k:unit['manifest'][k] for k in FIELDS},decision_version=unit['version'],source_unit=entry['unit'],input_occurrences_sha256=content_hash(sorted([r['occurrence'] for r in rows],key=lambda r:r['occurrence_id'])),outcomes=[{k:r[k] for k in ['status','reason','accepted_event_qids']}|dict(occurrence_id=r['occurrence']['occurrence_id']) for r in rows],ordinary_identity_decisions_changed=False))
 result=dict(normalized_schema='event-consumer-input-v1',status='VERIFIED_EVENT_CONSUMER_INPUTS',entities=entities,events=events,relations=relations,decision_binding=binding,current_count_receipt_sha256=content_hash(receipt),native_registry_sha256=config['native_registry']['sha256'],selection_version=RULE_VERSION,scope_version=HOP_VERSION+':'+counts['frontier_sha256'],event_route_complete=True,executed_with_documented_gaps=True,pending_inputs=[],retained_unresolved=[r for r in candidate_rows if r['status']=='UNRESOLVED'],data_exceptions=quarantine,source_gaps=scope['source_pending'],global_source_completeness=False,test_only=False,publication=False)
 result.update(admission_format='CURRENT_FRONTIER_EVENT_ROUTE_V1',resolved_occurrences=sum(r['status']=='RESOLVED' for r in candidate_rows),unresolved_occurrences=sum(r['status']=='UNRESOLVED' for r in candidate_rows),scope_audit=dict(counts=dict(Counter(r['inclusion'] for r in scope['candidates'])),source_gaps=scope['source_pending'],global_source_completeness=False),bounded_scope='Approved Event source traversal re-executed at exact current CPU heads; passed source cache only, unknown types/geometry/source and quarantine retained')
 return dict(count_receipt=receipt,selection=dict(version=RULE_VERSION,decisions=list(decisions.values())),scope=scope,geo=geo,entities=entities,events=events,relations=relations,candidate_evidence=candidate_rows,per_unit=per_unit,normalized=result)

def pin_code(d):
 if sha(d['path'])!=d['sha256']:raise ValueError('Event source/code hash differs: '+d['path'])

def refresh(config_descriptor,output):
 config=pin(config_descriptor);output=Path(output).resolve()
 if not output.is_relative_to(HERE):raise ValueError('Output leaves Event worker ownership')
 marker=output/'handoff.json'
 if output.exists():
  old=read(marker)
  if old['config']!=config_descriptor or old['processor']!=desc(__file__):raise ValueError('Changed Event request cannot overwrite generation')
  for artifact in old['artifacts'].values():pin_code(artifact)
  # Inputs are verified again on replay without rewriting history/artifacts.
  for d in config.values():
   if isinstance(d,dict) and set(d)=={'path','sha256'}:pin_code(d)
  return old
 values=compute(config);output.mkdir()
 refs={}
 for name,value in values.items():
  p=output/(name+'.json');write(p,value);refs[name]=desc(p)
 hand=dict(status='CURRENT_FRONTIER_EVENT_ROUTE_V1_READY',schema='geoai-current-frontier-event-route-v1',config=config_descriptor,processor=desc(__file__),artifacts=refs,decision_binding=values['count_receipt']['decision_binding'],current_count_receipt_sha256=content_hash(values['count_receipt']),native_registry_sha256=config['native_registry']['sha256'],accepted_event_qids=sorted(e['entity_id'] for e in values['entities']),resolved_occurrences=sum(r['status']=='RESOLVED' for r in values['candidate_evidence']),unresolved_occurrences=sum(r['status']=='UNRESOLVED' for r in values['candidate_evidence']),source_gaps=values['scope']['source_pending'],consumer_materialized=False,publication=False)
 write(marker,hand);return hand

def admit_current_event_route(route,*,count_receipt,native_registry,relation_receipt=None):
 """Strict publisher seam: pin all bytes, require exact current bindings, reproduce outputs."""
 hand=pin(route)
 if hand['schema']!='geoai-current-frontier-event-route-v1' or hand['processor']!=desc(__file__):raise ValueError('Unexpected current Event producer')
 if hand['current_count_receipt_sha256']!=content_hash(count_receipt) or hand['decision_binding']!=count_receipt['decision_binding'] or hand['native_registry_sha256']!=native_registry['sha256']:raise ValueError('Current Event count/registry frontier differs')
 config=pin(hand['config']);values=compute(config)
 if values['count_receipt']!=count_receipt:raise ValueError('Recomputed current counts receipt differs')
 for name,expected in values.items():
  if pin(hand['artifacts'][name])!=expected:raise ValueError('Current Event artifact differs from approved recomputation: '+name)
 result=deepcopy(values['normalized'])
 if relation_receipt is not None:
  if relation_receipt['decision_binding']!=count_receipt['decision_binding'] or relation_receipt['projection_sha256']!=content_hash(relation_receipt['projection']):raise ValueError('Ordinary/Event relation frontier differs')
  ordinary={row['observation_id']:row for row in relation_receipt['projection']['relations']}
  for row in result['relations']:
   if row['observation_id'] in ordinary and ordinary[row['observation_id']]!=row:raise ValueError('Ordinary/Event native assertion version differs')
  result['relations']=[row for row in result['relations'] if row['observation_id'] not in ordinary]
  result['ordinary_relation_receipt_sha256']=content_hash(relation_receipt)
 result['input_sha256']={route['path']:route['sha256'],hand['config']['path']:hand['config']['sha256'],__file__:sha(__file__)}
 return result


