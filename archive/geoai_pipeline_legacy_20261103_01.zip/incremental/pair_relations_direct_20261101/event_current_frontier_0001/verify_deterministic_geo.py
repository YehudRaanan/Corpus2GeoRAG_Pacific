"""Fresh interpreters with different set hash seeds must emit identical artifact bytes."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
from current_event_refresh import HERE,ROOT,desc,read,write
CODE=HERE/'current_event_refresh.py';OUTPUT=HERE/'actual13_0003';CONFIG=HERE/'config_actual13.json'
child=r'''
import hashlib,json,os,sys
from pathlib import Path
from current_event_refresh import compute,refresh,desc,read,pin,HERE
config=Path(sys.argv[1]);output=Path(sys.argv[2]);mode=sys.argv[3]
if mode=='create':
 hand=refresh(desc(config),output)
else:hand=read(output/'handoff.json')
values=compute(read(config))
proof={}
for name,value in values.items():
 raw=json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False).replace('\n',os.linesep).encode('utf-8')
 path=Path(hand['artifacts'][name]['path'])
 assert raw==path.read_bytes(),name+' fresh-process byte mismatch'
 proof[name]=hashlib.sha256(raw).hexdigest()
geo=values['geo'];assert len(geo['decisions'])==112
assert [r['qid'] for r in geo['decisions']]==sorted(r['qid'] for r in geo['decisions'])
# Actual PUBLISHER loader remains strict and is exercised read-only.
sys.path.insert(0,str(HERE.parents[1]/'publisher_direct_20261101/event_consumer_0001'))
from event_input import load_event_route
result=load_event_route(desc(output/'handoff.json'),count_receipt=values['count_receipt'],native_registry=read(config)['native_registry'])
assert result['status']=='VERIFIED_EVENT_CONSUMER_INPUTS' and len(result['events'])==3
print(json.dumps(dict(artifact_sha256=proof,publisher_admission=True,geo_decisions=112)),flush=True)
'''
results=[]
for seed,mode in [('11','create'),('991','verify')]:
 env=dict(os.environ,PYTHONHASHSEED=seed,PYTHONIOENCODING='utf-8')
 process=subprocess.run([sys.executable,'-B','-c',child,str(CONFIG),str(OUTPUT),mode],env=env,cwd=str(HERE),capture_output=True,text=True,encoding='utf-8',timeout=120)
 if process.returncode:
  print(process.stdout);print(process.stderr);raise SystemExit(process.returncode)
 result=json.loads(process.stdout);results.append(result);print('FRESH_PROCESS_PASS',seed,flush=True)
assert results[0]==results[1]
old=read(HERE/'actual13_0002/geo.json');new=read(OUTPUT/'geo.json')
assert sorted(old['decisions'],key=lambda r:r['qid'])==new['decisions']
assert {k:v for k,v in old.items() if k!='decisions'}=={k:v for k,v in new.items() if k!='decisions'}
# All non-GEO artifacts remain byte-identical to the preceding current13 generation.
for name,digest in results[0]['artifact_sha256'].items():
 if name!='geo':assert hashlib.sha256((HERE/'actual13_0002'/(name+'.json')).read_bytes()).hexdigest()==digest,name
hand=read(OUTPUT/'handoff.json')
verification=dict(status='PASS_CANONICAL_GEO_ORDER_FRESH_PROCESSES_AND_PUBLISHER_ADMISSION',hash_seeds=[11,991],fresh_processes=2,all_artifact_bytes_identical=True,only_change='112 GEO decisions canonically sorted by QID; all values unchanged; all non-GEO artifact bytes unchanged',processor=desc(CODE),route=desc(OUTPUT/'handoff.json'),count_receipt=hand['artifacts']['count_receipt'],native_registry=read(CONFIG)['native_registry'],artifacts=results[0]['artifact_sha256'],publisher_strict_admission=True,current_CPU_units=13,publication=False)
write(HERE/'deterministic_geo_verification.json',verification)
previous=read(HERE/'HANDOFF.json');previous.update(status='CURRENT13_EVENT_GEO_ORDER_FIXED_VERIFIED',processor=desc(CODE),route=verification['route'],count_receipt=verification['count_receipt'],verification=desc(HERE/'deterministic_geo_verification.json'),serialization_only=True,publisher_strict_admission=True)
write(HERE/'HANDOFF_GEO_SORT_0003.json',previous)
print(json.dumps(verification,indent=2),flush=True)

