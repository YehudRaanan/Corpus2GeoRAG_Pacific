"""Additional consumer-shape/native-dedup fixture checks on already-reproduced actual13 artifacts."""
import copy,json
from pathlib import Path
from unittest.mock import patch
import current_event_refresh as m
here=Path(__file__).resolve().parent
proof=m.read(here/'verification_v2.json');route=proof['route'];hand=m.pin(route)
values={name:m.pin(d) for name,d in hand['artifacts'].items()}
counts=values['count_receipt'];original=values['normalized']['relations'];assert len(original)==58
ordinary=dict(decision_binding=counts['decision_binding'],projection=dict(relations=original[:2]))
ordinary['projection_sha256']=m.content_hash(ordinary['projection'])
# Artifact reproduction was separately exercised on the real source frontier. These
# unit cases isolate the optional ordinary-assertion join without repeating source traversal.
with patch.object(m,'compute',return_value=copy.deepcopy(values)):
 result=m.admit_current_event_route(route,count_receipt=counts,native_registry=proof['native_registry'],relation_receipt=ordinary)
assert result['status']=='VERIFIED_EVENT_CONSUMER_INPUTS'
assert len(result['relations'])==56
assert result['data_exceptions']==values['normalized']['data_exceptions']
assert result['scope_audit']['counts'] and result['admission_format']=='CURRENT_FRONTIER_EVENT_ROUTE_V1'
bad=copy.deepcopy(ordinary);bad['projection']['relations'][0]['predicate']='CONFLICTING_FIXTURE_ONLY'
bad['projection_sha256']=m.content_hash(bad['projection'])
with patch.object(m,'compute',return_value=copy.deepcopy(values)):
 try:m.admit_current_event_route(route,count_receipt=counts,native_registry=proof['native_registry'],relation_receipt=bad)
 except ValueError as error:assert 'native assertion version differs' in str(error)
 else:raise AssertionError('Conflicting ordinary/Event native statement admitted')
receipt=dict(status='PASS_CURRENT_EVENT_CONSUMER_SHAPE_AND_NATIVE_JOIN_UNIT_CASES',actual_source_reproduction= m.desc(here/'verification_v2.json'),checks=['exact existing consumer status and audit fields','two matching native observations deduplicated','conflicting repeated native observation rejected','unknown/quarantine unchanged'],test_scope='Optional join unit cases use already-verified actual artifacts with compute patched; actual complete source reproduction is independently recorded in verification_v2.json')
m.write(here/'native_join_tests.json',receipt);print(json.dumps(receipt))
