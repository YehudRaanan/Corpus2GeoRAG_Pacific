# E5 / R7 - version 2 with the verified Oahu source

2026-11-01: PASS. The nine previously pending accepted-identity pairs now have outcomes at an explicit MIXED-SOURCE frontier. This is a versioned interim projection, with identity decisions still first-unit-exact-v1.

Authoritative output: real_pair_views_v2_20261101T205143791359Z/pair_views.json.
Code: extend_oahu_pair_views.py, SHA256 e522fa6ce3354b18bb3bc1f30d0a76de3676e8ec0cee1d2fe3fa0b3d38abe8c1.
Payload SHA256: 1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4.
Evidence: verification.json and independent_readback.json in that output directory.
Prior version preserved byte-for-byte: real_pair_views_20261101T203117785273Z/pair_views.json, SHA256 60638fb16df6e2814896a1ca0e94e7b56dbb5b8ec85f6f8c226af5df3ecde83f.

## Exact source frontier

Seven original complete BigQuery snapshot records and two complete archived records remain unchanged. The tenth is Q131347/Oahu, from the geometry owner's already verified local raw_response.json. This worker made no request.

Oahu source: official wbgetentities response preserved under geometry_direct_20261101/oahu_public_0001/raw_response.json; response SHA256 d2db952ad2c59676c7a5f5c121f27afa125388b05ea1774ca2611aced6adec74. Item revision 2555305862, modified 2026-10-09T11:12:44Z, retrieved 2026-11-01T20:41:38.942597+00:00. The source item revision is distinct from page processing revision 1375061414. Public retrieval time is not substituted for entity-modified time or older snapshot times.

Existing select_reference selected the whole available complete same-ID Oahu record; prior snapshot/archive selections were retained unchanged. The raw record, exact provenance and selected version are saved in selected_references. All source-owner receipt/report input/output hashes were verified. Its native_item_claims projection was independently reconciled with the raw response: the same 18 item-valued native statements, with exact revision/hash/represented-target annotations.

This mixed frontier is explicit: seven snapshot + two archive + one current public source record. The other nine records were NOT refreshed to current Wikidata. There is no common-current-time or globally complete Wikidata claim.

## Both directions inspected and resulting pair views

Existing relations.scan ran across ALL TEN selected entities with all ten accepted IDs as the target scope. This checks outgoing Oahu claims AND incoming claims to Oahu from the other nine selected raw records, using the existing native statement-shape, exclusion and time rules. It scanned 1,091 raw claims: four in-scope native statements, 526 item claims outside the identity set, and 561 non-item claims. Four native statements were retained, zero excluded; one has DIRECT temporal status and three NONE. None of these ten selected records supplies an in-scope native assertion involving Oahu in either direction.

Therefore the agreed pair-local logic selects BOTH private default/co-occurrence directions for each Oahu pair at this frontier:

| Oahu paired with | Native outgoing | Native incoming | Result |
|---|---:|---:|---|
| Q11751 | 0 | 0 | Two default directions |
| Q1490 | 0 | 0 | Two default directions |
| Q153732 | 0 | 0 | Two default directions |
| Q2505636 | 0 | 0 | Two default directions |
| Q51679 | 0 | 0 | Two default directions |
| Q5687462 | 0 | 0 | Two default directions |
| Q741723 | 0 | 0 | Two default directions |
| Q8042593 | 0 | 0 | Two default directions |
| Q8042652 | 0 | 0 | Two default directions |

These zeros describe available/linkable native assertions in the TEN SELECTED RECORDS, not a universal absence of a Wikidata relation. Each pair already had one supporting physical page in the unchanged internal count receipt.

| Active view class | Prior version | Version 2 |
|---|---:|---:|
| Native | 4 | 4 |
| Catalog inverse | 4 | 4 |
| Default | 64 | 82 |
| Total | 72 | 90 |
| Covered unordered pairs | 36 | 45 |
| Native-coverage pending pairs at declared frontier | 9 | 0 |

Exactly 18 new Oahu default views were added. All 72 prior active views, four native assertions, catalog inverses, dates and relation provenance remain equal. The prior pair snapshot stays unchanged and the new snapshot appends as history version 2. Exact replay adds no snapshot.

## Identity/count preservation and independent evidence

No accepted identity decision changed. All 136 original occurrences remain bound to the existing handoff: 30 accepted occurrences across ten IDs, 106 pending ID decisions, zero explicit unmatched. All 45 integer pair counts/denominators remain one, with the already computed private strengths unchanged. Identity/count history is still one supplied version; pair/source projection history is now two. Zero relation-coverage pending pairs does not resolve the 106 pending identity records.

Ten independent fresh-process checks passed: code/payload/prior-version/source hashes; seven/two/one selected-source partition; exact Oahu raw record/revision/retrieval; outgoing and incoming existing scan across ten IDs; exclusion/time/populate/producer replay; unchanged old 72 plus exactly 18 added default views; two symmetric views for all nine Oahu pairs; all 45 accepted-ID pairs and zero pending at the declared frontier; preserved two-version history/idempotent replay; and independent original-decision recount of the 136/30/106 partition without the pair counter. Existing formulas and mapping v2.1.1 were reused.

## Limits and next step

This closes the nine missing-source pair outcomes for first-unit-exact-v1 at this explicit mixed-version frontier. It is not a final relation decision after future model inference. A later accepted QID revision or relevant source update must invalidate/refresh affected identity/count/native/pair projections; the previously reported automatic revision trigger and targeted dependency-recomputation index remain unimplemented. Consumer weight serialization, publication and durable cross-stage recovery are unchanged/outside this increment.

Only pair_relations_direct_20261101 was written. Geometry source files, prior pair output, actual identity decisions, counts, catalogs, exclusions and shared plans remain unchanged. No external calls, paid work, nested agents, installation, consumer export, publication, deletion or security changes. Backup: Unprotected. No blocker remains for these nine pair outcomes at the stated frontier.
