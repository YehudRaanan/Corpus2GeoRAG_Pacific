"""Independent root-fix readback:36 exact delta outcomes, unchanged other chains and native dates."""
import gzip,json
from pathlib import Path
from event_rule_v2 import evaluate_wwii,RULE_VERSION
from apply_successor import HERE,read,write,desc,sha

def main():
 out=HERE/'generation_001';hand=read(out/'handoff.json');graph=read(hand['source_graph']['path']);root=graph['Q362']
 source=root['source'];assert sha(source['file'])==source['sha256']
 with gzip.open(source['file'],'rt',encoding='utf8') as stream:
  for number,line in enumerate(stream,1):
   if number==source['line']:
    raw=json.loads(line);assert raw['requested_qid']=='Q362' and raw['entity']==root['record'];break
  else:raise AssertionError('Native root source line absent')
 previous=read(hand['previous_policy_handoff']['path']);oldselection=read(previous['selection']['path']);newselection=read(hand['selection']['path']);old={r['qid']:r for r in oldselection['decisions']};new={r['qid']:r for r in newselection['decisions']}
 assert set(old)==set(new)=={'Q362','Q1645012','Q52418','Q713516'}
 for q in set(old)-{'Q362'}:assert old[q]==new[q]
 assert new['Q362']['keep_event'] and new['Q362']['acceptance_reason']=='ROOT_EVENT_IDENTITY' and new['Q362']['p361_chain']==[]
 assert new['Q362']['identity_evidence']['source']==source and new['Q362']['identity_evidence']['statement_fabricated'] is False
 assert evaluate_wwii('Q999999999',{})['status']=='UNRESOLVED'
 entities=read(hand['entities']['path']);events=read(hand['events']['path']);old_entities=read(previous['entities']['path']);old_events=read(previous['events']['path'])
 assert len(entities)==4 and len(events)==4 and len({r['event_id'] for r in events})==4
 for row in old_entities:assert row==next(r for r in entities if r['entity_id']==row['entity_id'])
 for row in old_events:assert row==next(r for r in events if r['event_id']==row['event_id'])
 newroot=next(r for r in entities if r['entity_id']=='Q362');assert newroot['raw_reference']['full']['entity']==root['record'] and newroot['attributes']['mention_ids']==[]
 root_event=next(r for r in events if r['event_id']=='Q362')
 assert root_event['temporal_evidence']['claims']=={p:root['record']['claims'].get(p,[]) for p in ('P580','P582','P585')}
 changed=0;stable=0;seen=set();zero=0
 for item in hand['per_unit_receipts']:
  receipt=read(item['event_route']['path']);assert sha(item['event_route']['path'])==item['event_route']['sha256'];prior=read(receipt['previous_receipt']['path']);assert sha(receipt['previous_receipt']['path'])==receipt['previous_receipt']['sha256']
  assert receipt['source_scope']==prior['source_scope'] and receipt['input_occurrences_sha256']==prior['input_occurrences_sha256'] and receipt['status']=='COMPLETED'
  oldrows={r['occurrence_id']:r for r in prior['outcomes']};assert set(oldrows)=={r['occurrence_id'] for r in receipt['outcomes']}
  if not receipt['outcomes']:zero+=1
  for row in receipt['outcomes']:
   oid=row['occurrence_id'];assert oid not in seen;seen.add(oid);assert row['status']=='RESOLVED'
   if row.get('acceptance_reason')=='ROOT_EVENT_IDENTITY':
    assert oldrows[oid]['status']=='UNRESOLVED' and row['accepted_event_qids']==['Q362'] and row['p361_chain']==[] and 'source_record_id' not in row['identity_evidence'];changed+=1
   else:assert row==oldrows[oid];stable+=1
  for artifact in receipt['artifacts']:assert sha(artifact['path'])==artifact['sha256']
 assert changed==36 and stable==4 and len(seen)==40 and zero==1
 for name in ('previous_policy_handoff','previous_new_unit_handoff','processor','rule','selection','entities','events','source_graph'):
  d=hand[name];assert sha(d['path'])==d['sha256']
 projection=Path(hand['previous_policy_handoff']['path']).parents[2]/'orchestration_direct_20261101/policy_v2_all17_sources_0340_0001/unit/projection.json'
 # The original raw decision artifact remains the caller-pinned hash; no state writer was called.
 assert sha(projection)==hand['input_binding']['identity_projection']
 proof=dict(status='PASS_INDEPENDENT_ROOT_EVENT_IDENTITY_SUCCESSOR',root_accepted=True,acceptance_reason='ROOT_EVENT_IDENTITY',root_path_length=0,fabricated_statements=0,
  corrected_occurrences=36,first_nine=21,new_eight=15,total_resolved_Event_occurrences=40,unresolved_Event_occurrences=0,
  existing3_entities_events_and_normal_P361_decisions_unchanged=True,existing4_nonroot_occurrence_outcomes_unchanged=True,
  source_native_record_and_version_verified=True,native_root_dates_unchanged=True,ordinary_decision_frontier_hash_unchanged=True,
  units=17,empty_Event_units=1,tests=4,previous_generations_preserved=True,hop_and_geometry_policy_unchanged=True,
  handoff=desc(out/'handoff.json'),consumer_materialized=False,publication=False)
 write(HERE/'independent_readback.json',proof)
 release=dict(hand,status='RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001_READY',verification=desc(HERE/'independent_readback.json'),tests=4)
 write(HERE/'RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001.json',release);print(json.dumps(proof));print(str(HERE/'RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001.json'))
if __name__=='__main__':main()
