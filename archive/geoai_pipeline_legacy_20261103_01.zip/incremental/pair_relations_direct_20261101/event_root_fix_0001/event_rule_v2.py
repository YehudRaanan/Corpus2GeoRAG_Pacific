"""Root identity correction; all non-root approved P361 behavior is reused unchanged."""
import sys
from copy import deepcopy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'event_wwii_rule_0001'))
from event_rule import evaluate_wwii as previous_evaluate,ROOT,HOP_VERSION
RULE_VERSION='owner-approved-event-wwii-p361-v2-root-identity'
def evaluate_wwii(qid,records):
 if qid!=ROOT:return previous_evaluate(qid,records)
 node=records.get(ROOT)
 if node is not None and node['record'].get('id')!=ROOT:raise ValueError('Native root identity differs')
 return dict(qid=ROOT,status='ACCEPTED_WWII_SCOPE',keep_event=True,reason='ROOT_EVENT_IDENTITY',acceptance_reason='ROOT_EVENT_IDENTITY',p361_chain=[],
  source_pending=[] if node is not None else [ROOT],identity_evidence=dict(qid=ROOT,source=deepcopy(node['source']) if node else None,
  native_record_revision=node['record'].get('lastrevid') if node else None,path_length=0,statement_fabricated=False))
