"""Versioned40-occurrence successor using existing source records and unchanged scope policy."""
import sys,json
from copy import deepcopy
from pathlib import Path
HERE=Path(__file__).resolve().parent;PAIR=HERE.parent;ROOT=PAIR.parent
sys.path[:0]=[str(PAIR/'event_runtime_0001'),str(PAIR/'event_wwii_rule_0001'),str(ROOT/'orchestration_direct_20261101')]
from event_runtime import sha,read,write
from event_rule_v2 import evaluate_wwii,RULE_VERSION,HOP_VERSION
from GG_Data.pipeline.event_model import event_rows
from decision_revision_hook import content_hash
FIELDS=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
def desc(p,expected=None):
 value=sha(p)
 if expected and value!=expected:raise ValueError('Input hash differs')
 return dict(path=str(Path(p).resolve()),sha256=value)
def main():
 out=HERE/'generation_001'
 if out.exists():raise ValueError('Use a new successor generation')
 old_path=PAIR/'event_wwii_rule_0001/POLICY_HANDOFF_0001.json';old=read(old_path)
 newer_path=PAIR/'event_new_units_0001/RELATIONS_NEW_UNITS_HANDOFF_0001.json';newer=read(newer_path)
 producer=read(PAIR/'event_wwii_rule_0001/generation_001/handoff.json');graph_desc=producer['artifacts']['p361_source_evidence.json'];desc(graph_desc['path'],graph_desc['sha256']);graph=read(graph_desc['path'])
 previous_selection=desc(old['selection']['path'],old['selection']['sha256']);selection=read(previous_selection['path'])
 candidates=read(PAIR/'event_wwii_rule_0001/generation_001/candidate_inputs.json')
 for entry in newer['units']:
  receipt=read(entry['event_route']['path'])
  path=next(d for d in receipt['artifacts'] if Path(d['path']).name=='source_evidence.json');desc(path['path'],path['sha256']);candidates.extend(read(path['path']))
 by_id={r['occurrence']['occurrence_id']:r for r in candidates}
 if len(by_id)!=40 or len(candidates)!=40:raise ValueError('Expected the exact40 existing routed occurrences')
 decisions=[]
 for prior in selection['decisions']:
  q=prior['qid'];evaluated=evaluate_wwii(q,graph);row=deepcopy(prior)
  if q!='Q362':
   for k in ('status','keep_event','reason','p361_chain','source_pending'):assert evaluated[k]==prior[k]
  else:row.update(evaluated);row['rule_version']=RULE_VERSION
  decisions.append(row)
 assert {r['qid'] for r in decisions if r['keep_event']}=={'Q362','Q1645012','Q52418','Q713516'}
 projection_path=ROOT/'orchestration_direct_20261101/policy_v2_all17_sources_0340_0001/unit/projection.json';projection_desc=desc(projection_path,selection['input_binding']['identity_projection']);projection=read(projection_path);units={v[-1]['manifest']['page_id']:v[-1] for v in projection['count_state']}
 out.mkdir();updated=dict(selection,version=RULE_VERSION,decisions=decisions,previous_selection=previous_selection,correction='Q362_ROOT_EVENT_IDENTITY_ZERO_LENGTH_PATH_NO_STATEMENT')
 write(out/'event_selection.json',updated);write(out/'candidate_evidence.json',candidates)
 entities=read(old['entities']['path']);events=read(old['events']['path']);desc(old['entities']['path'],old['entities']['sha256']);desc(old['events']['path'],old['events']['sha256'])
 root_decision=next(r for r in decisions if r['qid']=='Q362');entity,event=event_rows(graph['Q362']['record'],graph['Q362']['source'],root_decision);entity['reference_source']=graph['Q362']['source']['provider'];entities=entities+[entity];events=events+[event]
 assert len({r['entity_id'] for r in entities})==4 and len({r['event_id'] for r in events})==4
 write(out/'event_entities.json',entities);write(out/'events.json',events)
 artifact_names=('event_selection.json','candidate_evidence.json','event_entities.json','events.json');artifacts=[desc(out/n) for n in artifact_names]+[graph_desc]
 receipt_entries=list(old['per_unit_receipts'])+list(newer['units']);per_unit=[];changed=0;resolved=0
 for entry in receipt_entries:
  prior_desc=entry['event_route'];desc(prior_desc['path'],prior_desc['sha256']);prior=read(prior_desc['path']);page=prior['source_scope']['page_id'];unit=units[page]
  source_scope={k:unit['manifest'][k] for k in FIELDS};assert prior['source_scope']==source_scope
  ids={r['occurrence_id'] for r in prior['outcomes']};rows=sorted([r for r in unit['occurrences'] if r['occurrence_id'] in ids],key=lambda r:r['occurrence_id'])
  assert content_hash(rows)==prior['input_occurrences_sha256']
  outcomes=[]
  for old_outcome in prior['outcomes']:
   oid=old_outcome['occurrence_id'];candidate=by_id[oid];assert candidate['occurrence']==next(r for r in rows if r['occurrence_id']==oid)
   row=deepcopy(old_outcome)
   if candidate['candidate_qids']==['Q362']:
    row.update(status='RESOLVED',method=RULE_VERSION,reason='ROOT_EVENT_IDENTITY',acceptance_reason='ROOT_EVENT_IDENTITY',accepted_event_qids=['Q362'],p361_chain=[],identity_evidence=root_decision['identity_evidence']);changed+=1
   else:assert row['status']=='RESOLVED'
   resolved+=row['status']=='RESOLVED';outcomes.append(row)
  receipt=dict(status='COMPLETED',execution='EXECUTED',route='event_route',scope_result='NOT_APPLICABLE_ZERO_EVENT_OCCURRENCES' if not outcomes else 'EXECUTED_ROOT_CORRECTED_WWII_ACCEPTANCE',
   source_scope=source_scope,input_occurrences_sha256=prior['input_occurrences_sha256'],processor=desc(Path(__file__)),rule=desc(HERE/'event_rule_v2.py'),artifacts=artifacts,outcomes=outcomes,
   previous_receipt=prior_desc,ordinary_identity_decisions_changed=False,scope_hop_policy_unchanged=HOP_VERSION,geography_policy_unchanged=True)
  path=out/f'page_{page}_event_route_v2.json';write(path,receipt);per_unit.append(dict(page_id=page,event_occurrences=len(outcomes),event_route=desc(path)))
 assert changed==36 and resolved==40 and len(per_unit)==17
 hand=dict(status='ROOT_IDENTITY_SUCCESSOR_READY',version=RULE_VERSION,selection=desc(out/'event_selection.json'),entities=desc(out/'event_entities.json'),events=desc(out/'events.json'),
  accepted_event_qids=['Q362','Q1645012','Q52418','Q713516'],corrected_root_occurrences=36,first_nine_corrected=21,new_eight_corrected=15,resolved_Event_occurrences=40,unresolved_Event_occurrences=0,
  per_unit_receipts=per_unit,input_binding=selection['input_binding'],source_graph=graph_desc,previous_policy_handoff=desc(old_path),previous_new_unit_handoff=desc(newer_path),
  processor=desc(Path(__file__)),rule=desc(HERE/'event_rule_v2.py'),root_acceptance_reason='ROOT_EVENT_IDENTITY',root_path_length=0,fabricated_P361_statements=0,
  original3_events_and_normal_chains_unchanged=True,ordinary_identity_decisions_changed=False,scope_predicates_and_geography_policy_unchanged=True,
  root_hop_expansion='NOT_REEXECUTED_IN_THIS_BOUNDED_ACCEPTANCE_FIX',consumer_materialized=False,publication=False)
 write(out/'handoff.json',hand);print(json.dumps({k:v for k,v in hand.items() if k!='per_unit_receipts'}))
if __name__=='__main__':main()
