import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'event_wwii_rule_0001'))
from event_rule_v2 import evaluate_wwii
from event_rule import evaluate_wwii as original

def node(q,target=None):
 claims={}
 if target:claims['P361']=[dict(id=q+'$native',rank='normal',mainsnak=dict(property='P361',snaktype='value',datatype='wikibase-item',datavalue={'value':{'entity-type':'item','id':target,'numeric-id':int(target[1:])}}))]
 return dict(record={'id':q,'lastrevid':123,'claims':claims},source={'file':'fixture','sha256':'source-hash','revision':123})
class RootFixTests(unittest.TestCase):
 def test_root_identity_accepted_without_fabricated_edge(self):
  records={'Q362':node('Q362')};result=evaluate_wwii('Q362',records)
  self.assertTrue(result['keep_event']);self.assertEqual(result['acceptance_reason'],'ROOT_EVENT_IDENTITY');self.assertEqual(result['p361_chain'],[]);self.assertEqual(result['identity_evidence']['source'],records['Q362']['source']);self.assertNotIn('source_record_id',result['identity_evidence'])
 def test_normal_native_chain_is_byte_for_byte_unchanged(self):
  records={'Q1':node('Q1','Q2'),'Q2':node('Q2','Q362')};self.assertEqual(evaluate_wwii('Q1',records),original('Q1',records))
 def test_unproven_and_date_only_candidates_remain_unresolved(self):
  records={'Q1':node('Q1')};records['Q1']['record']['claims']['P585']=[{'mainsnak':{'datavalue':{'value':{'time':'+1942-01-01T00:00:00Z'}}}}]
  self.assertEqual(evaluate_wwii('Q1',records),original('Q1',records));self.assertFalse(evaluate_wwii('Q1',records)['keep_event'])
 def test_wrong_native_root_identity_is_rejected(self):
  with self.assertRaises(ValueError):evaluate_wwii('Q362',{'Q362':node('Q1')})
if __name__=='__main__':unittest.main()
