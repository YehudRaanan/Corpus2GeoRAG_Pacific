"""Private C3 persistence: one compressed E4 contribution per unit version."""
import hashlib
import json
import sqlite3
import sys
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'counts_direct_20261101'))
from pair_counts import aggregate_units, pair_counts, replace_unit, SCOPE_FIELDS


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def scope_key(manifest):
    return encoded([manifest[field] for field in SCOPE_FIELDS]).decode('utf-8')


class ContributionStore:
    def __init__(self, path):
        self.path = Path(path)
        self.db = sqlite3.connect(self.path, isolation_level=None)
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS contributions (
                seq INTEGER PRIMARY KEY, scope TEXT NOT NULL, version TEXT NOT NULL,
                sha256 TEXT NOT NULL, payload BLOB NOT NULL, UNIQUE(scope,version));
            CREATE TABLE IF NOT EXISTS active (
                scope TEXT PRIMARY KEY, seq INTEGER NOT NULL REFERENCES contributions(seq));
            CREATE TABLE IF NOT EXISTS refreshes (
                through_seq INTEGER PRIMARY KEY, frontier_sha256 TEXT NOT NULL,
                projection_sha256 TEXT NOT NULL);
        ''')

    def close(self):
        self.db.close()

    def _decode(self, row):
        raw=zlib.decompress(row[1])
        if hashlib.sha256(raw).hexdigest()!=row[0]:
            raise ValueError('Stored contribution content hash differs')
        return json.loads(raw)

    def apply(self, handoff, source_bytes):
        """Single-writer atomic admission; reuse E4 validation without global history copies."""
        key=scope_key(handoff['manifest'])
        self.db.execute('BEGIN IMMEDIATE')
        try:
            current=self.db.execute('SELECT c.sha256,c.payload,c.seq FROM contributions c JOIN active a ON a.seq=c.seq WHERE a.scope=?',(key,)).fetchone()
            state={tuple(json.loads(key)):[self._decode(current)]} if current else {}
            seen=self.db.execute('SELECT seq FROM contributions WHERE scope=? AND version=?',(key,handoff['version'])).fetchone()
            if seen and (not current or seen[0]!=current[2]):
                raise ValueError('Cannot restore a stale decision version')
            changed=replace_unit(state,handoff,source_bytes)
            if not changed:
                self.db.execute('COMMIT')
                return dict(changed=False,sequence=current[2])
            raw=encoded(handoff)
            cursor=self.db.execute('INSERT INTO contributions(scope,version,sha256,payload) VALUES(?,?,?,?)',
                                   (key,handoff['version'],hashlib.sha256(raw).hexdigest(),zlib.compress(raw)))
            seq=cursor.lastrowid
            self.db.execute('INSERT INTO active(scope,seq) VALUES(?,?) ON CONFLICT(scope) DO UPDATE SET seq=excluded.seq',(key,seq))
            self.db.execute('COMMIT')
            return dict(changed=True,sequence=seq,relations_refresh_required=True)
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def active_units(self):
        """Current units only. Full member/evidence provenance remains in each payload."""
        rows=self.db.execute('SELECT c.scope,c.sha256,c.payload FROM active a JOIN contributions c ON c.seq=a.seq ORDER BY c.scope').fetchall()
        return {tuple(json.loads(key)):[self._decode((sha,payload))] for key,sha,payload in rows}

    def history(self, manifest):
        return [self._decode(row) for row in self.db.execute(
            'SELECT sha256,payload FROM contributions WHERE scope=? ORDER BY seq',(scope_key(manifest),))]

    def _counts(self, state, include_pairs):
        # Existing reference semantics: original-row dedup, revision conflict retention,
        # physical-page denominators. Checkpoints rebuild active counts, never history.
        aggregate=aggregate_units(state)
        frontier=[dict(scope=dict(zip(SCOPE_FIELDS,key)),decision_version=history[-1]['version'],
                       contribution_sha256=digest(history[-1])) for key,history in sorted(state.items())]
        result=dict(frontier=frontier,frontier_sha256=digest(frontier),
                    identity_counts=aggregate['identity_counts'],typed_counts=aggregate['typed_counts'],
                    physical_pages=aggregate['unique_physical_pages'],
                    unique_occurrences=aggregate['unique_occurrences'],support_records=aggregate['support_records'],
                    pending_occurrences=sum(bool(row['pending_supports']) for row in aggregate['occurrences']),
                    explicit_unmatched_occurrences=sum(None in row['decision_values'] for row in aggregate['occurrences']),
                    conflicted_occurrences=sum(row['identity_conflict'] or 'page_or_type_conflict' in row['not_counted_reasons'] for row in aggregate['occurrences']))
        if include_pairs:
            result['pairs']=pair_counts(state)
        return result

    def counts(self, include_pairs=False):
        return self._counts(self.active_units(),include_pairs)

    def stats(self):
        through=self.db.execute('SELECT COALESCE(MAX(through_seq),0) FROM refreshes').fetchone()[0]
        return dict(contributions=self.db.execute('SELECT COUNT(*) FROM contributions').fetchone()[0],
                    active_units=self.db.execute('SELECT COUNT(*) FROM active').fetchone()[0],
                    pending_refreshes=self.db.execute('SELECT COUNT(*) FROM contributions WHERE seq>?',(through,)).fetchone()[0])

    def refresh_relations(self, recompute):
        """Durable obligation; callback must be idempotent and bind its native source frontier.

        This receipt proves callback completion, not consumer publication. No projection
        payload/history is duplicated in this store. Callback failure leaves work pending.
        """
        self.db.execute('BEGIN IMMEDIATE')
        try:
            through=self.db.execute('SELECT COALESCE(MAX(seq),0) FROM contributions').fetchone()[0]
            done=self.db.execute('SELECT COALESCE(MAX(through_seq),0) FROM refreshes').fetchone()[0]
            if through==done:
                self.db.execute('COMMIT')
                return dict(refreshed=False,through_sequence=through)
            state=self.active_units()
            counts=self._counts(state,False)
            projection=recompute(state,counts)
            receipt=dict(refreshed=True,through_sequence=through,frontier_sha256=counts['frontier_sha256'],projection_sha256=digest(projection))
            self.db.execute('INSERT INTO refreshes VALUES(?,?,?)',(through,receipt['frontier_sha256'],receipt['projection_sha256']))
            self.db.execute('COMMIT')
            return dict(receipt,projection=projection)
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
