"""Independent SQLite readback and unchanged reducer comparison; owned fixture only."""
import copy
import hashlib
import json
import sqlite3
import sys
import zlib
from pathlib import Path
from contribution_store import ContributionStore, digest, SCOPE_FIELDS
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'counts_direct_20261101'))
from pair_counts import fixture_unit,replace_unit,aggregate_units,pair_counts
HERE=Path(__file__).resolve().parent
DB=HERE/'fixture.sqlite'
if DB.exists():
    raise SystemExit('Preserve existing fixture: use a fresh output directory for another verification generation')
protected=[ROOT/'integration_direct_20261101/occurrence_decisions.py',ROOT/'integration_direct_20261101/aggregate_occurrences.py',ROOT/'counts_direct_20261101/pair_counts.py']
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in protected}
a,sa=fixture_unit(1,[0,1],['Q1','Q2'])
b,sb=fixture_unit(2,[2,3],['Q1','Q3'])
b2=copy.deepcopy(b)
b2.update(version='page-2-v2',prior_version=b['version'])
b2['decisions'][0]['qid']='Q4'
s=ContributionStore(DB)
for unit,source in [(a,sa),(b,sb),(b2,sb)]: s.apply(unit,source)
# Inject a failure after payload insertion and before the active pointer can move.
s.db.execute("CREATE TRIGGER fixture_abort BEFORE INSERT ON active WHEN NEW.scope LIKE '%page-never%' BEGIN SELECT RAISE(ABORT,'fixture'); END")
s.db.execute('DROP TRIGGER fixture_abort')
s.db.execute("CREATE TRIGGER fixture_abort BEFORE UPDATE ON active BEGIN SELECT RAISE(ABORT,'fixture pointer failure'); END")
b3=copy.deepcopy(b2)
b3.update(version='page-2-v3',prior_version=b2['version'])
pre=s.stats()
try: s.apply(b3,sb)
except sqlite3.IntegrityError: pass
else: raise AssertionError('Injected interruption did not reject commit')
assert s.stats()==pre
s.db.execute('DROP TRIGGER fixture_abort')
actual=s.counts(include_pairs=True)
assert not s.apply(b2,sb)['changed']
# A real callback is caller-owned. This fixture checks active replacement and frontier binding.
receipt=s.refresh_relations(lambda state,counts:{'pair_counts':pair_counts(state),'bound_frontier':counts['frontier_sha256']})
assert receipt['projection']['pair_counts']==actual['pairs']
assert not s.refresh_relations(lambda *_: (_ for _ in ()).throw(AssertionError('replayed')))['refreshed']
s.close()
# Read payloads directly, without ContributionStore decoding, in a reopened connection.
db=sqlite3.connect(f'file:{DB.as_posix()}?mode=ro',uri=True)
assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
rows=db.execute('SELECT c.scope,c.sha256,c.payload FROM contributions c JOIN active a ON a.seq=c.seq ORDER BY c.scope').fetchall()
state={}
for scope,expected,payload in rows:
    raw=zlib.decompress(payload)
    assert hashlib.sha256(raw).hexdigest()==expected
    state[tuple(json.loads(scope))]=[json.loads(raw)]
assert aggregate_units(state)['identity_counts']==actual['identity_counts']
assert pair_counts(state)==actual['pairs']
assert db.execute('SELECT COUNT(*) FROM contributions').fetchone()[0]==3
assert db.execute('SELECT COUNT(*) FROM active').fetchone()[0]==2
assert sum(len(unit['occurrences']) for versions in state.values() for unit in versions)==4
assert next(row for row in actual['pairs'] if row['source_qid']=='Q1' and row['target_qid']=='Q2')['source_strength']==1
historical=[json.loads(zlib.decompress(row[0])) for row in db.execute('SELECT payload FROM contributions ORDER BY seq')]
assert historical==[a,b,b2]
db.close()
assert before=={str(p):sha(p) for p in protected}
(HERE/'fixture_counts.json').write_text(json.dumps(actual,indent=2),encoding='utf-8')
report=dict(status='PASS_ISOLATED_C3_BOUNDARY',tests=6,independent_checks=['sqlite_integrity','direct_payload_hashes','reference_counts_and_pairs','history_exact','replay_no_callback','mid_transaction_rollback','reference_modules_unchanged'],
            fixture=dict(active_units=2,contributions=3,original_occurrences=4,physical_pages=2,identity_replacement='Q1 -> Q4 on page 2; Q1-Q2 denominator 2 -> 1'),
            database_bytes=DB.stat().st_size,compressed_payload_bytes=sum(len(zlib.compress(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())) for v in historical),
            protected_sha256=before,files_sha256={p.name:sha(p) for p in [HERE/'contribution_store.py',HERE/'test_contribution_store.py',HERE/'verify_readback.py',HERE/'INTERFACE.md',HERE/'fixture_counts.json',DB]},
            limitations=['Caller-owned actual native relation recompute and publisher integration not connected','Active counts still full reference recomputation at requested checkpoint; no corpus-scale performance claim','All-pairs optional reference path quadratic; do not invoke per-unit at corpus scale','SQLite store is private; successful callback receipt does not assert publication','Source-only invalidation remains existing relation source dispatcher responsibility'])
(HERE/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
