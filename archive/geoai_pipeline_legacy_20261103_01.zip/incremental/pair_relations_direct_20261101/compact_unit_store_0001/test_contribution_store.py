import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'counts_direct_20261101'))
from pair_counts import fixture_unit, pair_counts, aggregate_units, replace_unit
from contribution_store import ContributionStore

class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'store.sqlite'
        self.store = ContributionStore(self.path)
        self.a, self.sa = fixture_unit(1, [0, 1], ['Q1', 'Q2'])
        self.b, self.sb = fixture_unit(2, [2, 3], ['Q1', 'Q3'])
    def tearDown(self):
        self.store.close()
        self.temp.cleanup()
    def test_reference_aggregation_and_retry(self):
        state = {}
        for unit, source in [(self.a,self.sa),(self.b,self.sb)]:
            self.assertTrue(self.store.apply(unit,source)['changed'])
            replace_unit(state,unit,source)
        before = self.store.stats()
        self.assertFalse(self.store.apply(self.b,self.sb)['changed'])
        self.assertEqual(before,self.store.stats())
        actual = self.store.counts(include_pairs=True)
        self.assertEqual(actual['identity_counts'],aggregate_units(state)['identity_counts'])
        self.assertEqual(actual['pairs'],pair_counts(state))
        self.assertEqual(actual['unique_occurrences'],4)
        self.assertEqual(actual['physical_pages'],2)
    def test_replacement_retracts_and_preserves_history(self):
        self.store.apply(self.a,self.sa)
        self.store.apply(self.b,self.sb)
        revised=copy.deepcopy(self.b)
        revised.update(version='page-2-v2',prior_version=self.b['version'])
        revised['decisions'][0]['qid']='Q4'
        self.store.apply(revised,self.sb)
        got=self.store.counts(include_pairs=True)
        row=next(p for p in got['pairs'] if (p['source_qid'],p['target_qid'])==('Q1','Q2'))
        self.assertEqual(row['source_strength'],1)
        self.assertEqual(len(self.store.history(self.b['manifest'])),2)
        self.assertEqual(self.store.history(self.b['manifest'])[0],self.b)
        self.assertEqual(self.store.stats()['contributions'],3)
        with self.assertRaises(ValueError): self.store.apply(self.b,self.sb)
    def test_revision_dedup_and_conflict(self):
        self.store.apply(self.a,self.sa)
        revision=copy.deepcopy(self.a)
        revision['version']='revision-11-v1'
        revision['manifest']['support_revision_id']=11
        revision['shards'][0]['support_revision_id']=11
        for member in revision['occurrences']: member['revision_id']=11
        revision['decisions'][0]['qid']='Q9'
        self.store.apply(revision,self.sa)
        got=self.store.counts()
        self.assertEqual(got['physical_pages'],1)
        self.assertEqual(got['unique_occurrences'],2)
        self.assertEqual(got['support_records'],4)
        self.assertEqual(got['conflicted_occurrences'],1)
        self.assertEqual(got['identity_counts'],[dict(qid='Q2',mention_count=1,page_count=1)])
    def test_invalid_update_atomic_and_reopen(self):
        self.store.apply(self.a,self.sa)
        before=self.store.stats()
        bad=copy.deepcopy(self.a)
        bad['decisions'][0]['qid']='Q8'
        with self.assertRaises(ValueError): self.store.apply(bad,self.sa)
        with self.assertRaises(ValueError): self.store.apply(self.b,b'wrong bytes')
        self.assertEqual(before,self.store.stats())
        self.store.close()
        self.store=ContributionStore(self.path)
        self.assertFalse(self.store.apply(self.a,self.sa)['changed'])
        self.assertEqual(self.store.counts()['unique_occurrences'],2)
    def test_pending_unmatched_and_refresh_retry(self):
        self.a['decisions'][0]['qid']=None
        self.a['decisions'].pop()
        self.store.apply(self.a,self.sa)
        got=self.store.counts()
        self.assertEqual(got['pending_occurrences'],1)
        self.assertEqual(got['explicit_unmatched_occurrences'],1)
        def fail(*args): raise RuntimeError('fixture failure')
        with self.assertRaises(RuntimeError): self.store.refresh_relations(fail)
        self.assertEqual(self.store.stats()['pending_refreshes'],1)
        calls=[]
        def refresh(state, counts):
            calls.append(counts['frontier'])
            return {'fixture_relation_projection':len(state)}
        receipt=self.store.refresh_relations(refresh)
        self.assertTrue(receipt['refreshed'])
        self.assertEqual(self.store.stats()['pending_refreshes'],0)
        self.assertFalse(self.store.refresh_relations(refresh)['refreshed'])
        self.assertEqual(len(calls),1)
    def test_no_history_copy_on_new_unit(self):
        self.store.apply(self.a,self.sa)
        original=self.store.history(self.a['manifest'])
        self.store.apply(self.b,self.sb)
        self.assertEqual(original,self.store.history(self.a['manifest']))
        self.assertEqual(self.store.stats()['contributions'],2)

if __name__=='__main__': unittest.main(verbosity=2)
