# C3 compact contribution boundary v1

`ContributionStore(path).apply(handoff, source_bytes)` admits the existing closed E4 handoff, returning a durable sequence and changed/replay flag. One SQLite transaction stores a compressed immutable contribution and advances only its active pointer. Complete occurrence members, decisions, evidence, source and processing revision scope remain available. Historical versions are never copied into another unit or overwritten. A different processing revision remains a separate support, as required by E4.

`counts(include_pairs=False)` reads active contributions only and calls the existing reducers unchanged. It returns compact identity/typed counts, distinct physical pages, unique original occurrences, conflicts/pending/unmatched totals and the exact active frontier. Pair materialization is opt-in because the existing all-pairs reference formula is quadratic. No full historical projection is persisted.

`active_units()` supplies current E4 units only for the publisher boundary; `history(scope)` supplies that unit's immutable versions on demand. SQLite is private persistence, not a consumer schema. The caller owns policy admission and canonical state.

Every changed contribution creates a durable refresh obligation. Counts/identity changes require relation recomputation against the full current frontier, including directional denominators. `refresh_relations(callback)` supplies active units, compact counts and frontier to the existing caller-owned relation implementation; it records a receipt only after callback success. A failed callback leaves an explicit pending obligation. Exact replay adds neither history nor refresh obligation. No native relation is invented here. Relation source-only changes remain the caller's existing source-frontier dispatcher responsibility.

First bounded delivery: fixture verification against unchanged E4/count reference reducers. C4/PUBLISHER and INTEGRATION must connect this private boundary before any bulk-run readiness claim. No canonical files or old artifacts changed.
