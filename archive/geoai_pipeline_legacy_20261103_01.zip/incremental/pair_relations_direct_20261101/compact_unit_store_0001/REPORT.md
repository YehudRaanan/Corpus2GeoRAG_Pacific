# C3 bounded delivery 0001

PASS: six isolated tests plus seven direct-readback checks. Tests first failed because the adapter did not exist, then passed after implementation. A SQLite trigger additionally interrupted the transaction after contribution insertion: neither the contribution nor active pointer was committed. A reopened read-only connection verified integrity, payload hashes, exact preserved history and reference reducer equivalence.

Entrypoint: `contribution_store.py:ContributionStore(db_path)`.

- `apply(handoff, source_bytes)` validates the unchanged E4 interface and commits one compressed version plus active pointer atomically. Exact replay is a no-op; stale/conflicting versions and corrupt source bytes are rejected.
- `counts(include_pairs=False)` returns active frontier, identity/typed counts, physical pages, unique original occurrences and explicit pending/unmatched/conflict totals. Full members and decisions remain retrievable through `active_units()`; history through `history(manifest)`.
- `refresh_relations(recompute)` calls `recompute(active_state, compact_counts)` and binds the returned projection hash to the full active frontier. Changed units create durable refresh obligations; failure leaves them pending. The supplied callback must be idempotent, recompute denominator-dependent relations, and bind its native-source frontier. No actual native relation adapter has been connected by this isolated fixture.

Fixture: two pages, four original occurrences, three retained unit versions. Changing page 2 Q1 to Q4 retracts Q1's page-2 support; Q1-Q2 strength changes 1/2 to 1 using the unchanged pair reducer. A separate two-revision fixture keeps four supports but only two original occurrences and one physical page; conflicting QIDs remain uncounted without an invented winner. Explicit unmatched and pending remain distinct.

Storage: 24,576-byte SQLite database; 1,260 bytes of compressed handoff payloads. These tiny-fixture values are not corpus estimates. No history snapshot or projection payload is copied per unit. Old canonical artifacts and three reused reducers were unchanged, with hashes in verification.json.

Self-review: scope/version/content collision, wrong source bytes, transaction rollback, restart/replay and support-revision dedup checked. SQLite's default durable transaction settings retained; no journal/config changes. No new public schema, formulas or policy.

Remaining integration: INTEGRATION connects CPU admission to apply; PUBLISHER reviews active frontier/count/provenance boundary for C4; caller supplies its actual relation recompute. This bounded implementation still rebuilds active counts when requested and loads active members in memory; it has no corpus-scale performance claim. Optional all-pairs path is quadratic and must not run per unit at corpus scale. Bulk execution remains unrun. A source-only frontier change remains with the existing source dispatcher, not an identity contribution update.

Re-run unit tests: `C:\Users\User\anaconda3\python.exe -B pair_relations_direct_20261101/compact_unit_store_0001/test_contribution_store.py`. `verify_readback.py` intentionally refuses to overwrite its existing persistent fixture; preserve this generation.
