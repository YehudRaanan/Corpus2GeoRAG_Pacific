"""Small independent root-scope handoff verification; no acquisition or full-world expansion."""
import json,sys,gzip
from pathlib import Path
from collections import Counter
import ijson
from execute_root_scope import HERE,PAIR,ROOT,read,write,sha,desc,native_links,CLASS_METADATA

def main():
 stage=HERE/'cache_completed_001';hand=read(stage/'handoff.json');scope=read(hand['artifacts']['scope.json']['path']);geo=read(hand['artifacts']['geo_decisions.json']['path']);records=read(hand['artifacts']['sources.json']['path'])
 for d in [*hand['inputs'].values(),*hand['artifacts'].values(),hand['processor'],hand['traversal'],hand['previous']]:assert sha(d['path'])==d['sha256']
 registry=read(hand['inputs']['registry']['path'])['selected_references'];graph=read(hand['inputs']['source_graph']['path'])
 for q,r in registry.items():records.setdefault(q,dict(record=r['envelope']['entity'],source=r['provenance'],coverage='FULL'))
 for q in ('Q362','Q1645012','Q52418','Q713516'):records.setdefault(q,graph[q])
 first={r['qid'] for r in scope['candidates'] if r['hop']==1};unrepresented=first-set(hand['full_first_hop_source_gaps'])-records.keys()
 if unrepresented:
  with Path(hand['inputs']['verified_prior_scope_cache']['path']).open('rb') as stream:
   for q,node in ijson.kvitems(stream,'',use_float=True):
    if q in unrepresented and node.get('coverage','FULL')=='FULL':records[q]=node
 unrepresented=first-set(hand['full_first_hop_source_gaps'])-records.keys()
 if unrepresented:
  archive=hand['inputs']['native_archive']
  with gzip.open(archive['path'],'rt',encoding='utf8') as stream:
   for number,line in enumerate(stream,1):
    if not any(q in line for q in unrepresented):continue
    envelope=json.loads(line);q=envelope['requested_qid']
    if q not in unrepresented:continue
    raw=envelope['entity'];assert raw['id']==q and 'claims' in raw
    records[q]=dict(record=raw,source=dict(provider='WIKIDATA',file=archive['path'],sha256=archive['sha256'],line=number,record_id=q,revision=raw.get('lastrevid'),modified=raw.get('modified')),coverage='FULL')
    unrepresented.remove(q)
    if not unrepresented:break
 assert not (first-set(hand['full_first_hop_source_gaps'])-records.keys())
 assert len(records)==hand['source_frontier_records']
 complete_source=HERE/'source_frontier_complete_0001.json';write(complete_source,records)
 index={};expected_first=set();seen_first=set()
 for q,node in records.items():
  for edge in native_links(q,node):
   key=tuple(edge[k] for k in ('subject_qid','object_qid','source_predicate','source_record_id'));index[key]=edge
   if edge['source_predicate'] in CLASS_METADATA or 'existing_exclusion_reason' in edge:continue
   if edge['subject_qid']=='Q362':expected_first.add(key)
   if edge['object_qid']=='Q362':expected_first.add(key)
 counts=Counter()
 for row in scope['candidates']:
  assert row['anchor']=='Q362' and row['hop']==len(row['path']) and row['hop'] in (1,2);walk='Q362'
  for edge in row['path']:
   key=tuple(edge[k] for k in ('subject_qid','object_qid','source_predicate','source_record_id'));assert key in index
   expected=index[key];assert edge['raw_statement']==expected['raw_statement'] and edge['source']==expected['source'] and edge['source_predicate'] not in CLASS_METADATA
   assert edge['walk_from']==walk
   assert (edge['walk_from'],edge['walk_to'])==((edge['subject_qid'],edge['object_qid']) if edge['walk_direction']=='OUTGOING' else (edge['object_qid'],edge['subject_qid']))
   walk=edge['walk_to']
  assert walk==row['qid']
  if row['hop']==1:seen_first.add(tuple(row['path'][0][k] for k in ('subject_qid','object_qid','source_predicate','source_record_id')))
  if row['type']=='LOC':
   value=geo['geo'].get(row['qid']);assert row['inclusion']==('INCLUDE' if value is True else 'EXCLUDE' if value is False else 'PENDING_GEO')
  elif row['type'] is None:assert row['inclusion']=='PENDING_TYPE'
  else:assert row['inclusion']==('INCLUDE' if row['hop']==1 else 'EXCLUDE')
  counts[(row['hop'],row['inclusion'])]+=1
 assert seen_first==expected_first and len(first)==180 and sum(counts.values())==10466
 assert len(hand['full_first_hop_source_gaps'])==62 and hand['first_hop_paths']==250 and hand['known_second_hop_LOC_paths']==911
 assert geo['mask_sha256']=='8bb675894f9eca241517ba582960afe99e0be034e607906c3a77de1fee17f85f' and not geo['source_geometry_changed']
 baseline=read(HERE/'baseline_001/handoff.json');assert sha(hand['previous']['path'])==hand['previous']['sha256'] and baseline['first_hop_unique_QIDs']==180
 proof=dict(status='PASS_BOUNDED_ROOT_EXPANSION',root='Q362',first_hop_unique_QIDs=180,first_hop_paths=250,second_hop_paths=10216,known_second_hop_LOC_paths=911,
  total_paths_verified=10466,source_gaps=hand['full_first_hop_source_gaps'],source_gap_count=62,counts={str(k):v for k,v in counts.items()},
  all_explicit_first_hop_at_declared_frontier_verified=True,native_statement_direction_and_provenance_verified=True,only_LOC_second_hop_can_include=True,
  approved_mask_verified=True,unknown_geometry_retained=True,first_hop_source_completion_added=45,external_calls=0,aliases_requested=False,
  incoming_not_globally_complete=True,previous_generation_preserved=True,identity_decisions_changed=False,consumer_materialized=False,publication=False)
 write(HERE/'independent_readback_0001.json',proof)
 release=dict(status='ROOT_EXPANSION_HANDOFF_0001_READY',scope=hand['artifacts']['scope.json'],geo=hand['artifacts']['geo_decisions.json'],sources=desc(complete_source),
  verification=desc(HERE/'independent_readback_0001.json'),execution_handoff=desc(stage/'handoff.json'),root_identity_successor=hand['inputs']['root_successor'],
  first_hop_unique_QIDs=180,first_hop_paths=250,second_hop_paths=10216,known_second_hop_LOC_paths=911,first_hop_source_gap_count=62,first_hop_source_gaps=hand['full_first_hop_source_gaps'],
  available_first_hop_full_sources=118,source_coverage=hand['incoming_coverage'],mask_version=hand['mask_version'],mask_sha256=hand['mask_sha256'],
  inclusion_scope='Runtime expansion was not filtered by page membership. Firsthop has all explicit entity relation predicates at the declared source frontier. Unknown types/geometries remain pending.',
  remaining='62 firsthop source gaps at the searched frontier; endpoint typing and validated geometry gaps remain. No claim of complete global incoming Wikidata coverage.',
  external_calls=0,aliases_requested=False,consumer_materialized=False,publication=False)
 write(HERE/'ROOT_EXPANSION_HANDOFF_0001.json',release);print(json.dumps(proof));print(str(HERE/'ROOT_EXPANSION_HANDOFF_0001.json'))
if __name__=='__main__':main()
