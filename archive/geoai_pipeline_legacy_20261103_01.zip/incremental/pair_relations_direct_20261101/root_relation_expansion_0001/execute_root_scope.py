"""Bounded ROOT scope execution using approved source traversal and existing GEO classifier."""
import gzip,json,sys
from collections import Counter
from pathlib import Path
import ijson,pyarrow.parquet as pq
from shapely import wkb
HERE=Path(__file__).resolve().parent;PAIR=HERE.parent;ROOT=PAIR.parent
sys.path[:0]=[str(PAIR/'event_wwii_rule_0001'),str(PAIR/'event_runtime_0001'),str(ROOT/'orchestration_direct_20261101')]
from event_rule import discover_scope,native_links,CLASS_METADATA,HOP_VERSION
from event_runtime import sha,read,write
from wire_pacific_mask import scope_geo_map
ARCHIVE=Path(r'D:\Projects\GeoAI\Data\external\wwii_task_force\wikidata_entities.jsonl.gz')
ARCHIVE_SHA='95c6a8aa5ab803d904a0f5e85bfc5d2dade97b5b5f18c0c33ea48a54fc217277'
def desc(p,expected=None):
 value=sha(p)
 if expected and value!=expected:raise ValueError('Input hash differs')
 return dict(path=str(Path(p).resolve()),sha256=value)
def make_stage(name,records,kinds,geometries,geometry_source,catalog_source,inputs,previous=None):
 output=HERE/name
 if output.exists():raise ValueError('Use a new immutable stage')
 raw=discover_scope(['Q362'],records,kinds)
 locs={r['qid'] for r in raw['candidates'] if r['type']=='LOC'}
 geo=scope_geo_map({q:'LOC' for q in locs},geometries,{q:geometry_source if q in geometries else catalog_source for q in locs})
 for row in raw['candidates']:
  if row['type']!='LOC':continue
  decision=geo['geo'].get(row['qid']);row['inclusion']='INCLUDE' if decision is True else 'EXCLUDE' if decision is False else 'PENDING_GEO'
  row['reason']='APPROVED_PACIFIC_MASK' if decision is not None else 'MISSING_VALIDATED_GEOMETRY_RETAINED_UNKNOWN'
 raw['geometry_policy']='APPROVED_PACIFIC_MASK_APPLIED_LOC_ONLY';raw['mask_binding']={k:geo[k] for k in ('mask_version','mask_sha256','mask_code_sha256')}
 first=[r for r in raw['candidates'] if r['hop']==1];first_qids={r['qid'] for r in first};missing=sorted(q for q in first_qids if q not in records or records[q].get('coverage','FULL')!='FULL')
 counts=Counter((r['hop'],r['inclusion']) for r in raw['candidates']);output.mkdir()
 write(output/'scope.json',raw);write(output/'geo_decisions.json',geo)
 # Keep only actual statement subjects as source custody; all backing bytes remain untouched.
 used={e['subject_qid'] for row in raw['candidates'] for e in row['path']}|{'Q362'}
 write(output/'sources.json',{q:records[q] for q in sorted(used) if q in records})
 report=dict(status='ROOT_RELATION_SCOPE_EXECUTED',anchor='Q362',hop_version=HOP_VERSION,first_hop_paths=len(first),first_hop_unique_QIDs=len(first_qids),
  second_hop_paths=sum(r['hop']==2 for r in raw['candidates']),known_second_hop_LOC_paths=sum(r['hop']==2 and r['type']=='LOC' for r in raw['candidates']),
  path_counts={str(k):v for k,v in counts.items()},full_first_hop_source_gaps=missing,
  first_hop_type_unknown_QIDs=sorted({r['qid'] for r in first if r['type'] is None}),LOC_geometry_unknown_QIDs=sorted(q for q,value in geo['geo'].items() if value is None),
  structural_metadata_assertions=len(raw['structural_metadata']),source_frontier_records=len(records),
  incoming_coverage='EXPLICIT_ASSERTIONS_IN_REGISTRY340_EVENT4_AND_VERIFIED_DIRECT_NEIGHBOR_CACHE_RECORDS_ONLY_NOT_GLOBAL',
  source_expansion='ONLY_MISSING_ONEHOP_QIDs_FROM_BASELINE_NO_RECURSIVE_SOURCE_FETCH',mask_version=geo['mask_version'],mask_sha256=geo['mask_sha256'],
  inputs=inputs,previous=previous,processor=desc(Path(__file__)),traversal=desc(PAIR/'event_wwii_rule_0001/event_rule.py'),
  artifacts={n:desc(output/n) for n in ('scope.json','geo_decisions.json','sources.json')},external_calls=0,aliases_requested=False,
  identity_decisions_changed=False,consumer_materialized=False,publication=False)
 write(output/'handoff.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ('inputs','artifacts','first_hop_type_unknown_QIDs','LOC_geometry_unknown_QIDs')},ensure_ascii=True),flush=True)
 return report,first_qids

def main():
 root_hand_path=PAIR/'event_root_fix_0001/RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001.json';root_hand=read(root_hand_path)
 registry_path=PAIR/'accepted11_20_sources_0001/generation_014/native_registry.json';registry=read(registry_path)
 records={q:dict(record=r['envelope']['entity'],source=r['provenance'],coverage='FULL') for q,r in registry['selected_references'].items()}
 graph=read(root_hand['source_graph']['path'])
 for q in root_hand['accepted_event_qids']:records[q]=graph[q]
 projection_path=ROOT/'orchestration_direct_20261101/policy_v2_all17_sources_0340_0001/unit/projection.json';projection=read(projection_path);kinds={}
 for row in projection['count_receipt']['projection']['typed_counts']:kinds.setdefault(row['qid'],set()).add(row['entity_group'])
 for q in root_hand['accepted_event_qids']:kinds.setdefault(q,set()).add('Event')
 kinds={q:sorted(values) for q,values in kinds.items()}
 component=ROOT/'publisher_direct_20261101/orchestration_refresh_0001/policy_v2_all17_registry340/components/model'
 geometry_source=desc(component/'geometries.parquet','44fecf859df3616c423027590622bf7bdc490f2ab4dfb3cd77fefc45c63f7787');catalog_source=desc(component/'geography.json.gz')
 geometries={r['place_id']:wkb.loads(r['geometry']) for r in pq.read_table(geometry_source['path']).to_pylist()}
 inputs=dict(registry=desc(registry_path,'f1bf0d890542e63557d18af13e6067e3e8da3768e0a50543432516c0db5fb0dc'),root_successor=desc(root_hand_path),source_graph=desc(root_hand['source_graph']['path'],root_hand['source_graph']['sha256']),
  projection=desc(projection_path,root_hand['input_binding']['identity_projection']),geometry=geometry_source,geography_catalog=catalog_source,
  approved_GEO_receipt=desc(ROOT/'orchestration_direct_20261101/pacific_mask_integration_0001/receipt.json'))
 baseline,first=make_stage('baseline_001',records,kinds,geometries,geometry_source,catalog_source,inputs)
 missing=set(baseline['full_first_hop_source_gaps']);added=[]
 cache=PAIR/'event_wwii_rule_0001/generation_001/scope_source_evidence.json'
 if missing:
  with cache.open('rb') as stream:
   for q,node in ijson.kvitems(stream,'',use_float=True):
    if q in missing and node.get('coverage','FULL')=='FULL':records[q]=node;missing.remove(q);added.append(q)
 inputs['verified_prior_scope_cache']=desc(cache)
 if missing:
  inputs['native_archive']=desc(ARCHIVE,ARCHIVE_SHA)
  with gzip.open(ARCHIVE,'rt',encoding='utf8') as stream:
   for number,line in enumerate(stream,1):
    envelope=json.loads(line);q=envelope['requested_qid']
    if q not in missing:continue
    record=envelope['entity']
    if record.get('id')!=q or 'claims' not in record:continue
    records[q]=dict(record=record,source=dict(provider='WIKIDATA',file=str(ARCHIVE),sha256=ARCHIVE_SHA,line=number,record_id=q,revision=record.get('lastrevid'),modified=record.get('modified')),coverage='FULL')
    missing.remove(q);added.append(q)
    if not missing:break
 final,_=make_stage('cache_completed_001',records,kinds,geometries,geometry_source,catalog_source,inputs,desc(HERE/'baseline_001/handoff.json'))
 write(HERE/'CACHE_COMPLETION.json',dict(requested_only_baseline_first_neighbors=baseline['full_first_hop_source_gaps'],added_unique_QIDs=sorted(added),remaining_source_gaps=final['full_first_hop_source_gaps'],public_calls=0))
if __name__=='__main__':main()
