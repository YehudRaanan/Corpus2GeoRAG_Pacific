"""Read-only cache coverage/evidence audit for ten accepted real-unit identities."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
import ijson

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
COUNTS = ROOT / "counts_direct_20261101/real_counts_20261101T202248289937Z"
MAIN = Path(r"D:\Projects\GeoAI")


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run():
    receipt = json.loads((COUNTS / "verification.json").read_text())
    assert receipt["status"] == "PASS_REAL_COUNTS"
    for path, expected in receipt["protected_sha256"].items():
        assert sha(Path(path)) == expected
    for name, expected in receipt["output_sha256"].items():
        assert sha(COUNTS / name) == expected
    counts = json.loads((COUNTS / "counts.json").read_text())
    unit = ROOT / "integration_direct_20261101/real_handoff_0001/sealed_v1/unit.private.json"
    handoff = json.loads(unit.read_text())
    qids = {row["qid"] for row in counts["identity_counts"]}
    assert qids == {row["qid"] for row in handoff["decisions"]} and len(qids) == 10
    protected = {str(COUNTS / "counts.json"): sha(COUNTS / "counts.json"), str(unit): sha(unit)}
    versions, statements, scanned = {qid: [] for qid in qids}, [], []
    mapping_path = MAIN / "GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv"
    direction_path = MAIN / "GG_Data/mapping/RELATION_DIRECTION_LOOKUP_v2.1.1.csv"
    with mapping_path.open(encoding="utf-8-sig", newline="") as stream:
        mapping = {(row["source"], row["source_predicate"]): row for row in csv.DictReader(stream)}
    with direction_path.open(encoding="utf-8-sig", newline="") as stream:
        directions = {row["input_relation_id"]: row for row in csv.DictReader(stream)}
    protected.update({str(path): sha(path) for path in (mapping_path, direction_path)})

    def inspect(qid, entity, path, locator, retrieval=None):
        if qid not in qids:
            return
        complete = entity.get("id") == qid and "claims" in entity and "missing" not in entity
        versions[qid].append(dict(file=str(path), locator=locator, retrieval_utc=retrieval,
                                 revision=entity.get("lastrevid"), modified=entity.get("modified"),
                                 claims_present=complete, properties=len(entity.get("claims", {}))))
        if not complete:
            return
        for prop, claims in entity["claims"].items():
            for statement in claims:
                target = statement.get("mainsnak", {}).get("datavalue", {}).get("value", {})
                target = target.get("id") if isinstance(target, dict) else None
                if target not in qids:
                    continue
                rule = mapping.get(("Wikidata", "wd:" + prop))
                level2 = rule["level2_relation_id"] if rule else None
                statements.append(dict(source=qid, target=target, property=prop, statement=statement,
                    source_file=str(path), locator=locator, revision=entity.get("lastrevid"), retrieval_utc=retrieval,
                    catalog_mapping=rule, catalog_inverse=directions.get(level2)))

    cache = MAIN / "GG_Data/pipeline/outputs/wikidata_full_cache"
    for path in sorted(cache.glob("*.json.gz")):
        protected[str(path)] = sha(path)
        with gzip.open(path, "rb") as stream:
            for index, row in enumerate(ijson.items(stream, "rows.item")):
                if row["id"] in qids:
                    inspect(row["id"], json.loads(row["item"].rstrip(",\n\r ")), path, dict(row_index=index))
        scanned.append(dict(file=str(path), kind="BIGQUERY_FULL_ITEM_ROWS"))
    snapshot = cache / "table_snapshot.json"
    protected[str(snapshot)] = sha(snapshot)
    archive = MAIN / "Data/external/wwii_task_force/wikidata_entities.jsonl.gz"
    protected[str(archive)] = sha(archive)
    with gzip.open(archive, "rt", encoding="utf-8") as stream:
        for line, text in enumerate(stream, 1):
            if any(qid in text for qid in qids):
                envelope = json.loads(text)
                if envelope["requested_qid"] in qids:
                    inspect(envelope["requested_qid"], envelope["entity"], archive, dict(line=line))
    scanned.append(dict(file=str(archive), kind="ARCHIVED_FULL_ENTITY_JSONL"))
    coverage = [dict(qid=qid, full_record_versions=versions[qid],
                    full_claims_record_available=any(row["claims_present"] for row in versions[qid])) for qid in sorted(qids)]
    payload = dict(status="LOCAL_NATIVE_CACHE_AUDIT", checked_utc=datetime.now(timezone.utc).isoformat(),
                   accepted_qids=sorted(qids), accepted_occurrences=30, pending_occurrences=106,
                   counted_pairs=45, coverage=coverage, native_statement_evidence=statements,
                   scanned_sources=scanned, protected_sha256=protected,
                   no_edges_created=True, complete_native_frontier_declared=False,
                   limits="Only named full-record caches scanned; projected metadata is not native-relation coverage. No version, scope/exclusion or relation-population policy was executed.")
    assert all(sha(Path(path)) == expected for path, expected in protected.items())
    output = HERE / "real_native_cache_audit_0001.json"
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    assert json.loads(output.read_text()) == payload
    print(json.dumps(dict(output=str(output), full_record_qids=sum(row["full_claims_record_available"] for row in coverage),
                         missing=[row["qid"] for row in coverage if not row["full_claims_record_available"]],
                         evidence_occurrences=len(statements), statements=sorted({(s['source'],s['property'],s['target']) for s in statements}),
                         output_sha256=sha(output))))


if __name__ == "__main__":
    run()

