# E5 / Task 5 / R7 - pair-local fallback fixture

2026-11-01: PASS, 12 focused checks; fresh-process output/code and four shared-source hashes verified.

One readable stage file: pair_relations.py. Input is a caller-declared complete available/linkable native producer frontier, already-supplied private fallback views and private snapshot history. Native inverse handling reuses relations/native_pair_views.py and the existing build_graph generated fixture/catalog v2.1.2. No relation acquisition, new formulas or consumer field changes.

Three successive generated frontiers:

1. Native A-C only: A-B and B-A fallback remain active (four total views including A-C/inverse).
2. Native A-B arrives: its two active fallback views are replaced by native A-B and its catalog inverse; old fallback stays unchanged in the first history version (four total active views).
3. Native B-A plus another independent A-B assertion arrive: both directions keep their native facts, without redundant A-B inverses. Independent 1942/1943/1944 dates remain distinct (five total active views including A-C/inverse).

Each exact replay leaves history unchanged. All three source snapshots, supplied fallback evidence and active views are retained; no shared input is mutated. Caller mutation cannot rewrite saved history. RED baseline failed the named A-C/A-B assertion; GREEN passed 12 checks. JSON output readback passed inside the run and in a new Python process, with matching code/payload and four shared-source hashes.

Evidence: case_20261101T200716175626Z/verification.json and transitions_and_history.json.
Code SHA256: 1aa8f136b65a2b8091b6d0307f0e8804458dd3759fae2e1993e69ed065913091.

Boundaries: generated, in-memory complete-frontier replacement only. History is saved as JSON for inspection, not a durable recovery protocol. Completeness/linkability are caller prerequisites, not inferred here. No production units, network calls, paid work, consumer export, deployment or shared-plan writes. Backup: Unprotected (workspace has no Git repository).

Next increment feasibility: counts_direct_20261101/pair_counts.py can supply the fallback evidence without new formulas. Its positive shared_page_count pair rows can be projected to two private directions, keeping the existing source/target denominators and directional strengths. Zero-count diagnostic rows need to remain private diagnostics, with no invented consumer-edge policy. Use the same identity/page/native frontier, then verify denominator-only corrections update stored fallback evidence even while native views remain active. E5 history currently snapshots supplied fallback evidence, so this can be tested in a separate tiny adapter within the E5 directory without editing counts. G11 still blocks choosing consumer strength serialization. No combined count/native test was run in this increment.

The counts REPORT.md and source were read only; the reported top-level independent_verification.json was absent at inspection, so that report's independent receipt was not independently verified here.

Compatibility validation: the first main-Python attempt could not collect test_native_pair_consumer.py because rapidfuzz was missing. Reusing the existing read-only contract_fixtures/.venv-bridge/Lib/site-packages via process-local PYTHONPATH resolved this without installation. The existing graph exporter suite plus native-pair consumer tests then passed: 20 passed in 1.36s, exit 0. Evidence: existing_checks.log (initial collection error) and existing_checks_with_bridge.log (successful run). No global environment changed. Fresh-process receipt: fresh_process_verification.json.
