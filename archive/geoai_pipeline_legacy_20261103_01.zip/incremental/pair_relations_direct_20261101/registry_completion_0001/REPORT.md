# Callable bounded native-registry completion - PASS

Entrypoint: registry_completion.py::complete_registry(accepted_qids, *, prior_registry, prior_sha256, output_dir, max_public_qids=0).

Example for INTEGRATION:

    result = complete_registry(
        accepted_qids,
        prior_registry=previous_registry_path,
        prior_sha256=previous_registry_sha256,
        output_dir=new_owned_generation_path,
        max_public_qids=0,  # cache only; explicitly allow 1..5 for at most one exact public batch
    )

Use result['native_registry'] ({path,sha256}) for downstream relation/identity materialization. result also supplies completed_qids, explicit missing_qids, network_requests and source_receipts ({path,sha256} list). Identity acceptance remains the caller's responsibility; this function never accepts identities, infers business types, creates relations or publishes anything.

Lookup order: preserve the entire caller-pinned prior registry; reuse existing hash-verified completed registry caches and their full source envelopes; for unresolved requested IDs only, reuse the existing six BigQuery full-item files and whole-native archive lookup. Selection reuses entities.native_record/select_reference/choose_name: snapshot first, otherwise latest available complete same-ID record, with no cross-version field blending. New source entries do not inherit an earlier batch's business-type assignment. Whole native P31/other claims remain intact.

Public acquisition is off by default. An explicit max_public_qids from1through5 allows at most ONE official exact-ID batch for that many actual misses. No speculative IDs, retries or unbounded follow-on collection. A failed/missing public answer remains an explicit gap; it is never evidence of no native relation. The raw response and request receipt are saved when that branch runs. This increment did not make a public call: the five real test IDs reused the two local and three previously preserved public sources.

Each generation writes native_registry.json, gaps.json, optional public source artifacts, and completion_receipt.json LAST. The receipt binds the accepted-ID set, previous registry path/hash, public scope, code hash, source hashes and output hashes. Exact replay (including changed input order) validates and returns the same result without writing or fetching. A different request, changed source/output or incomplete existing directory is rejected; the caller must allocate a new version directory. Existing prior records and generations are not overwritten. Pass the returned registry as the explicit prior for the next batch; no mutable latest resolver is selected.

Verification: the missing-module baseline failed before implementation. Seven focused checks passed for Q11220,Q1637241,Q1999049,Q2906424,Q6981960 from prior registry17. Result: registry22, five completed IDs, no gaps, zero network requests; network calls were forbidden by the test. Reversed-input replay changed neither bytes nor mtimes; a different request was rejected; all prior17 records and source receipts stayed exact. A new Python process passed six independent checks, including network-forbidden replay, native names/whole records, source hashes and the explicit gap artifact.

Output: run_0001/native_registry.json.
SHA256: d1bf806fc74298958bfcb47e369d943ee3dbcf4cba9f2d658cc3b8efb2eec482.
Evidence: verification.json, independent_readback.json, run_0001/completion_receipt.json.

Limitations: one local writer, explicit output ownership, source-only registry, no power-loss/distributed transaction guarantee. The new bounded public branch reuses the previously executed request pattern but was not exercised by another network request in this increment; actual three-QID public evidence remains registry_addition_0002/public_missing_three. Source/decision/policy upgrades downstream still require matching refreshed relation receipts. No GPU, nested agents, consumer fields, shared-source edits or publication. Backup: Unprotected.
