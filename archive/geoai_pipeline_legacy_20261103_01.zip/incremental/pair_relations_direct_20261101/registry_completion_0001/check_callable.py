"""Real five-QID completion and exact read-only replay; all records already cached."""
import json
from pathlib import Path
from unittest.mock import patch
from registry_completion import complete_registry,sha

HERE=Path(__file__).resolve().parent
PAIR=HERE.parent
WANTED=['Q11220','Q1637241','Q1999049','Q2906424','Q6981960']
BASE=PAIR/'registry_addition_0001/native_registry_complete.json'
BASE_SHA='543ad1408de93e546430a9bf22b76bcc2492c2bce5dffa5e212402d523664d65'


def check():
    output=HERE/'run_0001'
    with patch('urllib.request.urlopen',side_effect=AssertionError('Unexpected network call for cached IDs')):
        first=complete_registry(WANTED,prior_registry=BASE,prior_sha256=BASE_SHA,output_dir=output,max_public_qids=0)
        assert first['completed_qids']==sorted(WANTED) and first['missing_qids']==[] and first['network_requests']==0
        registry=json.loads(Path(first['native_registry']['path']).read_text())
        assert len(registry['selected_references'])==22
        base=json.loads(BASE.read_text())
        assert {q:registry['selected_references'][q] for q in base['selected_references']}==base['selected_references']
        before={str(p):(sha(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
        second=complete_registry(list(reversed(WANTED)),prior_registry=BASE,prior_sha256=BASE_SHA,output_dir=output,max_public_qids=0)
        assert second==first
        assert before=={str(p):(sha(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
        try:
            complete_registry(WANTED[:-1],prior_registry=BASE,prior_sha256=BASE_SHA,output_dir=output,max_public_qids=0)
        except ValueError as error:
            assert 'request' in str(error).lower()
        else:
            raise AssertionError('Changed request overwrote existing generation')
    assert sha(BASE)==BASE_SHA
    assert all(sha(Path(row['path']))==row['sha256'] for row in first['source_receipts'])
    proof=dict(status='PASS_CALLABLE_REGISTRY_AND_READ_ONLY_REPLAY',checks=['five_actual_QIDs_complete','registry17_preserved_registry22',
        'zero_network_calls_enforced','input_order_independent_replay','all_output_hashes_mtimes_unchanged','changed_request_rejected','source_receipts_and_base_unchanged'],
        result=first,code_sha256=sha(HERE/'registry_completion.py'),test_sha256=sha(Path(__file__)))
    (HERE/'verification.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(status=proof['status'],checks=len(proof['checks']),native_registry=first['native_registry'],network_requests=first['network_requests'])))


if __name__=='__main__':
    check()
