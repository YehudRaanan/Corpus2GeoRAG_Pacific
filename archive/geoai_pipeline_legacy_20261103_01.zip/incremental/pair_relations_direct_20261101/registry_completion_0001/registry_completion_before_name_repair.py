"""Bounded native registry completion. Existing records/generations are never overwritten."""
import gzip,hashlib,json,re,sys,urllib.request,urllib.parse,urllib.error
from copy import deepcopy
from datetime import datetime,timezone
from pathlib import Path
import ijson
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PAIR=HERE.parent
MAIN=Path(r'D:\Projects\GeoAI')
sys.path.insert(0,str(MAIN))
from GG_Data.pipeline.entities import native_record,select_reference,choose_name


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def encoded(value):
    return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()


def complete_registry(accepted_qids,*,prior_registry,prior_sha256,output_dir,max_public_qids=0):
    """Complete only requested accepted IDs; at most one public request for up to five exact misses."""
    qids=sorted(set(accepted_qids))
    if any(not isinstance(q,str) or not re.fullmatch(r'Q[1-9][0-9]*',q) for q in qids):
        raise ValueError('Accepted identities must be exact QIDs')
    if type(max_public_qids) is not int or not 0<=max_public_qids<=5:
        raise ValueError('Public scope must explicitly allow zero to five QIDs per generation')
    prior_registry=Path(prior_registry).resolve()
    output=Path(output_dir).resolve()
    if not output.is_relative_to(PAIR.resolve()):raise ValueError('Output leaves pair-relations ownership')
    if sha(prior_registry)!=prior_sha256:raise ValueError('Prior registry hash differs')
    request=dict(qids=qids,prior_registry=str(prior_registry),prior_sha256=prior_sha256,max_public_qids=max_public_qids,
                 completion_code_sha256=sha(Path(__file__)))
    marker=output/'completion_receipt.json'
    if output.exists():
        if not marker.exists():raise ValueError('Incomplete generation exists; use a new output path')
        receipt=json.loads(marker.read_text())
        if receipt['request']!=request:raise ValueError('Changed request cannot overwrite a generation')
        if any(sha(output/name)!=value for name,value in receipt['artifact_sha256'].items()):raise ValueError('Completed output changed')
        if any(sha(Path(row['path']))!=row['sha256'] for row in receipt['result']['source_receipts']):raise ValueError('Completed source changed')
        return receipt['result']  # Exact replay reads only; no public request, write or timestamp change.
    original=json.loads(prior_registry.read_text())
    selected=deepcopy(original['selected_references'])
    needed=set(qids)-set(selected)
    available={q:[] for q in needed}
    sources={str(prior_registry):prior_sha256}
    def pin(path,expected=None):
        path=Path(path).resolve();value=sha(path)
        if expected is not None and value!=expected:raise ValueError('Cached source hash differs: '+str(path))
        sources[str(path)]=value
        return value
    # Reuse previously verified whole-record cache entries, never their identity decisions/types.
    for proof_path in sorted(PAIR.glob('registry_addition_*/complete_verification.json')):
        proof=json.loads(proof_path.read_text())
        expected=proof.get('artifact_sha256',{}).get('native_registry_complete.json')
        if not expected:continue
        cache=proof_path.with_name('native_registry_complete.json')
        pin(cache,expected);pin(proof_path)
        records=json.loads(cache.read_text())['selected_references']
        for q in needed & records.keys():
            item=records[q]
            native_record(item['envelope'],q)
            pin(item['provenance']['file'],item['provenance']['sha256'])
            available[q].append((item['envelope'],item['provenance']))
    unresolved={q for q in needed if not available[q]}
    if unresolved:
        meta=json.loads((PAIR/'real_pair_readiness_0001.json').read_text())
        query_meta={r['file']:r for r in meta['query_cache_provenance']}
        for path in sorted((MAIN/'GG_Data/pipeline/outputs/wikidata_full_cache').glob('*.json.gz')):
            value=pin(path)
            with gzip.open(path,'rb') as stream:
                for index,row in enumerate(ijson.items(stream,'rows.item')):
                    q=row['id']
                    if q not in unresolved:continue
                    envelope=dict(requested_qid=q,entity=json.loads(row['item'].rstrip(',\n\r ')))
                    native_record(envelope,q)
                    available[q].append((envelope,dict(provider='BIGQUERY',file=str(path),sha256=value,row_index=index,record_id=q,
                        snapshot_at=meta['table_snapshot_at'],retrieved_at=query_meta[str(path)]['retrieved_at'])))
        archive=MAIN/'Data/external/wwii_task_force/wikidata_entities.jsonl.gz'
        value=pin(archive)
        with gzip.open(archive,'rt',encoding='utf-8') as stream:
            for line,text in enumerate(stream,1):
                if not any(q in text for q in unresolved):continue
                envelope=json.loads(text);q=envelope['requested_qid']
                if q in unresolved:
                    native_record(envelope,q)
                    available[q].append((envelope,dict(provider='WIKIDATA',file=str(archive),sha256=value,line=line,record_id=q)))
    missing=[q for q in sorted(needed) if not available[q]]
    output.mkdir(parents=True)
    network_requests=0
    public=missing[:max_public_qids]
    if public:
        network_requests=1
        url='https://www.wikidata.org/w/api.php?'+urllib.parse.urlencode(dict(action='wbgetentities',ids='|'.join(public),format='json'))
        source_receipt=dict(requested_qids=public,source_url=url,requested_at=datetime.now(timezone.utc).isoformat(),requests_attempted=1)
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'GeoAI-local-source-registry/1.0 (exact entity read)'})
            with urllib.request.urlopen(req,timeout=30) as response:raw=response.read();source_receipt['http_status']=response.status
            (output/'public_response.json').write_bytes(raw)
            value=pin(output/'public_response.json');body=json.loads(raw)
            source_receipt.update(status='PUBLIC_RESPONSE_SAVED',raw_response_sha256=value,retrieved_at=datetime.now(timezone.utc).isoformat())
            for q in public:
                record=body.get('entities',{}).get(q,{})
                if record.get('id')!=q or 'missing' in record or 'claims' not in record:continue
                envelope=dict(requested_qid=q,entity=record);native_record(envelope,q)
                available[q].append((envelope,dict(provider='WIKIDATA',file=str(output/'public_response.json'),sha256=value,
                    source_url=url,retrieved_at=source_receipt['retrieved_at'],record_id=q,response_locator='entities.'+q)))
        except (urllib.error.URLError,TimeoutError,json.JSONDecodeError) as error:
            source_receipt.update(status='PUBLIC_READ_FAILED_NO_RETRY',error=str(error))
        (output/'public_source_receipt.json').write_bytes(encoded(source_receipt));pin(output/'public_source_receipt.json')
    gaps={}
    for q in sorted(needed):
        if not available[q]:gaps[q]='NO_COMPLETE_SAME_ID_SOURCE_WITHIN_DECLARED_SCOPE';continue
        pinned=[pair for pair in available[q] if pair[1]['provider']=='BIGQUERY']
        if pinned and not all(pair[0]==pinned[0][0] for pair in pinned):gaps[q]='CONFLICTING_PINNED_SNAPSHOT_RECORDS';continue
        envelope,provenance=select_reference(q,pinned[0] if pinned else None,available[q])
        selected[q]=dict(envelope=envelope,provenance=provenance,policy='SNAPSHOT_FIRST' if pinned else 'LATEST_AVAILABLE_COMPLETE_SAME_ID',
            entity_revision=envelope['entity'].get('lastrevid'),entity_modified=envelope['entity'].get('modified'),
            native_name_check=choose_name(q,envelope['entity'],{},[]))
    registry=dict(registry_kind='SOURCE_ONLY_NOT_ACTIVE_RELATIONS',base_registry=dict(path=str(prior_registry),sha256=prior_sha256),
        requested_accepted_qids=qids,selected_references=selected,missing_qids=gaps,native_producer_graph=deepcopy(original['native_producer_graph']))
    (output/'native_registry.json').write_bytes(encoded(registry))
    (output/'gaps.json').write_bytes(encoded(dict(gaps=gaps,missing_is_not_no_native_relation=True)))
    result=dict(status='COMPLETE' if not gaps else 'PARTIAL',completed_qids=[q for q in qids if q in selected],missing_qids=sorted(gaps),
        native_registry=dict(path=str(output/'native_registry.json'),sha256=sha(output/'native_registry.json')),network_requests=network_requests,
        source_receipts=[dict(path=path,sha256=value) for path,value in sorted(sources.items())],consumer_export=False)
    artifacts={p.name:sha(p) for p in output.iterdir() if p.is_file()}
    marker.write_bytes(encoded(dict(request=request,result=result,artifact_sha256=artifacts)))  # Last file acknowledges this generation.
    return result
