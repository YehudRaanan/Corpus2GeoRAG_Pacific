# Rendered-cache and complete mechanical overlay followup

## Applied mechanical overlay

`mechanical_78_20261101/mechanical_78_overlay.json` covers **all71 primary template_name and all7 primary protected_text rows**. Outcomes:71 known template-name syntax exclusions and7 exact nowiki literal recoveries. The seven recovered original surfaces are Samboja Seizure Unit, Lino, US Bureau of Standards, October1941, BY&D, Amphibious Force,1942. Evidence retains original9 fields, source_row_index, Source, page, containing revision, extraction_revision_id, raw hash/path, original passage offsets, exact raw offsets, template AST and proposed before/after. No original field/binding/eligibility changes. The base SHA256 was verified again before this full small-category pass. CPU1, measured RSS283.0MB,35.53s.

## Actual saved rendered payloads

`rendered_cache_probe_20261101/rendered_cache_probe.json` inventories1,914 saved request files in three named roots: history1590, historical pilot32, native wiki_parse292. There are1,038 successful parse payloads with parse.text;746 have both raw wikitext and HTML. Every payload was examined rather than trusting an html_evidence filename. All are legacy action=parse HTML;0 contain data-mw or mw:Transclusion markers. The known4881b0... receipt is included and contains page36625946/revision1380781167, raw SHA3e12964395df3d1ac227b0b301725bc6e70067c3342c37a193941fcff59763b9.

Exact join on **page + containing revision + raw SHA256** finds61 of33,827 unknown-template rows, across3 support keys on page1120226. None of the earlier76 sample rows, including KIA/navy/Campaignbox, has matching rendered HTML in these roots. Other local cache roots are outside this bounded inventory. Five real families were inspected from those61 matched rows; each case verifies request.oldid, parse.pageid/revid, payload wikitext hash, original Text unique placement and exact word span.

| Row | Verified revision | Raw AST family / original surface | Saved rendered evidence |
|---|---:|---|---|
| 900944 | 1371559406 | webarchive / 14 June 2007 | 1 candidate DOM components; no invocation provenance boundary |
| 901178 | 1371559406 | japanese nationalism sidebar / Japanese | 2 candidate DOM components; no invocation provenance boundary |
| 901678 | 1346427148 | failed verification / October 2020 | 1 candidate DOM components; no invocation provenance boundary |
| 901686 | 1346427148 | page range too broad / October 2020 | 1 candidate DOM components; no invocation provenance boundary |
| 901687 | 1346427148 | self-published inline / October 2020 | 1 candidate DOM components; no invocation provenance boundary |

For example, failed verification renders under `<sup class="noprint Inline-Template">`; October2020 occurs in a descendant title attribute, while the visible label is failed verification. Page range too broad and self-published inline have analogous noprint wrappers and date titles. The Japanese nationalism sidebar renders a `<table class="sidebar ..." role="navigation">`. These are actual structural nodes, saved with DOM paths/node hashes in `legacy_dom_facts.json`, not whole-page word-presence guesses. The webarchive case has an exact archive-URL anchor; that anchor alone does not identify an invocation boundary.

## FineWiki handler comparison and minimal safe approach

FineWiki comparison source: `src/2_extraction/run_extraction.py`, snapshot71306a3fed631b8c1a77e5479eb9edddc8866003; historical project pin remains unknown. `process_document`/Article consumes renderedHTML; `get_plaintext` excludes Navigation/noprint/Messagebox/Category/Media/Infobox body components, while `extract_infoboxes` records metadata. `custom_html_to_plaintext` and `_get_element_text` apply DOM traversal/hidden-element handling. `table_to_markdown` retains ordinary tables and its cell helper can fall back to ALT. Thus the saved noprint/navigation nodes have concrete FineWiki exclusion handlers; no coordinate-specific handler was found. None of these helpers supplies missing raw-template-to-DOM provenance.

The installed lxml parser is sufficient for structural inspection; no dependency was installed and mwparserfromhtml itself is absent. `rendered_template_probe.py:rendered_template_nodes` is a minimal evidence adapter: require an explicit mw:Transclusion + JSON data-mw boundary, exact AST template target and complete parameter key/value equality, reject duplicate parameter keys, return every matching node without first-match choice. It yields rendered-node evidence only and never invents raw character origins. Synthetic positive and wrong-family/wrong-value/duplicate/legacy negative cases pass5 checks after an observed RED. This adapter intentionally returns no invocation mapping for the inspected legacy payloads.

**No unknown-template rendering was applied.** Positive evidence is the actual cached same-revision HTML and identified noprint/navigation components; the genuine remaining gap is invocation identity, not missing HTML in general. The precise next step is a revision/raw-bound rendering payload that retains Parsoid data-mw/DSR transclusion metadata, or an existing saved per-invocation expansion receipt. With one of those, run the strict adapter and structural FineWiki handlers; preserve generated text as generated evidence rather than false exact raw origins. For current legacy payloads, a separately proved family-specific raw-AST rule could handle known maintenance date controls, but no such rule was silently introduced here. KIA/navy first require same-revision cache coverage and invocation identity. No network collection, renderer execution, model, framework copy or general manual queue was requested.

## Verification

Five rendered-boundary assertions pass; nine prior mechanics assertions pass. Overlay readback verifies78 unique source row IDs, complete71+7 category coverage, exact original word slices, unchanged eligibility and binding claims. Earlier original4-helper suite273passed; no source helper changed. A first exploratory multi-revision probe used a single raw payload and was discarded; final cases independently bind each row to its own verified revision/hash and assert the original word slice.

Artifact SHA256:
- `templates_media.py`: `f814022a5df1193e1efe6685e34756117c714cb0440e4baaf5143454a83d9627`
- `apply_template_protected_mechanics.py`: `21d2b3c345b2091d69fd985029bf2b0e40d2ca1476b44753738286e50d565015`
- `rendered_template_probe.py`: `847117427795d4cf4447a8688381ee27241bcc55fda0e287f9fc19a820b1a28b`
- `test_rendered_template_probe.py`: `553af1d822e35c7314902be436d575a13d46a716f27a9274aa82ab6a88897ca3`
- `mechanical_78_20261101\mechanical_78_overlay.json`: `528aa89d5e1c1b3022ef06f63ffebaadc88d9918a8d118b58cb22dc89004399c`
- `rendered_cache_probe_20261101\rendered_cache_probe.json`: `62b082078ef07118b30c071908907708c54c911201ff83c0c54d602a70c66fdc`
- `rendered_cache_probe_20261101\legacy_dom_facts.json`: `04e774e25a8a74c49355380015bce664ec5f0e397e85e1033fe21a5e91c83f1d`
