"""Development-only treatment evidence for every literal fragment placement."""
import sys
from pathlib import Path
from collections import Counter
from functools import lru_cache
import argparse
import gzip
import inspect
import json
import time

ROOT = Path(r"D:\Projects\GeoAI-incremental-dev-20261101")
sys.path.insert(0, str(ROOT / "review_cases"))
from classify_placements import classify_placements, digest, BASE, BASE_SHA, PILOT, BROAD
from GG_Data.entity_resolution.hundred_page_pilot.clean_source_text import clean_text, map_mention
from GG_Data.entity_resolution.hundred_page_pilot.collect_entities import validate_revision

cached_clean = lru_cache(maxsize=1)(clean_text)


def treatment(raw, passage, start, end):
    result = classify_placements(raw, passage, start, end)
    cleaned = cached_clean(raw)
    for alternative in result["alternatives"]:
        mapping = map_mention(cleaned, alternative["raw_start"], alternative["raw_end"])
        alternative["clean_mapping"] = mapping
        alternative["clean_surface"] = cleaned.text[mapping["start"]:mapping["end"]] if mapping["status"] == "mapped" else None
        alternative["raw_context"] = raw[max(0, alternative["raw_start"] - 100):alternative["raw_end"] + 100]
        alternative["clean_origins"] = cleaned.origins[mapping["start"]:mapping["end"]] if mapping["status"] == "mapped" else []
    outcomes = {(a["clean_mapping"]["status"], a["clean_surface"]) for a in result["alternatives"]}
    if not outcomes:
        verdict = "NO_LITERAL_SUPPORT"
    elif len(outcomes) > 1:
        verdict = "PLACEMENT_DEPENDENT_CLEANING"
    elif next(iter(outcomes))[0] == "excluded":
        verdict = "ALL_PLACEMENTS_REMOVED_BY_EXISTING_CLEANER"
    elif next(iter(outcomes))[0] == "mapped":
        verdict = "SAME_EXACT_SURFACE_AT_ALL_PLACEMENTS"
    else:
        verdict = "UNCERTAIN_CLEANING_RETAIN_RAW"
    return {**result, "treatment": verdict, "selected_raw_offset": None,
            "policy_basis": "clean_text syntax mechanics only; no _clean_page section/filter masks",
            "production_eligible": False}


def self_check():
    removed = treatment("{{cite book|last=Rottman}} {{cite book|last=Rottman}}", "Rottman", 0, 7)
    assert removed.get("treatment") == "ALL_PLACEMENTS_REMOVED_BY_EXISTING_CLEANER", removed
    assert len(removed["alternatives"]) == 2
    mapped = treatment("* [[Tokyo]]\n* [[Tokyo]]", "[[Tokyo]]", 2, 7)
    assert mapped["treatment"] == "SAME_EXACT_SURFACE_AT_ALL_PLACEMENTS", mapped
    assert [a["clean_surface"] for a in mapped["alternatives"]] == ["Tokyo", "Tokyo"]
    mixed = treatment("Tokyo <!-- Tokyo -->", "Tokyo", 0, 5)
    assert mixed["treatment"] == "PLACEMENT_DEPENDENT_CLEANING", mixed
    assert [a["clean_mapping"]["status"] for a in mixed["alternatives"]] == ["mapped", "excluded"]
    unknown = treatment("{{mystery|Tokyo}} {{mystery|Tokyo}}", "Tokyo", 0, 5)
    assert unknown["treatment"] == "UNCERTAIN_CLEANING_RETAIN_RAW", unknown
    overlap = treatment("aaaa", "aa", 0, 1)
    assert [a["passage_start"] for a in overlap["alternatives"]] == [0, 1, 2]
    assert treatment("Tokyo", "Osaka", 0, 5)["treatment"] == "NO_LITERAL_SUPPORT"
    print("PASS: six treatment cases; all alternatives retained; cite removal, exact mapping, mixed, unknown, overlapping, absent")


def sample():
    import pyarrow as pa
    import pyarrow.parquet as pq
    started = time.monotonic()
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    assert digest(BASE) == BASE_SHA
    seed_path = ROOT / "review_cases" / "placement_consensus_32.json"
    seeds = json.loads(seed_path.read_text(encoding="utf-8"))["results"]
    chosen = {r["source_row_index"]: r for r in seeds}
    seen_sources = {r["Source"] for r in seeds}
    fields = ["source_row_index", "occurrence_id", "Source", "page_id", "containing_support_revision_id",
              "source_revision_sha256", "attribution_status", "source_scope_status", "source_scope_reason",
              "processing_eligible", "clean_status", "Text", "word", "start", "end", "extraction_revision_id", "revision_id"]
    scanned = 0
    for batch in pq.ParquetFile(BASE).iter_batches(batch_size=2048, columns=fields, use_threads=False):
        for row in batch.to_pylist():
            scanned += 1
            if row["attribution_status"] == "CONTAINING_SUPPORT_NONUNIQUE_PASSAGE" and row["source_scope_status"] == "REVIEW" and row["Source"] not in seen_sources:
                seen_sources.add(row["Source"])
                chosen[row["source_row_index"]] = row
            if len(chosen) == 64 or scanned == 100000:
                break
        if len(chosen) == 64 or scanned == 100000:
            break
    registry_path = PILOT / "revisions.parquet"
    assert digest(registry_path) == "e12be0977b16175cf9a9cd1766ee26ae780f3da467e001e230795ac806008f60"
    assert digest(BROAD) == "b37da8892dd96094bb151b43d262d5ff0c42286a3e71f9980d9197e4b025fac5"
    registry = {(r["page_id"], r["revision_id"]): r for r in pq.read_table(registry_path).to_pylist()}
    with gzip.open(BROAD, "rt", encoding="utf-8") as stream:
        for row in json.load(stream):
            key = row["wiki_page_id"], row["revision_id"]
            registry.setdefault(key, dict(page_id=key[0], revision_id=key[1], wikitext_path=row["raw_path"],
                sha256=row["raw_sha256"], evidence_path=row["evidence"]))
    results, verified, raw_key, raw = [], {}, None, None
    for row in sorted(chosen.values(), key=lambda r: (r["page_id"], r["containing_support_revision_id"], r["source_row_index"])):
        assert time.monotonic() - started < 180, "Bounded microtask deadline"
        key = row["page_id"], row["containing_support_revision_id"]
        revision = registry[key]
        assert revision["sha256"] == row.get("source_revision_sha256", row.get("raw_sha256"))
        if key != raw_key:
            raw = validate_revision(revision)
            raw_key = key
            verified[str(key)] = {**revision, "evidence_sha256": digest(Path(revision["evidence_path"]))}
        passage = row.get("Text", row.get("passage"))
        start, end = row.get("start", row.get("original_start")), row.get("end", row.get("original_end"))
        assert passage[start:end] == row["word"]
        result = treatment(raw, passage, start, end)
        assert len(result["alternatives"]) > 1
        if "alternatives" in row:
            assert [(a["passage_start"], a["raw_start"], a["raw_end"]) for a in row["alternatives"]] == [(a["passage_start"], a["raw_start"], a["raw_end"]) for a in result["alternatives"]]
        results.append(dict(source_row_index=row["source_row_index"], occurrence_id=row["occurrence_id"], Source=row["Source"],
            page_id=key[0], processing_support_revision_id=key[1], extraction_revision_id=row["extraction_revision_id"],
            original_revision_id=row.get("revision_id", row.get("original_revision_id")), raw_sha256=revision["sha256"],
            original_scope_status=row.get("source_scope_status", row.get("original_scope_status")),
            original_scope_reason=row.get("source_scope_reason", row.get("original_scope_reason")),
            original_processing_eligible=row["processing_eligible"], original_clean_status=row["clean_status"],
            word=row["word"], passage=passage, original_start=start, original_end=end, **result))
    assert len(results) <= 64 and digest(BASE) == BASE_SHA
    report = dict(status="PASS", base_path=str(BASE), base_sha256_before_after=BASE_SHA,
        selection="32 prior biased rows plus first additional distinct Source keys within first100000 rows, maximum64; not representative",
        rows_scanned=scanned, rows=len(results), sources=len(seen_sources), alternatives=sum(len(r["alternatives"]) for r in results),
        counts=dict(Counter(r["treatment"] for r in results)), verified_raw_revisions=verified,
        reused_functions={f.__name__:dict(file=inspect.getsourcefile(f), line=inspect.getsourcelines(f)[1], sha256=digest(Path(inspect.getsourcefile(f)))) for f in (classify_placements, clean_text, map_mention, validate_revision)},
        no_original_values_or_eligibility_changed=True, no_offset_selected=True, no_identity_claims=True,
        no_corpus_count_projection=True, original_cleaner_origin="Local source-text-v3 adaptation; FineWiki-informed plan does not prove direct external cleaner execution",
        elapsed_seconds=round(time.monotonic()-started, 3), code_sha256=digest(Path(__file__)), backup_status="Unprotected", results=results)
    target = Path(__file__).parent / "fragment_treatment_64.json"
    with target.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
    print(json.dumps({k:v for k,v in report.items() if k not in {"results", "verified_raw_revisions", "reused_functions"}}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sample", action="store_true")
    args = parser.parse_args()
    self_check()
    if args.sample:
        sample()
