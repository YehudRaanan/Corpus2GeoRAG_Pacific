"""Fifteen unapplied policy rule groups over verified JSONL. No parsing or expansion."""
from pathlib import Path
from collections import Counter,defaultdict
from itertools import combinations
import json,hashlib
ROOT=Path(r'D:\Projects\GeoAI-incremental-dev-20261101\review_treatments')
SOURCE=ROOT/'unknown_component_inventory_20261101_v4'
NAMES={'sortname','Sortname','ill','Ill','navy','Navy','army','Army','naval','Naval','flagu','Flagu','KIA','WIA','MIA','POW','USCGC','HNLMS','MV','GS','STN'}
TEXT={'center','Center','cquote','Cquote','poemquote','Poemquote','bracket','Bracket','translation','Translation','langx','Langx','abbr','Abbr','quote','Quote'}
TABLES={'Officeholder table','member','Member','command structure','Aircraft specs','Weather box','succession box','Succession box','collapsible list','Collapsible list','indented plainlist','Indented plainlist','columns-list','flatlist','Flatlist','Tree chart','CFB Yearly Record Entry','CFB Yearly Record Subhead','unit awards table','Historical populations','ahnentafel','Airport-dest-list','NJint','jct','stack','Stack'}
NUMERIC={'dts','Dts','Date table sorting','birth date','Birth date','death date and age','Death date and age','ayd','Ayd','marriage','Marriage','Inflation','inflation','inflation/fn','inflation/year','convert','Convert','cvt','Cvt','circa','Circa','date','Date','NFL Year','start date','Start date','end date','End date','age','Age','bdl'}
NAV={'other ships','Other ships','About','about','for','For','Redirect','redirect','distinguish','Distinguish','Other uses','other uses','Japanese nationalism sidebar','Military unit sidebar','Main','main','See also','see also','further','Further'}
NAV_PREFIXES=('Campaignbox ','campaignbox ','Navbox','navbox','Sidebar','sidebar')
REFS={'notelist','Notelist','#tag:ref','efn-ua','Efn-ua','reflist','Reflist','refn','Refn','note','Note','notes','Notes'}
ARCHIVE={'Webarchive','webarchive','Deprecated archive','deprecated archive','usurped','Usurped','Citation','citation'}
MAINTENANCE={'failed verification','Failed verification','page range too broad','Page range too broad','self-published inline','Self-published inline','full citation needed','Full citation needed','dead link','Dead link','Synthesis','synthesis','As of?','as of?','refimprove','Refimprove','source?','Source?','not in source','Not in source','Use Australian English','use Australian English','use australian english','Use Philippine English','unreferenced','Unreferenced','More citations needed','more citations needed','More footnotes needed','more footnotes needed','page needed','Page needed','citation needed','Citation needed','clarification needed','Clarification needed','cn','CN'}
DECORATIVE={'shipboxflag','Shipboxflag','ICS','flagdeco','Flagdeco','flagicon','Flagicon','flagicon image','usn flag'}
CONTROLS={'nolink','sort','sortkey','sort key','officeholder_sort','officeholder sort','image','image_size','image size','image_width','image width','style','class','width','height','align','fontsize','padding','border','bgcolor','color','df','mf','abbr','format','bot','fix-attempted','wrap','ImageSize'}
GROUPS={
'01_display_names':('IN','Visible names, labels, unit/ship labels','Exact listed families and display/cross-display roles; no generated surface claimed'),
'02_body_text_quotes':('IN','Body text and quotations','Exact listed text/quote helpers; explicit metadata controls separated'),
'03_body_tables_lists':('IN','Body table/list values','Explicit body families; member name/nota and officeholder display fields retained'),
'04_date_numeric_display':('IN','Date, quantity and numeric display components','Component membership only; date operands/conversions still need supported rendering'),
'05_media_text':('IN','Caption, ALT and media description text','Actual media/gallery text roles or explicitly named caption/ALT/title/description fields'),
'06_nowiki_literal':('IN','Visible nowiki literal text','Literal source content; no nested markup parsing'),
'07_controls_syntax':('OUT','Sorting, image, format and known name syntax','Explicit control keys or primary template_name; unknown name-only templates are not blanket excluded'),
'08_navigation':('OUT','Navigation, hatnotes and disambiguation','Listed exact families and explicit case-sensitive prefix proposals; role=navigation representative evidence'),
'09_refs_notes':('OUT','Footnotes, references and reference children','Actual ref/reference ancestors, note sections, explicit ref slots and listed note families; OWNER APPROVAL PENDING'),
'10_archive_citation':('OUT','Archive and citation metadata','Listed archive/citation families or actual bibliographic section type'),
'11_maintenance':('OUT','Maintenance and noprint components','Listed exact maintenance aliases; representative saved noprint evidence'),
'12_decorative_media':('OUT','Decorative flags and media controls','Explicit decorative flag/code families; no fabricated country/display expansion'),
'13_coordinates':('OUT','Coordinate metadata','Separate owner choice; name label and numeric/control roles are retained in breakdown'),
'14_malformed':('HOLD','Malformed source constructs','Hold by parser-repair TYPE, not per-occurrence semantic review'),
'15_unsupported':('HOLD','Other unsupported structural family types','Exact families/roles retained outside active policy until one type decision or handler exists')}

def policy_group(s):
    # Only trim name-boundary whitespace. Never lowercase/casefold family names.
    name=s['name_exact'].strip();slot=s.get('mention_parameter_key','').strip();reason=s['primary_reason'];anc=s.get('ancestor_types',[]);section=s.get('section_type','')
    if any(a in {'Tag:ref','Tag:references','Tag:REF','Tag:References'} for a in anc) or slot in {'ref','refs','reference','references','citation'} or name in REFS or section=='notes':return '09_refs_notes'
    if section=='bibliographic' or name in ARCHIVE:return '10_archive_citation'
    if section=='related' or name in NAV or name.startswith(NAV_PREFIXES):return '08_navigation'
    if name in MAINTENANCE:return '11_maintenance'
    if reason=='unparsed_markup':return '14_malformed'
    if reason=='coordinates':return '13_coordinates'
    if reason=='template_name':return '07_controls_syntax'
    if reason=='protected_text' and name in {'nowiki','Nowiki','NOWIKI'}:return '06_nowiki_literal'
    if slot in CONTROLS or slot.startswith(('image1','image2','image3','image4','image5','filename')):return '07_controls_syntax'
    if name in {'ill','Ill'} and slot in {'2','3','4','5','lt2'}:return '07_controls_syntax'
    if name in {'langx','Langx'} and slot in {'1','label','link','italic','help'}:return '07_controls_syntax'
    if reason in {'media_review','gallery_review'}:return '05_media_text'
    if reason=='image_field_review':
        field=s.get('role_detail','')
        return '05_media_text' if 'alt' in field else '12_decorative_media'
    if slot.startswith(('caption','image_alt','image alt')) or slot in {'description','alt','footer','header'} and name.strip() in {'Listen','listen','multiple image'}:return '05_media_text'
    if name in DECORATIVE:return '12_decorative_media'
    if name in NAMES:return '01_display_names'
    if name in TEXT:return '02_body_text_quotes'
    if name in TABLES:return '03_body_tables_lists'
    if name in NUMERIC:return '04_date_numeric_display'
    return '15_unsupported'

def run(output):
    output=Path(output)
    if output.exists():raise FileExistsError(output)
    summary=json.loads((SOURCE/'grouped_summary_verified.json').read_text(encoding='utf8'))
    groups={k:{'group_id':k,'proposal':v[0],'label':v[1],'rule':v[2],'approved':False,'ner_rows':0,'physical_ids':set(),'fine_category_ids':set(),'exact_names':Counter(),'roles':Counter(),'examples':[]} for k,v in GROUPS.items()}
    seen_rows=set();physical_groups=defaultdict(set);role_counts=defaultdict(Counter);aliases=defaultdict(Counter)
    for line in (SOURCE/'component_instances.jsonl').open(encoding='utf8'):
        c=json.loads(line);s=c['signature'];key=policy_group(s);g=groups[key];pid=c['physical_component_id'];n=len(c['ner_occurrences'])
        g['ner_rows']+=n;g['physical_ids'].add(pid);g['fine_category_ids'].add(c['category_id']);g['exact_names'][s['name_exact']]+=n;g['roles'][s.get('mention_parameter_key','')]+=n;physical_groups[pid].add(key)
        aliases[s['name_exact'].strip()][s['name_exact']]+=n;role_counts[(s['name_exact'],s.get('mention_parameter_key',''))][key]+=n
        if len(g['examples'])<2 and all(e['physical_component_id']!=pid for e in g['examples']):g['examples'].append({k:c[k] for k in ['physical_component_id','page_id','containing_support_revision_id','raw_sha256','raw_start','raw_end','OriginalRawText']}|{'signature':s,'source_row_indices':[r['source_row_index'] for r in c['ner_occurrences']]})
        for row in c['ner_occurrences']:
            assert row['source_row_index'] not in seen_rows;seen_rows.add(row['source_row_index'])
    assert len(seen_rows)==36238 and sum(g['ner_rows'] for g in groups.values())==36238
    assert len(physical_groups)==20720
    overlap=Counter()
    for memberships in physical_groups.values():
        for pair in combinations(sorted(memberships),2):overlap[pair]+=1
    for g in groups.values():
        g['physical_components']=len(g.pop('physical_ids'));g['fine_category_ids']=sorted(g['fine_category_ids']);g['exact_names']=dict(g['exact_names']);g['roles']=dict(g['roles'])
    report={'scope':'NER-bearing36238 rows only; no all-page-child claim','source_base_sha256':summary['base_sha256'],'input_fine_categories':5819,'input_exact_family_entries':len(summary['families']),
        'policy_rule_groups':15,'normalization':{'family_names':'boundary whitespace trimmed for matching only; case preserved; all exact aliases recorded','parameter_names':'boundary whitespace trimmed; exact role lists; no generic first-parameter rule','policy_key':'15 structural rule selectors plus meaningful ref/notes/bibliographic context; fine keys remain unchanged','suppressed_from_policy_key':['raw attribute values and numeric style settings','generic ancestor chain length','content values and IDs','incidental value-node segmentation']},
        'ner_rows':len(seen_rows),'unique_physical_components':len(physical_groups),'physical_components_in_multiple_groups':sum(len(v)>1 for v in physical_groups.values()),
        'group_physical_count_sum':sum(g['physical_components'] for g in groups.values()),'physical_counts_additive':False,'ner_row_counts_additive':True,
        'overlap_pairs':[{'groups':list(k),'physical_components':v} for k,v in overlap.most_common()],
        'all_rules_require_owner_policy_approval':True,'policy_applied':False,'groups':list(groups.values()),
        'explicit_whitespace_aliases':[{'policy_match_name':k,'exact_name_rows':dict(v)} for k,v in aliases.items() if len(v)>1 or next(iter(v))!=k],
        'role_breakdowns':[{'name_exact':name,'parameter_role':slot,'group_row_counts':dict(counts)} for (name,slot),counts in sorted(role_counts.items())]}
    output.mkdir();(output/'policy_groups.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    lines=['# Owner decision packet:15 structural rules','',
'**All IN/OUT/HOLD rules are proposals. No policy was applied.** Scope is the36,238 NER-bearing rows already verified, including all33,827 unknown-template rows; not all page children. Fine5819 signatures and all raw evidence remain intact.','',
'Family matching trims leading/trailing whitespace only and preserves case. Exact aliases are listed in JSON; there is no automatic casefold merge. Explicit prefix selectors for navigation remain approval proposals. The policy view ignores numeric styles, raw attribute values, generic ancestor-chain length and content IDs; meaningful reference/notes/bibliographic context and parameter roles remain.','',
'| Proposed rule | Decision | Distinct NER rows | Physical components |','|---|---|---:|---:|']
    for g in groups.values():lines.append(f'| {g["label"]} | {g["proposal"]} | {g["ner_rows"]:,} | {g["physical_components"]:,} |')
    lines += ['',f'NER-row counts are disjoint and add to36,238. Physical counts are **not additive**: {report["physical_components_in_multiple_groups"]:,} source components contain roles assigned to multiple groups. The union is20,720 physical components; summing group component counts gives{report["group_physical_count_sum"]:,}. Pairwise overlaps are recorded in JSON.','',
'## Critical role splits','',
'| Exact family / role | Group row counts |','|---|---|']
    critical={'member','Officeholder table','sortname','Sortname'}
    for (name,slot),counts in sorted(role_counts.items()):
        if name.strip() in critical:lines.append(f'| `{json.dumps(name,ensure_ascii=False)}` / `{slot}` | {dict(counts)} |')
    lines += ['',
'Sortname first/last and cross-display occurrences share the display-name TYPE-IN proposal. This neither chooses a generic first parameter nor invents rendered expansion. member:name/nota are body values; member:ref and actual child-ref ancestors are reference TYPE-OUT. officeholder_sort/image are controls; officeholder/rank/term values are body-table TYPE-IN. Surface repair and dynamic rendering remain separate from component membership.','',
'## Two existing source examples per group','']
    for g in groups.values():
        lines += [f'**{g["label"]} — proposed {g["proposal"]}.** {g["rule"]}', '']
        for e in g['examples']:
            value=json.dumps(e['OriginalRawText'][:280],ensure_ascii=False)
            lines.append(f'- Rows {e["source_row_indices"][:5]}, page {e["page_id"]}, revision {e["containing_support_revision_id"]}, raw [{e["raw_start"]}:{e["raw_end"]}): `{value}`')
        lines.append('')
    lines += ['## Approval and remaining scope','',
'Owner approval is required for every policy choice before uniform application. The reference/footnote OUT rule is explicitly pending: it covers child references as a type rather than promoting or excluding individual prose passages. Coordinate metadata is a separate OUT proposal, with name-label/numeric slots retained in breakdown for a different owner choice. Remaining unsupported families stay outside active processing as identified types; no per-occurrence semantic manual queue is proposed.','',
'Exact known-template syntax and nowiki mechanics already have separate evidence overlays; this packet still does not change their final eligibility. No original source, base field, binding, consumer field, generated rendering or policy was changed. No source was reparsed; this packet reads only the verified JSONL and summary.','',
'Validation:8 policy-role assertions passed after observed RED; all36,238 NER IDs counted once; physical union matches20,720.']
    text='\n'.join(lines)+'\n'
    for a,b in {'packet:15':'packet: 15','the36,238':'the 36,238','all33,827':'all 33,827','Fine5819':'Fine 5819','to36,238':'to 36,238','is20,720':'is 20,720','gives'+str(report['group_physical_count_sum']):'gives '+str(report['group_physical_count_sum']),'Validation:8':'Validation: 8','all36,238':'all 36,238','matches20,720':'matches 20,720'}.items():text=text.replace(a,b)
    (output/'owner_decision_packet.md').write_text(text,encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k not in {'groups','role_breakdowns','explicit_whitespace_aliases','overlap_pairs'}},ensure_ascii=False))
    print(json.dumps([{k:g[k] for k in ['group_id','proposal','ner_rows','physical_components']} for g in groups.values()]))
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);run(p.parse_args().output)
