# Exact saved-raw recovery follow-up — 2026-11-01

Implemented `review_treatments/exact_saved_recovery.py`. Final evidence ledger is **`exact_saved_recovery_Q5368015_verified.json`**. This adds an actionable exact saved-revision support candidate for a known unsupported fragment branch, with all original values and processing bindings unchanged.

The function rejects a different original Source key or physical page before considering text. It then reuses `validate_revision` to require exact saved API page/revision/raw equality and raw SHA; `positions` supplies every literal full-Text placement. Only complete literal containment creates `EXACT_SAVED_RAW_SUPPORT_CANDIDATE`. A miss remains `STILL_UNSUPPORTED_IN_TESTED_SAVED_RAW`. No stripping, NFC, whitespace normalization or fuzzy fallback is used. It never selects a raw offset or applies a binding.

## Verified source proof

- Original Source **Q5368015** maps in both base and broad index to physical page **36625946**, title **ABCD Encirclement**.
- Existing broad cached revision is **1381878715**, raw `page_acquisition/raw/page-02940.txt`, SHA `2d5d96ae50ea44acc4c547031289709f4b5da422d1ef7b3cb22351c1bd43dd01`. Its saved API receipt also passed `validate_revision`.
- Alternative saved revision is **1380781167**, physically the same page, from `D:\Projects\GeoAI-source-page-ids-20261026\Data\external\source_page_versions_history_20261027\requests\4881b0c41d66e88df18dab8038f2d298e71583f6be84d59fd64c2d155da0708c.json.gz`.
- This receipt has HTTP 200 / `ok=true`; `action=parse`, `oldid=1380781167`, `prop=text|wikitext|revid`. Its `parse.wikitext` is a real raw string, with `parse.pageid=36625946`, `parse.revid=1380781167`, matching title. **The HTML `parse.text` field was never used as containment proof.** The preview's generic `html_evidence` label obscured the available wikitext.
- Receipt SHA is `00e6ef2f460de65e811168e8e42e6070ef3106edbb651f55b83600fdb92ad366`. Raw UTF-8 is **6,393 bytes / 6,344 Python characters**, SHA `3e12964395df3d1ac227b0b301725bc6e70067c3342c37a193941fcff59763b9`.
- `saved_raw_page36625946_rev1380781167.txt` is a byte-identical extraction into this task's isolated output directory. It is not a new source observation. Existing `raw_revision_rows` read the receipt, and existing `validate_revision` independently checked the extracted file against that same saved receipt.

## Actual outcomes

The bounded prefix contains **51** Q5368015 rows with `PASSAGE_NOT_IN_CACHED_REVISION`: independently checked **47 REVIEW + 4 EXCLUDE**. The recovery candidate ledger includes only the **47 REVIEW** rows. The four already excluded rows were not production candidates and were not treated.

| Candidate support result, first100000 rows only | Rows |
|---|---:|
| Full original Text occurs exactly once in saved alternative raw | 33 |
| Full original Text absent in saved alternative raw | 14 |

Every selected row's complete Text was independently absent from the current cached raw revision. All 33 positive rows have one full-passage match in the tested saved raw. Subsequent existing cleaner treatment gives **19 exact mapped surfaces and 14 all-removed citation spans**. Support recovery alone therefore does not imply clean-text eligibility.

Concrete before/after evidence, Python offsets end-exclusive:

| Original row / surface | Before | Candidate evidence |
|---|---|---|
| **91152** / `ABCD`, passage offsets17–21 | SourceQ5368015/page36625946; attribution `PASSAGE_NOT_IN_CACHED_REVISION`; REVIEW / `FRAGMENT_ONLY_NO_UNIQUE_REVISION_PLACEMENT`; original revision, containing-support revision and extraction revision all null | Revision1380781167 contains the **entire identical passage at raw74**. Mention raw91–95, `display_value`; cleaner maps to5–9, exact source coverage. |
| **91153** / `ABCD`, passage offsets38–42 | Same unchanged provenance/status fields; this is a distinct preserved occurrence, not deduplicated with91152 | Same full-passage hit74; distinct mention raw112–116; cleaner maps to23–27, exact source coverage. |
| **91241** / `United States`, passage offsets7–20 | Same Source/page and original unsupported REVIEW status | Full passage beginning `In the United States, reporting on the Japanese bombing of Chinese cities was particularly negative.` has **zero** exact hits in current cached1381878715 **and** saved alternative1380781167. It remains unsupported in these tested raws, with no clean offset or invented normalized placement. |

All original per-row fields, raw passage, word, original offsets, occurrence ID, source/status/eligibility, null extraction revision and prior binding values are retained under `original`. Candidate processing page/revision and evidence are separate fields. No original or sidecar binding was changed. No chronology-based search assumption is made.

## Reused original local implementation

- `prepare_pages.py:509`, `raw_revision_rows`: saved parse-wikitext/revision-content reader.
- `collect_entities.py:103`, `validate_revision`: raw SHA and saved API page/revision/body validation.
- `prepare_mentions.py:89`, `positions`: all overlapping literal placements.
- `fragment_recovery.py:21`, `treatment`: existing placement classifier plus full-page clean_text and origin-aware map_mention.

Automatically inspected source paths, line numbers and code hashes are in the verified ledger. FineWiki rendered-HTML extraction offers no raw-fragment occurrence recovery equivalent; this change deliberately applies the project's actual existing raw-revision helpers. No external model or renderer claim is made.

## Verification and limits

RED first failed on the stub with `AssertionError: {}`. GREEN passed real synthetic saved API/raw checks for correct-page literal matches, all duplicate hits retained, wrong page, wrong Source key, wrong revision, and nonidentical text. The actual47-row preview then passed API/raw/hash, source/page, original-word-slice, current-cache-absence and before/after base-SHA assertions. Fresh final rerun produced identical33/14 counts.

An initial integration attempt exposed that broad-index `source_title` is null for QID-keyed sources; inspected data showed `title=ABCD Encirclement`. The guard now explicitly compares the broad API `title` with saved API `wiki_title`, preserving the null original source_title. The first successful ledger's two hand-entered helper line references were corrected by generating a separate verified ledger with automatic source inspection; the earlier ledger remains preserved and is superseded for source references.

No network, source calls, models, paid services, installation, Git, base mutation, eligibility change or production batch occurred. Base SHA before and after remains `68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d`. No full-repository suite was run for this bounded stage; the earlier unchanged cleaner's88 tests passed. There is no inference about the other unsupported sources or all59,455 unsupported REVIEW rows. The14 misses are negative only for these tested saved raws. Original extraction revision remains unknown and does not veto a verified processing-support candidate.

Script SHA: `decf8e58cfe5ab71be275c88fba20ec6263408d9f143fd89b3d5d593ef263dec`. Outputs are local **Unprotected**. No denied or pending action remains.
