"""Apply already-tested mechanical proposals to all71 template-name +7 protected rows.
Separate evidence overlay only. Never writes base fields or eligibility.
"""
from pathlib import Path
import json,gzip,hashlib,time
from collections import Counter
from functools import lru_cache
import pyarrow as pa
import pyarrow.parquet as pq
import psutil
from templates_media import BASE,BASE_HASH,PROJECT,treat_span,positions

def run(output):
    started=time.monotonic();pa.set_cpu_count(1);pa.set_io_thread_count(1)
    output=Path(output)
    if output.exists():raise FileExistsError(output)
    with BASE.open('rb') as stream:
        if hashlib.file_digest(stream,'sha256').hexdigest()!=BASE_HASH:raise ValueError('Base changed')
    f=pq.ParquetFile(BASE);rows=[]
    columns=['source_row_index','entity_group','score','word','start','end','Source','Index','Text','subtype',
        'page_id','containing_support_revision_id','extraction_revision_id','attribution_status','source_revision_sha256','source_scope_reason']
    for batch in f.iter_batches(batch_size=4096,columns=columns,use_threads=False):
        for row in batch.to_pylist():
            if row['source_scope_reason'] in {'template_name','protected_text'}:rows.append(row)
    assert Counter(r['source_scope_reason'] for r in rows)=={'template_name':71,'protected_text':7}
    revisions={(r['page_id'],r['revision_id']):r for r in pq.read_table(PROJECT/'Data/external/hundred_page_pilot_20261028/revisions.parquet').to_pylist()}
    index=Path(r'D:\Projects\GeoAI-simplified-agent-20261030\Data\external\simplified_agent_20261030\page_acquisition\page_sources.json.gz')
    with gzip.open(index,'rt',encoding='utf8') as stream:
        for r in json.load(stream):
            revisions.setdefault((r['wiki_page_id'],r['revision_id']),{'wikitext_path':r['raw_path'],'sha256':r['raw_sha256']})
    @lru_cache(maxsize=2)
    def raw_revision(key):
        rev=revisions[key];data=Path(rev['wikitext_path']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==rev['sha256']
        return data.decode('utf8'),rev
    cases=[]
    for row in rows:
        key=(row['page_id'],row['containing_support_revision_id'])
        raw,rev=raw_revision(key)
        assert rev['sha256']==row['source_revision_sha256']
        places=positions(raw,row['Text']); assert len(places)==1
        a,b=places[0]+row['start'],places[0]+row['end'];assert raw[a:b]==row['word']
        proposal=treat_span(raw,a,b)
        cases.append({'original_evidence':row,'passage_raw_start':places[0],'raw_path':rev['wikitext_path'],
            'proposal':proposal})
    assert len({c['original_evidence']['source_row_index'] for c in cases})==78
    report={'base_path':str(BASE),'base_sha256':BASE_HASH,'base_rows':f.metadata.num_rows,'complete_primary_categories':{'template_name':71,'protected_text':7},
        'outcomes':dict(Counter(c['proposal']['treatment'] for c in cases)),
        'outcomes_by_category':{k:dict(Counter(c['proposal']['treatment'] for c in cases if c['original_evidence']['source_scope_reason']==k)) for k in ['template_name','protected_text']},
        'eligibility_changed':False,'original_fields_changed':False,'containing_support_relabelled_as_extraction':False,
        'limitations':'Mechanical development proposals only; unresolved unknown templates are outside these complete primary categories.',
        'elapsed_seconds':time.monotonic()-started,'rss_mb':psutil.Process().memory_info().rss/1048576,'cases':cases}
    output.mkdir()
    (output/'mechanical_78_overlay.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'}))
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path);run(p.parse_args().output)
