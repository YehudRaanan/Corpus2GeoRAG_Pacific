# Fragment treatment microtask — 2026-11-01

Implemented `D:\Projects\GeoAI-incremental-dev-20261101\review_treatments\fragment_recovery.py`. Its development ledger `fragment_treatment_64.json` applies the existing origin-aware cleaner to **every** literal placement, rather than requiring an arbitrary unique placement before examining cleaning behavior. No mention, original value, scope, eligibility, processing binding, identity, or source was changed.

## Concrete rules and reuse

1. Reuse `review_cases/classify_placements.py:27` to enumerate all overlapping literal passage placements and classify each component. No second parser or first-hit fallback was added.
2. Reuse `clean_source_text.py:78` (`clean_text`, policy source-text-v3) on the verified complete raw page. This uses full parser context. It does **not** call `_clean_page` or add section/filter masks. Existing parser mechanics remove citation/control templates, reference tags, comments and syntax; supported displayed values retain exact origins; unknown constructs retain a review overlap.
3. Reuse `clean_source_text.py:365` (`map_mention`) at each alternative raw mention span. This distinguishes complete exact source coverage, removal, partial removal, and uncertainty. The ledger records every raw/clean span, mapped surface, per-character origins, component classification and local raw context.
4. All removed → `ALL_PLACEMENTS_REMOVED_BY_EXISTING_CLEANER`; all mapped to the same surface → `SAME_EXACT_SURFACE_AT_ALL_PLACEMENTS`; different outcomes → `PLACEMENT_DEPENDENT_CLEANING`; one unanimous uncertain outcome → `UNCERTAIN_CLEANING_RETAIN_RAW`. No match → `NO_LITERAL_SUPPORT`.

These are usable derived treatment facts. They do not prove which placement generated an occurrence or establish owner approval for a production citation/reference exclusion policy. A surface common to all placements can be retained as a candidate clean value with **all** origin alternatives, while unique clean offsets remain unset. An all-removed result can prevent fallback reintroduction in an experimental cleaned view while the raw occurrence remains intact. Neither permits automatic scope/eligibility promotion.

The accepted local plan `D:\Projects\GeoAI-luke-pilot-20261028\docs\superpowers\plans\2026-10-29-source-preserving-text-cleaner.md` describes this as a small local cleaner informed by reviewed extraction rules and explicitly says not to copy the full FineWiki framework. Provenance worker identified FineWiki → mwparserfromHTML → Wikimedia Enterprise HTML as the external reference chain. The executable local implementation uses **mwparserfromhell 0.7.2 and raw wikitext**. This run reuses the actual local adaptation; it does not claim to execute FineWiki or prove HTML/wikitext equivalence. The historical external code pin remains unknown.

## Actual bounded run

Selection preserved all 32 earlier biased sample rows, then added the first row from each additional distinct original Source key encountered in a bounded prefix scan. Stopped at **64 rows after scanning 44,263**. This is a deliberate diversity extension, not a representative sample or population estimate.

| Verified sample result | Rows |
|---|---:|
| Removed at every placement by existing cleaner | 33 |
| Same exact clean surface at every placement | 28 |
| Uncertain at every placement | 3 |
| Placement-dependent cleaner result | 0 |

All **154 alternatives**, **64 occurrence IDs**, and **35 original Source keys / physical page-revision pairs** survive. Five rows have mixed **component** classifications (infobox versus article text) yet the same exact clean surface at every placement; those disagreements also survive.

Real before/after evidence (Python character offsets, end-exclusive):

| Row | Original surface and verified page/revision | All relevant outcomes |
|---|---|---|
| 647 | `Rottman`; 64096955 / 1372397745; passage ` |last=Rottman ` at 7429 and 7602 | Raw mention 7436–7443 and 7609–7616 both citation; both `source_span_removed`; no clean offsets. |
| 4802 | `Korean War`; 559609 / 1345020428; `[[Korean War]]` | Raw 919–929 in infobox → clean 366–376; raw 11350–11360 in article text → clean 6987–6997. Same exact surface, component disagreement retained. |
| 41054 | `Year`; 441881 / 1382518394; `! Year` | Raw 64166–64170 → clean 38850–38854; raw 65346–65350 → clean 39277–39281. Both exact source coverage; separate table contexts retained. |
| 21549 | `3rd Fleet \|\| 1st CarDiv`; 29607850 / 1323366204 | Raw 2488–2511 and 2745–2768 both classify as article-table KEEP, but both have `partial_source_removal`. Clean offsets remain null. A classifier consensus alone would miss this obstruction. |
| 16166 | `Commander-in-Chief`; 7815422 / 1374292211 | Raw 19375–19393 and 24710–24728 overlap unknown Officeholder-table templates. Both retain `source_review_overlap`; no invented display rule. |
| 38490 | `Col`; 13316586 / 1335230951; `{{Col-begin}}` | Three placements, all unknown-template review. No generic unknown-template deletion. |

Five mixed-component rows are 4802, 8102, 8692, 9403 and 12802. The 33 removed sampled rows all have citation classification. The three uncertain cases comprise two unknown-template rows and the table-boundary row above. No mixed removed/mapped real case appeared in this sample; that path is exercised by the tiny check.

## Source and input evidence

The original `validate_revision` function (`collect_entities.py:103`) independently hashes each raw file and parses its saved API receipt, requiring the same physical page ID, revision ID and exact wikitext body. All 35 sampled pairs passed. Every registry/raw/receipt path and raw/receipt SHA is recorded in the ledger. Saved HTML was not substituted for raw wikitext.

Row647 raw file is broad-cache `page_acquisition/raw/page-05600.txt`, SHA `3a8e5b4d75404b31d84a21bfa11a3968b152b26e8e1cce09db28426e1c90d182`; receipt `5820d1a7685461dd8cf6d2ff2bb26ccd6ebf2ff18abcde92d45c01bba769e511.json.gz`, SHA `53a34e0402972a8c99a1c27af6a8d3204470f332485df49dc782486a6a3c1b4d`.

Base Parquet SHA verified before and after: `68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d`. Frozen registry and broad index hashes also matched their supplied pins. Retrieved/processing-support revision and original extraction revision remain separate; an unknown extraction revision was not used as a veto on verified processing support.

## Verification and limits

- RED: a stub treatment returned `{}` and the first real assertion failed with `AssertionError: {}`.
- GREEN: six tiny real-parser cases passed: citations, exact displayed links, mixed visible/comment placements, unknown templates, overlapping hits, and no literal support.
- Actual sample completed in 5.313 seconds with all assertions passing, one Arrow CPU/I/O thread, one OMP thread and one-page cleaner cache. All prior32 placement triples were asserted identical.
- Existing cleaner tests: `python -m pytest .../test_clean_source_text.py -q -p no:cacheprovider --basetemp <task-specific Temp path>`: **88 passed in 3.63s**, exit 0. A `pyreadline3` console-destructor `OSError` printed during interpreter shutdown; no test failed. Full repository suite was not run in this bounded microtask.
- No corpus counts are inferred from this sample. It demonstrates 64 concrete nonunique REVIEW treatments among the supplied 24,559 nonunique population; it does not resolve or audit the remaining population.
- The supplied 59,455 unsupported REVIEW rows and 14,215 unsupported EXCLUDE rows were not evaluated by this implementation. No NFC/whitespace equivalence, reversibility, historical raw recovery, or new source observation is claimed.
- Genuine unresolved choice: authorizing a production source-component policy remains separate from proving how the existing cleaner behaves. Exact source placement still cannot be chosen for these rows. Unknown templates and partial table spans need a grounded display/span rule before clean offsets are safe.
- No network, model, install, Git, original source/data mutation, production batch or consumer-contract change. MAIN Git inspection was not retried. Outputs are local only: **Unprotected**.

Script SHA: `afcf6f32775add4f2c901348e2242418ee737c8172df344887eaf8338369ae02`.
Ledger SHA: `d58f18b1808fbe1d84297efa3df95fd57ac506a76fc233bb547899efc1078f16`.
