from build_component_policy_packet import policy_group

def s(name,slot='',ancestors=None,reason='unknown_template'):
 return {'name_exact':name,'mention_parameter_key':slot,'ancestor_types':ancestors or [],'primary_reason':reason}
assert policy_group(s('member','nota'))=='03_body_tables_lists'
assert policy_group(s('member','ref'))=='09_refs_notes'
assert policy_group(s('Officeholder table\n','officeholder_sort'))=='07_controls_syntax'
assert policy_group(s('Officeholder table\n','officeholder'))=='03_body_tables_lists'
assert policy_group(s('sortname','@cross_boundary'))=='01_display_names'
assert policy_group(s('center','1',['Tag:ref']))=='09_refs_notes'
assert policy_group(s('KIA','@template_name'))=='01_display_names'
assert policy_group(s('Unknown FAMILY','@template_name'))=='15_unsupported'
print('8 policy-role checks passed')
