# Unidentified component TYPE inventory

Final outputs are in `unknown_component_inventory_20261101_v4/`. `grouped_summary_verified.json` is the definitive summary; earlier runs are retained development evidence. **IN, OUT and HOLD below are proposals only. No source policy or eligibility change was applied.**

Coverage: all **33,827 unknown_template NER rows**, plus media_review 334, gallery_review 95, image_field_review 238, unparsed_markup 35, coordinates 1,631, template_name 71 and protected_text 7: **36,238 rows**. Parsed 4,426 supporting page/revisions. This covers NER-bearing unresolved components in these eight base categories, **not all child components of all 5,725 cached revisions**.

Counts: **20,720 distinct physical source components**, **5,819 exact structural categories**, and **26,278 component/category assignments**. A component with NER in multiple parameter slots has several category assignments but counts once physically. Family component totals use distinct physical spans. Full run 184.92s, measured RSS 368.6MB, CPU 1.

## Rules for one owner decision per TYPE

Categories preserve exact case-sensitive template name, ordered parameter-key/node-kind shape, duplicate keys, the actual NER-bearing parameter slot, evidenced ancestor node types, and top-level section type. Actual raw tag attributes are retained where present. No HTML/DOM classes were invented for raw wikitext. Names such as `Webarchive`/`webarchive`, `Coord`/`coord`, and `Death date and age`/`death date and age` remain separate categories. No name-prefix merges were applied.

Proposed IN: body display/name fields, body tables/lists, date/numeric display components, caption text, and exact nowiki literal text. Proposed OUT: explicit sorting/image/style controls, navigation/hatnotes, decorative flag/code components, maintenance metadata and archive/citation support components. HOLD is a category decision, never a per-row manual queue: reference/note prose policy, malformed-source reconstruction, coordinate-control policy, and exact unsupported display families remain identified types. IN means retain the component for treatment; it does not prove an exact rendered NER surface or authorize a production promotion.

Unknown-template proposal row counts: `{'HOLD': 18331, 'IN': 7949, 'OUT': 7547}`. All eight category proposal row counts: `{'HOLD': 20021, 'IN': 8435, 'OUT': 7782}`.

## Major exact families

These are family summaries for reading; uniform decisions use the finer parameter-slot signatures in the verified JSON. A family may have IN display fields and OUT control fields.

| Exact family name | NER rows | Physical components | Largest NER-bearing parameter slots |
|---|---:|---:|---|
| `"sortname"` | 2078 | 1419 | @cross_boundary:1595, 4:220, 1:134, 3:89 |
| `"Officeholder table\n"` | 1120 | 222 | image:228, term_end:219, term_start:207, officeholder:174 |
| `"other ships"` | 1060 | 764 | 1:1016, 2:27, @cross_boundary:11, 3:4 |
| `"shipboxflag"` | 897 | 870 | 1:870, 2:25, @cross_boundary:2 |
| `"notelist"` | 863 | 9 | refs:863 |
| `"ICS"` | 775 | 775 | 1:775 |
| `"dts"` | 757 | 736 | 1:746, @cross_boundary:11 |
| `"Webarchive"` | 731 | 720 | date:731 |
| `"flagdeco"` | 701 | 476 | 1:535, 2:164, @cross_boundary:2 |
| `"member"` | 694 | 58 | nota:445, ref:190, name:59 |
| `"#tag:ref"` | 617 | 179 | 1:617 |
| `"Death date and age"` | 573 | 314 | @cross_boundary:247, 4:189, 1:136, 2:1 |
| `"usurped"` | 570 | 223 | 1:570 |
| `"death date and age"` | 516 | 286 | @cross_boundary:229, 4:171, 1:116 |
| `"center"` | 473 | 189 | 1:473 |
| `"Aircraft specs\n"` | 469 | 42 | ref:117, eng1 name:92, guns:83, crew:36 |
| `"ill"` | 428 | 239 | 1:204, 3:101, @cross_boundary:81, lt:40 |
| `"ayd"` | 402 | 202 | @cross_boundary:155, 1:120, 2:109, 4:18 |
| `"Weather box\n"` | 384 | 17 | location:51, source 1:21, Jul high C:9, Aug low C:8 |
| `"navy"` | 377 | 327 | 1:331, 2:45, @cross_boundary:1 |
| `"command structure\n"` | 372 | 16 | subordinate:317, name:22, parent:17, date:16 |
| `"birth date"` | 372 | 335 | @cross_boundary:264, 1:108 |
| `"marriage"` | 312 | 111 | 1:113, 2:99, 3:52, @cross_boundary:48 |
| `"Other ships"` | 303 | 219 | 1:292, 2:8, @cross_boundary:3 |
| `"succession box\n"` | 276 | 46 | title:98, years:90, before:44, after:44 |
| `"Birth date"` | 265 | 241 | @cross_boundary:191, 1:74 |
| `"webarchive"` | 263 | 260 | date:263 |
| `"About"` | 262 | 79 | 3:93, 1:66, 2:51, 5:17 |
| `"collapsible list"` | 255 | 20 | 1:167, 2:22, 6:15, title:11 |
| `"indented plainlist"` | 248 | 39 | 1:248 |

## Two real source examples for each major family

Full untruncated OriginalRawText and every original occurrence remain in JSONL; examples below are excerpts.

**"sortname"** — 2078 NER rows / 1419 components.
- Rows [1051645], page64217056, revision1377613794, raw[3870:3905): `"{{sortname|Gordon|Abbott|nolink=1}}"`
- Rows [1051651], page64217056, revision1377613794, raw[4016:4055): `"{{sortname|William E.|Abbott|nolink=1}}"`

**"Officeholder table\n"** — 1120 NER rows / 222 components.
- Rows [16167], page7815422, revision1374292211, raw[19472:19860): `"{{Officeholder table\n| order             = 1\n| image             = Chuichi Nagumo.jpg\n| military_rank     = Vice Admiral\n| officeholder      = [[Chūichi Nagumo]]<br>南雲 忠一\n| officeholder_sort = Nagumo, Chūichi\n| born_year         = 1887\n| died_year         = 19"`
- Rows [16182], page7815422, revision1374292211, raw[20130:20524): `"{{Officeholder table\n| order             = 1\n| image             = RyunosukeKusaka.jpg\n| military_rank     = Rear Admiral\n| officeholder      = [[Ryūnosuke Kusaka]]<br>草鹿 龍之介\n| officeholder_sort = Kusaka, Ryūnosuke\n| born_year         = 1893\n| died_year       "`

**"other ships"** — 1060 NER rows / 764 components.
- Rows [523939, 523940], page464776, revision1378506333, raw[40:77): `"{{other ships|French ship Richelieu}}"`
- Rows [525182, 525183], page4346944, revision1379690872, raw[63:107): `"{{other ships|French ship La Motte-Picquet}}"`

**"shipboxflag"** — 897 NER rows / 870 components.
- Rows [91309], page1995922, revision1381972978, raw[687:723): `"{{shipboxflag|United Kingdom|civil}}"`
- Rows [91310], page1995922, revision1381972978, raw[724:760): `"{{shipboxflag|United Kingdom|naval}}"`

**"notelist"** — 863 NER rows / 9 components.
- Rows [478322], page46947588, revision1380921892, raw[67287:67431): `"{{notelist|refs=\n{{efn|name=LongBow|Long-bow units}}\n{{efn|name=CompMod|Completed to modified design}}\n{{efn|name=NeverComp|Never completed}}\n}}"`
- Rows [678942, 678943], page264714, revision1379465394, raw[109683:109913): `"{{notelist|refs=\n{{efn|name=Kentucky|''Kentucky'' was not officially launched; her hull was moved from drydock to allow ''Missouri'' to be admitted for repairs following her [[1950 USS Missouri grounding incident|grounding]].}}\n}}"`

**"ICS"** — 775 NER rows / 775 components.
- Rows [180362], page27029528, revision1350166934, raw[923:938): `"{{ICS|Uniform}}"`
- Rows [566966], page32696455, revision1376079714, raw[1733:1747): `"{{ICS|Juliet}}"`

**"dts"** — 757 NER rows / 736 components.
- Rows [471236], page209561, revision1365263491, raw[29650:29671): `"{{dts|14 April 1948}}"`
- Rows [471237], page209561, revision1365263491, raw[29674:29693): `"{{dts|14 May 1948}}"`

**"Webarchive"** — 731 NER rows / 720 components.
- Rows [2094], page441912, revision1382391173, raw[58730:58888): `"{{Webarchive|url=https://web.archive.org/web/20110217111354/http://www.ausa.org/SiteCollectionDocuments/ILW%20Web-ExclusivePubs/LWP_60.pdf |date=2011-02-17 }}"`
- Rows [2432], page441912, revision1382391173, raw[77418:77535): `"{{Webarchive|url=https://web.archive.org/web/20220612041029/https://www.jber.jb.mil/Units/Army/ |date=12 June 2022 }}"`

**"flagdeco"** — 701 NER rows / 476 components.
- Rows [62361], page82697574, revision1379800072, raw[330:358): `"{{flagdeco|Empire of Japan}}"`
- Rows [62364], page82697574, revision1379800072, raw[390:423): `"{{flagdeco|Empire of Japan|army}}"`

**"member"** — 694 NER rows / 58 components.
- Rows [1039977], page39108288, revision1372746312, raw[764:1300): `"{{member|name=Bernard L. Anderson|nota=US Army Air Corps Major. Formed Kalayaan Command in [[Quezon|Tayabas Province]] that focused on intel work. Linked up with [[Alejo Santos]] in the Bulacan Military Area north of Manila.<ref name=Lapham/>{{rp|26}} Colonel "`
- Rows [1039994, 1039995, 1039996, 1039997, 1039998, 1039999], page39108288, revision1372746312, raw[1301:1796): `"{{member|name=Robert Arnold|nota=Commanded military and guerrillas of the 15th Infantry Regiment, Philippine Army which operated in [[Ilocos Norte]].<ref name=\"Harkins, P. 1956\"/>{{rp|222–224}}  His thirty American soldiers joined forces with Walter Cushing's "`

**"#tag:ref"** — 617 NER rows / 179 components.
- Rows [133], page48975579, revision1375061414, raw[6662:6774): `"{{#tag:ref|[[Sentai]]s were air groups with several flying squadrons.{{sfn|Takai|Sakaida|2001|p=6}}|group=Note}}"`
- Rows [5193, 5194], page25813188, revision1320553478, raw[609:922): `"{{#tag:ref|At the start of the war, the normal size of an Australian infantry battalion was 910 men all ranks, however, following the reorganisation of the 5th Division along the [[Jungle division|jungle establishment]], the size dropped to 803 men all ranks.<"`

**"Death date and age"** — 573 NER rows / 314 components.
- Rows [94044], page4087942, revision1379846503, raw[411:453): `"{{Death date and age|1961|2|28|1890|3|26}}"`
- Rows [112781], page3088677, revision1381748554, raw[265:316): `"{{Death date and age|1948|12|23|1892|12|15|df=yes}}"`

**"usurped"** — 570 NER rows / 223 components.
- Rows [86880], page45431391, revision1376502371, raw[313:439): `"{{usurped|1=[https://web.archive.org/web/20160316130914/http://www.ijnsubsite.info/Subrons/subron8.htm Submarine Squadron 8]}}"`
- Rows [187054], page10329642, revision1324432499, raw[6189:6446): `"{{usurped|1=[https://web.archive.org/web/20070928084426/http://forum.rleeermey.net/viewtopic.php?t=4063&view=next&sid=0bae3a5d6dae2de71cdc7391b980fc57 R. Lee Ermeys MAIL CALL Forum • View topic - Surrender Flight [ Guest &#93;<!-- Bot generated title -->]}}"`

**"death date and age"** — 516 NER rows / 286 components.
- Rows [94323], page1307385, revision1381257210, raw[2312:2361): `"{{death date and age|2000|09|06|1918|12|03|df=y}}"`
- Rows [98264], page67902496, revision1380335659, raw[665:709): `"{{death date and age|2021|06|06|1926|04|04}}"`

**"center"** — 473 NER rows / 189 components.
- Rows [16431], page7815422, revision1374292211, raw[28363:28424): `"{{center|'''Some of the commanders of the ''Kidō Butai'''''}}"`
- Rows [65334], page4567536, revision1382177468, raw[25761:25873): `"{{center|<small>* These airplane commanders and crews exchanged aircraft assignments on 9 August 1945 </small>}}"`

**"Aircraft specs\n"** — 469 NER rows / 42 components.
- Rows [103712, 103713, 103714, 103715, 103716], page514297, revision1376262123, raw[12056:14374): `"{{Aircraft specs\n|ref= ''Aircraft of World War II - 300 of the World's Greatest aircraft 1939–45,''<ref name=\"chant-15\"/> ''Aichi B7A Ryusei (Shooting Star),''<ref name=\"combinedfleet\"/> and ''Japanese Aircraft of the Pacific War''<ref name=\"Francillon1979p291"`
- Rows [103976, 103977, 103978, 103981, 103982], page1791766, revision1369063874, raw[9081:11128): `"{{Aircraft specs\n|ref= ''Japanese Aircraft of the Pacific War''<ref name=\"Francillon1979p26871\">{{Harvnb|Francillon|1979|pp=268–271.}}</ref> ''Aircraft of World War II - 300 of the World's Greatest aircraft 1939-45''<ref name=\"chant-17\"/>\n|prime units?= met\n<!"`

**"ill"** — 428 NER rows / 239 components.
- Rows [5472], page84259370, revision1379522402, raw[1073:1113): `"{{ill|Yutaka Morioka|it|Yutaka Morioka}}"`
- Rows [16361, 16362], page7815422, revision1374292211, raw[25358:25388): `"{{ill|Kinpei Teraoka|ja|寺岡謹平}}"`

**"ayd"** — 402 NER rows / 202 components.
- Rows [16378], page7815422, revision1374292211, raw[25989:26018): `"{{ayd|1944|10|20|1945|05|10}}"`
- Rows [390278, 390279], page165200, revision1368811430, raw[7397:7426): `"{{ayd|1894|07|18|1895|05|11}}"`

**"Weather box\n"** — 384 NER rows / 17 components.
- Rows [175590, 175591, 175592], page226214, revision1378466600, raw[31139:35712): `"{{Weather box\n|location = Attu (1961–1990 normals, extremes 1917–1993)\n|single line = Y\n|collapsed = yes\n|Jan record high F = 49\n|Feb record high F = 51\n|Mar record high F = 51\n|Apr record high F = 53\n|May record high F = 59\n|Jun record high F = 64\n|Jul record"`
- Rows [306448], page692168, revision1379119907, raw[17542:18856): `"{{Weather box\n|width = auto\n|location = Biak, Papua\n|metric first = yes\n|single line = yes\n|Jan high C = 30.0\n|Feb high C = 29.2\n|Mar high C = 31.0\n|Apr high C = 30.2\n|May high C = 30.1\n|Jun high C = 29.7\n|Jul high C = 31.0\n|Aug high C = 29.7\n|Sep high C = 29."`

**"navy"** — 377 NER rows / 327 components.
- Rows [697], page13404868, revision1212134108, raw[175:199): `"{{navy|Empire of Japan}}"`
- Rows [4795], page559609, revision1345020428, raw[499:522): `"{{navy|United Kingdom}}"`

**"command structure\n"** — 372 NER rows / 16 components.
- Rows [1958], page441912, revision1382391173, raw[52400:53582): `"{{command structure\n|name= 11th Airborne Division \n|date= 1950-1956\n|parent= 11th Airborne Division\n|subordinate=Headquarters Company<br>[[188th Glider Infantry Regiment (United States)|188th Airborne Infantry Regiment]]<br>[[503rd Infantry Regiment (United St"`
- Rows [1985], page441912, revision1382391173, raw[53583:54891): `"{{command structure\n|name= 11th Airborne Division ([[Pentomic]])\n|date= 1957-1958\n|parent= 11th Airborne Division\n|subordinate=Command & Control Battalion<br>Headquarters & Headquarters Logistics Company<br>11th Administration Company<br>11th Aviation Company<"`

**"birth date"** — 372 NER rows / 335 components.
- Rows [94320], page1307385, revision1381257210, raw[2152:2182): `"{{birth date|1918|12|03|df=y}}"`
- Rows [98261], page67902496, revision1380335659, raw[571:596): `"{{birth date|1926|04|04}}"`

**"marriage"** — 312 NER rows / 111 components.
- Rows [94328, 94329], page1307385, revision1381257210, raw[2622:2662): `"{{marriage|Johanna Sunarti|30 May 1947}}"`
- Rows [114255], page8370817, revision1291051665, raw[448:484): `"{{marriage|Mary Winston White|1938}}"`

**"Other ships"** — 303 NER rows / 219 components.
- Rows [111863], page2426186, revision1327560358, raw[198:238): `"{{Other ships|Akatsuki-class destroyer}}"`
- Rows [565204, 565205], page4417237, revision1375397610, raw[46:75): `"{{Other ships|HMAS Armidale}}"`

**"succession box\n"** — 276 NER rows / 46 components.
- Rows [183478, 183479, 183480], page53726612, revision1380079275, raw[15933:16144): `"{{succession box\n| title=Officer in Charge of the [[Marine Corps Intelligence|Intelligence Section, HQMC]]\n| before= [[Robert E. Hommel]]\n| years= July 1957 – September 1957\n| after= [[James M. Masters, Sr.]]\n}}"`
- Rows [305454, 305455], page56145830, revision1380079915, raw[13614:13818): `"{{succession box\n| title=Commanding Officer of [[10th Marine Regiment (United States)|10th Marine Regiment]]\n| before=[[Raphael Griffin]]\n| years=January 1, 1945 - June 6, 1945\n| after=Saville T. Clark\n}}"`

**"Birth date"** — 265 NER rows / 241 components.
- Rows [94042], page4087942, revision1379846503, raw[363:387): `"{{Birth date|1890|3|26}}"`
- Rows [114011], page22831367, revision1380153318, raw[399:429): `"{{Birth date|1920|10|20|df=y}}"`

**"webarchive"** — 263 NER rows / 260 components.
- Rows [127852], page948688, revision1380185428, raw[8111:8251): `"{{webarchive|url=https://web.archive.org/web/20120222014830/http://www.destroyersonline.com/usndd/sumnrasbuilt.htm |date=22 February 2012 }}"`
- Rows [143544], page20144275, revision1357535149, raw[17855:17993): `"{{webarchive|url=https://web.archive.org/web/20081119033941/http://www.axpow.org/celebratingangelmaudedavison.htm |date=19 November 2008}}"`

**"About"** — 262 NER rows / 79 components.
- Rows [136389], page903485, revision1377444144, raw[54:148): `"{{About|the island|the channel in the Aleutian Islands|Amchitka Pass|the CD|Amchitka (album)}}"`
- Rows [149832, 149833], page50873988, revision1335836004, raw[0:123): `"{{About|I Bomber Command (formerly AAF Antisubmarine Command)|I Bomber Command (later XX Bomber Command)|I Bomber Command}}"`

**"collapsible list"** — 255 NER rows / 20 components.
- Rows [94349], page1307385, revision1381257210, raw[3458:3585): `"{{collapsible list|title={{nobold|''See list''}}\n| [[Siliwangi Division]]\n| [[Indonesian Army]]\n| [[Indonesian Armed Forces]]}}"`
- Rows [94352, 94353, 94354, 94355, 94356, 94357], page1307385, revision1381257210, raw[3606:4252): `"{{collapsible list|title={{nobold|''See list''}}\n|{{tree list}}\n* [[World War II]]\n** [[Dutch East Indies campaign]]\n*** [[Battle of Java (1942)|Battle of Java]]\n* [[Indonesian National Revolution]]\n** [[Madiun Affair]]\n** [[Operation Kraai]]\n** [[General Offe"`

**"indented plainlist"** — 248 NER rows / 39 components.
- Rows [161725], page615412, revision1358037097, raw[15875:15965): `"{{indented plainlist|\n* Struck 1&nbsp;March 1959\n* Sold for scrap, 3&nbsp;February 1960\n}}"`
- Rows [161731, 161732, 161733], page615412, revision1358037097, raw[16119:16207): `"{{indented plainlist|\n* Struck 1&nbsp;May 1959\n* Sold for scrap, 31&nbsp;October 1961\n}}"`

## Remaining primary categories

| Primary category | NER rows | Exact structural categories | Physical component spans |
|---|---:|---:|---:|
| unparsed_markup | 35 | 2 | 12 |
| coordinates | 1631 | 181 | 869 |
| media_review | 334 | 157 | 185 |
| image_field_review | 238 | 65 | 70 |
| template_name | 71 | 68 | 68 |
| gallery_review | 95 | 17 | 20 |
| protected_text | 7 | 3 | 4 |

**media_review examples:**
- Rows [35567, 35568], page21556690, revision1267379882, raw[1182:1257): `"Unit colour patch of the 2/7th Independent Company/2/7th Commando Squadron."`
- Rows [119176], page5652638, revision1377954802, raw[2565:2582): `"Brigadier General"`

**gallery_review examples:**
- Rows [174885, 174886], page18685782, revision1375594690, raw[13655:13845): `"alt=a heavily damaged Haruna, having sunk from the stern, several days after coming under attack at her moorings|Heavily damaged ''Haruna'' sunk at her moorings in Kure harbor, October 1945."`
- Rows [347469, 347470, 347471, 347472], page10909242, revision1361702300, raw[15009:15302): `"alt=Canon de 155 Grande Puissance Filloux (GPF) on display at the North 12th Street (East) gate of the Illinois Veterans Home complex in Quincy, IL.|Canon de 155 Grande Puissance Filloux (GPF) on display at the North 12th Street (East) gate"`

**image_field_review examples:**
- Rows [101053], page4243438, revision1376994314, raw[490:519): `" Flying Tigers Bite Back.ogg\n"`
- Rows [174235, 174236, 174237], page82201145, revision1379698689, raw[198:296): `" [[File:Japanese cruiser Tokiwa 1945.jpg|300px|The wreck of Japanese cruiser ''Tokiwa'' in 1945]]\n"`

**unparsed_markup examples:**
- Rows [1050, 1051, 1052, 1053], page441912, revision1382391173, raw[289:432): `"{{Infobox military unit\n| unit_name = 11th Airborne Division\n| image = 11th Airborne Division Insignia 2022.png\n| image_size = 150\n| caption = "`
- Rows [524541, 524542, 524543, 524544], page464776, revision1378506333, raw[43222:43338): `"[[File:USS New Jersey (BB-62) and French battleship Richelieu at anchor on 7 September 1943 (80-G-204842).jpg|thumb|"`

## Verification and evidence limits

Readback verified all nine immutable base fields for **all 36,238 selected NER rows**, unique row IDs, exact original Text/start/end/word slices, source hashes, physical counts and category counts. All 57 rows that needed larger context were resolved with the original full-page source_intervals rules; no word-sized fake component fallback remains. Six AST/context/parameter checks passed after observed RED failures. No base mutation, source-identity rewrite, extraction-provenance promotion, network, dependency installation, model or production consumer field was used.

`component_instances.jsonl` preserves OriginalRawText, page/revision/raw hash/path, raw component span, source_row_index, all nine original fields, exact mention and passage offsets, section titles and actual structural signature. `grouped_summary_verified.json` limits each exact category to three examples and each family to two distinct physical-component examples.

Saved HTML supports category proposals without exact expansion claims: representative Japanese nationalism sidebar has role=navigation; failed verification/page range too broad/self-published inline have noprint wrappers. These are FineWiki structural exclusions, not raw-to-HTML invocation mappings. Corrected cache coverage is 2,620 unknown rows across 79 same-page/revision HTML supports; 61 is only the raw+HTML receipt subset. See rendered_cache_coverage_correction.md. KIA/navy retain explicit display-component types; generated display mapping is separate from the category decision.

Next action: owner approves/changes IN/OUT/HOLD once for the exact categories or an explicitly listed compatible group; then apply that type rule uniformly to the evidence overlay. Implement missing display/repair handlers by family where needed. No semantic per-instance queue is the proposed solution.
