# Template/media REVIEW mechanics microtask

Final evidence is **templates_media_sample_20261101_v3/template_media_cases.json**; v1/v2 are retained intermediate evidence and have superseded unknown-name proposals. No base row, original field, binding, extraction revision claim, or eligibility field was written.

## Actual original/reference comparison

The accepted project plan `docs/superpowers/plans/2026-10-29-source-preserving-text-cleaner.md` explicitly specifies a small local cleaner informed by reviewed extraction rules, not a full FineWiki HTML deployment. Local `source-text-v3` / `article-source-v3` use installed mwparserfromhell 0.7.2 on raw wikitext.

Provenance worker independently traced [FineWiki extraction code](https://huggingface.co/datasets/HuggingFaceFW/finewiki/blob/71306a3fed631b8c1a77e5479eb9edddc8866003/src/2_extraction/run_extraction.py). This is a comparison snapshot; no historical project pin is proved. `process_document` builds `Article` from rendered HTML, calls `extract_infoboxes` for metadata and `get_plaintext` for body. It excludes Media-img/audio/video, Navigation, Category, noprint, Infobox from body; transcluded prose is retained with `exclude_transcluded_paragraphs=False`. `custom_html_to_plaintext` handles display:none (math exception); `table_to_markdown` preserves ordinary tables; `_extract_cell_text_for_table` can retain ALT when the cell otherwise has no text. No explicit coord-named rule was identified. These HTML handlers cannot expand raw `{{navy|...}}` or establish exact raw-source character origins.

Local cleaner differences: infobox display values are retained except image/style keys; quotations, Japanese names, lists, lang/font wrappers and documented ship modes use explicit display-field handlers. Unknown/ambiguous/duplicate-key templates remain literal REVIEW. `template_text_fields` rejects aliases that shadow each other. `template_targets` supplies documented ship display modes, not arbitrary template execution. `prepare_mentions.positions` enumerates exact placements; this stage requires one containing placement.

## Implemented mechanics

`templates_media.py:treat_span` reuses `source_intervals`, `normal`, `clean_text`, `map_mention`, `positions`, and the original parser. Exact supported-template name/control spans yield an exclude-noncontent proposal. Unknown-template names remain unresolved: `{{KIA}}` demonstrates why name syntax alone cannot prove absence of generated visible text. Known display helpers use the existing cleaner and exact source coverage; the check `{{lang|ja|[[Tokyo]]}}` yields Tokyo, never an arbitrary first parameter. No owned real REVIEW sample passed that supported-display path; no recovery rate is inferred.

For a parsed `<nowiki>` node, the exact content slice is recovered literally without parsing nested markup; no text is invented. `pre`, `source`, `syntaxhighlight`, and `math` are intentionally not generalized from this rule. Coordinates, image fields, unframed media captions, galleries, and malformed markup have explicit unresolved outcomes pending the family-specific rules below. These are development proposals, not semantic/eligibility approvals.

## Coverage and concrete cases

Validated base SHA256 `68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d`; 2,235,432 projected rows scanned. Sample is first distinct family/passages, deliberately bounded and nonrepresentative. 76 cases: {'genuinely_unresolved': 64, 'exclude_noncontent': 8, 'recover': 4}. CPU1; measured RSS 284.6 MB; elapsed 35.89s.

| Primary category | Sample / total | Concrete row and observed mechanics | Action |
|---|---:|---|---|
| coordinates | 8/1631 | 14157: coord positional4=S; display=title; other cases include inline coordinate modes | Unresolved; separate coordinate data/control from entity-like surface with a coord-specific rule. |
| gallery_review | 8/95 | 174885: gallery line has filename, alt=..., then caption containing Kure | Reuse media top-level option/caption parsing; actual caption and ALT require separate evidence spans. |
| image_field_review | 8/238 | 101053: image=Flying Tigers Bite Back.ogg; row140064 image_alt contains B-1B Lancer prose | Separate known media filename metadata from ALT prose. No blanket image* exclusion. |
| media_review | 8/334 | 23429: unframed Image with250px/right and one prose caption mentioning Australian | Recover caption candidate through existing top-level media field parser; framing/display semantics remain explicit. |
| protected_text | 4/7 | 195538: nowiki content - Samboja Seizure Unit | Recover exact literal Samboja Seizure Unit; original evidence retained. |
| template_name | 8/71 | 105867: Infobox militant organization name in an incomplete passage; full raw AST is complete | Exclude supported template name syntax; keep visible parameter values separate. |
| unknown_template | 24/33827 | 697: navy value Empire of Japan; row25 Campaignbox Japan and row4561 KIA are template names | Unresolved; require documented display/HTML evidence. Do not discard all unknowns. |
| unparsed_markup | 8/35 | 1050: unit_name=11th Airborne Division has no enclosing parsed template in full raw evidence | Unresolved malformed containing structure; fragment-only name/value guessing is unsafe. |

Every sampled case in the JSON includes source_row_index, original Text/word/start/end, Source, page, containing revision, raw SHA256/path, unique passage raw start, exact raw mention offsets, source role evidence, enclosing template literal/family/key/value list, and before/after proposal. Containing support is not relabelled as extraction provenance.

## Validation and next bounded task

RED observed before implementation: Campaignbox-name check failed on unresolved stub. GREEN7 then passed. A second real-case RED caught the overbroad unknown-name exclusion; the final9 checks pass, including KIA, duplicate quote aliases, unknown navy, coord, malformed syntax, supported lang, and literal nowiki. The original four focused helper test files pass273 tests in13.12s after setting PYTHONPATH; the first collection attempt lacked GG_Data on PYTHONPATH and was corrected. Pyreadline emitted a destructor OSError after the passing suite (exit0). No whole-repository or production run was attempted within this bounded microtask.

Next microtask: apply the existing top-level media-option/caption parser to the8 gallery and8 media cases, preserving each caption/ALT/file/control span, then add strict infobox image filename-vs-ALT rules for the8 image-field cases. Coordinate transformation and unknown template family rendering need separate documented rules. The caption worker owns its stage, so this file deliberately does not duplicate those edits.

File SHA256 receipts:
- `templates_media.py`: `f814022a5df1193e1efe6685e34756117c714cb0440e4baaf5143454a83d9627`
- `test_templates_media.py`: `b35898a9e9914ffdbd105b7e4eee5b6d1129c1f07f29f80d12f0cebf789f6ae9`
- `template_media_cases.json`: `fd6dabd96c81e24658e93129588db3e4ffed1c62a495f70c31c93668f28802c0`
