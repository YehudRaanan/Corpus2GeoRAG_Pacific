# Applied saved-raw processing support — 2026-11-01

**Applied 1,366 verified processing-revision bindings** in a new supplemental overlay: the initially approved33 Q5368015 recoveries plus1,333 additional recoveries from the complete59,455-row unsupported REVIEW population. No base row, primary binding, original Source, extraction revision, scope, cleaning status or eligibility changed.

Final consumer artifact:

`D:\Projects\GeoAI-incremental-dev-20261101\review_treatments\applied_full_review_saved_raw\processing_revision_bindings_all_applied.parquet`

Use the existing primary binding file **plus this one cumulative supplement**, joining by original `source_row_index`, `occurrence_id`, `wiki_site`, and `page_id`, and filling only null primary processing bindings. The33-row seed and1,333-row additional files are preserved staging evidence; do not also stack them with the cumulative file. The final supplement retains the existing seven columns and Arrow types:

`source_row_index, occurrence_id, wiki_site, page_id, processing_revision_id, processing_revision_sha256, binding_status`.

## Actual full-population results

| Outcome | Count |
|---|---:|
| Original base rows paired with primary bindings during selection | 2,235,432 |
| Unsupported REVIEW rows checked | 59,455 |
| Unsupported EXCLUDE rows left outside active recovery | 14,215 |
| Initially applied Q5368015 bindings | 33 |
| Additional bindings applied by the complete saved-cache pass | 1,333 |
| Total distinct supplemental bindings | **1,366** |
| Still no exact match in the enumerated saved raw evidence | **58,089** |
| Matching saved-revision alternatives retained | 3,501 |
| Matching literal placement alternatives retained | 3,501 |
| Rows with multiple matching saved revisions | 360 |
| Maximum matching revisions for one row | 23 |
| Original Source keys / physical pages receiving bindings | 26 / 26 |
| Accepted nonnull bindings overridden / duplicate supplemental IDs | **0 / 0** |

All59,455 original target rows, including unmatched outcomes, remain in `outcomes59455.jsonl.gz`. The47 Q5368015 outcomes from the initial checkpoint also remain in `applied_seed33/outcomes47.json`. The earlier51-gap prefix count comprised47 REVIEW and4 EXCLUDE; the latter four were not candidates.

All1,366 recovered rows remain original-scope REVIEW, `processing_eligible=false`, and `extraction_revision_id=null`. Their **original**, unchanged clean statuses are1,106 mapped,197 excluded and63 uncertain. These values are not a fresh cleaning decision on the selected processing revision. Support recovery alone does not authorize matching or settle reference-prose policy.

## Binding mechanics and actual source reuse

`exact_saved_recovery.py:36`, `supplemental_binding`, checks the exact original row/occurrence/wiki/page join, rejects any accepted nonnull primary binding, checks physical-page equality, requires complete literal Text containment in API/hash-validated raw, then reuses the existing `bind_record` function. It passes supported processing evidence through a new dictionary; the original row/status remains intact.

Reused existing implementation:

- `prepare_pages.py:509`, `raw_revision_rows`: reads raw `parse.wikitext` or revision-content API slots from saved receipts.
- `collect_entities.py:103`, `validate_revision`: requires raw SHA and exact saved API page/revision/body equality.
- `prepare_mentions.py:89`, `positions`: retains all literal placements, including overlapping ones.
- `processing_revision_binding/bind_processing_revision.py:21`, `bind_record`: emits the established seven-column processing binding.
- The earlier `fragment_recovery.py:21` treatment remains available for origin-aware cleaning comparisons; full support application does not silently promote a cleaning result.

The full pass enumerated **4,538 existing receipt paths** from the explicit old request/page/native-evidence cache directories and the pilot/broad registry references. **1,293 receipts contained supported raw fields**, producing **1,731 distinct relevant physical-page/revision/raw-hash combinations** across the1,567 target pages. Duplicate receipt copies remain evidence paths attached to one raw revision. All receipts parsed without errors; no same-page/revision conflicting raw hashes were found. `saved_raw_catalog.json` records every enumerated path, explicit directory, raw copy, hash, saved API reference and revision key.

For each original Source/page, the code tests full original Text against every validated same-page saved raw. Source keys must match the pinned index literally; canonical QIDs are not substituted. Where several saved revisions contain that passage, it preserves every matching revision and all positions. The deterministic processing representative is the highest numeric matching revision ID, while the already accepted33 seed representatives are retained. This is verified processing containment, with no claim about Daniel's original extraction revision.

## Concrete recovered and unresolved cases

| Row / original Source / physical page | Before | Applied processing evidence |
|---|---|---|
| **91152**, Q5368015,36625946; `ABCD` offsets17–21 | Original `PASSAGE_NOT_IN_CACHED_REVISION`; REVIEW; primary processing revision null | Revision1380781167 contains the identical full passage at raw74; mention raw91–95. Companion row91153 remains a distinct occurrence at raw112–116. All33 approved seed bindings retain this revision/raw SHA. |
| **485650**, Q188163,11660; `Fat Man` offsets4–11 | Same unsupported REVIEW/null primary state | Full-passage matches:1288540060@1522;1329801790@1522;1350465625@1523;1368489010@1523;**1380597647@1523**. Selected1380597647, raw mention1527–1534; all five alternatives retained. |
| **311321**, Q184870,53179; `World War II` offsets14–26 | Same unsupported REVIEW/null primary state | Six saved revisions match. Selected**1377861998**, full passage raw49055, raw mention49069–49081. All six version/position alternatives remain recorded. |
| **434899**, Q127417,48596; `1935` offsets23–27 | Same unsupported REVIEW/null primary state | Revision1377650348, complete passage raw2032; mention raw2055–2059. |
| **91241**, Q5368015,36625946; `United States` | Unsupported REVIEW/null primary | Full passage beginning `In the United States, reporting on the Japanese bombing of Chinese cities was particularly negative.` remains absent in the enumerated same-page saved raw. No supplemental binding is written; its original row remains in the complete outcome ledger. |

Source references for reproducible checks:

- Q5368015 revision1380781167: existing `source_page_versions_history_20261027/requests/4881b0c41d66e88df18dab8038f2d298e71583f6be84d59fd64c2d155da0708c.json.gz`; receipt SHA `00e6ef2f460de65e811168e8e42e6070ef3106edbb651f55b83600fdb92ad366`; raw SHA `3e12964395df3d1ac227b0b301725bc6e70067c3342c37a193941fcff59763b9`. The raw wikitext field, not its HTML sibling, provides support.
- Row485650 selected revision: `native_corpus_graphs_20261028/evidence/wiki_exact/4b26ff37bf10433a14e07be11073a55041dfca819c933684df5d92fb60ca35f7.json.gz`; raw SHA `541307b4166ef9d7dbd879489ec217edd5520f5685e06d788e0fe8beb1718365`.
- Row311321 selected revision: `native_corpus_graphs_20261028/evidence/wiki_exact/9d3ed3db90bc9eb4491c7336585b164d65065711ee3e5cd3999a60390bb56a11.json.gz`; raw SHA `70f2a357e0174d1c4c8406b47fc83f8e64d723ca5e9bc1cdafbfe6bfab21e770`.

These relative source references are under `D:\Projects\GeoAI-source-page-ids-20261026\Data\external`. Exact absolute paths and receipt/raw hashes for every matched revision are in the catalog. All82 actually matched raw revisions independently revalidated against API evidence; their receipt statuses were all HTTP200:78 parse receipts and4 revision-query receipts.

## Verification, performance and custody

- RED failed on a missing supplemental binding, then GREEN passed correct page/source, duplicate literal hits, wrong page/source/revision, nonidentical passage, immutable joins and accepted-binding override rejection.
- Seed checkpoint wrote/read back33 bindings and retained47 outcomes before full processing.
- Full pass checked the first32 and100 target records, then continued without approval pauses. Full application/readback took **168.547 seconds**. CPU and Arrow I/O were restricted to one thread; active raw passage payload was51,416,234 UTF-8 bytes, below the256MiB guard; data was batched at4,096 rows, output bindings at256 rows, and raw validation cached at four revisions.
- Independent persisted readback rejoined **all59,455** original ledger records to the unchanged base, verified all primary bindings were null, and recomputed **all3,501** exact matching alternatives after separately validating the82 matched raws. Both staging overlay IDs and ledger IDs were unique.
- Independent source-custody check verified **all59,455** exact original Source-key/physical-page pairs against the pinned5,693-key index, with no canonical QID substitution.
- Cumulative overlay independently rechecked1,366 null primary joins, seven-column schema, disjoint IDs and exact persisted readback.
- Existing `test_prepare_mentions.py` and `test_clean_source_text.py`: **131 passed in7.48s**, exit0. A `pyreadline3` console-destructor OSError printed during interpreter shutdown; no test failed. Original `bind_processing_revision.py` self-check also passed. The full repository test suite was not run; no original implementation module changed.

Hashes:

| Artifact | SHA-256 |
|---|---|
| Original base, before/after | `68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d` |
| Original primary bindings, before/after | `ec5049c88a53379c59898aa3af2a834e56b29c09e5b8e970610097c594dcdbb0` |
| Final cumulative1,366-row supplement | `06ee8e3c4e42e0073f13703dbade22f607cbcf6d2f62b804e835c297c10ad4f9` |
| Complete59,455-row outcome ledger | `1dba601ebb13bd956265961150b8c5fbd25fdee14ad6b0f37c9f2315cc2b59db` |
| Enumerated saved-raw catalog | `b13a1452ca328e7e988d5722c89030ae2b9e09a21087e6453d7c21d3af8a4ff8` |
| Broad original-source index | `b37da8892dd96094bb151b43d262d5ff0c42286a3e71f9980d9197e4b025fac5` |
| Final stage code, including verification/materialization commands | `5853d91aca20ff42433e6f23b1b04d07262d9bb215617afc0d6d3ec51168f972` |

Receipts are `applied_seed33/binding_receipt.json` and, under `applied_full_review_saved_raw`, `binding_receipt.json`, `independent_readback.json`, `source_identity_custody.json`, and `cumulative_binding_receipt.json`. Application receipts retain the code hash actually executed at their respective checkpoints. Later additions provide independent verification and cumulative materialization; they do not rewrite those receipts.

This is a complete target-row pass against the **enumerated existing saved evidence**, not a claim that every historical Wikipedia revision or every other possible local cache was searched. The58,089 misses remain explicit outcomes. No normalization, fuzzy matching, new source acquisition, network, model, paid service, dependency install, Git operation, original-source mutation, production batch or eligibility/policy promotion occurred. Reference-prose policy remains held independently of processing support. No denied or pending action remains. Outputs are local **Unprotected**.
