# Independent readback: result and practical limits

Full integrity readback passed for all 2,235,432 rows, exact original IDs, primary plus only cumulative binding joins, disjoint counts, 5,750 cleaned page/revisions, 1,929,444 origin segments and all 3,090 geographic evidence records (3,087 distinct source intervals). All 32 caption artifacts and 43 mechanical span artifacts retain their recorded hashes.

IN reconciliation, disjoint:
- Verified mapped text: 1,294,967.
- Explicit needs-family-handler flag: 12,045.
- Existing uncertain mapping: 14,640.
- Ambiguous exact passage placement: 4,170.
- Previously removed template-name syntax: 71.
- Total: 1,325,893 IN; other gaps after mapped/explicit-handler rows: 18,881.

The 71 previously removed rows are all known template-name syntax (for example Infobox, military person and Infobox person). They emit no text and remain ineligible, but their policy-IN label is a follow-up policy-classification finding, not unidentified historical content. The writer was not changed by this readback.

The 14,640 uncertain mappings include 2,418 prior display_value rows. Some can still need a family handler or handler correction; 12,045 is the explicit flag count, not a complete diagnosis of all rendering work. Full disjoint old-reason counts and examples are in independent_readback.json.

Actual scope tradeoffs:
- Officeholder table / Chuichi Nagumo and wartime command dates -> outside the initial general-table scope.
- member / Bernard L. Anderson, 15th Infantry Regiment and Ilocos Norte -> outside that general-table scope, despite useful wartime information.
- Infobox commands={{ubli|K Company, ...}} -> policy-IN; unknown display expansion stays pending instead of concatenating parameters.
- The {{USS|Hornet|CV-8|2}} sailed. -> The Hornet sailed. through the documented existing handler.
- Narrative #tag:ref explaining Sentai -> OUT under the approved notes/reference rule.
- Coordinate template -> no textual NER; exact raw component, supplied parameters, page/revision/hash and offsets remain in the separate geo evidence.

All original rows, caption work and span overlays remain preserved. No production batch or eligibility promotion occurred. The next step is bounded resolution of the identified syntax classification and rendering/placement categories, not a claim that preparation is complete.
