# Approved narrow policy: measured implementation impact

Rows scanned: 2,235,432; full corpus: True. Unique parsed page/revisions: 5,750.

| Before -> after | Rows |
|---|---:|
| EXCLUDE->OUT | 632,620 |
| KEEP->IN | 1,273,665 |
| KEEP->OUT | 97,647 |
| KEEP->PENDING | 840 |
| REVIEW->IN | 52,228 |
| REVIEW->OUT | 113,287 |
| REVIEW->PENDING | 65,145 |

Policy IN 1,325,893; OUT 843,554; PENDING 65,985. IN is source membership, not model eligibility or proof of successful rendering.

Verified base mappings: 1,265,395; verified mechanical overlays: 29,572; family handler needed: 12,045.

Coordinate/map source components preserved: 3,090. Exact raw and supplied structured parameters are saved even when conversion is unavailable. No new geometry or consumer fields were created.

## Practical implications

General tables lose useful content by the approved scope choice: Officeholder table records Nagumo commanding in 1941-1942; member tables describe Filipino guerrilla leaders, military units and places. Explanatory notes about Sentai are also excluded. These are coverage losses, not claims that those facts are false or useless.

A nested commands={{ubli|K Company, ...}} in the article infobox remains policy-IN. Special inline body templates reuse documented family handlers, e.g. {{USS|Hornet|CV-8|2}} -> Hornet. Unknown operands are never blindly concatenated; their exact families remain in impact.json until a display handler/context rule exists.

References/notes, navigation, maintenance, galleries/captions and general body tables are outside this initial text scope. Completed caption/span evidence and all original rows remain retained for later scope expansion. No caption work was discarded.

Policy uses verified page context where available. Original structural EXCLUDE rows retain their exclusion using immutable base evidence, including unsupported fragments; missing/ambiguous source support is separately counted. Recovered normalization-only placements are not guessed. Full scanning does not claim every row has resolved policy or rendering.

cleaned_pages.jsonl.gz contains only mapped supported text and compressed exact character origins. Unknown family text is omitted from that ready-text projection and retained in source/pending evidence, never declared OUT merely because rendering is missing.

All processing_eligible flags remain false. Production prerequisites are not declared complete. Backup status: Unprotected.

## Priority and code examples

Read the component sections in narrow_source_policy.py: each rule has its rationale and a relevant before/after or retained/removed example before the implementation. Priority is section exclusions > refs/media/geo > general tables > unresolved standalone context > infobox/body/list inclusion. Rendering readiness is separate.

## Actual before/after examples

- Row 0, OUT / existing_structural_page_control: "US" -> null; page 48975579, revision 1375061414.
- Row 4, IN / article_infobox_content: "1 November 1944" -> "1 November 1944"; page 48975579, revision 1375061414.
- Row 8, OUT / existing_structural_image_field: "USAAF" -> null; page 48975579, revision 1375061414.
- Row 12, OUT / media_gallery_or_caption: "Japanese" -> null; page 48975579, revision 1375061414.
- Row 16, OUT / existing_structural_citation: "Enright|Ryan" -> null; page 48975579, revision 1375061414.
- Row 22, OUT / existing_structural_template_control: "1912" -> null; page 48975579, revision 1375061414.
- Row 25, OUT / navigation_maintenance_or_metadata: "Japan" -> null; page 48975579, revision 1375061414.
- Row 26, IN / body_prose_or_ordinary_list: "1 November 1944" -> "1 November 1944"; page 48975579, revision 1375061414.
- Row 40, IN / body_prose_or_ordinary_list: "United States [[Twentieth Air Force" -> "United States Twentieth Air Force"; page 48975579, revision 1375061414.
- Row 133, OUT / reference_or_note: "Sentai" -> null; page 48975579, revision 1375061414.
- Row 253, OUT / existing_structural_bibliographic_section: "May 2021" -> null; page 48975579, revision 1375061414.
- Row 313, OUT / existing_structural_category_metadata: "World War II" -> null; page 48975579, revision 1375061414.
- Row 464, IN / body_with_syntax_requires_surface_mapping: "Texas|BB-35" -> "Texas"; page 8385178, revision 1360005623.
- Row 473, OUT / existing_structural_related_or_external_link_section: "United States" -> null; page 8385178, revision 1360005623.
- Row 627, OUT / general_body_table: "Streamer" -> null; page 64096955, revision 1372397745.
- Row 647, OUT / references_notes_or_related_section: "Rottman" -> null; page 64096955, revision 1372397745.
- Row 697, IN / article_infobox_content: "Empire of Japan" -> null; page 13404868, revision 1212134108.
- Row 735, OUT / technical_syntax: "Combined Fleet]] || [[Southern Expeditionary Fleet (Imperial Japanese Navy)#Southern Expeditionary Fleet/1st Southern Expeditionary Fleet|IJN" -> null; page 13404868, revision 1212134108.
- Row 759, PENDING / crosses_policy_component_boundary: "Commander in chief''' <ref>Wendel" -> null; page 13404868, revision 1212134108.
- Row 768, OUT / general_body_table: "Rear-Admiral|| [[Bunji Asakura" -> null; page 13404868, revision 1212134108.
- Row 1050, PENDING / pending_structural_family_or_malformed_source: "11th" -> null; page 441912, revision 1382391173.
- Row 1092, PENDING / missing_processing_revision_support: "John Cogbill" -> null; page 441912, revision None.
- Row 1266, OUT / existing_structural_navigation: "Battle of" -> null; page 441912, revision 1382391173.
- Row 1463, OUT / existing_structural_image_filename: "Manila Walled City" -> null; page 441912, revision 1382391173.
- Row 2308, OUT / media_gallery_or_caption: "US Army" -> null; page 441912, revision 1382391173.
- Row 2742, OUT / existing_structural_image_option: "Dark" -> null; page 441912, revision 1382391173.
- Row 2834, OUT / same_policy_across_multiple_contexts: "1994" -> null; page 441912, revision 1382391173.
- Row 4802, IN / same_policy_across_multiple_contexts: "Korean War" -> null; page 559609, revision 1345020428.
- Row 13845, OUT / existing_structural_url: "February 2019" -> null; page 25796709, revision 1373560317.
- Row 14157, OUT / coordinate_syntax_geo_preserved: "S" -> null; page 5597186, revision 1381658744.
