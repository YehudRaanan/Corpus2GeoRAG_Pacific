"""Approved narrow source/cleaning projection. No base edits or production batches.

Priority: excluded sections > references/media/coordinates > general tables >
unknown standalone context > body/ordinary lists/article infobox content.
Syntax is OUT as text. Unknown display families stay explicit, never concatenated.
Offsets are Python characters, end-exclusive, in verified saved source.
"""
import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
from functools import lru_cache
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(r'D:\Projects\GeoAI-incremental-dev-20261101')
PILOT = Path(r'D:\Projects\GeoAI-luke-pilot-20261028')
sys.path.insert(0, str(PILOT))
sys.path.insert(0, str(ROOT/'review_treatments'))
import mwparserfromhell as mw
import pyarrow as pa
import pyarrow.parquet as pq
import psutil
from inventory_unknown_components import nodes_with_spans
from GG_Data.entity_resolution.hundred_page_pilot.clean_source_text import clean_text
from GG_Data.entity_resolution.hundred_page_pilot.filter_source_content import (
    source_intervals, section_path, normal, BACK, RELATED, NOTES, LIST_TEMPLATES,
    TEMPLATE_TEXT_GROUPS, DISPLAY_STYLES, IMAGE_KEYS, CAPTION_KEYS)
from build_component_policy_packet import NAV, REFS, ARCHIVE, MAINTENANCE, DECORATIVE

BASE = ROOT/'ingestion/full_ingestion_20261101/mentions.parquet'
PRIMARY = ROOT/'processing_revision_binding/processing_revision_bindings.parquet'
RECOVERY = ROOT/'review_treatments/applied_full_review_saved_raw/processing_revision_bindings_all_applied.parquet'
CATALOG = ROOT/'review_treatments/applied_full_review_saved_raw/saved_raw_catalog.json'
BROAD = Path(r'D:\Projects\GeoAI-simplified-agent-20261030\Data\external\simplified_agent_20261030\page_acquisition\page_sources.json.gz')
PINNED = {BASE:'68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d',
 PRIMARY:'ec5049c88a53379c59898aa3af2a834e56b29c09e5b8e970610097c594dcdbb0',
 RECOVERY:'06ee8e3c4e42e0073f13703dbade22f607cbcf6d2f62b804e835c297c10ad4f9'}
LABELS = {1:'body_prose_or_ordinary_list', 2:'article_infobox_content',
 3:'pending_structural_family_or_malformed_source', 4:'general_body_table',
 5:'media_gallery_or_caption', 6:'reference_or_note', 7:'navigation_maintenance_or_metadata',
 8:'references_notes_or_related_section', 9:'coordinate_syntax_geo_preserved', 10:'technical_syntax',11:'infobox_technical_control'}
TABLES = {'officeholder table','officeholder table start','officeholder table end',
 'member','member/start','member/end','aircraft specs','weather box','command structure',
 'succession box','historical populations','airport-dest-list','airport destination list',
 'tree chart','unit awards table','ahnentafel','s-ttl','s-bef','s-aft'}
LISTS = LIST_TEMPLATES | {'ubli','ublist','unordered list','unbulleted indent list',
 'ulist','blist','clist','numbered list','indented plainlist','flatlist','collapsible list'}
MEDIA = {'gallery','multiple image','listen','external media','wide image','plain image with caption'}
NAV_NAMES = {normal(n) for n in NAV} | {'main article','for-multi','for multi','for2',
 'details','seealso','other people','family name hatnote','hatnote','redirect2','portalbar'}
REF_NAMES = {normal(n) for n in REFS | ARCHIVE} | {'r','multiref','efn-ur','efn-la',
 'sfnb','sfnq','sfnmp','snf','sfb','ref','reference page','navsource','nhc'}
MAINT_NAMES = {normal(n) for n in MAINTENANCE} | {'no footnotes','more footnotes',
 'use shortened footnotes','unreferenced section','more citations needed section','engvarb',
 'one source','expand section','better source needed','unreliable source?','rs'}
GEO_FIELDS = re.compile(r'coordinates?|coord|lat(?:itude|d|m|s| deg| min| sec| dir)?|lon(?:gitude|gd|gm|gs|g deg|g min|g sec|g dir)?')

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def merged_ranges(mask):
    return [(m.start(),m.end()) for m in re.finditer(b'\x01+',mask)]

def build_view(raw):
    nodes = nodes_with_spans(raw)
    spans, headings = source_intervals(raw)
    templates = [n for n in nodes if n['kind']=='Template']
    infoboxes = [n for n in templates if normal(n['name_exact']).startswith('infobox')]
    tables = [n for n in nodes if n['kind']=='Tag' and normal(n['name_exact'])=='table']
    entries = []
    handler = bytearray(len(raw))
    geo = []

    def add(n, code, priority):
        entries.append((priority,n['start'],n['end'],code))

    def inside_info(n):
        return any(i['start']<=n['start']<n['end']<=i['end'] for i in infoboxes)

    # Article infoboxes retain content, including nested ordinary lists. Example:
    # commands={{ubli|K Company, [[3rd Battalion, 5th Marines|3rd Battalion]]}}
    # keeps the command/list content; rendering of ubli stays separately pending.
    for n in infoboxes:
        add(n,2,1)

    # A literal table containing Infobox ship begin/career/characteristics is the
    # infobox shell, not a general body table. Preserve that evidenced container.
    shells = [t for t in tables if any(t['start']<=i['start']<i['end']<=t['end'] for i in infoboxes)]
    for n in shells:
        add(n,2,1)

    def in_article_info(n):
        return inside_info(n) or any(i['start']<=n['start']<n['end']<=i['end'] for i in shells)

    # General body tables are OUT, even when useful. Real example: Officeholder
    # table / Chuichi Nagumo / term_start=10 April 1941 / term_end=14 July 1942.
    # The same kind of displayed data in an article infobox remains policy-IN.
    for n in tables:
        if n not in shells and not in_article_info(n): add(n,4,3)
    for n in templates:
        name = normal(re.sub(r'<!--[\s\S]*?-->','',n['name_exact']))
        if (name in TABLES or name.startswith(('election box ','cfb yearly record '))) and not in_article_info(n):
            add(n,4,3)

    # Media captions and galleries are OUT for this first scope. For example,
    # [[File:Aircraft.jpg|thumb|May 1942]] contributes no text; raw is retained.
    # This also covers image/caption fields inside the article infobox.
    for n in nodes:
        if (n['kind']=='Wikilink' and normal(n['name_exact']) in {'file','image'}) or (n['kind']=='Tag' and normal(n['name_exact'])=='gallery'):
            add(n,5,4)
        if n['kind']=='Template' and normal(n['name_exact']) in MEDIA: add(n,5,4)
        if n['kind']=='ParameterValue' and in_article_info(n):
            key = normal(n['name_exact'])
            # Infobox formatting is OUT in both policy and cleaned text:
            # style=color: red -> nothing. The direct ship characteristics field
            # class=Fletcher-class destroyer is content, so that exact role stays.
            ship_class = key=='class' and any(normal(i['name_exact'])=='infobox ship/characteristics' and n['ancestor_types']==i['ancestor_types']+['Template'] and i['start']<=n['start']<n['end']<=i['end'] for i in infoboxes)
            if key in DISPLAY_STYLES | {'sort','sortkey','sort key','nolink','officeholder sort'} and not ship_class:
                add(n,11,4)
            if key in IMAGE_KEYS | CAPTION_KEYS or re.fullmatch(r'(?:image|logo|caption|image caption|map caption|image alt|alt)(?: \d+|\d*)',key) or key.startswith(('image size','image width')):
                add(n,5,4)
            if GEO_FIELDS.fullmatch(key):
                add(n,9,5)
                geo.append(dict(kind='infobox_coordinate_field',start=n['start'],end=n['end'],name=n['name_exact'],raw=raw[n['start']:n['end']],parameters=[]))

    # Notes/references are OUT regardless of their prose. Real example:
    # {{#tag:ref|[[Sentai]]s were air groups with several flying squadrons...}}
    # is removed as a reference component; no sentence-by-sentence judgment occurs.
    for a,b,role,detail in spans:
        n = {'start':a,'end':b}
        if role in {'citation','reference_note'}: add(n,6,5)
        elif role in {'navigation','page_control','category_metadata','comment','url'}: add(n,7,5)
        elif role in {'caption','media_review','gallery_review','image_field','image_field_review','image_filename','image_option'}: add(n,5,4)
        elif role in {'parameter_key','template_control','hidden_link_target','tag_markup'}: add(n,10,4)
        elif role=='unparsed_markup': add(n,3,2)
        elif role=='unknown_template': handler[a:b] = b'\1'*(b-a)

    # Known navigation, citation and maintenance families are OUT structurally.
    # {{Refimprove|date=January 2009}} -> nothing; its date is editorial metadata.
    # Unknown family names are never automatically treated as these families.
    for n in templates:
        name = normal(n['name_exact'])
        if name in REF_NAMES or re.fullmatch(r'#tag:\s*(?:ref|references)',name): add(n,6,5)
        elif name in NAV_NAMES or name.startswith(('campaignbox ','navbox','sidebar')): add(n,7,5)
        elif name in MAINT_NAMES or name in {normal(x) for x in DECORATIVE}: add(n,7,5)

    # Coordinates are OUT of textual NER but kept as structured source evidence.
    # {{Coord|17|07|00|S|122|15|20|E|display=title}} retains all supplied values,
    # the exact raw component and page/revision offsets. No geometry is invented.
    for n in templates:
        name = normal(n['name_exact'])
        if name=='coord' or name.startswith(('location map','osm location map','mapframe')):
            parsed = mw.parse(n['literal']).filter_templates(recursive=False)[0]
            geo.append(dict(kind='coordinate_or_map_template',start=n['start'],end=n['end'],name=n['name_exact'],raw=n['literal'],parameters=[dict(key=str(p.name),value=str(p.value),explicit_key=p.showkey) for p in parsed.params]))
            if name=='coord': add(n,9,5)
            elif not in_article_info(n): add(n,5,4)

    # Inline body templates stay IN, but only verified family-specific display
    # handlers produce text. Example: The {{USS|Hornet|CV-8|2}} sailed. ->
    # The Hornet sailed. Language codes and ship mode/link controls are omitted.
    # Unknown {{NewFamily|safe|secret=garbage}} is preserved in evidence, with
    # NEEDS_HANDLER and no invented "safe garbage" expansion in cleaned text.
    # Standalone unknown components get one family/context decision queue instead
    # of being silently declared body text or discarded by their name.
    for n in templates:
        name = normal(n['name_exact'])
        left = raw.rfind('\n',0,n['start'])+1
        right = raw.find('\n',n['end'])
        if right<0: right=len(raw)
        outside = raw[left:n['start']]+raw[n['end']:right]
        visible = mw.parse(outside).strip_code().strip(" *#:;'=\t")
        inline = bool(re.search(r'[^\W\d_]',visible))
        if not in_article_info(n) and not inline and name not in LISTS | set(TEMPLATE_TEXT_GROUPS):
            add(n,3,2)

    # Entire back-matter/notes sections are OUT. "==Notes== ..." is removed
    # until the next heading of the applicable section path, including child refs.
    boundaries = [h[0] for h in headings]+[len(raw)]
    for i,(a,_,_) in enumerate(headings):
        if {normal(s) for s in section_path(headings,a)} & (BACK|RELATED|NOTES):
            entries.append((6,a,boundaries[i+1],8))

    codes = bytearray(b'\1')*len(raw)
    for _,a,b,code in sorted(entries):
        codes[a:b] = bytes([code])*(b-a)

    # Reuse the tested cleaner; hide excluded content and unknown expansions.
    # [[Tokyo|the capital]] -> the capital; <ref>...</ref> -> nothing.
    # Do not mask known template syntax before parsing: the ship handler needs
    # its family/mode fields to select the documented visible surface.
    hidden = bytearray(1 if c in {3,4,5,6,7,8,9,11} or h else 0 for c,h in zip(codes,handler))
    cleaned = clean_text(raw,merged_ranges(hidden))
    uncertain = bytearray(len(raw))
    for a,b in cleaned.review_spans: uncertain[a:b]=b'\1'*(b-a)
    chars=[]; origins=[]
    for ch,(a,b) in zip(cleaned.text,cleaned.origins):
        if a==b:
            keep = a<len(raw) and codes[a] in {1,2,10} and not handler[a]
        else:
            keep = not any(uncertain[a:b]) and not any(hidden[a:b])
        if keep: chars.append(ch);origins.append((a,b))
    return dict(raw=raw,codes=codes,handler=handler,nodes=templates,geo=geo,
        cleaned_text=''.join(chars),origins=origins)

def classify(view,left,right):
    if not 0<=left<right<=len(view['raw']): raise ValueError('Invalid verified-source interval')
    values = set(view['codes'][left:right])
    if values <= {1,2}: return 'IN',LABELS[2 if 2 in values else 1]
    if values <= {1,2,10} and values & {1,2}: return 'IN','body_with_syntax_requires_surface_mapping'
    if values=={3}: return 'PENDING',LABELS[3]
    if values and values <= {4,5,6,7,8,9,10,11}: return 'OUT',LABELS[max(values)]
    return 'PENDING','crosses_policy_component_boundary'

def origin_segments(origins):
    """Losslessly compress consecutive one-character origins; shared spans stay exact."""
    result=[];i=0
    while i<len(origins):
        a,b=origins[i];j=i+1
        if b==a+1:
            while j<len(origins) and origins[j]==(a+j-i,a+j-i+1):j+=1
            mode='linear';end=a+j-i
        else:
            while j<len(origins) and origins[j]==(a,b):j+=1
            mode='shared';end=b
        result.append([i,j,a,end,mode]);i=j
    return result

def self_check():
    cases=[
      ('Tokyo<ref>Explanatory note about Sentai.</ref> was defended.','Sentai','OUT'),
      ('{|\n| Tokyo || 1942\n|}','Tokyo','OUT'),
      ('{{Infobox person|name=Tokyo|commands={{ubli|K Company}}}}','K Company','IN'),
      ('The {{USS|Hornet|CV-8|2}} sailed.','Hornet','IN'),
      ('The {{NewFamily|safe|secret=garbage}} sailed.','safe','IN'),
      ('{{UnknownStandalone|Tokyo}}','Tokyo','PENDING'),
      ('{{Infobox event|name=Raid|caption=May 1942|coordinates={{coord|15|135}}}}','May 1942','OUT'),
      ('{{Infobox event|coordinates={{coord|15|135}}}}','135','OUT'),
      ('==Notes==\nTokyo\n==History==\nTokyo','Tokyo','OUT'),
      ('{{Officeholder table|officeholder=Nagumo|term_start=10 April 1941}}','Nagumo','OUT'),
      ('{{Infobox person|name=Tokyo|style=color: red|sortkey=Secret}}','red','OUT'),
      ('{{Infobox ship/characteristics|class=Fletcher-class destroyer}}','Fletcher','IN')]
    for raw,word,expected in cases:
        v=build_view(raw);left=raw.index(word)
        assert classify(v,left,left+len(word))[0]==expected,(raw,word,classify(v,left,left+len(word)))
        assert len(v['cleaned_text'])==len(v['origins'])
    ship=build_view('The {{USS|Hornet|CV-8|2}} sailed.')
    assert ship['cleaned_text']=='The Hornet sailed.',ship['cleaned_text']
    unknown=build_view('The {{NewFamily|safe|secret=garbage}} sailed.')
    assert 'safe' not in unknown['cleaned_text'] and 'garbage' not in unknown['cleaned_text']
    geo=build_view('{{Infobox event|coordinates={{coord|15|135}}}}')
    assert any(e['parameters'] for e in geo['geo']) and not geo['cleaned_text'].strip()
    assert 'Sentai' not in build_view(cases[0][0])['cleaned_text']
    controls=build_view('{{Infobox person|name=Tokyo|style=color: red|sortkey=Secret}}')
    assert 'red' not in controls['cleaned_text'] and 'Secret' not in controls['cleaned_text']
    assert 'Fletcher-class destroyer' in build_view(cases[-1][0])['cleaned_text']
    print('PASS: 12 structural cases, documented ship display, unknown-template suppression, coordinate provenance, infobox controls/ship class and origin lengths',flush=True)

def run(output,limit):
    started=time.monotonic();pa.set_cpu_count(1);pa.set_io_thread_count(1)
    if output.exists():raise FileExistsError('Use a new version; preserve every previous artifact')
    source_paths=[*PINNED,CATALOG,BROAD,Path(__file__),Path(sys.modules[source_intervals.__module__].__file__),Path(sys.modules[clean_text.__module__].__file__),ROOT/'review_treatments/inventory_unknown_components.py',ROOT/'review_treatments/templates_media.py',ROOT/'review_treatments/build_component_policy_packet.py',PILOT/'Data/external/hundred_page_pilot_20261028/revisions.parquet']
    hashes={str(p):digest(p) for p in source_paths}
    for p,h in PINNED.items():assert hashes[str(p)]==h,('Pinned source changed',p)
    recovery={r['source_row_index']:r for r in pq.read_table(RECOVERY).to_pylist()}
    assert len(recovery)==1366
    catalog={}
    for r in pq.read_table(PILOT/'Data/external/hundred_page_pilot_20261028/revisions.parquet').to_pylist():
        catalog[r['page_id'],r['revision_id'],r['sha256']]=r['wikitext_path']
    with gzip.open(BROAD,'rt',encoding='utf8') as stream:
        for r in json.load(stream):catalog.setdefault((r['wiki_page_id'],r['revision_id'],r['raw_sha256']),r['raw_path'])
    for r in json.loads(CATALOG.read_text(encoding='utf8'))['catalog'].values():
        r=r['revision'];catalog[r['page_id'],r['revision_id'],r['sha256']]=r['wikitext_path']
    overlay={}
    overlay_hashes={}
    for path in sorted((ROOT/'review_treatments/span_application').glob('span_*.jsonl')):
        overlay_hashes[str(path)]=digest(path)
        for number,line in enumerate(path.open(encoding='utf8'),1):
            r=json.loads(line)
            if r['application_status']=='APPLIED':
                assert r['source_row_index'] not in overlay
                overlay[r['source_row_index']]=dict(word=r['transformed_word'],reference=f'{path}:{number}',origins=r['treatment']['component_origins'],raw_sha256=r['provenance']['raw_sha256'])
    assert len(overlay)==31948
    output.mkdir(parents=True);shutil.copyfile(__file__,output/Path(__file__).name)
    counters=Counter();intersections=Counter();reasons=Counter();examples={};families=defaultdict(lambda:dict(rows=0,examples=[]))
    written=set();parses=0;last_progress=time.monotonic()
    geo_writer=gzip.open(output/'structured_geo_evidence.jsonl.gz','wt',encoding='utf8')
    page_writer=gzip.open(output/'cleaned_pages.jsonl.gz','wt',encoding='utf8')

    @lru_cache(maxsize=2)
    def page_view(key):
        nonlocal parses
        path=Path(catalog[key]);data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==key[2]
        raw=data.decode('utf8');view=build_view(raw);parses+=1
        if key not in written:
            written.add(key)
            provenance=dict(page_id=key[0],processing_revision_id=key[1],raw_sha256=key[2],raw_path=str(path))
            for evidence in view['geo']:
                geo_writer.write(json.dumps(provenance|evidence,ensure_ascii=False)+'\n');counters['geo_components']+=1
            page_writer.write(json.dumps(provenance|dict(text=view['cleaned_text'],origin_segments=origin_segments(view['origins']),raw_length=len(raw)),ensure_ascii=False)+'\n')
        return view

    @lru_cache(maxsize=512)
    def placements(key,text):
        raw=page_view(key)['raw'];found=[];at=0
        while len(found)<65:
            at=raw.find(text,at)
            if at<0:break
            found.append(at);at+=1
        return tuple(found)

    schema=pa.schema([('source_row_index',pa.int64()),('occurrence_id',pa.string()),('page_id',pa.int64()),('processing_revision_id',pa.int64()),('raw_sha256',pa.string()),('old_scope',pa.string()),('old_reason',pa.string()),('policy_decision',pa.string()),('policy_reason',pa.string()),('evidence_frame',pa.string()),('raw_start',pa.int64()),('raw_end',pa.int64()),('needs_rendering_handler',pa.bool_()),('surface_status',pa.string()),('surface_word',pa.string()),('surface_origin_reference',pa.string()),('processing_eligible',pa.bool_())],metadata={b'base_sha256':PINNED[BASE].encode(),b'policy':b'owner-approved narrow source policy 2026-11-01 17:45:48 UTC',b'eligibility':b'false: preparation projection only; no production batches'})
    columns=['source_row_index','occurrence_id','page_id','Text','word','start','end','source_scope_status','source_scope_reason','clean_status','Text_clean','clean_start','clean_end']
    base=pq.ParquetFile(BASE);bindings=pq.ParquetFile(PRIMARY)
    with pq.ParquetWriter(output/'narrow_policy.parquet',schema,compression='zstd') as writer:
        for batch,bb in zip(base.iter_batches(batch_size=8192,columns=columns,use_threads=False),bindings.iter_batches(batch_size=8192,use_threads=False),strict=True):
            rows=batch.to_pylist();bound=bb.to_pylist();assert len(rows)==len(bound);out=[]
            for row,binding in zip(rows,bound):
                index=row['source_row_index']
                if limit is not None and index>=limit:break
                assert index==counters['rows'] and binding['source_row_index']==index and binding['occurrence_id']==row['occurrence_id']
                if index in recovery:
                    newer=recovery[index];assert binding['processing_revision_id'] is None and newer['occurrence_id']==binding['occurrence_id']
                    assert row['page_id'] in {None,newer['page_id']};binding=newer;counters['recovery_bindings_used']+=1
                key=(binding['page_id'],binding['processing_revision_id'],binding['processing_revision_sha256'])
                result=dict(source_row_index=index,occurrence_id=row['occurrence_id'],page_id=key[0],processing_revision_id=key[1],raw_sha256=key[2],old_scope=row['source_scope_status'],old_reason=row['source_scope_reason'],policy_decision='PENDING',policy_reason='missing_processing_revision_support',evidence_frame='NO_VERIFIED_PLACEMENT',raw_start=None,raw_end=None,needs_rendering_handler=False,surface_status='NOT_READY',surface_word=None,surface_origin_reference=None,processing_eligible=False)
                if key[1] is not None:counters['bound']+=1
                else:
                    counters['unbound']+=1;counters['unbound_'+row['source_scope_status']]+=1
                view=None;points=()
                if key[1] is not None:
                    if key in catalog:
                        view=page_view(key);points=placements(key,row['Text'])
                    else:result['policy_reason']='verified_binding_raw_not_in_catalog'
                if row['source_scope_status']=='EXCLUDE':
                    result.update(policy_decision='OUT',policy_reason='existing_structural_'+row['source_scope_reason'],evidence_frame='BASE_STRUCTURAL_EVIDENCE')
                elif view is not None and points:
                    decisions=[classify(view,p+row['start'],p+row['end']) for p in points]
                    if len(points)>64:
                        result['policy_reason']='too_many_exact_passage_placements'
                    elif len(set(d for d,_ in decisions))==1:
                        decision=decisions[0][0]
                        result.update(policy_decision=decision,policy_reason=decisions[0][1] if len(set(decisions))==1 else 'same_policy_across_multiple_contexts',evidence_frame='VERIFIED_REVISION_EXACT_PASSAGE')
                    else:result['policy_reason']='multiple_placements_disagree_on_policy'
                    if len(points)==1:
                        a,b=points[0]+row['start'],points[0]+row['end'];assert view['raw'][a:b]==row['word']
                        result.update(raw_start=a,raw_end=b)
                        result['needs_rendering_handler']=result['policy_decision']=='IN' and any(view['handler'][a:b])
                        if result['policy_decision']=='IN':
                            applied=overlay.get(index)
                            if applied and applied['raw_sha256']==key[2] and all(x==y or classify(view,x,y)[0]=='IN' for x,y in applied['origins']):
                                result.update(surface_status='VERIFIED_MECHANICAL_OVERLAY',surface_word=applied['word'],surface_origin_reference=applied['reference'],needs_rendering_handler=False)
                            elif row['clean_status']=='mapped' and not result['needs_rendering_handler']:
                                result.update(surface_status='BASE_VERIFIED_MAPPING',surface_word=row['Text_clean'][row['clean_start']:row['clean_end']],surface_origin_reference=f'base row {index}: clean_origins_json, clean_start/end')
                            else:result['surface_status']='NEEDS_FAMILY_HANDLER' if result['needs_rendering_handler'] else 'BASE_'+row['clean_status'].upper()
                    elif result['policy_decision']=='IN':result['surface_status']='AMBIGUOUS_EXACT_PLACEMENT'
                elif view is not None:result['policy_reason']='no_exact_passage_in_bound_revision_recovery_mapping_not_projected'
                decision=result['policy_decision'];counters['rows']+=1;counters[decision]+=1
                counters['surface_'+result['surface_status']]+=1
                if result['needs_rendering_handler']:counters['needs_handler']+=1
                intersections[row['source_scope_status']+'->'+decision]+=1
                reasons[decision+':'+result['policy_reason']]+=1
                exkey=(row['source_scope_status'],decision,result['policy_reason'])
                example=dict(row=index,word=row['word'],raw_text_excerpt=row['Text'][:350],**{k:result[k] for k in ['page_id','processing_revision_id','raw_start','raw_end','policy_decision','policy_reason','surface_status','surface_word']})
                if exkey not in examples:
                    examples[exkey]=example
                if view is not None and result['raw_start'] is not None and (result['needs_rendering_handler'] or decision=='PENDING'):
                    a,b=result['raw_start'],result['raw_end']
                    containers=[n for n in view['nodes'] if n['start']<=a<b<=n['end']]
                    name=min(containers,key=lambda n:n['end']-n['start'])['name_exact'] if containers else '@non_template_boundary'
                    f=families[name];f['rows']+=1
                    if len(f['examples'])<2:f['examples'].append(example|dict(raw_component=min(containers,key=lambda n:n['end']-n['start'])['literal'] if containers else view['raw'][max(0,a-80):b+80]))
                out.append(result)
            if out:writer.write_table(pa.Table.from_pylist(out,schema=schema))
            if time.monotonic()-last_progress>=20:
                print(json.dumps(dict(rows=counters['rows'],pages=len(written),parses=parses,IN=counters['IN'],OUT=counters['OUT'],PENDING=counters['PENDING'],elapsed_seconds=round(time.monotonic()-started,1),rss_mb=round(psutil.Process().memory_info().rss/1048576))),flush=True);last_progress=time.monotonic()
            if limit is not None and counters['rows']>=limit:break
    geo_writer.close();page_writer.close()
    assert counters['rows']==(base.metadata.num_rows if limit is None else min(limit,base.metadata.num_rows))
    assert counters['IN']+counters['OUT']+counters['PENDING']==counters['rows']
    assert hashes=={str(p):digest(p) for p in source_paths}
    report=dict(policy='approved narrow source policy',counts=dict(counters),before_after=dict(intersections),decision_reasons=dict(reasons),unique_verified_page_revisions=len(written),page_parses=parses,full_corpus_scanned=limit is None,source_hashes_unchanged=True,source_hashes=hashes,span_overlay_hashes=overlay_hashes,examples=list(examples.values()),pending_family_counts=dict(sorted(families.items(),key=lambda x:-x[1]['rows'])),elapsed_seconds=round(time.monotonic()-started,2),originals_and_overlays_unchanged=True,processing_eligible_promoted=False,production_batches_started=False,coordinate_geometry_invented=False,coordinate_evidence_format='Exact raw coordinate/map component and structured supplied parameters, page/revision/hash/offsets; numeric conversion not attempted',backup_status='Unprotected')
    (output/'impact.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    lines=['# Approved narrow policy: measured implementation impact','',f"Rows scanned: {counters['rows']:,}; full corpus: {limit is None}. Unique parsed page/revisions: {len(written):,}.",'','| Before -> after | Rows |','|---|---:|']
    lines += [f'| {k} | {v:,} |' for k,v in sorted(intersections.items())]
    lines += ['',f"Policy IN {counters['IN']:,}; OUT {counters['OUT']:,}; PENDING {counters['PENDING']:,}. IN is source membership, not model eligibility or proof of successful rendering.",'',f"Verified base mappings: {counters['surface_BASE_VERIFIED_MAPPING']:,}; verified mechanical overlays: {counters['surface_VERIFIED_MECHANICAL_OVERLAY']:,}; family handler needed: {counters['needs_handler']:,}.",'',f"Coordinate/map source components preserved: {counters['geo_components']:,}. Exact raw and supplied structured parameters are saved even when conversion is unavailable. No new geometry or consumer fields were created.",'','## Practical implications','', 'General tables lose useful content by the approved scope choice: Officeholder table records Nagumo commanding in 1941-1942; member tables describe Filipino guerrilla leaders, military units and places. Explanatory notes about Sentai are also excluded. These are coverage losses, not claims that those facts are false or useless.', '', 'A nested commands={{ubli|K Company, ...}} in the article infobox remains policy-IN. Special inline body templates reuse documented family handlers, e.g. {{USS|Hornet|CV-8|2}} -> Hornet. Unknown operands are never blindly concatenated; their exact families remain in impact.json until a display handler/context rule exists.', '', 'References/notes, navigation, maintenance, galleries/captions and general body tables are outside this initial text scope. Completed caption/span evidence and all original rows remain retained for later scope expansion. No caption work was discarded.', '', 'Policy uses verified page context where available. Original structural EXCLUDE rows retain their exclusion using immutable base evidence, including unsupported fragments; missing/ambiguous source support is separately counted. Recovered normalization-only placements are not guessed. Full scanning does not claim every row has resolved policy or rendering.', '', 'cleaned_pages.jsonl.gz contains only mapped supported text and compressed exact character origins. Unknown family text is omitted from that ready-text projection and retained in source/pending evidence, never declared OUT merely because rendering is missing.', '', 'All processing_eligible flags remain false. Production prerequisites are not declared complete. Backup status: Unprotected.','', '## Priority and code examples','', 'Read the component sections in narrow_source_policy.py: each rule has its rationale and a relevant before/after or retained/removed example before the implementation. Priority is section exclusions > refs/media/geo > general tables > unresolved standalone context > infobox/body/list inclusion. Rendering readiness is separate.', '', '## Actual before/after examples', '']
    for e in list(examples.values())[:30]:lines.append(f"- Row {e['row']}, {e['policy_decision']} / {e['policy_reason']}: {json.dumps(e['word'],ensure_ascii=False)} -> {json.dumps(e['surface_word'],ensure_ascii=False)}; page {e['page_id']}, revision {e['processing_revision_id']}.")
    (output/'IMPACT_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    print(json.dumps({k:report[k] for k in ['counts','before_after','unique_verified_page_revisions','full_corpus_scanned','elapsed_seconds']}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--limit',type=int)
    args=parser.parse_args()
    self_check()
    if args.output:run(args.output,args.limit)
