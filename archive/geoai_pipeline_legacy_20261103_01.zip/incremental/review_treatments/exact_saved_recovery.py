"""Exact saved-raw support candidates; never update input or processing bindings."""
import argparse
import gzip
import hashlib
import inspect
import json
from pathlib import Path
import sys
import tempfile
import time
from collections import Counter, defaultdict
from functools import lru_cache

PRIMARY = Path(r"D:\Projects\GeoAI-incremental-dev-20261101\processing_revision_binding\processing_revision_bindings.parquet")
BROAD_SHA = "b37da8892dd96094bb151b43d262d5ff0c42286a3e71f9980d9197e4b025fac5"

ROOT = Path(r"D:\Projects\GeoAI-incremental-dev-20261101")
sys.path.insert(0, str(ROOT / "review_treatments"))
from fragment_recovery import treatment, digest, BASE, BASE_SHA, BROAD
from GG_Data.entity_resolution.hundred_page_pilot.collect_entities import validate_revision
from GG_Data.entity_resolution.hundred_page_pilot.prepare_pages import raw_revision_rows
from GG_Data.entity_resolution.hundred_page_pilot.prepare_mentions import positions
sys.path.insert(0, str(ROOT / "processing_revision_binding"))
from bind_processing_revision import bind_record, COLUMNS


@lru_cache(maxsize=4)
def _validated_raw(page_id, revision_id, sha256, raw_path, receipt_path):
    return validate_revision(dict(page_id=page_id, revision_id=revision_id, sha256=sha256, wikitext_path=raw_path, evidence_path=receipt_path))


def validated_raw(revision):
    return _validated_raw(revision["page_id"], revision["revision_id"], revision["sha256"], revision["wikitext_path"], revision["evidence_path"])


def supplemental_binding(row, revision, primary):
    for field in ("source_row_index", "occurrence_id", "wiki_site", "page_id"):
        if row[field] != primary[field]:
            raise ValueError("Original/primary identity mismatch")
    if primary["processing_revision_id"] is not None:
        raise ValueError("Never override an accepted processing binding")
    if row["page_id"] != revision["page_id"]:
        raise ValueError("Saved revision belongs to a different physical page")
    hits = positions(validated_raw(revision), row["Text"])
    if not hits:
        raise ValueError("Exact full passage support is required")
    status = "VERIFIED_CONTAINING_SUPPORT_EXTRACTION_UNKNOWN" if len(hits) == 1 else "CONTAINING_SUPPORT_NONUNIQUE_PASSAGE"
    return bind_record(dict(row, attribution_status=status, containing_support_revision_id=revision["revision_id"], source_revision_sha256=revision["sha256"]))


def recover_exact(row, revision, source_binding):
    result = dict(literal_positions=[], selected_raw_offset=None, binding_applied=False)
    if row["Source"] != source_binding["source_key"]:
        return {**result, "candidate_status": "REJECT_SOURCE_KEY_MISMATCH"}
    if row["page_id"] != source_binding["wiki_page_id"] or row["page_id"] != revision["page_id"]:
        return {**result, "candidate_status": "REJECT_PAGE_IDENTITY_MISMATCH"}
    raw = validate_revision(revision)
    hits = positions(raw, row["Text"])
    result.update(literal_positions=hits, candidate_status="EXACT_SAVED_RAW_SUPPORT_CANDIDATE" if hits else "STILL_UNSUPPORTED_IN_TESTED_SAVED_RAW")
    if hits:
        assert row["Text"][row["start"]:row["end"]] == row["word"]
        result["placement_treatment"] = treatment(raw, row["Text"], row["start"], row["end"])
    return result


def self_check():
    with tempfile.TemporaryDirectory(prefix="exact-saved-recovery-") as tmp:
        directory = Path(tmp)
        raw = "Tokyo Tokyo"
        raw_path, receipt_path = directory / "raw.txt", directory / "receipt.json.gz"
        raw_path.write_bytes(raw.encode("utf-8"))
        record = {"ok": True, "response_text": json.dumps({"parse": {"pageid": 1, "revid": 2, "title": "Test", "wikitext": raw}})}
        with gzip.open(receipt_path, "wt", encoding="utf-8") as stream:
            json.dump(record, stream)
        revision = dict(page_id=1, revision_id=2, wikitext_path=str(raw_path), evidence_path=str(receipt_path), sha256=digest(raw_path))
        row = dict(Source="Q1", page_id=1, Text="Tokyo", word="Tokyo", start=0, end=5)
        binding = dict(source_key="Q1", wiki_page_id=1)
        primary = dict(source_row_index=0, occurrence_id="toy", wiki_site="enwiki", page_id=1, processing_revision_id=None)
        bound_row = dict(row, source_row_index=0, occurrence_id="toy", wiki_site="enwiki")
        candidate = supplemental_binding(bound_row, revision, primary)
        assert candidate is not None and candidate["processing_revision_id"] == 2, candidate
        try:
            supplemental_binding(bound_row, revision, dict(primary, processing_revision_id=99))
        except ValueError:
            pass
        else:
            raise AssertionError("Existing accepted bindings must never be overridden")
        supported = recover_exact(row, revision, binding)
        assert supported.get("candidate_status") == "EXACT_SAVED_RAW_SUPPORT_CANDIDATE", supported
        assert supported["literal_positions"] == [0, 6] and supported["selected_raw_offset"] is None
        assert recover_exact({**row, "page_id": 9}, revision, binding)["candidate_status"] == "REJECT_PAGE_IDENTITY_MISMATCH"
        assert recover_exact({**row, "Source": "Q2"}, revision, binding)["candidate_status"] == "REJECT_SOURCE_KEY_MISMATCH"
        assert recover_exact({**row, "Text": "Tokyo ", "word": "Tokyo"}, revision, binding)["literal_positions"] == [0]
        absent = recover_exact({**row, "Text": "Tokyo\n", "word": "Tokyo"}, revision, binding)
        assert absent["candidate_status"] == "STILL_UNSUPPORTED_IN_TESTED_SAVED_RAW" and absent["literal_positions"] == []
        wrong_revision = {**revision, "revision_id": 3}
        try:
            recover_exact(row, wrong_revision, binding)
        except ValueError as error:
            assert "does not bind" in str(error)
        else:
            raise AssertionError("Unbound revision must fail validation")
    print("PASS exact recovery: correct page/source, every literal placement, wrong page/source/revision, nonidentical text")


def preview():
    import pyarrow as pa
    import pyarrow.parquet as pq
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    assert digest(BASE) == BASE_SHA
    evidence = Path(r"D:\Projects\GeoAI-source-page-ids-20261026\Data\external\source_page_versions_history_20261027\requests\4881b0c41d66e88df18dab8038f2d298e71583f6be84d59fd64c2d155da0708c.json.gz")
    with gzip.open(evidence, "rt", encoding="utf-8") as stream:
        record = json.load(stream)
    assert record["http_status"] == 200 and record["ok"]
    assert record["params"]["action"] == "parse" and record["params"]["oldid"] == 1380781167
    raw_rows = raw_revision_rows(record, evidence)
    assert len(raw_rows) == 1
    saved = raw_rows[0]
    assert (saved["page_id"], saved["revision_id"], saved["wiki_title"]) == (36625946, 1380781167, "ABCD Encirclement")
    raw_bytes = saved["raw"].encode("utf-8")
    expected_raw_sha = "3e12964395df3d1ac227b0b301725bc6e70067c3342c37a193941fcff59763b9"
    assert hashlib.sha256(raw_bytes).hexdigest() == expected_raw_sha
    # This is a byte-identical local extraction of an existing receipt, not a new source observation.
    raw_path = Path(__file__).parent / "saved_raw_page36625946_rev1380781167.txt"
    if raw_path.exists():
        assert raw_path.read_bytes() == raw_bytes
    else:
        with raw_path.open("xb") as stream:
            stream.write(raw_bytes)
    revision = dict(page_id=saved["page_id"], revision_id=saved["revision_id"], wikitext_path=str(raw_path),
                    sha256=expected_raw_sha, evidence_path=str(evidence))
    with gzip.open(BROAD, "rt", encoding="utf-8") as stream:
        binding = next(row for row in json.load(stream) if row["source_key"] == "Q5368015")
    assert binding["wiki_page_id"] == 36625946 and binding["title"] == saved["wiki_title"]
    current = dict(page_id=binding["wiki_page_id"], revision_id=binding["revision_id"], wikitext_path=binding["raw_path"],
                   sha256=binding["raw_sha256"], evidence_path=binding["evidence"])
    current_raw = validate_revision(current)
    selected, scanned = [], 0
    fields = ["source_row_index", "occurrence_id", "Source", "Text", "word", "start", "end", "page_id",
              "attribution_status", "source_scope_status", "source_scope_reason", "processing_eligible", "clean_status",
              "extraction_revision_id", "revision_id", "containing_support_revision_id", "source_revision_sha256"]
    for batch in pq.ParquetFile(BASE).iter_batches(batch_size=2048, columns=fields, use_threads=False):
        for row in batch.to_pylist():
            scanned += 1
            if row["Source"] == "Q5368015" and row["attribution_status"] == "PASSAGE_NOT_IN_CACHED_REVISION" and row["source_scope_status"] == "REVIEW":
                assert row["page_id"] == binding["wiki_page_id"]
                assert positions(current_raw, row["Text"]) == []
                selected.append(row)
            if scanned == 100000:
                break
        if scanned == 100000:
            break
    results = [{"original": row, "candidate_processing_page_id": revision["page_id"],
                "candidate_processing_revision_id": revision["revision_id"], "candidate_raw_sha256": expected_raw_sha,
                "current_cached_revision_id": current["revision_id"], "current_cached_exact_positions": [],
                **recover_exact(row, revision, binding)} for row in selected]
    assert results and digest(BASE) == BASE_SHA
    counts = {status: sum(r["candidate_status"] == status for r in results) for status in {r["candidate_status"] for r in results}}
    assert counts.get("EXACT_SAVED_RAW_SUPPORT_CANDIDATE", 0) >= 2
    assert counts.get("STILL_UNSUPPORTED_IN_TESTED_SAVED_RAW", 0) >= 1
    report = dict(status="PASS", selection="Q5368015 unsupported REVIEW rows within first100000 base rows only", scanned_rows=scanned,
        selected_rows=len(results), counts=counts, base_sha256_before_after=BASE_SHA, candidate_revision=revision,
        source_identity_evidence={k:binding[k] for k in ("source_key", "wiki_page_id", "source_title", "title", "revision_id", "raw_path", "raw_sha256", "evidence")},
        saved_receipt_sha256=digest(evidence), current_cached_revision=current, current_receipt_sha256=digest(Path(current["evidence_path"])),
        broad_index_sha256=digest(BROAD), raw_utf8_bytes=len(raw_bytes), raw_characters=len(saved["raw"]),
        source_extraction_revision_unchanged=True, processing_bindings_unchanged=True, no_eligibility_or_policy_change=True,
        no_normalization_or_fuzzy_matching=True, no_new_source_observation=True, no_population_projection=True,
        reused_functions={fn.__name__: dict(path=inspect.getsourcefile(fn), line=inspect.getsourcelines(fn)[1], sha256=digest(Path(inspect.getsourcefile(fn)))) for fn in (raw_revision_rows, validate_revision, positions, treatment)},
        code_sha256=digest(Path(__file__)), backup_status="Unprotected", results=results)
    with (Path(__file__).parent / "exact_saved_recovery_Q5368015_verified.json").open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False)
    print(json.dumps({k:v for k,v in report.items() if k not in {"results", "source_identity_evidence", "current_cached_revision"}}, indent=2))


def apply_seed():
    import pyarrow as pa
    import pyarrow.parquet as pq
    started = time.monotonic()
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    prior_path = ROOT / "review_treatments" / "exact_saved_recovery_Q5368015_verified.json"
    prior = json.loads(prior_path.read_text(encoding="utf-8"))
    revision = prior["candidate_revision"]
    assert digest(BASE) == BASE_SHA
    primary_sha = json.loads((PRIMARY.parent / "binding_receipt.json").read_text())["sidecar_sha256"]
    assert digest(PRIMARY) == primary_sha
    originals = {r["source_row_index"]: r for r in pq.read_table(BASE, filters=[("Source", "=", "Q5368015")], use_threads=False).to_pylist()}
    indices = [r["original"]["source_row_index"] for r in prior["results"]]
    primary_rows = {r["source_row_index"]: r for r in pq.read_table(PRIMARY, filters=[("source_row_index", "in", indices)], use_threads=False).to_pylist()}
    output = ROOT / "review_treatments" / "applied_seed33"
    output.mkdir(exist_ok=False)
    bindings, outcomes = [], []
    for result in prior["results"]:
        row = originals[result["original"]["source_row_index"]]
        assert all(row[k] == v for k, v in result["original"].items())
        primary = primary_rows[row["source_row_index"]]
        assert primary["processing_revision_id"] is None
        bound = None
        if result["candidate_status"] == "EXACT_SAVED_RAW_SUPPORT_CANDIDATE":
            bound = supplemental_binding(row, revision, primary)
            bindings.append(bound)
        outcomes.append(dict(result, binding_applied=bound is not None, applied_supplemental_binding=bound))
    assert len(bindings) == 33 and len(outcomes) == 47
    assert len({r["occurrence_id"] for r in bindings}) == len(bindings)
    schema = pq.ParquetFile(PRIMARY).schema_arrow.with_metadata({b"base_parquet_sha256": BASE_SHA.encode(),
        b"primary_binding_sha256": primary_sha.encode(), b"revision_role": b"supplemental verified containing PROCESSING revision; extraction unchanged",
        b"overlay_rule": b"join by original row/occurrence/wiki/page; apply only where primary processing_revision_id is null",
        b"eligibility": b"unchanged"})
    target = output / "processing_revision_bindings.parquet"
    pq.write_table(pa.Table.from_pylist(bindings, schema=schema), target, compression="zstd")
    assert schema.names == COLUMNS
    assert pq.read_table(target, use_threads=False).to_pylist() == bindings
    assert digest(BASE) == BASE_SHA and digest(PRIMARY) == primary_sha
    with (output / "outcomes47.json").open("x", encoding="utf-8") as stream:
        json.dump(dict(results=outcomes, base_sha256=BASE_SHA, primary_sha256=primary_sha), stream, ensure_ascii=False, indent=2)
    receipt = dict(status="PASS", applied_bindings=len(bindings), retained_outcomes=len(outcomes), still_unmatched=14,
        original_base_sha256=BASE_SHA, primary_binding_sha256=primary_sha, overlay_path=str(target), overlay_sha256=digest(target),
        prior_candidate_ledger_sha256=digest(prior_path), saved_raw_revision=revision, saved_receipt_sha256=digest(Path(revision["evidence_path"])),
        accepted_nonnull_overrides=0, duplicate_occurrence_ids=0, readback_rows=33, original_status_eligibility_source_extraction_unchanged=True,
        no_production_batch=True, elapsed_seconds=round(time.monotonic()-started, 3), code_sha256=digest(Path(__file__)), backup_status="Unprotected")
    with (output / "binding_receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2), flush=True)


def apply_all_saved():
    """Stream base once, inspect explicit saved caches, and bind null-only support."""
    import pyarrow as pa
    import pyarrow.parquet as pq
    started = time.monotonic()
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    assert digest(BASE) == BASE_SHA
    assert digest(BROAD) == BROAD_SHA
    primary_sha = json.loads((PRIMARY.parent / "binding_receipt.json").read_text())["sidecar_sha256"]
    assert digest(PRIMARY) == primary_sha
    output = ROOT / "review_treatments" / "applied_full_review_saved_raw"
    output.mkdir(exist_ok=False)
    raw_directory = output / "saved_raw"
    raw_directory.mkdir()
    seed_path = ROOT / "review_treatments" / "applied_seed33" / "processing_revision_bindings.parquet"
    seed_bindings = {r["occurrence_id"]: r for r in pq.read_table(seed_path, use_threads=False).to_pylist()}
    assert len(seed_bindings) == 33
    with gzip.open(BROAD, "rt", encoding="utf-8") as stream:
        source_bindings = {r["source_key"]: r for r in json.load(stream)}
    fields = ["source_row_index", "occurrence_id", "wiki_site", "page_id", "Source", "Text", "word", "start", "end",
              "attribution_status", "source_scope_status", "source_scope_reason", "clean_status", "processing_eligible",
              "extraction_revision_id", "revision_id", "containing_support_revision_id", "source_revision_sha256"]
    groups, primary_rows, scope_counts = defaultdict(list), {}, Counter()
    scanned, text_bytes = 0, 0
    base_file, primary_file = pq.ParquetFile(BASE), pq.ParquetFile(PRIMARY)
    for base_batch, binding_batch in zip(base_file.iter_batches(batch_size=4096, columns=fields, use_threads=False),
                                          primary_file.iter_batches(batch_size=4096, use_threads=False), strict=True):
        assert base_batch.num_rows == binding_batch.num_rows
        for row, primary in zip(base_batch.to_pylist(), binding_batch.to_pylist(), strict=True):
            scanned += 1
            assert row["source_row_index"] == primary["source_row_index"] and row["occurrence_id"] == primary["occurrence_id"]
            if primary["processing_revision_id"] is None:
                scope_counts[row["source_scope_status"]] += 1
                if row["source_scope_status"] == "REVIEW":
                    assert row["attribution_status"] == "PASSAGE_NOT_IN_CACHED_REVISION"
                    assert row["processing_eligible"] is False and row["revision_id"] is None and row["extraction_revision_id"] is None
                    groups[row["page_id"]].append(row)
                    primary_rows[row["occurrence_id"]] = primary
                    text_bytes += len(row["Text"].encode("utf-8"))
        if scanned % 262144 == 0:
            print(f"ACTIVE_SCAN rows={scanned} active={len(primary_rows)} elapsed={time.monotonic()-started:.1f}s", flush=True)
    assert len(primary_rows) == 59455 and scope_counts["EXCLUDE"] == 14215
    assert text_bytes < 256 * 1024 * 1024, "Bounded active raw-text payload exceeds256MiB"
    print(f"ACTIVE_READY rows={len(primary_rows)} pages={len(groups)} text_bytes={text_bytes} elapsed={time.monotonic()-started:.1f}s", flush=True)
    # Explicit existing cache surfaces only. No private metadata cache or network.
    old = Path(r"D:\Projects\GeoAI-source-page-ids-20261026\Data\external")
    directories = [old / name / "requests" for name in ("source_page_ids_20261026", "source_page_versions_staged_20261027", "source_page_versions_history_20261027")]
    directories += [old / "source_page_ids_20261026" / name for name in ("pages", "candidate_pages")]
    directories += [old / "native_corpus_graphs_20261028" / "evidence" / "wiki_exact", old / "native_corpus_graphs_20261028" / "wiki_parse" / "requests"]
    paths = {p for directory in directories if directory.is_dir() for p in directory.glob("*.json.gz")}
    paths.update(Path(row["evidence"]) for row in source_bindings.values())
    paths.update(Path(row["evidence_path"]) for row in pq.read_table(ROOT.parent / "GeoAI-luke-pilot-20261028" / "Data" / "external" / "hundred_page_pilot_20261028" / "revisions.parquet").to_pylist())
    paths = sorted(paths)
    catalog, by_page, cache_counts, errors = {}, defaultdict(list), Counter(), []
    for number, path in enumerate(paths, 1):
        try:
            with gzip.open(path, "rt", encoding="utf-8") as stream:
                record = json.load(stream)
            raw_rows = raw_revision_rows(record, path)
            cache_counts["receipts_with_raw"] += bool(raw_rows)
            for saved in raw_rows:
                if saved["page_id"] not in groups:
                    continue
                params = record.get("params", {})
                if params.get("action") == "parse" and "oldid" in params:
                    assert int(params["oldid"]) == saved["revision_id"]
                raw_bytes = saved["raw"].encode("utf-8")
                sha = hashlib.sha256(raw_bytes).hexdigest()
                key = f'{saved["page_id"]}:{saved["revision_id"]}:{sha}'
                evidence = dict(path=str(path), sha256=digest(path), api_oldid=params.get("oldid"))
                if key in catalog:
                    catalog[key]["saved_api_receipts"].append(evidence)
                    continue
                raw_path = raw_directory / f'page{saved["page_id"]}_rev{saved["revision_id"]}_{sha[:12]}.txt'
                with raw_path.open("xb") as stream:
                    stream.write(raw_bytes)
                revision = dict(page_id=saved["page_id"], revision_id=saved["revision_id"], sha256=sha,
                    wikitext_path=str(raw_path), evidence_path=str(path))
                assert validate_revision(revision) == saved["raw"]
                catalog[key] = dict(revision=revision, title=saved["wiki_title"], saved_api_receipts=[evidence])
                by_page[saved["page_id"]].append(key)
                cache_counts["validated_revisions"] += 1
        except (ValueError, KeyError, AssertionError, OSError, TypeError) as error:
            errors.append(dict(path=str(path), error=f"{type(error).__name__}: {error}"))
        if number % 128 == 0 or number == len(paths):
            elapsed = time.monotonic()-started
            print(f"SAVED_SCAN receipts={number}/{len(paths)} revisions={len(catalog)} errors={len(errors)} elapsed={elapsed:.1f}s rough_scan_remaining={elapsed/number*(len(paths)-number):.1f}s", flush=True)
    revision_hashes = defaultdict(set)
    for item in catalog.values():
        r = item["revision"]
        revision_hashes[(r["page_id"], r["revision_id"])].add(r["sha256"])
    conflicting_revisions = {key for key, hashes in revision_hashes.items() if len(hashes) > 1}
    with (output / "saved_raw_catalog.json").open("x", encoding="utf-8") as stream:
        json.dump(dict(catalog=catalog, explicit_directories=[str(p) for p in directories], receipt_paths=[str(p) for p in paths], errors=errors,
            conflicting_revisions=list(conflicting_revisions)), stream, ensure_ascii=False, indent=2)
    schema = primary_file.schema_arrow.with_metadata({b"base_parquet_sha256": BASE_SHA.encode(), b"primary_binding_sha256": primary_sha.encode(),
        b"overlay_rule": b"null-only supplemental; disjoint from applied_seed33", b"revision_role": b"PROCESSING support, never extraction", b"eligibility": b"unchanged"})
    target = output / "processing_revision_bindings.parquet"
    counts, expected, processed = Counter(), {}, 0
    with pq.ParquetWriter(target, schema, compression="zstd") as writer, gzip.open(output / "outcomes59455.jsonl.gz", "xt", encoding="utf-8") as outcomes:
        pending = []
        for page_id, rows in sorted(groups.items()):
            revisions = {key: validate_revision(catalog[key]["revision"]) for key in by_page[page_id]
                         if (page_id, catalog[key]["revision"]["revision_id"]) not in conflicting_revisions}
            for row in rows:
                binding = source_bindings.get(row["Source"])
                identity_ok = bool(binding and binding["source_key"] == row["Source"] and binding["wiki_page_id"] == row["page_id"])
                matches = []
                if identity_ok:
                    for key, raw in revisions.items():
                        hits = positions(raw, row["Text"])
                        if hits:
                            matches.append(dict(catalog_key=key, revision_id=catalog[key]["revision"]["revision_id"], positions=hits))
                matches.sort(key=lambda match: (match["revision_id"], match["catalog_key"]))
                selected, applied = None, None
                seed = seed_bindings.get(row["occurrence_id"])
                if seed:
                    selected = next((match for match in matches if match["revision_id"] == seed["processing_revision_id"] and catalog[match["catalog_key"]]["revision"]["sha256"] == seed["processing_revision_sha256"]), None)
                    assert selected is not None
                    counts["already_applied_seed"] += 1
                elif matches:
                    selected = matches[-1]
                    applied = supplemental_binding(row, catalog[selected["catalog_key"]]["revision"], primary_rows[row["occurrence_id"]])
                    assert applied["occurrence_id"] not in expected
                    pending.append(applied)
                    expected[applied["occurrence_id"]] = applied
                    counts["additional_applied"] += 1
                status = "SAVED_RAW_PROCESSING_SUPPORT_APPLIED" if selected else "NO_EXACT_MATCH_IN_ENUMERATED_SAVED_RAW" if identity_ok else "SOURCE_PAGE_IDENTITY_UNRESOLVED"
                counts[status] += 1
                counts["all_matching_revision_alternatives"] += len(matches)
                counts["all_literal_position_alternatives"] += sum(len(m["positions"]) for m in matches)
                outcome = dict(original=row, outcome=status, exact_matching_saved_revisions=matches, selected_processing_representative=selected,
                    representative_policy="PRESERVE_ACCEPTED_SEED_ELSE_HIGHEST_SAVED_MATCHING_REVISION_ID; no extraction claim", supplemental_binding=applied,
                    seed_binding_retained=seed, primary_binding_was_null=True, eligibility_source_original_status_extraction_unchanged=True)
                outcomes.write(json.dumps(outcome, ensure_ascii=False)+"\n")
                processed += 1
                if len(pending) == 256:
                    writer.write_table(pa.Table.from_pylist(pending, schema=schema))
                    pending.clear()
                if processed in (32, 100) or processed % 2048 == 0:
                    assert len(expected) == counts["additional_applied"]
                    print(f"RECOVERY rows={processed}/59455 additional_applied={counts['additional_applied']} seed={counts['already_applied_seed']} elapsed={time.monotonic()-started:.1f}s", flush=True)
            revisions.clear()
        if pending:
            writer.write_table(pa.Table.from_pylist(pending, schema=schema))
    assert processed == 59455 and counts["already_applied_seed"] == 33
    readback = 0
    for batch in pq.ParquetFile(target).iter_batches(batch_size=4096, use_threads=False):
        for bound in batch.to_pylist():
            assert bound == expected.pop(bound["occurrence_id"])
            assert primary_rows[bound["occurrence_id"]]["processing_revision_id"] is None and bound["occurrence_id"] not in seed_bindings
            readback += 1
    assert not expected and readback == counts["additional_applied"]
    ledger_rows = 0
    with gzip.open(output / "outcomes59455.jsonl.gz", "rt", encoding="utf-8") as stream:
        for line in stream:
            outcome = json.loads(line)
            assert outcome["original"]["occurrence_id"] in primary_rows
            ledger_rows += 1
    assert ledger_rows == 59455 and digest(BASE) == BASE_SHA and digest(PRIMARY) == primary_sha
    receipt = dict(status="PASS", counts=dict(counts), active_review_rows=processed, excluded_rows_not_candidates=14215, base_rows_scanned=scanned,
        original_base_sha256=BASE_SHA, primary_binding_sha256=primary_sha, seed_overlay_sha256=digest(seed_path),
        additional_overlay_path=str(target), additional_overlay_sha256=digest(target), additional_overlay_readback_rows=readback,
        total_supplemental_bindings_applied=readback+33, outcome_ledger_readback_rows=ledger_rows,
        saved_raw_catalog_sha256=digest(output / "saved_raw_catalog.json"), cache_counts=dict(cache_counts), receipt_scan_count=len(paths),
        malformed_or_unreadable_receipts=len(errors), conflicting_raw_revisions=len(conflicting_revisions), active_text_utf8_bytes=text_bytes,
        matching_scope="all59455 unsupported REVIEW occurrences against enumerated existing saved raw API receipts/registries; no claim that no other cache exists",
        representative_policy="preserve seed33; otherwise highest numeric saved exact-matching revision ID on verified same page; preserve all alternatives",
        accepted_nonnull_overrides=0, duplicate_supplemental_occurrence_ids=0, base_primary_source_extraction_eligibility_original_status_unchanged=True,
        no_network_normalization_models_or_production_batch=True, elapsed_seconds=round(time.monotonic()-started,3), code_sha256=digest(Path(__file__)), backup_status="Unprotected")
    with (output / "binding_receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2), flush=True)


def verify_applied():
    """Independent persisted-ledger/base join and exact alternative readback."""
    import pyarrow as pa
    import pyarrow.parquet as pq
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    output = ROOT / "review_treatments" / "applied_full_review_saved_raw"
    receipt = json.loads((output / "binding_receipt.json").read_text())
    assert digest(BASE) == BASE_SHA and digest(PRIMARY) == receipt["primary_binding_sha256"]
    seed_path = ROOT / "review_treatments" / "applied_seed33" / "processing_revision_bindings.parquet"
    seed = {r["occurrence_id"]: r for r in pq.read_table(seed_path, use_threads=False).to_pylist()}
    combined = dict(seed)
    for row in pq.read_table(output / "processing_revision_bindings.parquet", use_threads=False).to_pylist():
        assert row["occurrence_id"] not in combined
        combined[row["occurrence_id"]] = row
    assert len(seed) == 33 and len(combined) == 1366
    with (output / "saved_raw_catalog.json").open(encoding="utf-8") as stream:
        catalog = json.load(stream)["catalog"]
    ledger, match_checks, counts, sources, pages, examples = {}, defaultdict(list), Counter(), set(), set(), []
    with gzip.open(output / "outcomes59455.jsonl.gz", "rt", encoding="utf-8") as stream:
        for line in stream:
            outcome = json.loads(line)
            row = outcome["original"]
            assert row["source_row_index"] not in ledger
            ledger[row["source_row_index"]] = outcome
            matches, selected = outcome["exact_matching_saved_revisions"], outcome["selected_processing_representative"]
            counts["retained_outcomes"] += 1
            if selected:
                assert selected in matches
                expected_selection = next(m for m in matches if m["revision_id"] == seed[row["occurrence_id"]]["processing_revision_id"]) if row["occurrence_id"] in seed else max(matches, key=lambda m: (m["revision_id"], m["catalog_key"]))
                assert selected == expected_selection
                bound = combined[row["occurrence_id"]]
                revision = catalog[selected["catalog_key"]]["revision"]
                expected_status = "VERIFIED_CONTAINING_SUPPORT_EXTRACTION_UNKNOWN" if len(selected["positions"]) == 1 else "CONTAINING_SUPPORT_NONUNIQUE_PASSAGE"
                assert bound == bind_record(dict(row, attribution_status=expected_status, containing_support_revision_id=revision["revision_id"], source_revision_sha256=revision["sha256"]))
                sources.add(row["Source"])
                pages.add(row["page_id"])
                counts["applied"] += 1
                counts["multiple_matching_revisions"] += len(matches) > 1
                if len(examples) < 8 and (not examples or row["Source"] not in {e["Source"] for e in examples}):
                    examples.append(dict(source_row_index=row["source_row_index"], Source=row["Source"], page_id=row["page_id"], word=row["word"],
                        original_attribution=row["attribution_status"], original_scope=row["source_scope_status"], original_eligible=row["processing_eligible"],
                        selected_revision=revision["revision_id"], selected_sha256=revision["sha256"], all_matches=matches,
                        passage_preview=row["Text"][:200], original_start=row["start"], original_end=row["end"]))
            else:
                assert row["occurrence_id"] not in combined and not matches
                counts["unmatched"] += 1
            for match in matches:
                revision = catalog[match["catalog_key"]]["revision"]
                assert revision["page_id"] == row["page_id"] and revision["revision_id"] == match["revision_id"]
                match_checks[match["catalog_key"]].append((row["Text"], match["positions"]))
    assert len(ledger) == 59455 and len({o["original"]["occurrence_id"] for o in ledger.values()}) == 59455
    fields = list(next(iter(ledger.values()))["original"])
    base_verified, primary_verified = 0, 0
    for base_batch, primary_batch in zip(pq.ParquetFile(BASE).iter_batches(batch_size=4096, columns=fields, use_threads=False),
                                         pq.ParquetFile(PRIMARY).iter_batches(batch_size=4096, use_threads=False), strict=True):
        for row, primary in zip(base_batch.to_pylist(), primary_batch.to_pylist(), strict=True):
            if row["source_row_index"] in ledger:
                assert ledger[row["source_row_index"]]["original"] == row
                assert primary["processing_revision_id"] is None
                assert all(primary[k] == row[k] for k in ("source_row_index", "occurrence_id", "wiki_site", "page_id"))
                base_verified += 1
                primary_verified += 1
    exact_checks = 0
    for key, checks in match_checks.items():
        raw = validate_revision(catalog[key]["revision"])
        for text, expected_positions in checks:
            assert positions(raw, text) == expected_positions
            exact_checks += 1
    assert base_verified == primary_verified == 59455 and exact_checks == 3501
    assert digest(BASE) == BASE_SHA and digest(PRIMARY) == receipt["primary_binding_sha256"]
    verified = dict(status="PASS", counts=dict(counts), base_rows_independently_joined=base_verified, primary_nulls_independently_verified=primary_verified,
        distinct_applied_sources=len(sources), distinct_applied_pages=len(pages), matching_raw_revisions_independently_API_hash_validated=len(match_checks),
        exact_matching_revision_alternatives_independently_recomputed=exact_checks, accepted_nonnull_overrides=0, duplicate_overlay_or_ledger_ids=0,
        schema_columns=COLUMNS, source_base_primary_extraction_eligibility_original_status_unchanged=True, examples=examples,
        full_overlay_sha256=digest(output / "processing_revision_bindings.parquet"), seed_overlay_sha256=digest(seed_path),
        outcome_ledger_sha256=digest(output / "outcomes59455.jsonl.gz"), backup_status="Unprotected")
    with (output / "independent_readback.json").open("x", encoding="utf-8") as stream:
        json.dump(verified, stream, indent=2, ensure_ascii=False)
    print(json.dumps({k:v for k,v in verified.items() if k != "examples"}, indent=2), flush=True)


def verify_source_custody():
    output = ROOT / "review_treatments" / "applied_full_review_saved_raw"
    assert digest(BROAD) == BROAD_SHA
    with gzip.open(BROAD, "rt", encoding="utf-8") as stream:
        records = json.load(stream)
    source_bindings = {r["source_key"]: r for r in records}
    assert len(records) == len(source_bindings) == 5693
    checked = 0
    with gzip.open(output / "outcomes59455.jsonl.gz", "rt", encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)["original"]
            binding = source_bindings[row["Source"]]
            assert binding["source_key"] == row["Source"] and binding["wiki_page_id"] == row["page_id"] and row["wiki_site"] == "enwiki"
            checked += 1
    assert checked == 59455
    receipt = dict(status="PASS", exact_original_source_key_physical_page_checks=checked, source_index_sha256=BROAD_SHA,
        no_canonical_qid_substitution=True, outcome_ledger_sha256=digest(output / "outcomes59455.jsonl.gz"))
    with (output / "source_identity_custody.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2))


def materialize_cumulative():
    import pyarrow as pa
    import pyarrow.parquet as pq
    pa.set_cpu_count(1)
    pa.set_io_thread_count(1)
    output = ROOT / "review_treatments" / "applied_full_review_saved_raw"
    full_receipt = json.loads((output / "binding_receipt.json").read_text())
    assert digest(BASE) == BASE_SHA and digest(PRIMARY) == full_receipt["primary_binding_sha256"]
    seed_path = ROOT / "review_treatments" / "applied_seed33" / "processing_revision_bindings.parquet"
    additional_path = output / "processing_revision_bindings.parquet"
    assert digest(seed_path) == full_receipt["seed_overlay_sha256"] and digest(additional_path) == full_receipt["additional_overlay_sha256"]
    rows = pq.read_table(seed_path, use_threads=False).to_pylist() + pq.read_table(additional_path, use_threads=False).to_pylist()
    assert len(rows) == len({r["occurrence_id"] for r in rows}) == 1366
    rows.sort(key=lambda row: row["source_row_index"])
    primary = {r["occurrence_id"]: r for r in pq.read_table(PRIMARY, filters=[("source_row_index", "in", [r["source_row_index"] for r in rows])], use_threads=False).to_pylist()}
    for row in rows:
        prior = primary[row["occurrence_id"]]
        assert prior["processing_revision_id"] is None
        assert all(row[key] == prior[key] for key in ("source_row_index", "occurrence_id", "wiki_site", "page_id"))
    schema = pq.ParquetFile(PRIMARY).schema_arrow.with_metadata({b"base_parquet_sha256": BASE_SHA.encode(),
        b"primary_binding_sha256": full_receipt["primary_binding_sha256"].encode(), b"revision_role": b"PROCESSING support; extraction unchanged",
        b"overlay_rule": b"one cumulative null-only supplement; replaces seed33 and additional1333 staging overlays; do not stack staging overlays",
        b"eligibility": b"unchanged"})
    target = output / "processing_revision_bindings_all_applied.parquet"
    assert not target.exists() and schema.names == COLUMNS
    pq.write_table(pa.Table.from_pylist(rows, schema=schema), target, compression="zstd")
    assert pq.read_table(target, use_threads=False).to_pylist() == rows
    assert digest(BASE) == BASE_SHA and digest(PRIMARY) == full_receipt["primary_binding_sha256"]
    receipt = dict(status="PASS", applied_bindings=1366, readback_rows=1366, accepted_nonnull_overrides=0, duplicate_occurrence_ids=0,
        cumulative_overlay_path=str(target), cumulative_overlay_sha256=digest(target), base_sha256=BASE_SHA,
        primary_binding_sha256=full_receipt["primary_binding_sha256"], schema_columns=COLUMNS,
        usage="Use primary plus this cumulative overlay; do not additionally stack seed33/additional1333 staging overlays",
        original_source_status_extraction_eligibility_unchanged=True, all59455_outcomes_retained=True,
        independent_readback_sha256=digest(output / "independent_readback.json"),
        source_identity_custody_sha256=digest(output / "source_identity_custody.json"), backup_status="Unprotected")
    with (output / "cumulative_binding_receipt.json").open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--apply-seed", action="store_true")
    parser.add_argument("--apply-all-saved", action="store_true")
    parser.add_argument("--verify-applied", action="store_true")
    parser.add_argument("--verify-source-custody", action="store_true")
    parser.add_argument("--materialize-cumulative", action="store_true")
    args = parser.parse_args()
    self_check()
    if args.preview:
        preview()
    if args.apply_seed:
        apply_seed()
    if args.apply_all_saved:
        apply_all_saved()
    if args.verify_applied:
        verify_applied()
    if args.verify_source_custody:
        verify_source_custody()
    if args.materialize_cumulative:
        materialize_cumulative()
