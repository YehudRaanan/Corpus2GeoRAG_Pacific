"""Grounded note/span components; original rows and source policies stay recorded.

FineWiki uses rendered HTML and excludes citations/references. This small raw-
wikitext treatment preserves explanatory visible components under owner direction;
plain unrecognized bibliographic/reference content stays explicitly unresolved.
"""
import argparse
from collections import Counter
from functools import lru_cache
import gzip,hashlib,json,time
from pathlib import Path
import mwparserfromhell as mw
import pyarrow as pa
import pyarrow.parquet as pq
from GG_Data.entity_resolution.hundred_page_pilot.clean_source_text import clean_text,_clean_page,CleanText
from GG_Data.entity_resolution.hundred_page_pilot.filter_source_content import source_intervals,classify_span,citation_only_ref,EXCLUDE_ROLES,REVIEW_ROLES,normal
from GG_Data.entity_resolution.hundred_page_pilot.prepare_mentions import positions,source_occurrences
from GG_Data.entity_resolution.hundred_page_pilot.recover_page_qids import template_targets
from GG_Data.entity_resolution.hundred_page_pilot.collect_entities import validate_revision
cached_intervals=lru_cache(maxsize=4)(source_intervals)
cached_clean=lru_cache(maxsize=4)(_clean_page)
cached_templates=lru_cache(maxsize=4)(template_targets)
cached_names=lru_cache(maxsize=4)(lambda raw:source_occurrences(raw,[],[]))


def treatment(raw,row,passage_start):
    """Return source-backed visible content without rewriting the input row."""
    if raw[passage_start:passage_start+len(row['Text'])] != row['Text']:
        raise ValueError('Passage/revision evidence mismatch')
    left,right=passage_start+row['start'],passage_start+row['end']
    spans,headings=cached_intervals(raw)
    original=classify_span(left,right,spans,headings)
    base=dict(current_classification=original,origin_frame='VERIFIED_REVISION_CHARACTER_OFFSETS')
    if original['status']=='EXCLUDE':
        return dict(base,status='excluded',reason='existing_noncontent_rule',effective_classification=original)
    refs=[(a,b) for a,b,role,detail in spans if role=='reference_note' and detail=='ref' and a<=left<right<=b]
    if len(refs)==1:
        a,b=refs[0];literal=raw[a:b];node=mw.parse(literal).nodes[0]
        body=str(node.contents);offset=a+literal.find('>')+1
        if raw[offset:offset+len(body)]!=body:raise ValueError('Reference body does not roundtrip')
        if citation_only_ref(body):
            return dict(base,status='excluded',reason='complete_short_citation')
        cleaned=_note_clean(body)
        projection=_project(cleaned,offset,left,right,whole=True)
        if projection['status']!='mapped':return dict(base,**projection)
        group=next((normal(attr.value) for attr in node.attributes if normal(attr.name)=='group'),'')
        # Explicit explanatory-note grouping supports retention; a plain book/
        # web reference is rendered but is not silently declared narrative prose.
        if group not in {'note','notes'}:
            return dict(base,**dict(projection,status='pending'),reason='visible_reference_retention_unresolved')
        return dict(base,**projection,reason='visible_explanatory_note',effective_classification=dict(status='KEEP',reason='visible_explanatory_note'))
    if original['reason']=='notes_section':
        projection=_project(clean_text(row['Text']),passage_start,left,right,whole=True)
        return dict(base,**dict(projection,status='pending'),reason='notes_section_visible_rendered_retention_unresolved')
    if original['reason']!='partial_source_overlap':
        return dict(base,status='pending',reason='outside_targeted_treatments')
    # Permit proven markup/control removal, never crossing into other content.
    syntax={'parameter_key','template_control','hidden_link_target','tag_markup'}
    dangerous=(set(EXCLUDE_ROLES)-syntax)|set(REVIEW_ROLES)
    if any(a<right and left<b and role in dangerous for a,b,role,_ in spans):
        return dict(base,status='pending',reason='crosses_excluded_or_uncertain_content_no_clipping')
    templates=[t for t in cached_templates(raw) if t['template_status']=='SUPPORTED_DOCUMENTED_SHIP_TARGET' and t['raw_start']<=left<right<=t['raw_end']]
    if len(templates)==1 and '|' in row['word']:
        t=templates[0];a,b=t['raw_start'],t['raw_end']
        projection=_project(clean_text(raw[a:b]),a,a,b,whole=True)
        return dict(base,**projection,reason='unique_documented_template_display',source_rule=t['target_rule'],supported_template=dict(raw_start=a,raw_end=b,raw_text=raw[a:b],documented_display=t['display_name'],target_title=t['target_title']),effective_classification=dict(status='KEEP',reason='supported_visible_display'))
    projection=_project(cached_clean(raw),0,left,right)
    candidates=[dict(surface=o['surface'],raw_start=o['raw_start'],raw_end=o['raw_end'],method=o['method'])
                for o in cached_names(raw) if o['method'] in {'ordinary_link_anchor','documented_template_target'}
                and o['raw_start']<right and left<o['raw_end']]
    constructs=[(a,b) for a,b,role,_ in spans if role=='link_construct' and a<right and left<b]
    # The older name collector masks table prose; parser link spans still prove
    # that a table-cell crossing contains separate source names.
    if max(len(set(constructs)),len({(o['raw_start'],o['raw_end']) for o in candidates}))>1 and projection['status']=='mapped':
        return dict(base,**dict(projection,status='pending'),reason='multiple_independent_source_names_no_identity_completion',source_candidates=candidates,source_construct_spans=constructs,effective_classification=dict(status='REVIEW',reason='compound_source_occurrences'))
    return dict(base,**projection,reason='supported_visible_span_markup_only' if projection['status']=='mapped' else 'incomplete_visible_span',effective_classification=dict(status='KEEP' if projection['status']=='mapped' else 'REVIEW',reason='source_origin_projection'))


def _project(cleaned,offset,left,right,whole=False):
    """Keep all displayed characters for this span, with their real origins."""
    start,end=left-offset,right-offset
    if any(a<end and start<b for a,b in cleaned.review_spans):
        return dict(status='pending',projection_reason='unsupported_rendering')
    indices=[i for i,(a,b) in enumerate(cleaned.origins) if a<end and start<b or a==b and start<=a<end]
    if not indices:return dict(status='excluded',projection_reason='no_visible_source_characters')
    if any(a<b and not start<=a<b<=end for a,b in (cleaned.origins[i] for i in indices)):
        return dict(status='pending',projection_reason='partial_decoded_character')
    first,last=indices[0],indices[-1]+1
    if indices!=list(range(first,last)):
        return dict(status='pending',projection_reason='noncontiguous_display_no_clipping')
    a,b=(0,len(cleaned.text)) if whole else (first,last)
    return dict(status='mapped',effective_surface=cleaned.text[first:last],component_text=cleaned.text[a:b],component_origins=[(x+offset,y+offset) for x,y in cleaned.origins[a:b]],effective_start=first-a,effective_end=last-a)


def toy(raw,word):
    left=raw.index(word)
    return dict(Text=raw,word=word,start=left,end=left+len(word))


def self_check():
    raw='<ref group=Note>Japan advanced. {{cite book|author=Smith}}</ref>'
    result=treatment(raw,toy(raw,'Japan'),0)
    assert result['status']=='mapped' and result['effective_surface']=='Japan','Explanatory visible note must survive'
    assert 'Smith' not in result['component_text']
    raw='<ref>Smith (2002), p. 7</ref>'
    assert treatment(raw,toy(raw,'Smith'),0)['status']=='excluded'
    raw='<ref group=Note>Japan {{cite book|author=Smith}} reached Italy.</ref>'
    assert treatment(raw,toy(raw,'Italy'),0)['status']=='mapped'
    raw='General [[Robert Blake (USMC)|Robert Blake]] served.'
    assert treatment(raw,toy(raw,'General [[Robert Blake (USMC)|Robert Blake'),0)['effective_surface']=='General Robert Blake'
    raw='The ship {{USS|Texas|BB-35}} served.'
    assert treatment(raw,toy(raw,'Texas|BB-35'),0)['effective_surface']=='USS Texas (BB-35)'
    raw='Commander <ref>Wendel, database</ref>'
    assert treatment(raw,toy(raw,'Commander <ref>Wendel'),0)['status']=='pending'
    raw='[[One]] and [[Two]] served.'
    result=treatment(raw,toy(raw,'One]] and [[Two'),0)
    assert result['status']=='pending' and result['component_text']=='One and Two','Two independent source names must not become one completed entity'
    raw="<ref group=Note>{{cite book|author=Smith}}<nowiki>''</nowiki>Japan advanced.</ref>"
    assert treatment(raw,toy(raw,'Japan'),0)['effective_surface']=='Japan'
    print('PASS: 8 basic treatments; notes/citations, source origins, known template display, no clipping or compound identity')


def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def _note_clean(body):
    """Keep explicit nowiki contents literal; reuse the cleaner for other nodes."""
    if '<nowiki' not in body.lower():return clean_text(body)
    text=[];origins=[];reviews=[];cursor=0
    for node in mw.parse(body).nodes:
        literal=str(node)
        if type(node).__name__=='Tag' and normal(node.tag)=='nowiki' and not node.self_closing:
            contents=str(node.contents);opening=literal.find('>')+1
            if literal[opening:opening+len(contents)]!=contents:raise ValueError('Literal nowiki offset mismatch')
            text.append(contents)
            origins.extend((cursor+opening+i,cursor+opening+i+1) for i in range(len(contents)))
        else:
            part=clean_text(literal);text.append(part.text)
            origins.extend((a+cursor,b+cursor) for a,b in part.origins)
            reviews.extend((a+cursor,b+cursor) for a,b in part.review_spans)
        cursor+=len(literal)
    return CleanText(''.join(text),origins,reviews,[],len(body))


def sample():
    started=time.monotonic();pa.set_cpu_count(1);pa.set_io_thread_count(1)
    base=Path(r"D:\Projects\GeoAI-incremental-dev-20261101\ingestion\full_ingestion_20261101\mentions.parquet")
    base_sha='68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d'
    assert digest(base)==base_sha
    old=Path(r"D:\Projects\GeoAI-luke-pilot-20261028\Data\external\hundred_page_pilot_20261028\revisions.parquet")
    assert digest(old)=='e12be0977b16175cf9a9cd1766ee26ae780f3da467e001e230795ac806008f60'
    registry={(r['page_id'],r['revision_id']):r for r in pq.read_table(old).to_pylist()}
    broad=Path(r"D:\Projects\GeoAI-simplified-agent-20261030\Data\external\simplified_agent_20261030\page_acquisition\page_sources.json.gz")
    assert digest(broad)=='b37da8892dd96094bb151b43d262d5ff0c42286a3e71f9980d9197e4b025fac5'
    with gzip.open(broad,'rt',encoding='utf-8') as stream:
        for r in json.load(stream):
            key=r['wiki_page_id'],r['revision_id']
            registry.setdefault(key,dict(page_id=key[0],revision_id=key[1],wikitext_path=r['raw_path'],sha256=r['raw_sha256'],evidence_path=r['evidence']))
    wanted={16,40,333,334,335,336,338,362,464,521,622,735,759,14442}
    fields=['source_row_index','occurrence_id','Source','Text','word','start','end','page_id','containing_support_revision_id','source_revision_sha256','source_scope_status','source_scope_reason','clean_status','attribution_status','extraction_revision_id','processing_eligible']
    chosen=[];notes_extra=False;scanned=0
    for batch in pq.ParquetFile(base).iter_batches(batch_size=2048,columns=fields,use_threads=False):
        for row in batch.to_pylist():
            scanned+=1
            if row['source_row_index'] in wanted or (row['source_scope_reason']=='notes_section' and not notes_extra):
                chosen.append(row);notes_extra=notes_extra or row['source_scope_reason']=='notes_section'
        if scanned>=16384:break
    pages={};results=[]
    for row in chosen:
        key=row['page_id'],row['containing_support_revision_id'];support=registry[key]
        assert support['sha256']==row['source_revision_sha256']
        if key not in pages:pages[key]=validate_revision(support)
        raw=pages[key];hits=positions(raw,row['Text'])
        result=treatment(raw,row,hits[0]) if len(hits)==1 else dict(status='pending',reason='nonunique original passage',alternatives=hits)
        if result['status']=='mapped' or 'effective_surface' in result:
            a,b=result['effective_start'],result['effective_end']
            assert result['component_text'][a:b]==result['effective_surface']
            assert len(result['component_text'])==len(result['component_origins'])
            assert all(0<=x<=y<=len(raw) for x,y in result['component_origins'])
        result.setdefault('effective_classification',dict(status='EXCLUDE' if result['status']=='excluded' else 'REVIEW',reason=result['reason']))
        results.append(dict(source_row_index=row['source_row_index'],occurrence_id=row['occurrence_id'],Source=row['Source'],page_id=key[0],containing_support_revision_id=key[1],raw_sha256=support['sha256'],raw_path=support['wikitext_path'],evidence_path=support['evidence_path'],original_word=row['word'],original_scope_status=row['source_scope_status'],original_scope_reason=row['source_scope_reason'],original_clean_status=row['clean_status'],original_start=row['start'],original_end=row['end'],extraction_revision_id=row['extraction_revision_id'],processing_eligible=row['processing_eligible'],**result))
    assert digest(base)==base_sha
    source_root=Path(r"D:\Projects\GeoAI-luke-pilot-20261028\GG_Data\entity_resolution\hundred_page_pilot")
    report=dict(status='PASS',sample='Purposeful early examples, not representative; selected IDs plus first notes_section if present in first16384 rows',rows_scanned=scanned,sampled_rows=len(results),full_category_counts={'reference_note':68148,'partial_source_overlap':41936,'notes_section':324},sampled_category_counts=dict(Counter(r['original_scope_reason'] for r in results)),outcomes=dict(Counter(r['status'] for r in results)),verified_raw_revisions=len(pages),results=results,base_sha256=base_sha,base_unchanged=True,no_identity_assignment=True,no_batch_eligibility_promotion=True,source_hashes={str(source_root/name):digest(source_root/name) for name in ('clean_source_text.py','filter_source_content.py','prepare_mentions.py','recover_page_qids.py')},original_reference=dict(name='FineWiki',input='rendered Enterprise HTML, not raw wikitext',checked_commit='71306a3fed631b8c1a77e5479eb9edddc8866003',historical_reviewed_pin='unknown',source_url='https://huggingface.co/datasets/HuggingFaceFW/finewiki/blob/71306a3fed631b8c1a77e5479eb9edddc8866003/src/2_extraction/run_extraction.py',helpers=['WikipediaParser.process_document','get_plaintext','custom_html_to_plaintext'],rules='Citation and Reference types excluded; compiled_ref_words headings and div.reflist/div.mw-references-wrap removed; no evidenced semantic exemption for explanatory notes',comparison='local raw adapter adds three unconditional raw note drops; explicit explanatory-note component preservation here follows current owner direction, not a claim FineWiki retains all notes'),elapsed_seconds=round(time.monotonic()-started,3),code_sha256=digest(Path(__file__)))
    target=Path(__file__).parent/'notes_and_spans_sample_v3.json'
    if target.exists():raise FileExistsError('Preserve prior treatment evidence')
    target.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in {'results','source_hashes','original_reference'}},indent=2),flush=True)
    for r in results:print(json.dumps(dict(row=r['source_row_index'],before=r['original_word'],after=r.get('effective_surface'),status=r['status'],reason=r['reason']),ensure_ascii=True),flush=True)


def apply_span_chunk(start_row,limit):
    """Write one immutable, read-back-checked mechanical overlay; no release gate."""
    if start_row<0 or not 1<=limit<=1000:raise ValueError('Choose a nonnegative cursor and 1..1000 candidates')
    started=time.monotonic();pa.set_cpu_count(1);pa.set_io_thread_count(1)
    base=Path(r"D:\Projects\GeoAI-incremental-dev-20261101\ingestion\full_ingestion_20261101\mentions.parquet")
    base_sha='68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d'
    assert digest(base)==base_sha
    output=Path(__file__).parent/'span_application';output.mkdir(exist_ok=True)
    helper_sha=digest(Path(__file__));snapshot=output/'helper_snapshot.py.txt'
    if snapshot.exists():assert digest(snapshot)==helper_sha,'Helper changed after freeze'
    else:snapshot.write_bytes(Path(__file__).read_bytes())
    target=output/f'span_{start_row:09d}.jsonl'
    receipt_path=target.with_suffix('.receipt.json')
    if target.exists() or receipt_path.exists():raise FileExistsError('Keep old chunks; choose the next recorded cursor')
    old=Path(r"D:\Projects\GeoAI-luke-pilot-20261028\Data\external\hundred_page_pilot_20261028\revisions.parquet")
    assert digest(old)=='e12be0977b16175cf9a9cd1766ee26ae780f3da467e001e230795ac806008f60'
    registry={(r['page_id'],r['revision_id']):r for r in pq.read_table(old).to_pylist()}
    broad=Path(r"D:\Projects\GeoAI-simplified-agent-20261030\Data\external\simplified_agent_20261030\page_acquisition\page_sources.json.gz")
    assert digest(broad)=='b37da8892dd96094bb151b43d262d5ff0c42286a3e71f9980d9197e4b025fac5'
    with gzip.open(broad,'rt',encoding='utf-8') as stream:
        for r in json.load(stream):
            key=r['wiki_page_id'],r['revision_id'];registry.setdefault(key,dict(page_id=key[0],revision_id=key[1],wikitext_path=r['raw_path'],sha256=r['raw_sha256'],evidence_path=r['evidence']))
    @lru_cache(maxsize=4)
    def verified_page(page,revision):return validate_revision(registry[page,revision])
    original_fields=['entity_group','score','word','start','end','Source','Index','Text','subtype']
    fields=original_fields+['source_row_index','occurrence_id','wiki_site','page_id','containing_support_revision_id','source_revision_sha256','source_scope_status','source_scope_reason','clean_status','attribution_status','extraction_revision_id','processing_eligible']
    file=pq.ParquetFile(base);first_group=0;group_start=0
    while first_group<file.num_row_groups and group_start+file.metadata.row_group(first_group).num_rows<=start_row:
        group_start+=file.metadata.row_group(first_group).num_rows;first_group+=1
    chosen=[];cursor=start_row;scanned=0
    for batch in file.iter_batches(batch_size=2048,row_groups=range(first_group,file.num_row_groups),columns=fields,use_threads=False):
        for row in batch.to_pylist():
            if row['source_row_index']<start_row:continue
            scanned+=1;cursor=row['source_row_index']+1
            if row['source_scope_status']=='REVIEW' and row['source_scope_reason']=='partial_source_overlap':chosen.append(row)
            if len(chosen)==limit:break
        if len(chosen)==limit:break
    records=[];counts=Counter();pages=set()
    for row in chosen:
        key=row['page_id'],row['containing_support_revision_id'];support=registry.get(key)
        result=dict(status='pending',reason='PENDING_NO_VERIFIED_SUPPORT')
        if support is not None and row['attribution_status'] in {'VERIFIED_CONTAINING_SUPPORT_EXTRACTION_UNKNOWN','CONTAINING_SUPPORT_NONUNIQUE_PASSAGE'}:
            assert support['sha256']==row['source_revision_sha256']
            raw=verified_page(*key);pages.add(key);hits=positions(raw,row['Text'])
            if len(hits)!=1:result=dict(status='pending',reason='PENDING_NONUNIQUE_PASSAGE',alternatives=hits)
            else:
                left,right=hits[0]+row['start'],hits[0]+row['end'];spans,headings=cached_intervals(raw)
                current=classify_span(left,right,spans,headings)
                # No global reference/note prose retention is authorized here.
                ref_crossing=any(a<right and left<b and role in {'reference_note','citation'} for a,b,role,_ in spans)
                in_notes=bool({normal(s) for s in current['sections']} & {'notes','footnotes','explanatory notes'})
                if ref_crossing or in_notes:result=dict(status='pending',reason='PENDING_REFERENCE_POLICY',current_classification=current)
                else:result=treatment(raw,row,hits[0])
        status='APPLIED' if result['status']=='mapped' else 'PENDING'
        reason=result['reason'];counts[status]+=1;counts[status+':'+reason]+=1
        if status=='APPLIED':
            a,b=result['effective_start'],result['effective_end']
            assert result['component_text'][a:b]==result['effective_surface']
            assert len(result['component_text'])==len(result['component_origins'])
            assert all(0<=x<=y<=len(raw) for x,y in result['component_origins'])
        records.append(dict(source_row_index=row['source_row_index'],occurrence_id=row['occurrence_id'],base_sha256=base_sha,
            original=row,application_status=status,application_reason=reason,
            transformed_word=result.get('effective_surface'),transformed_context=result.get('component_text'),
            context_scope='VERIFIED_SOURCE_COMPONENT_ONLY; original full passage retained',
            provenance=dict(page_id=key[0],containing_support_revision_id=key[1],raw_sha256=row['source_revision_sha256'],raw_path=support['wikitext_path'] if support else None,evidence_path=support['evidence_path'] if support else None),treatment=result))
    with target.open('x',encoding='utf-8') as stream:
        for record in records:stream.write(json.dumps(record,ensure_ascii=False)+'\n')
    loaded=[json.loads(line) for line in target.open(encoding='utf-8')]
    assert [json.dumps(r,sort_keys=True) for r in loaded]==[json.dumps(r,sort_keys=True) for r in records]
    assert len({r['occurrence_id'] for r in loaded})==len(loaded)
    assert digest(base)==base_sha and digest(Path(__file__))==helper_sha
    receipt=dict(status='PASS',start_row=start_row,next_row=cursor,eof=cursor>=file.metadata.num_rows,
        candidates=len(records),rows_scanned=scanned,counts=dict(counts),verified_page_revisions=len(pages),
        helper_sha256=helper_sha,base_sha256=base_sha,output_path=str(target),output_sha256=digest(target),output_bytes=target.stat().st_size,
        readback_rows=len(loaded),original_fields_preserved=True,reference_policy_held=True,identity_or_type_changed=False,
        eligibility_changed=False,production_batches_released=False,elapsed_seconds=round(time.monotonic()-started,3),backup_status='Unprotected')
    receipt_path.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    (output/'progress.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps(receipt,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sample',action='store_true');parser.add_argument('--apply-spans',action='store_true')
    parser.add_argument('--start-row',type=int,default=0);parser.add_argument('--limit',type=int,default=100)
    args=parser.parse_args();self_check()
    if args.sample:sample()
    if args.apply_spans:apply_span_chunk(args.start_row,args.limit)
