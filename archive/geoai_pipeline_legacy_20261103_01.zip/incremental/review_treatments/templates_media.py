"""Bounded development-only AST treatment proposals, never eligibility decisions.

Reuses local source-text-v3/article-source-v3 mechanics. FineWiki was a design
reference, not an installed renderer; no arbitrary template expansion is claimed.
All offsets are Python characters, end-exclusive, in saved containing wikitext.
"""
from pathlib import Path
import sys
import json
import hashlib
from functools import lru_cache
from collections import Counter, defaultdict
import re

PROJECT=Path(r'D:\Projects\GeoAI-luke-pilot-20261028')
sys.dont_write_bytecode=True
sys.path.insert(0,str(PROJECT))
import mwparserfromhell as mw
from GG_Data.entity_resolution.hundred_page_pilot.clean_source_text import clean_text,map_mention
from GG_Data.entity_resolution.hundred_page_pilot.filter_source_content import source_intervals,normal
from GG_Data.entity_resolution.hundred_page_pilot.prepare_mentions import positions

OWNED={'unknown_template','coordinates','media_review','image_field_review','gallery_review','template_name','unparsed_markup','protected_text'}
BASE=Path(r'D:\Projects\GeoAI-incremental-dev-20261101\ingestion\full_ingestion_20261101\mentions.parquet')
BASE_HASH='68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d'

@lru_cache(maxsize=2)
def page_ast(raw):
    spans,_=source_intervals(raw)
    code=mw.parse(raw)
    templates=[]
    for node in code.filter_templates():
        literal=str(node)
        for at in positions(raw,literal):
            templates.append({'start':at,'end':at+len(literal),'family':normal(node.name),'literal':literal,
                'parameters':[{'key':normal(p.name),'value':str(p.value),'explicit_key':p.showkey} for p in node.params]})
    return spans,code,templates

def treat_span(raw,left,right):
    if type(left) is not int or type(right) is not int or not 0<=left<right<=len(raw):
        raise ValueError('Invalid original source offsets')
    spans,code,templates=page_ast(raw)
    evidence=[s for s in spans if s[0]<=left<right<=s[1]]
    enclosing=sorted([t for t in templates if t['start']<=left<right<=t['end']],key=lambda t:t['end']-t['start'])
    result={'treatment':'genuinely_unresolved','reason':'unsupported_or_context_dependent_rendering','before':raw[left:right],
        'after':None,'source_start':left,'source_end':right,'evidence':evidence,'templates':enclosing,
        'scope':'development_proposal_only','eligibility_changed':False}
    # Exact AST names and explicit parameter/control fields are syntax even when
    # the containing template's rendering is unavailable. No value is guessed.
    syntax=next((s for s in evidence if s[2] in {'template_name','parameter_key','template_control'}),None)
    if syntax:
        if syntax[2]=='template_name' and any(s[2]=='unknown_template' for s in evidence):
            result['reason']='unknown_template_name_may_generate_visible_content'
            return result
        result.update(treatment='exclude_noncontent',reason='exact_ast_'+syntax[2],after='')
        return result
    # nowiki is a literal-text node, not a template renderer. Recover the exact
    # source slice without reparsing its contents (e.g. [[Tokyo]] stays literal).
    for node in code.filter_tags():
        if normal(node.tag)!='nowiki' or node.self_closing:
            continue
        literal=str(node)
        opening=literal.find('>')+1
        contents=str(node.contents)
        for at in positions(raw,literal):
            a=at+opening; b=a+len(contents)
            if a<=left<right<=b and raw[a:b]==contents:
                result.update(treatment='recover',reason='nowiki_exact_literal_text',after=raw[left:right],
                    recovered_container=contents,recovered_container_start=a)
                return result
    roles={s[2] for s in evidence}
    if roles & {'coordinates','media_review','gallery_review','image_field_review','unparsed_markup','protected_text'}:
        result['reason']='requires_specific_'+','.join(sorted(roles & OWNED))+'_rule'
        return result
    # The existing cleaner itself accepts/rejects supported display handlers,
    # duplicate keys, aliases, ship modes, and unknown wrappers. Never first-param.
    if enclosing:
        parent=enclosing[-1]
        local=clean_text(parent['literal'])
        mapped=map_mention(local,left-parent['start'],right-parent['start'])
        result['original_cleaner_mapping']=mapped
        if mapped['status']=='mapped':
            result.update(treatment='keep_transformed',reason='source_text_v3_exact_display_coverage',
                after=local.text[mapped['start']:mapped['end']],transformed_container=local.text)
    return result

def run_sample(output):
    import gzip
    import time
    import pyarrow as pa
    import pyarrow.parquet as pq
    import psutil
    started=time.monotonic()
    pa.set_cpu_count(1); pa.set_io_thread_count(1)
    with BASE.open('rb') as f:
        actual=hashlib.file_digest(f,'sha256').hexdigest()
    if actual!=BASE_HASH: raise ValueError('Validated base hash mismatch')
    output=Path(output)
    if output.exists(): raise FileExistsError(output)
    output.mkdir()
    f=pq.ParquetFile(BASE)
    columns=['source_row_index','Source','page_id','containing_support_revision_id','extraction_revision_id',
        'attribution_status','source_revision_sha256','Text','word','start','end','source_scope_reason']
    samples=defaultdict(list); seen=defaultdict(set); totals=Counter()
    for batch in f.iter_batches(batch_size=4096,columns=columns,use_threads=False):
        for row in batch.to_pylist():
            reason=row['source_scope_reason']
            if reason not in OWNED: continue
            totals[reason]+=1
            # Bounded, deterministic family/text diversity; not a random accuracy sample.
            prefix=row['Text'][:row['end']]
            names=re.findall(r'\{\{([^|{}\n]+)',prefix)
            signature=(names[-1].strip().casefold() if names and reason in {'unknown_template','template_name'} else row['Text'])
            cap=24 if reason=='unknown_template' else 8
            if len(samples[reason])<cap and signature not in seen[reason]:
                seen[reason].add(signature); samples[reason].append(row)
    old=PROJECT/'Data/external/hundred_page_pilot_20261028/revisions.parquet'
    revisions={(r['page_id'],r['revision_id']):r for r in pq.read_table(old).to_pylist()}
    broad=Path(r'D:\Projects\GeoAI-simplified-agent-20261030\Data\external\simplified_agent_20261030\page_acquisition\page_sources.json.gz')
    with gzip.open(broad,'rt',encoding='utf8') as stream:
        for r in json.load(stream):
            revisions.setdefault((r['wiki_page_id'],r['revision_id']),{'wikitext_path':r['raw_path'],'sha256':r['raw_sha256']})
    @lru_cache(maxsize=2)
    def saved(key):
        revision=revisions[key]; data=Path(revision['wikitext_path']).read_bytes()
        if hashlib.sha256(data).hexdigest()!=revision['sha256']: raise ValueError('Raw source hash changed')
        return data.decode('utf8'),revision
    cases=[]
    for category,rows in samples.items():
        for row in rows:
            raw,rev=saved((row['page_id'],row['containing_support_revision_id']))
            if rev['sha256']!=row['source_revision_sha256']: raise ValueError('Containing revision binding mismatch')
            places=positions(raw,row['Text'])
            if len(places)!=1: raise ValueError('Sample requires unique containing placement')
            a=places[0]+row['start']; b=places[0]+row['end']
            if raw[a:b]!=row['word']: raise ValueError('Original occurrence differs')
            proposal=treat_span(raw,a,b)
            cases.append({'base_row':row,'raw_path':rev['wikitext_path'],'passage_raw_start':places[0],
                'raw_context':raw[max(0,a-100):b+100],'proposal':proposal})
    report={'base_path':str(BASE),'base_sha256':actual,'base_rows':f.metadata.num_rows,'sample_method':'first distinct containing template family / passage per category; max24 unknown, max8 others; nonrepresentative',
        'category_totals':dict(totals),'sampled_category_coverage':{k:{'sampled':len(samples[k]),'total':totals[k]} for k in sorted(OWNED)},
        'treatment_counts':dict(Counter(c['proposal']['treatment'] for c in cases)),
        'source_fields_unchanged':True,'extraction_revision_claims_added':0,'eligibility_changed':False,
        'limitations':['No template expansion or historical rendering.','Proposals only; no base-row rewrite or processing promotion.','Unknown parent templates remain unresolved even if nested supported syntax exists.'],
        'elapsed_seconds':time.monotonic()-started,'rss_mb':psutil.Process().memory_info().rss/1048576,
        'cases':cases}
    (output/'template_media_cases.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'},ensure_ascii=False))

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sample-output',required=True,type=Path)
    run_sample(p.parse_args().sample_output)


