# Saved HTML coverage correction

The earlier rendered-cache report used an unnecessarily strict join requiring raw wikitext in the same parse receipt. Its 61-row count is the **raw+HTML receipt subset**, not the full same-revision HTML coverage.

A complete projected join by verified page and containing revision finds **2,620 unknown-template NER rows across 79 supports** with saved parse.text. In the earlier 76-case sample, five rows across three page/revision pairs have matching HTML-only receipts. Those receipts omit parse.wikitext, so a raw-payload content comparison is unavailable. The independent base files have zero CRLF sequences; no CRLF/Unicode-equivalent mismatch was identified in these candidates. Separate hashes and exact decoded-text checks are saved in rendered_unicode_identity_check.json; full corrected counts are in rendered_page_revision_coverage_correction.json.

This corrects coverage terminology. It does not provide invocation-level mapping: the inspected legacy HTML still has no data-mw or mw:Transclusion metadata. A structural family proposal can use actual representative navigation/noprint nodes without claiming exact expansion or raw-to-DOM invocation identity.
