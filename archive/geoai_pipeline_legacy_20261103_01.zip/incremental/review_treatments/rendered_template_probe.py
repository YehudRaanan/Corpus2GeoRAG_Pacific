"""Read saved parse receipts and require explicit template provenance boundaries.
No expansion, collection, HTML/source alignment by text search, or eligibility writes.
"""
from pathlib import Path
import sys,json,gzip,hashlib,re,time
from functools import lru_cache
from collections import Counter
sys.dont_write_bytecode=True
import mwparserfromhell as mw
from lxml import html as lhtml,etree
from templates_media import BASE,BASE_HASH,page_ast,positions,normal

CACHE_ROOT=Path(r'D:\Projects\GeoAI-source-page-ids-20261026\Data\external')
FOLDERS=['source_page_versions_history_20261027/requests','source_page_ids_history_pilot_20261027/requests','native_corpus_graphs_20261028/wiki_parse/requests']

def rendered_template_nodes(html,template_literal):
    """Return evidence nodes only for exact AST target/parameter data-mw identity.

    Multiple matches remain multiple; caller must not choose a first match. Text
    is rendered-node evidence, never an invented raw-source character mapping.
    """
    nodes=mw.parse(template_literal).filter_templates(recursive=False)
    if len(nodes)!=1 or str(nodes[0])!=template_literal:return []
    ast=nodes[0];params=[(normal(p.name),str(p.value)) for p in ast.params]
    if len({k for k,v in params})!=len(params):return []
    root=lhtml.fromstring(html,parser=lhtml.HTMLParser(no_network=True))
    found=[]
    for node in root.xpath('//*[@data-mw]'):
        if 'mw:Transclusion' not in node.get('typeof','').split():continue
        try:
            data=json.loads(node.get('data-mw'));parts=data['parts']
            if len(parts)!=1 or not isinstance(parts[0],dict):continue
            template=parts[0]['template']
            if normal(template['target']['wt'])!=normal(ast.name):continue
            supplied={normal(k):v['wt'] for k,v in template.get('params',{}).items()}
            if supplied!=dict(params):continue
        except (ValueError,KeyError,TypeError):continue
        found.append({'dom_path':root.getroottree().getpath(node),'node_html':etree.tostring(node,encoding='unicode'),
            'node_text':''.join(node.itertext()),'data_mw':data,'mapping_status':'rendered_boundary_only_no_raw_character_mapping'})
    return found

@lru_cache(maxsize=2)
def read_parse(path):
    data=Path(path).read_bytes();receipt=json.loads(gzip.decompress(data));parse=json.loads(receipt['response_text'])['parse']
    def value(key):
        v=parse.get(key,'');return v.get('*','') if isinstance(v,dict) else v
    return receipt,parse,value('text'),value('wikitext'),hashlib.sha256(data).hexdigest()

def run(output):
    import pyarrow as pa,pyarrow.parquet as pq,psutil
    started=time.monotonic();pa.set_cpu_count(1);pa.set_io_thread_count(1)
    output=Path(output)
    if output.exists():raise FileExistsError(output)
    with BASE.open('rb') as stream:
        if hashlib.file_digest(stream,'sha256').hexdigest()!=BASE_HASH:raise ValueError('Base changed')
    inventory=[];errors=[];files_scanned=Counter()
    for folder in FOLDERS:
        for path in (CACHE_ROOT/folder).glob('*.json.gz'):
            files_scanned[folder]+=1
            try:
                d=json.loads(gzip.decompress(path.read_bytes()))
                if d.get('params',{}).get('action')!='parse':continue
                p=json.loads(d['response_text']).get('parse')
                if not p:continue
                text=p.get('text','');text=text.get('*','') if isinstance(text,dict) else text
                raw=p.get('wikitext','');raw=raw.get('*','') if isinstance(raw,dict) else raw
                inventory.append({'path':str(path),'page_id':p.get('pageid'),'revision_id':p.get('revid'),
                    'raw_sha256':hashlib.sha256(raw.encode()).hexdigest() if raw else None,'raw_chars':len(raw),
                    'html_sha256':hashlib.sha256(text.encode()).hexdigest(),'html_chars':len(text),
                    'has_data_mw':bool(re.search(r'\bdata-mw\s*=',text)),'has_transclusion':'mw:Transclusion' in text,
                    'request_oldid':d.get('params',{}).get('oldid'),'request_prop':d.get('params',{}).get('prop')})
            except Exception as exc:errors.append({'path':str(path),'error':str(exc)})
    by_key={(r['page_id'],r['revision_id'],r['raw_sha256']):r for r in inventory if r['html_chars'] and r['raw_sha256']}
    f=pq.ParquetFile(BASE);matches=[]
    for batch in f.iter_batches(batch_size=4096,columns=['source_row_index','source_scope_reason','page_id','containing_support_revision_id','source_revision_sha256'],use_threads=False):
        for row in batch.to_pylist():
            if row['source_scope_reason']=='unknown_template':
                key=(row['page_id'],row['containing_support_revision_id'],row['source_revision_sha256'])
                if key in by_key:matches.append(row)
    wanted={r['source_row_index'] for r in matches};rows=[];cursor=0
    cols=['source_row_index','page_id','containing_support_revision_id','extraction_revision_id','source_revision_sha256','Source','Text','word','start','end']
    for group in range(f.num_row_groups):
        count=f.metadata.row_group(group).num_rows
        if any(cursor<=i<cursor+count for i in wanted):
            rows.extend(r for r in f.read_row_group(group,columns=cols,use_threads=False).to_pylist() if r['source_row_index'] in wanted)
        cursor+=count
    cases=[];families=set()
    for row in rows:
        key=(row['page_id'],row['containing_support_revision_id'],row['source_revision_sha256']);meta=by_key[key]
        receipt,p,html,raw,receipt_hash=read_parse(meta['path'])
        assert p['pageid']==key[0] and p['revid']==key[1] and hashlib.sha256(raw.encode()).hexdigest()==key[2]
        assert receipt['params']['oldid']==key[1]
        places=positions(raw,row['Text'])
        if len(places)!=1:continue
        a,b=places[0]+row['start'],places[0]+row['end'];assert raw[a:b]==row['word']
        _,_,templates=page_ast(raw)
        ts=sorted([t for t in templates if t['start']<=a<b<=t['end']],key=lambda t:t['end']-t['start'])
        if not ts or ts[0]['family'] in families:continue
        families.add(ts[0]['family']);t=ts[0]
        boundaries=rendered_template_nodes(html,t['literal'])
        dom=lhtml.fromstring(html,parser=lhtml.HTMLParser(no_network=True))
        cases.append({'original_evidence':row,'receipt_path':meta['path'],'receipt_sha256':receipt_hash,'raw_sha256':key[2],
            'html_sha256':meta['html_sha256'],'html_format':'legacy_action_parse_HTML','html_chars':len(html),
            'template':t,'raw_start':a,'raw_end':b,'before':raw[a:b],'after':None,
            'explicit_data_mw_nodes':len(dom.xpath('//*[@data-mw]')),'explicit_transclusion_nodes':len(dom.xpath('//*[contains(@typeof,"mw:Transclusion")]')),
            'matching_rendered_boundaries':boundaries,'treatment':'genuinely_unresolved',
            'reason':'same_revision_HTML_present_but_no_invocation_provenance_boundary','eligibility_changed':False})
        if len(cases)>=5:break
    initial=json.loads((Path(__file__).parent/'templates_media_sample_20261101_v3/template_media_cases.json').read_text(encoding='utf8'))
    sample_hits=sum((c['base_row']['page_id'],c['base_row']['containing_support_revision_id'],c['base_row']['source_revision_sha256']) in by_key for c in initial['cases'])
    report={'base_sha256':BASE_HASH,'base_rows':f.metadata.num_rows,'request_files_scanned':dict(files_scanned),
        'parse_payloads':len(inventory),'html_payloads':sum(bool(x['html_chars']) for x in inventory),
        'payloads_with_raw_and_html':sum(bool(x['html_chars'] and x['raw_chars']) for x in inventory),
        'payloads_with_data_mw':sum(x['has_data_mw'] for x in inventory),'payloads_with_transclusion':sum(x['has_transclusion'] for x in inventory),
        'original_76_sample_exact_cache_matches':sample_hits,'unknown_template_total':33827,'unknown_rows_exact_page_revision_rawhash_match':len(matches),
        'matched_support_keys':len({(r['page_id'],r['containing_support_revision_id'],r['source_revision_sha256']) for r in matches}),
        'matched_family_cases':len(cases),'new_unknown_rendering_proposals':0,'errors':errors,
        'limitations':'Inventory covers three named saved-cache roots only. Legacy API parse.text lacks invocation-level Parsoid metadata. No text-presence alignment or generated raw offsets.',
        'elapsed_seconds':time.monotonic()-started,'rss_mb':psutil.Process().memory_info().rss/1048576,
        'inventory':inventory,'cases':cases}
    output.mkdir();(output/'rendered_cache_probe.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k not in {'inventory','cases'}},ensure_ascii=False))
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path);run(p.parse_args().output)
