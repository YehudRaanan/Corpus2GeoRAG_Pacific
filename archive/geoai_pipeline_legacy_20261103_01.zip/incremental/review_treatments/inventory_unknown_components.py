"""Inventory exact source component TYPES and count components separately from NER.

Only reads the validated base and saved raw revisions. IN/OUT/HOLD are proposals.
This inventories NER-bearing REVIEW components, not every child in all5725 pages.
"""
from pathlib import Path
import sys,json,gzip,hashlib,re,time
from collections import Counter,defaultdict
from functools import lru_cache
sys.dont_write_bytecode=True
sys.path.insert(0,r'D:\Projects\GeoAI-incremental-dev-20261101\review_treatments')
from templates_media import BASE,BASE_HASH,PROJECT,mw,positions
from GG_Data.entity_resolution.hundred_page_pilot.filter_source_content import source_intervals,normal,BACK,RELATED,NOTES
REASONS={'unknown_template','media_review','gallery_review','image_field_review','unparsed_markup','coordinates','template_name','protected_text'}

def nodes_with_spans(raw):
    """Walk existing AST nodes; use the original cleaner's offset arithmetic."""
    found=[]
    def visit(code,offset,ancestors):
        cursor=offset
        for node in code.nodes:
            literal=str(node);kind=type(node).__name__;end=cursor+len(literal)
            record={'kind':kind,'start':cursor,'end':end,'literal':literal,'ancestor_types':ancestors,'name_exact':'','parameter_keys':[],'parameter_shape':[],'raw_attributes':[]}
            if kind=='Template':
                record['name_exact']=str(node.name)
                record['parameter_keys']=[str(p.name).strip() for p in node.params]
                record['parameter_shape']=[{'key':str(p.name).strip(),'explicit_key':p.showkey,'value_node_kinds':[type(x).__name__ for x in p.value.nodes]} for p in node.params]
            elif kind=='Tag':
                record['name_exact']=str(node.tag)
                record['raw_attributes']=[str(a) for a in node.attributes] if not node.wiki_markup else []
            elif kind=='Wikilink':record['name_exact']=str(node.title).split(':',1)[0] if ':' in str(node.title) else 'ordinary_link'
            elif kind=='Heading':record.update(name_exact=str(node.title),level=node.level)
            found.append(record)
            if kind=='Template':
                visit(node.name,cursor+2,ancestors+['Template'])
                at=cursor+2+len(str(node.name))
                for p in node.params:
                    value=str(p.value);left=at+1+len(str(p))-len(value)
                    found.append({'kind':'ParameterValue','start':left,'end':left+len(value),'literal':value,
                        'ancestor_types':ancestors+['Template'],'name_exact':str(p.name).strip(),'parameter_keys':[], 'parameter_shape':[],'raw_attributes':[]})
                    visit(p.value,left,ancestors+['Template','ParameterValue']);at+=1+len(str(p))
            elif kind=='Tag' and not node.self_closing and node.contents is not None:
                if node.wiki_markup:
                    opening=len(node.wiki_markup)+sum(len(str(a)) for a in node.attributes)+len(node.padding or '')+len(node.wiki_style_separator or '')
                else:opening=1+len(str(node.tag))+sum(len(str(a)) for a in node.attributes)+len(node.padding or '')+1
                if literal[opening:opening+len(str(node.contents))]!=str(node.contents):raise ValueError('Tag offset roundtrip failed')
                visit(node.contents,cursor+opening,ancestors+['Tag:'+str(node.tag)])
            elif kind=='Wikilink':
                visit(node.title,cursor+2,ancestors+['Wikilink'])
                if node.text is not None:visit(node.text,cursor+3+len(str(node.title)),ancestors+['Wikilink'])
            elif kind=='Heading':visit(node.title,cursor+node.level,ancestors+['Heading'])
            elif kind=='ExternalLink' and node.title is not None:
                visit(node.title,cursor+1+len(str(node.url))+(0 if node.suppress_space else 1),ancestors+['ExternalLink'])
            cursor=end
        if cursor!=offset+len(str(code)):raise ValueError('AST offset roundtrip failed')
    visit(mw.parse(raw),0,[])
    return found

@lru_cache(maxsize=512)
def local_roles(literal):
    return source_intervals(literal)[0]

def parameter_slot(container,nodes,left,right):
    if container['kind']!='Template':return ''
    direct=container['ancestor_types']+['Template']
    candidates=[n for n in nodes if n['kind']=='ParameterValue' and n['ancestor_types']==direct and container['start']<=n['start']<=left<right<=n['end']<=container['end']]
    if candidates:return min(candidates,key=lambda n:n['end']-n['start'])['name_exact']
    name_start=container['start']+2
    return '@template_name' if name_start<=left<right<=name_start+len(container['name_exact']) else '@cross_boundary'

def section_type(nodes,point):
    stack=[]
    for n in nodes:
        if n['kind']!='Heading' or n['ancestor_types'] or n['start']>point:continue
        while stack and stack[-1][0]>=n['level']:stack.pop()
        stack.append((n['level'],n['name_exact']))
    titles=[x[1] for x in stack];names={normal(t) for t in titles}
    kind='bibliographic' if names&BACK else 'related' if names&RELATED else 'notes' if names&NOTES else 'article_or_unspecified'
    return kind,titles

def proposed_rule(signature):
    name=signature['name_exact'].strip();low=normal(name);role=signature['primary_reason'];slot=normal(signature.get('mention_parameter_key',''))
    if role=='template_name':return 'OUT','supported template-name syntax only'
    if role=='protected_text' and low=='nowiki':return 'IN','literal protected text; do not parse markup inside'
    if role=='unparsed_markup':return 'HOLD','malformed source syntax requires a parser repair rule'
    if role=='coordinates':return 'HOLD','coordinate component; separate visible coordinate data from controls before entity use'
    maintenance={'failed verification','page range too broad','self-published inline','full citation needed','dead link','synthesis','as of?','refimprove','source?','not in source','use australian english','unreferenced','more citations needed','citation needed','clarification needed'}
    if low in maintenance:return 'OUT','maintenance component; noprint representative evidence for verified families'
    if slot in {'nolink','sort','sortkey','sort key','officeholder sort','image','image size','image width','style','class','width','align'}:return 'OUT','explicit sorting/image/style control field; separate from visible values'
    if low in {'other ships','about','for','redirect','distinguish'}:return 'OUT','navigation/disambiguation component TYPE proposal; no exact expansion claimed'
    if low in {'shipboxflag','ics','flagdeco','flagicon image'}:return 'OUT','decorative/encoded flag component TYPE proposal; no generated image/name expansion'
    if low in {'notelist','#tag:ref','notes','reflist'}:return 'HOLD','note/reference component TYPE; pending one owner policy decision on reference prose'
    if slot=='@template_name':return 'HOLD','unknown template name may itself generate body content; no blanket name exclusion'
    if low=='sortname' and slot in {'1','2'}:return 'IN','person-name display operands; sorting/link-control slots stay separate'
    if low in {'officeholder table','member','command structure','center','aircraft specs','weather box','dts','birth date','death date and age','ayd','marriage','inflation','inflation/fn','inflation/year'}:return 'IN','body table/text/date/numeric display component TYPE proposal; rendering operands are not automatically exact NER surfaces'
    if low in {'webarchive','deprecated archive'}:return 'OUT','archive/citation support component; not body prose'
    if low=='japanese nationalism sidebar':return 'OUT','representative saved HTML has sidebar role=navigation'
    if low in {'kia','navy','army','flagu','ill','bracket','translation','legend2'}:return 'IN','body display component proposed IN; generated rendering remains separate from raw mapping'
    if role in {'media_review','gallery_review'}:return 'IN','media text field candidate; file/option fields remain separate categories'
    if role=='image_field_review':
        field=signature.get('role_detail','').strip()
        if 'alt' in normal(field):return 'IN','accessibility text component; owner decides inclusion once for this type'
        if signature.get('filename_extension'):return 'OUT','media filename field, not caption text'
        return 'HOLD','mixed image-field shape; choose a uniform field-type rule'
    return 'HOLD','exact structural family retained for one category decision; no first-parameter expansion'

def run(output):
    import pyarrow as pa,pyarrow.parquet as pq,psutil
    pa.set_cpu_count(1);pa.set_io_thread_count(1);started=time.monotonic();output=Path(output)
    if output.exists():raise FileExistsError(output)
    output.mkdir()
    with BASE.open('rb') as stream:
        if hashlib.file_digest(stream,'sha256').hexdigest()!=BASE_HASH:raise ValueError('Base changed')
    grouped=defaultdict(list);texts={};totals=Counter();f=pq.ParquetFile(BASE)
    columns=['entity_group','score','word','start','end','Source','Index','Text','subtype','source_row_index','page_id','containing_support_revision_id','extraction_revision_id','source_revision_sha256','source_scope_reason']
    for batch in f.iter_batches(batch_size=4096,columns=columns,use_threads=False):
        for row in batch.to_pylist():
            if row['source_scope_reason'] not in REASONS:continue
            row['Text']=texts.setdefault(row['Text'],row['Text']);totals[row['source_scope_reason']]+=1
            grouped[row['page_id'],row['containing_support_revision_id']].append(row)
    revisions={(r['page_id'],r['revision_id']):r for r in pq.read_table(PROJECT/'Data/external/hundred_page_pilot_20261028/revisions.parquet').to_pylist()}
    index=Path(r'D:\Projects\GeoAI-simplified-agent-20261030\Data\external\simplified_agent_20261030\page_acquisition\page_sources.json.gz')
    with gzip.open(index,'rt',encoding='utf8') as stream:
        for r in json.load(stream):revisions.setdefault((r['wiki_page_id'],r['revision_id']),{'wikitext_path':r['raw_path'],'sha256':r['raw_sha256']})
    categories={};family_totals={};processed=0;instance_count=0;unmapped=[];physical_components=set()
    with (output/'component_instances.jsonl').open('w',encoding='utf8') as writer:
        for pages_done,(key,rows) in enumerate(grouped.items(),1):
            rev=revisions[key];data=Path(rev['wikitext_path']).read_bytes();digest=hashlib.sha256(data).hexdigest()
            if digest!=rev['sha256']:raise ValueError('Raw hash changed')
            raw=data.decode('utf8');nodes=nodes_with_spans(raw);placements={};instances={};full_context_spans=None
            for row in rows:
                assert row['source_revision_sha256']==digest
                text=row['Text'];places=placements.setdefault(text,positions(raw,text))
                if len(places)!=1:raise ValueError('Base REVIEW category lacks unique raw placement')
                left,right=places[0]+row['start'],places[0]+row['end'];assert raw[left:right]==row['word']
                reason=row['source_scope_reason']
                enclosing=sorted([n for n in nodes if n['start']<=left<right<=n['end']],key=lambda n:n['end']-n['start'])
                selection=None
                for container in enclosing:
                    if container['kind'] not in {'Template','Tag','Wikilink','Text'}:continue
                    roles=[s for s in local_roles(container['literal']) if s[2]==reason and s[0]<=left-container['start']<right-container['start']<=s[1]]
                    if roles:
                        span=min(roles,key=lambda s:s[1]-s[0]);selection=(container,container['start']+span[0],container['start']+span[1],span[3]);break
                if selection is None:
                    # Some original roles depend on surrounding source. Reuse the
                    # complete page policy rather than inventing word-sized nodes.
                    if full_context_spans is None:full_context_spans=source_intervals(raw)[0]
                    roles=[s for s in full_context_spans if s[2]==reason and s[0]<=left<right<=s[1]]
                    if roles:
                        span=min(roles,key=lambda s:s[1]-s[0]);a,b=span[:2]
                        containers=[n for n in nodes if n['start']<=a<b<=n['end']]
                        container=min(containers,key=lambda n:n['end']-n['start']) if containers else {'kind':'RawSourceConstruct','start':a,'end':b,'name_exact':span[3],'parameter_shape':[],'parameter_keys':[],'ancestor_types':[],'raw_attributes':[]}
                        selection=(container,a,b,span[3])
                    else:
                        container=enclosing[0] if enclosing else {'kind':'RawText','start':left,'end':right,'name_exact':'','parameter_shape':[],'parameter_keys':[],'ancestor_types':[],'raw_attributes':[]}
                        selection=(container,left,right,'UNRESOLVED_LOCAL_CONTEXT');unmapped.append(row['source_row_index'])
                container,a,b,detail=selection;section,titles=section_type(nodes,left)
                signature={'primary_reason':reason,'container_kind':container['kind'],'name_exact':container['name_exact'],
                    'mention_parameter_key':parameter_slot(container,nodes,left,right),'parameter_shape':container['parameter_shape'],'duplicate_parameter_keys':[k for k,n in Counter(container['parameter_keys']).items() if n>1],
                    'ancestor_types':container['ancestor_types'],'section_type':section,'role_detail':detail,
                    'component_value_node_kinds':[type(n).__name__ for n in mw.parse(raw[a:b]).nodes],
                    'raw_attributes':container['raw_attributes']}
                extension=re.search(r'(?i)\.([a-z0-9]{2,5})(?:\s|$|\{)',raw[a:b])
                if reason=='image_field_review' and extension:signature['filename_extension']=extension.group(1).lower()
                encoded=json.dumps(signature,ensure_ascii=False,sort_keys=True);category=hashlib.sha256(encoded.encode()).hexdigest()[:16]
                identity=(a,b,category)
                if identity not in instances:
                    proposal,rule=proposed_rule(signature)
                    instances[identity]={'component_id':f'{key[0]}:{key[1]}:{a}:{b}:{category}','physical_component_id':f'{key[0]}:{key[1]}:{a}:{b}','category_id':category,'signature':signature,
                        'proposed_type_rule':proposal,'proposal_reason':rule,'approved':False,'page_id':key[0],'containing_support_revision_id':key[1],
                        'raw_sha256':digest,'raw_path':rev['wikitext_path'],'raw_start':a,'raw_end':b,'OriginalRawText':raw[a:b],
                        'section_titles':titles,'ner_occurrences':[]}
                instances[identity]['ner_occurrences'].append(dict(row,raw_mention_start=left,raw_mention_end=right,passage_raw_start=places[0]))
            for instance in instances.values():
                writer.write(json.dumps(instance,ensure_ascii=False)+'\n');instance_count+=1;physical_components.add(instance['physical_component_id'])
                cid=instance['category_id'];count=len(instance['ner_occurrences'])
                summary=categories.setdefault(cid,{'category_id':cid,'signature':instance['signature'],'proposed_type_rule':instance['proposed_type_rule'],
                    'proposal_reason':instance['proposal_reason'],'approved':False,'component_instances':0,'ner_rows':0,'examples':[]})
                summary['component_instances']+=1;summary['ner_rows']+=count
                if len(summary['examples'])<3:summary['examples'].append({k:instance[k] for k in ['component_id','page_id','containing_support_revision_id','raw_sha256','raw_start','raw_end','OriginalRawText']}|{'source_row_indices':[x['source_row_index'] for x in instance['ner_occurrences']]})
                family=(instance['signature']['primary_reason'],instance['signature']['container_kind'],instance['signature']['name_exact'])
                family_key=json.dumps(family,ensure_ascii=False)
                fam=family_totals.setdefault(family_key,{'primary_reason':family[0],'container_kind':family[1],'name_exact':family[2],'component_instances':0,'ner_rows':0,'category_ids':set(),'physical_ids':set(),'examples':[]})
                fam['physical_ids'].add(instance['physical_component_id']);fam['component_instances']=len(fam['physical_ids']);fam['ner_rows']+=count;fam['category_ids'].add(cid)
                if len(fam['examples'])<2:fam['examples'].append(summary['examples'][-1])
            processed+=len(rows)
            if len(grouped)==0:raise ValueError('No selected rows')
            if processed%1000<len(rows):
                progress={'processed_ner_rows':processed,'selected_ner_rows':sum(totals.values()),'page_revisions_completed':pages_done, 'component_instances':instance_count,'categories':len(categories),'elapsed_seconds':round(time.monotonic()-started,2),'rss_mb':round(psutil.Process().memory_info().rss/1048576,1)}
                (output/'progress.json').write_text(json.dumps(progress,indent=2),encoding='utf8');print(json.dumps(progress),flush=True)
    for fam in family_totals.values():
        fam['category_ids']=sorted(fam['category_ids']);del fam['physical_ids']
    report={'base_sha256':BASE_HASH,'base_rows':f.metadata.num_rows,'selected_primary_reason_counts':dict(totals),'ner_rows':processed,
        'distinct_component_instances':len(physical_components),'category_component_assignments':instance_count,'exact_structural_categories':len(categories),'page_revisions_parsed':len(grouped),
        'scope':'ALL NER-bearing components in eight named base REVIEW reasons; NOT all raw-page children or all5725 revisions',
        'unmatched_local_role_rows':unmapped,'original_fields_changed':False,'policy_applied':False,'elapsed_seconds':time.monotonic()-started,
        'rss_mb':psutil.Process().memory_info().rss/1048576,'families':sorted(family_totals.values(),key=lambda x:-x['ner_rows']),
        'categories':sorted(categories.values(),key=lambda x:-x['ner_rows'])}
    (output/'grouped_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:v for k,v in report.items() if k not in {'families','categories','unmatched_local_role_rows'}},ensure_ascii=False),flush=True)
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path);run(p.parse_args().output)

