from inventory_unknown_components import nodes_with_spans
raw='A {{navy|{{flag|Japan}}|1=X|1=Y}} B'
nodes=nodes_with_spans(raw)
templates=[n for n in nodes if n['kind']=='Template']
assert len(templates)==2,templates
for n in nodes:assert raw[n['start']:n['end']]==n['literal']
outer=templates[0]
assert outer['name_exact']=='navy' and outer['parameter_keys']==['1','1','1']
assert templates[1]['ancestor_types']==['Template','ParameterValue']
raw='<ref>{{KIA}}</ref>\n<gallery>File:X.jpg|caption</gallery>'
nodes=nodes_with_spans(raw)
assert any(n['kind']=='Template' and n['ancestor_types']==['Tag:ref'] for n in nodes)
assert any(n['kind']=='Tag' and n['name_exact']=='gallery' for n in nodes)
print('4 AST inventory checks passed')
from inventory_unknown_components import section_type,parameter_slot
raw='{{outer|name={{lang|ja|Tokyo}}}}'
nodes=nodes_with_spans(raw);outer=next(n for n in nodes if n['kind']=='Template');left=raw.index('Tokyo')
assert parameter_slot(outer,nodes,left,left+5)=='name'
nodes=nodes_with_spans('{{quote|\n==Notes==\nText}}')
assert section_type(nodes,100)[0]=='article_or_unspecified'
print('2 context/parameter-slot checks passed')
