"""Run with the dedicated existing template-pilot Python; no test dependencies."""
from templates_media import treat_span

def check(raw, word, treatment, after=None):
    start=raw.index(word)
    result=treat_span(raw,start,start+len(word))
    assert result['treatment']==treatment, (raw,result)
    if after is not None:
        assert result['after']==after, result

check('{{Campaignbox Japan}}','Japan','genuinely_unresolved')
check('{{KIA}}','KIA','genuinely_unresolved')
check('{{Infobox military person|name=Tokyo}}','military person','exclude_noncontent')
check('{{lang|ja|[[Tokyo]]}}','Tokyo','keep_transformed','Tokyo')
check('{{navy|Empire of Japan}}','Empire of Japan','genuinely_unresolved')
check('<nowiki>[[Tokyo]]</nowiki>','Tokyo','recover','Tokyo')
check('{{quote|text=Tokyo|1=Osaka}}','Tokyo','genuinely_unresolved')
check('{{coord|27|03|S|154|12|E|display=inline}}','S','genuinely_unresolved')
check('broken {{quote|Tokyo','Tokyo','genuinely_unresolved')
print('9 checks passed')

