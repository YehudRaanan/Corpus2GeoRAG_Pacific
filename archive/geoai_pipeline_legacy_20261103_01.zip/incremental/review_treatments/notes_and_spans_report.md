# Grounded note and boundary treatments — completed bounded increment

Eight basic checks pass after observed RED failures. The final same-case sample passed: **14 verified occurrences, 8 mapped components, 1 existing citation exclusion, 5 pending**. Runtime 1.375 seconds; exit 0. This is supporting evidence only, not a global rewrite or batch release.

## Original implementation versus the local adaptation

FineWiki is the original reference; mwparserfromhell is the local parser, not that original extraction system. The accepted `docs/superpowers/plans/2026-10-29-source-preserving-text-cleaner.md` explicitly calls this a small local cleaner rather than a full FineWiki HTML deployment.

Comparison source: https://huggingface.co/datasets/HuggingFaceFW/finewiki/blob/71306a3fed631b8c1a77e5479eb9edddc8866003/src/2_extraction/run_extraction.py . This is the currently checked commit, not a proven historical reviewed pin. `WikipediaParser.process_document`/`get_plaintext` exclude Citation and Reference objects on rendered Enterprise HTML; `custom_html_to_plaintext` removes reference-list containers and compiled reference headings. No semantic explanatory-note exemption was evidenced. Templates there are already expanded HTML.

Our raw-wikitext adapter instead omits note content in three places: `_clean_page` masks reference_note and NOTES sections; `clean_text` drops ref/references tags; its template handler drops efn/refn/note families. This explains row333 loss without blaming a missing extraction revision. Explanatory-note preservation here follows the current owner direction, not a claim FineWiki retains all references.

## What the new file actually does

- Renders explicit explanatory `<ref group=Note>` body components using existing `clean_text`, retaining full source-character origins and known ship-template displays. Nested cite templates remain removed. Literal nowiki content is retained literally with its own character origins.
- Reconstructs complete visible boundary spans by the existing full-source origin projection; rank and visible name both survive. It does not find a shorter matching substring or assign a QID.
- For a unique documented ship template crossing, uses that template’s actual display control. Row464 maps to Texas because the source template explicitly selects name-only display; BB-35 remains in the unchanged raw evidence.
- Checks independent source occurrences and parser link spans. The older name collector masks table prose, so its empty candidate set cannot prove a table span is one entity. Row735 therefore retains rendered text but stays pending.
- Refuses to clip a mention spanning prose into reference content (row759), and preserves ambiguous plain reference content as rendered evidence rather than blanket accepting or dropping it.

## Actual cases

| Row | Page / containing revision | Original mention | Component result | Treatment |
|---:|---|---|---|---|
| 16 | 48975579 / 1375061414 | Enright\|Ryan | — | excluded: existing_noncontent_rule |
| 40 | 48975579 / 1375061414 | United States [[Twentieth Air Force | United States Twentieth Air Force | mapped: supported_visible_span_markup_only |
| 333 | 8385178 / 1360005623 | 1942 | 1942 | mapped: visible_explanatory_note |
| 334 | 8385178 / 1360005623 | World War II | World War II | mapped: visible_explanatory_note |
| 335 | 8385178 / 1360005623 | Yorktown | Yorktown | mapped: visible_explanatory_note |
| 336 | 8385178 / 1360005623 | CV-10 | CV-10 | mapped: visible_explanatory_note |
| 338 | 8385178 / 1360005623 | Mark 1 | Mark 1 | pending: visible_reference_retention_unresolved |
| 362 | 8385178 / 1360005623 | Frank | Frank | pending: visible_reference_retention_unresolved |
| 464 | 8385178 / 1360005623 | Texas\|BB-35 | Texas | mapped: unique_documented_template_display |
| 521 | 64096955 / 1372397745 | Lieutenant Colonel [[Robert Blake (USMC)\|Robert Blake | Lieutenant Colonel Robert Blake | mapped: supported_visible_span_markup_only |
| 622 | 64096955 / 1372397745 | Pacific]] Special Order Number 104 | Pacific Special Order Number 104 | mapped: supported_visible_span_markup_only |
| 735 | 13404868 / 1212134108 | Combined Fleet]] \|\| [[Southern Expeditionary Fleet (Imperial Japanese Navy)#Southern Expeditionary Fleet/1st Southern Expeditionary Fleet\|IJN | Combined Fleet  IJN | pending: multiple_independent_source_names_no_identity_completion |
| 759 | 13404868 / 1212134108 | Commander in chief''' <ref>Wendel | — | pending: crosses_excluded_or_uncertain_content_no_clipping |
| 14442 | 28013065 / 1380888738 | Kurombo Gama | Kurombo Gama | pending: visible_reference_retention_unresolved |

Row333 component text: “Though the guns were starting to be replaced by 1942, it served to the end of World War II on some ships such as USS Yorktown (CV-10).”

## Coverage and next actionable distinction

This purposeful sample inspected 16,384 projected early rows to select 7 reference_note, 6 partial_source_overlap and 1 known citation control case, across 5 raw revisions. It does not estimate recovery rates for the full 68,148 reference_note or 41,936 partial_source_overlap categories. None of the 324 notes_section cases occurred in this bounded selection; that branch has no real-case acceptance claim here.

The remaining issues are concrete: row362 is a full author/book/publisher/year/ASIN reference that the existing short-citation recognizer does not recognize; adding that documented bibliography format is a parser-coverage increment, not a need to adjudicate every author manually. Row338 is a web-reference title. Row14442 mixes cited quotation and prose; the rendered text and literal punctuation now survive. Whether such reference-body narrative belongs in accepted GeoAI source scope is the genuine Reference-exclusion versus narrative-retention choice. Row735 is a compound mention and row759 crosses content components; neither should become a clipped single identity.

## Provenance and verification

All raw sources were verified by `validate_revision` against exact page/revision/API text and hashes, with prior-registry precedence before broad cache. Base SHA256 is unchanged: `68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d`. Original rows, Source, extraction_revision_id, processing bindings, scope and eligibility are unchanged; no original code or frozen caption helper changed. No network, model, install, Git or production batches. Backup: Unprotected.

Reused local functions: `filter_source_content.source_intervals`, `classify_span`, `citation_only_ref`; `clean_source_text.clean_text`, `_clean_page`; `prepare_mentions.source_occurrences`; `recover_page_qids.template_targets`. Their exact current SHA256 values match the frozen ingestion pins:

- `D:\Projects\GeoAI-luke-pilot-20261028\GG_Data\entity_resolution\hundred_page_pilot\clean_source_text.py`: `40c57302ed57ee6770cf9850285cd84c06a76ae41fbd717df53b3c5ea2fad0f6`
- `D:\Projects\GeoAI-luke-pilot-20261028\GG_Data\entity_resolution\hundred_page_pilot\filter_source_content.py`: `631c8b11b230824762698e95d5bd49b01ecc77fe16f10e8a4cd2a05229759577`
- `D:\Projects\GeoAI-luke-pilot-20261028\GG_Data\entity_resolution\hundred_page_pilot\prepare_mentions.py`: `fce2579152b8b3e085bfba455814f5cd59d73d1eb3662c3faba856cda23a7f4a`
- `D:\Projects\GeoAI-luke-pilot-20261028\GG_Data\entity_resolution\hundred_page_pilot\recover_page_qids.py`: `ccace67971d38b72b3a0c325a08229c21944e6748060e46967772fe7dad5c270`

Final code SHA256: `268a47e919e1e19d91aa5beae51ac8ad5490de738d88ddeedd7d8fc68d43ccda`. Full per-character origins, raw paths, original/effective classifications and source spans are in `notes_and_spans_sample_v3.json`. Earlier v1/v2 reports are retained as development evidence; v3 is the final result.

Command: `D:\Projects\GeoAI-luke-pilot-20261028\.venv-template-pilot\Scripts\python.exe -B notes_and_spans.py --sample`, with PYTHONPATH pointing to that project, PYTHONDONTWRITEBYTECODE=1, UTF-8 output and OMP/OPENBLAS/MKL threads=1.


## Supplemental notes_section coverage

The follow-up in `notes_section_followup.md` / `.json` now verifies two actual Notes-section examples from different pages: row48806 bibliography and row53355 source attribution. This closes the zero-example category gap; it does not verify all324 or establish a representative recovery rate. Existing treatment code and base are unchanged.
