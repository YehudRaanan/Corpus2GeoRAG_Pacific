from rendered_template_probe import rendered_template_nodes
legacy='<p>Imperial Japanese Navy</p>'
assert rendered_template_nodes(legacy,'{{navy|Empire of Japan}}')==[]
parsoid='''<span typeof="mw:Transclusion" data-mw='{"parts":[{"template":{"target":{"wt":"navy"},"params":{"1":{"wt":"Empire of Japan"}}}}]}'>Imperial Japanese Navy</span>'''
r=rendered_template_nodes(parsoid,'{{navy|Empire of Japan}}')
assert len(r)==1 and r[0]['node_text']=='Imperial Japanese Navy',r
assert rendered_template_nodes(parsoid,'{{navy|Australia}}')==[]
assert rendered_template_nodes(parsoid,'{{army|Empire of Japan}}')==[]
assert rendered_template_nodes(parsoid,'{{navy|Empire of Japan|1=Australia}}')==[]
print('5 rendered-boundary checks passed')
