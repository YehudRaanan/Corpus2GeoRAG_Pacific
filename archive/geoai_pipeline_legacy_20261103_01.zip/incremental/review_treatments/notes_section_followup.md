# Notes-section coverage follow-up

Two actual notes_section rows from different Sources/pages were verified against their exact containing raw revision and saved API evidence. They supplement the earlier 14-case report. This is **2 purposeful cases out of 324**, not a representative sample or verification of all 324.

## Actual before/after

1. Row **48806**, Source Q210606, page **1583220**, revision **1382148665**, exact heading **Notes**. Original text: `*Col H. Avery Chenoweth (2005) Semper Fi: The Definitive Illustrated History of the U.S. Marines`. Original word: `Col H. Avery Chenoweth`; original clean status: excluded. Visible component: `Col H. Avery Chenoweth (2005) Semper Fi: The Definitive Illustrated History of the U.S. Marines`, with source origins. This is a bibliography entry, not an explanatory statement about that person. Existing treatment status remains pending.

2. Row **53355**, Source Q130426, page **18009317**, revision **1318531827**, exact heading **Notes**. Original text: `*This article incorporates material from Japanese Wikipedia page [[:ja:第35師団_(日本軍)|第35師団 (日本軍)]], accessed 17 March 2016`. Original word: `Japanese`; original clean status: excluded. Visible component: `This article incorporates material from Japanese Wikipedia page 第35師団 (日本軍), accessed 17 March 2016`. This is source attribution, not a fact establishing an entity identity. Existing treatment remains pending.

Both are concrete non-narrative cases and must be distinguished from row333's actual explanatory note about guns serving through WWII. Their existence does not justify blanket keeping or dropping Notes sections.

## Original versus local mechanics

The checked FineWiki reference is commit 71306a3fed631b8c1a77e5479eb9edddc8866003. Its rendered-HTML extractor excludes Citation/Reference elements and suppresses headings using compiled_ref_words, with reference-list wrapper removal. It is not a raw-wikitext parser. Exact membership is now verified from the pinned vocabulary: enwiki contains `Further reading`, `References`, `See also`, `External links`, and `Notes`. Heading text uses get_text(strip=True), then case-sensitive membership. Both actual `Notes` headings therefore match structural suppression in this comparison source. This is not a claim of executed upstream output for the historical pages. The historical reviewed pin and matching historical rendered HTML remain unestablished.

Local mechanics are explicit: `normal(Notes)` becomes `notes`; `filter_source_content.NOTES` contains it; `classify_span` returns REVIEW/notes_section; `_clean_page` masks NOTES section content. The current `notes_and_spans` component branch renders visible text and source origins while keeping retention pending. No new rendering framework or retained-scope rule was added.

## Verification and limits

Selection projected reason/index/Source/page columns until row53355 (53,356 projected rows). Only two matching full row groups were read for detailed examples. Exact page/revision/raw hashes and API text binding were checked with the prior registry taking precedence. Base hash remained 68e9ce0229162a23b746195763f32c02c9b8295471724cf2773d7a60dbdf7e2d. Existing treatment code hash remains 268a47e919e1e19d91aa5beae51ac8ad5490de738d88ddeedd7d8fc68d43ccda.

Evidence: notes_section_followup.json contains original records, exact headings, raw/API paths and hashes, origin maps and treatment results. No source, base, extraction revision, processing binding, identity, eligibility or consumer field changed. No network, install, model, paid operation, Git or global application. Backup: Unprotected.

Pinned vocabulary evidence SHA256: `383b251d33f18ddfa2c1e29afed4ba11f6ff9efaa6ab7ddba98adc384c65d2b1`; local source: `C:\Users\User\Documents\Codex\2026-11-01\task\finewiki_compiled_ref_words_71306a3.json`. Footnotes and Explanatory notes are absent from this enwiki list; the broader local NOTES set is a separate adaptation.
