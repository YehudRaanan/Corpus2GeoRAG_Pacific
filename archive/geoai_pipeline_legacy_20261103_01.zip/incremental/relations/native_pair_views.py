"""Select native/inverse views from one complete declared snapshot frontier.

Input is existing build_graph output, not arbitrary edges or partial pair data.
This stage does not discover relations, compute co-occurrence, or change fields.
Run this file directly only for small generated-fixture checks.
"""


def select_native_views(edges):
    """Suppress only redundant derived inverses for pairs native both ways."""
    # Only actual native base assertions establish directional availability.
    native_pairs = {
        (edge["source"], edge["target"])
        for edge in edges
        if not edge.get("derived") and edge.get("source_edge_id") is None
    }
    selected = []
    for edge in edges:
        # Predicate names cannot tell us whether an assertion is native.
        is_reverse = (
            edge.get("derived") is True
            and edge.get("derived_direction") == "REVERSE"
            and edge.get("source_edge_id") is not None
        )
        source, target = edge["source"], edge["target"]
        both_native = (source, target) in native_pairs and (target, source) in native_pairs
        if is_reverse and source != target and both_native:
            continue  # Native facts already provide both directions for this pair.
        selected.append(edge)  # Preserve the original object and every field.
    return selected


def _self_check():
    """Exercise the actual exporter with generated rows and its real pinned lookup."""
    import csv
    from copy import deepcopy
    from pathlib import Path

    from GG_Data.pipeline.graph_export import build_graph
    from GG_Data.pipeline.test_graph_export import fixture

    # Reuse the existing tiny fixture, but bind its assertion to actual catalog rows.
    catalog_root = Path(r"D:\Projects\GeoAI\GG_Data\mapping")
    with (catalog_root / "RELATION_MAPPING_TABLE_v2.1.1.csv").open(encoding="utf-8-sig", newline="") as stream:
        mapping = next(row for row in csv.DictReader(stream)
                       if (row["source"], row["source_predicate"]) == ("Wikidata", "wd:P607"))
    with (catalog_root / "RELATION_DIRECTION_LOOKUP_v2.1.1.csv").open(encoding="utf-8-sig", newline="") as stream:
        directions = [row for row in csv.DictReader(stream)
                      if row["input_relation_id"] in {"wd:P607", "inverse:wd:P607"}]
    template = fixture()
    template["mapping"] = [mapping]
    template["directions"] = directions
    template["metadata"]["relation_map_version"] = "relation-map-v2.1.1"
    template["relations"][0].update(
        selected_source_predicate="wd:P607", level2_relation="wd:P607",
        level2_label=mapping["level2_relation_label"], level1_relation=mapping["level1_family"],
        relation_map_version="relation-map-v2.1.1",
    )
    base = template["relations"][0]
    forward = deepcopy(template)
    backward = deepcopy(template)
    backward["relations"][0].update(subject_entity_id="Q2", object_entity_id="Q1")
    both = deepcopy(template)
    both["relations"].append(dict(base, observation_id="obs-back", subject_entity_id="Q2", object_entity_id="Q1"))
    self_loop = deepcopy(template)
    self_loop["relations"][0]["object_entity_id"] = "Q1"
    unrelated = deepcopy(template)
    unrelated["entities"].append(dict(template["entities"][0], entity_id="Q3", name="Third"))
    unrelated["relations"].append(dict(base, observation_id="obs-third", subject_entity_id="Q3", object_entity_id="Q1"))
    independent = deepcopy(both)
    independent["relations"].insert(1, dict(base, observation_id="obs-independent", time_from="+1943-00-00T00:00:00Z"))
    cases = [
        ("forward-only", forward, ["obs-1", "obs-1::REVERSE"]),
        ("backward-only", backward, ["obs-1", "obs-1::REVERSE"]),
        ("both-native", both, ["obs-1", "obs-back"]),
        ("self-loop", self_loop, ["obs-1"]),
        ("unrelated-third", unrelated, ["obs-1", "obs-1::REVERSE", "obs-third", "obs-third::REVERSE"]),
        ("independent-assertions", independent, ["obs-1", "obs-independent", "obs-back"]),
    ]
    input_views = selected_views = native_assertions = 0
    for name, source, expected_ids in cases:
        source_before = deepcopy(source)
        graph, _ = build_graph(**source)
        edges_before = deepcopy(graph["edges"])
        selected = select_native_views(graph["edges"])
        assert [edge["id"] for edge in selected] == expected_ids, name + ": unexpected active views"
        # Every native assertion must survive as its unchanged original object.
        native_ids = {row["observation_id"] for row in source["relations"]}
        assert native_ids <= {edge["id"] for edge in selected}, name + ": native assertion lost"
        assert all(any(edge is original for original in graph["edges"]) for edge in selected), name + ": edge copied or rewritten"
        assert graph["edges"] == edges_before and source == source_before, name + ": input mutated"
        for edge in selected:
            if edge.get("source_edge_id"):
                assert edge["type"] == "inverse:wd:P607" and edge["derived_direction"] == "REVERSE"
                assert edge["count"] == 1 and edge["start_date"] == "+1942-00-00T00:00:00Z"
        input_views += len(graph["edges"])
        selected_views += len(selected)
        native_assertions += len(source["relations"])
    assert (input_views, selected_views, native_assertions) == (19, 14, 10)
    print("PASS: 6 generated pair cases; 19 producer views -> 14 active views; all 10 native assertions retained")
    print("Pinned real catalog: relation-map-v2.1.1, wd:P607 -> inverse:wd:P607; no fields rewritten")


if __name__ == "__main__":
    _self_check()

