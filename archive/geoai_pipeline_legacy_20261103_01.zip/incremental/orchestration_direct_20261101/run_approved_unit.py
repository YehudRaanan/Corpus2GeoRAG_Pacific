"""Pinned approved-decision file -> ONE first-unit run, with an atomic stage journal.
Example: python -B run_approved_unit.py manifest.json EXPECTED_SHA256
No inference, policy choice, external publication, or multi-unit aggregation.
"""
import argparse
import json
import sys
from pathlib import Path
from copy import deepcopy

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path[:0]=[str(HERE/'runtime_handoff_0001'),str(HERE/'runtime_seams_0001'),
              str(ROOT/'publisher_direct_20261101/component_materializer_0001')]
from decision_handoff import build_handoff
from advance_full_geometry import advance_full
from materialize_components import materialize_components
from refresh_full_chain_checkpoint import refresh_checkpoint,initialize
from cadence_caller import save
from decision_revision_hook import require_current,content_hash
from occurrence_decisions import SCOPE_FIELDS
from durable_unit import recover
from check_one_unit import read,digest


def pinned(descriptor):
    path=Path(descriptor['path'])
    if digest(path)!=descriptor['sha256']:raise ValueError('Pinned input changed: '+str(path))
    return read(path)


def context_json(context):
    value=deepcopy(context)
    for name in ('count_state','relation_state'):value[name]=list(value[name].values())
    return value


def context_state(value):
    result=deepcopy(value)
    for name in ('count_state','relation_state'):
        result[name]={tuple(versions[-1]['manifest'][k] for k in SCOPE_FIELDS):versions for versions in result[name]}
    return result


def reference_for(path,baseline,context,components,sealed_dir,unit_hash,prior_descriptors,decision_artifact):
    chain=deepcopy(pinned(dict(path=baseline['chain_path'],sha256=baseline['chain_sha256'])))
    counts=context['count_receipt']['projection']
    for name in ('count_receipt','relation_receipt'):require_current(context[name],context['count_state'])
    require_current(context['full_geometry']['receipt'],context['count_state'])
    version=counts['decision_version']
    for stage in ('approved_decisions','handoff','counts','relations','full_geometry','components'):
        chain['stages'][stage]=dict(status='COMPLETED',version=version)
    chain['stages']['counts'].update(accepted_occurrences=counts['accepted_occurrences'],pending_occurrences=counts['pending_occurrences'])
    # Baseline source/grouping/exact code binding is retained; this caller validates the NEW stages.
    chain['derived_stage_validation']=dict(code_path=str(Path(__file__)),code_sha256=digest(Path(__file__)),
        baseline_chain=baseline['chain_path'],baseline_sha256=baseline['chain_sha256'],decision_artifact=decision_artifact)
    receipt=read(Path(components['receipt_path']))
    if receipt['decision_binding']!=context['count_receipt']['decision_binding']:raise ValueError('Materialized frontier differs')
    files=[Path(sealed_dir)/name for name in ('seal.json','unit.private.json','source.private.bin')]
    files += [Path(components['receipt_path']),Path(components['receipt_path']).parent/'readback.json',
              Path(context['full_geometry']['receipt_path']),Path(decision_artifact['path']),Path(__file__)]
    for descriptor in prior_descriptors:
        files += [Path(descriptor['unit_directory'])/name for name in ('seal.json','unit.private.json','source.private.bin')]
    chain['verified_artifact_sha256'].update({str(p):digest(p) for p in files})
    chain['receipt_sha256'][str(Path(sealed_dir)/'seal.json')]=digest(Path(sealed_dir)/'seal.json')
    chain['receipt_sha256'][components['receipt_path']]=components['receipt_sha256']
    chain['verified_artifact_sha256'].update({str(Path(components['receipt_path']).parent.parent/name):h for name,h in receipt['artifact_sha256'].items()})
    save(path,chain)
    return dict(chain_path=str(path),chain_sha256=digest(path),unit_directory=str(sealed_dir),unit_sha256=unit_hash,prior_history=prior_descriptors)


def run_approved_unit(manifest_path,manifest_sha256,stop_after=None):
    manifest=pinned(dict(path=str(manifest_path),sha256=manifest_sha256))
    decisions=pinned(manifest['approved_decisions'])
    baseline=pinned(manifest['full_geometry_baseline'])
    bindings=pinned(manifest['geometry_bindings'])
    directory=Path(manifest['run_directory']).resolve()
    namespace=Path(manifest['publisher_output_directory']).resolve()
    if not directory.is_relative_to(HERE) or not namespace.is_relative_to((ROOT/'publisher_direct_20261101/orchestration_refresh_0001').resolve()):
        raise ValueError('Run outputs must remain in caller-owned directories')
    directory.mkdir(parents=True,exist_ok=True)
    journal_path=directory/'runner_state.json'
    if journal_path.exists():
        journal=read(journal_path)
        if journal['manifest_sha256']!=manifest_sha256 or journal['runner_sha256']!=digest(Path(__file__)):
            raise ValueError('Run manifest or caller code differs from the persisted run')
        for record in journal['stages'].values():pinned(record)
    else:
        journal=dict(manifest_sha256=manifest_sha256,runner_sha256=digest(Path(__file__)),stages={})
        save(journal_path,journal)
    def stage(name,operation):
        if name in journal['stages']:return pinned(journal['stages'][name])
        result=operation()
        if name=='checkpoint' and result['status']=='WAIT_LOCAL_CADENCE':return result
        path=directory/(name+'.json');save(path,result)
        journal['stages'][name]=dict(path=str(path),sha256=digest(path));save(journal_path,journal)
        if stop_after==name:raise RuntimeError('TEST_ONLY_STOP_AFTER_'+name)
        return result
    current=manifest['current_unit'];prior=[]
    for entry in current.get('prior_history',[]):
        loaded=recover(entry['unit_directory'],entry['unit_sha256'],prior_history=prior)
        if loaded['status']!='sealed':raise ValueError('Prior unit is unsealed')
        prior.append(loaded['handoff'])
    built=stage('handoff',lambda:build_handoff(directory/'sealed_successor',current_sealed_dir=current['unit_directory'],
        current_unit_sha256=current['unit_sha256'],prior_history=prior,supplied_decisions=decisions['decisions'],decision_version=decisions['decision_version']))
    loaded=recover(built['sealed_dir'],built['unit_sha256'],prior_history=built['prior_history'])
    source=(Path(built['sealed_dir'])/'source.private.bin').read_bytes()
    def project():
        context=None
        for index,unit in enumerate([*built['prior_history'],loaded['handoff']]):
            context=advance_full(directory/'projections'/str(index),context,unit,source,
                native_path=manifest['native_registry']['path'],native_hash=manifest['native_registry']['sha256'],
                geometry_bindings=bindings,geometry_bindings_sha256=content_hash(bindings),baseline=baseline,
                fragment_artifact_root=manifest['fragment_artifact_root'])
        return context_json(context)
    context=context_state(stage('projection',project))
    require_current(context['full_geometry']['receipt'],context['count_state'])
    for f,h in {**context['full_geometry']['receipt']['source_sha256'],**context['full_geometry']['receipt']['projection']['artifact_sha256']}.items():
        if digest(Path(f))!=h:raise ValueError('Persisted geometry source/output differs: '+f)
    namespace.mkdir(parents=True,exist_ok=True)
    def materialize():
        paths=[Path(built['sealed_dir'])/'seal.json',Path(built['sealed_dir'])/'unit.private.json',
               Path(context['full_geometry']['receipt_path']),directory/'projection.json',Path(manifest['approved_decisions']['path']),Path(__file__)]
        return materialize_components(namespace/'components',identity_state=context['count_state'],count_receipt=context['count_receipt'],
            relation_receipt=context['relation_receipt'],geometry_receipt=context['full_geometry']['receipt'],native_registry=manifest['native_registry'],
            source_receipts=[dict(path=str(p),sha256=digest(p)) for p in paths],consumer_root=manifest['consumer_root'])
    components=stage('materialize',materialize)
    if digest(Path(components['receipt_path']))!=components['receipt_sha256']:raise ValueError('Persisted component receipt changed')
    prior_descriptors=[*current.get('prior_history',[]),dict(unit_directory=current['unit_directory'],unit_sha256=current['unit_sha256'])]
    reference=reference_for(directory/'stage_chain.json',manifest['baseline_reference'],context,components,
                            built['sealed_dir'],built['unit_sha256'],prior_descriptors,manifest['approved_decisions'])
    timing=manifest['cadence'];cadence_state=directory/'cadence_state.json'
    initialize(cadence_state,timing['run_start'],timing['required_stages'])
    refresh_manifest=Path(components['receipt_path']).parent/'refresh_inputs.json'
    arguments=dict(manifest_path=refresh_manifest,manifest_sha256=digest(refresh_manifest),previous_snapshot=manifest['previous_snapshot'],
                   references=[reference],decision_time=timing['decision_time'],completed_at=timing['completed_at'],final_flush=timing.get('final_flush',False))
    checkpoint=stage('checkpoint',lambda:refresh_checkpoint(namespace/'snapshot',cadence_state,**arguments))
    if checkpoint['status']=='SUCCESS_LOCAL_CHECKPOINT_SIMULATION':
        refresh_checkpoint(namespace/'snapshot',cadence_state,**arguments,previous_result=checkpoint)
    return dict(status=checkpoint['status'],runner_state_path=str(journal_path),stages=journal['stages'],
                decision_version=built['decision_version'],checkpoint=checkpoint,first_unit_only=True,publication=False)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest');parser.add_argument('sha256');parser.add_argument('--stop-after',choices=['handoff','projection','materialize','checkpoint'])
    args=parser.parse_args()
    result=run_approved_unit(args.manifest,args.sha256,args.stop_after)
    print(json.dumps(dict(status=result['status'],runner_state=result['runner_state_path'],decision_version=result['decision_version'],publication=False)))
