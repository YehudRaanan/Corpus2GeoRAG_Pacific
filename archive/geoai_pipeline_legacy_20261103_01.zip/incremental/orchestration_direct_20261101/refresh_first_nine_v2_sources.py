"""Freeze the finished nine-unit v2 frontier with RELATIONS' released priority sources."""
from copy import deepcopy
from pathlib import Path
from run_ready_units import run_ready_units,pinned
from check_one_unit import read,digest
from reconcile_ready_units import record

HERE=Path(__file__).resolve().parent;OUT=HERE/'policy_v2_sources_0276_0001'

def refresh():
    OUT.mkdir(exist_ok=True)
    release=read(HERE.parent/'pair_relations_direct_20261101/accepted11_20_sources_0001/PRIORITY_Q218932_HANDOFF.json')
    assert release['status']=='VERIFIED_PARTIAL_PRIORITY_READY' and release['priority_Q218932_covered']
    registry=pinned(release['native_registry']);prior=read(HERE.parent/'pair_relations_direct_20261101/unit9_sources_0001/generation_003/native_registry.json')
    assert all(registry['selected_references'][qid]==row for qid,row in prior['selected_references'].items())
    cursor=read(HERE/'policy_v2_integration_0001/state/index.json');assert len(cursor['jobs'])==9
    result=read(HERE/'policy_v2_integration_0001/unit_10/unit_result.json')
    old_job=read(HERE/'policy_v2_integration_0001/unit_10/job.json')
    history=deepcopy(old_job['current_unit']['prior_history'])
    history.append({key:old_job['current_unit'][key] for key in ('unit_directory','unit_sha256')})
    routes=next(row['route_receipts'] for row in read(HERE/'route_receipt_generation_0002/receipt.json')['units'] if row['unit']==10)
    job=dict(old_job,mode='REPLAY_CURRENT',current_unit=dict(result['sealed_unit'],prior_history=history),
        output_directory=str(OUT/'unit_10'),publisher_output_directory=str(HERE.parent/'publisher_direct_20261101/orchestration_refresh_0001/policy_v2_first_nine_registry276'),route_receipts=routes)
    pin=record(OUT/'job.json',job)
    manifest=read(HERE/'policy_v2_integration_0001/manifest.json')
    manifest.update(initial_projection=cursor['projection'],native_registry=release['native_registry'],jobs=[pin],output_directory=str(OUT/'state'))
    manifest_pin=record(OUT/'manifest.json',manifest)
    print('PRIORITY SOURCE VERIFIED:Q218932; prior194 unchanged; independent frozen nine-unit consumer refresh',flush=True)
    print(run_ready_units(manifest_pin['path'],manifest_pin['sha256']),flush=True)

if __name__=='__main__':refresh()
