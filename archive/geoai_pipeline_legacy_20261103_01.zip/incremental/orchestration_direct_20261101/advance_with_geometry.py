"""One-unit relation chain plus a scoped geometry-support fragment; no publisher call."""
import json
import sys
from copy import deepcopy
from pathlib import Path
from shutil import copyfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'geometry_direct_20261101/identity_revision_0001'))
from check_invalidation import geometry_view, signature, active_occurrences
from advance_count_relations import advance, read, digest, recover, seal_unit, encoded, sha
from decision_revision_hook import require_current, content_hash, decision_binding


def advance_geometry(previous, handoff, source, native_path, native_hash, bindings, expected_binding_hash):
    if content_hash(bindings)!=expected_binding_hash:
        raise ValueError('Geometry support bindings differ from caller-pinned content')
    if any(b['owner_qid']!=b['source_handoff']['qid'] for b in bindings.values()):
        raise ValueError('Source geometry may not be relabelled to another owner')
    current = advance(previous,handoff,source,native_path,native_hash)
    require_current(current['count_receipt'],current['count_state'])
    require_current(current['relation_receipt'],current['count_state'])
    source_binding = dict(support_bindings_sha256=expected_binding_hash,
                          count_receipt_sha256=content_hash(current['count_receipt']),
                          relation_receipt_sha256=content_hash(current['relation_receipt']))
    prior = current.get('geometry_receipt')
    if prior is not None:
        try:
            require_current(prior,current['count_state'])
        except ValueError:
            pass
        else:
            if prior['projection']['source_binding']==source_binding:
                return current
    # Existing helper returns a scoped support fragment. Other geometry remains outside this update.
    projection = geometry_view(current['count_state'],bindings)
    projection['source_binding'] = source_binding
    receipt = dict(decision_binding=decision_binding(current['count_state']),projection=projection,
                   projection_sha256=content_hash(projection),scope_qids=sorted({b['owner_qid'] for b in bindings.values()}))
    require_current(receipt,current['count_state'])
    result = deepcopy(current)
    result['geometry_receipt'] = receipt
    result['geometry_history'] = [*result.get('geometry_history',[]),deepcopy(receipt)]
    return result


def check(output):
    original = ROOT / 'integration_direct_20261101/real_handoff_0001'
    source_receipt = read(original / 'receipt.json')
    geo = ROOT / 'geometry_direct_20261101/tokyo_handoff_0001'
    geo_receipt = read(geo / 'verification.json')
    protected = dict(source_receipt['protected_sha256'])
    protected.update({str(original / name):h for name,h in source_receipt['output_sha256'].items()})
    protected.update(geo_receipt['inputs'])
    protected.update({str(geo / name):h for name,h in geo_receipt['files'].items()})
    protected[str(original / 'receipt.json')] = '67f7867fa76e8f411f444c3e0ab242212717cf764baf4e4b2687475d33355b7d'
    protected[str(geo / 'verification.json')] = '6abd5bf262bb7972acad0336d2370d3b817b7811c9a4f9f7eec6021bcde90bcd'
    helper = ROOT / 'geometry_direct_20261101/identity_revision_0001/check_invalidation.py'
    protected[str(helper)] = 'd06af9a2e613bb7365fc4e24633741916f55a37765a42635693fee269661c6af'
    protected[str(HERE / 'advance_count_relations.py')] = '9f7fd61c7d3a9283d3b05c7fe4d0444d4773fcca7a75a2dc316a0d392dc02ee6'
    native = ROOT / 'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    native_hash = '1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4'
    protected[str(native)] = native_hash
    assert all(digest(Path(p))==h for p,h in protected.items())
    copied = output / 'copied_v1'
    copied.mkdir()
    for name in ('seal.json','unit.private.json','source.private.bin'):
        copyfile(original/'sealed_v1'/name,copied/name)
    first = recover(copied,source_receipt['pinned_unit_sha256'])['handoff']
    source = (copied/'source.private.bin').read_bytes()
    real_geo = read(geo/'handoff.json')
    seed = advance(None,first,source,native,native_hash)
    bindings = {row['member']['occurrence_id']:dict(owner_qid='Q1490',support_signature=signature(row),
                    source_handoff=deepcopy(real_geo)) for row in active_occurrences(seed['count_state'])
                    if row['decision'] and row['decision']['qid']=='Q1490'}
    assert len(bindings)==8
    binding_hash = content_hash(bindings)
    versions,contexts = [first],[]
    context = advance_geometry(seed,first,source,native,native_hash,bindings,binding_hash)
    contexts.append(context)
    for number,changes in ((2,1),(3,8)):
        update = deepcopy(first)
        update.update(version=f'SANDBOX_TOKYO_SUPPORT_v{number}',prior_version=versions[-1]['version'])
        changed = 0
        for decision in update['decisions']:
            if decision['qid']=='Q1490' and changed<changes:
                decision.update(qid='Q999999991',evidence=dict(simulated=True,prior=deepcopy(decision['evidence'])))
                changed += 1
        assert changed==changes
        slot = output/f'synthetic_v{number}'
        expected_hash = sha(encoded(update))
        seal_unit(slot,update,source,expected_hash,prior_history=versions)
        update = recover(slot,expected_hash,prior_history=versions)['handoff']
        frozen = deepcopy(context)
        successor = advance_geometry(context,update,source,native,native_hash,bindings,binding_hash)
        assert context==frozen
        projection = successor['geometry_receipt']['projection']
        assert len(projection['links'])==8-changes and len(projection['invalidated'])==changes
        assert set(projection['active_geometry'])==({'Q1490'} if changes<8 else set())
        assert 'Q999999991' not in projection['active_geometry']
        assert all(r['status']=='RETRACTED_PENDING_REVALIDATION' for r in projection['invalidated'])
        if changes<8: assert projection['active_geometry']['Q1490']==real_geo
        try:
            require_current(context['geometry_receipt'],successor['count_state'])
        except ValueError:
            pass
        else:
            raise AssertionError('Old geometry receipt accepted for new decision frontier')
        assert advance_geometry(successor,update,source,native,native_hash,bindings,binding_hash) is successor
        versions.append(update);contexts.append(successor);context=successor
    assert len(context['geometry_history'])==len(context['count_history'])==len(context['relation_history'])==3
    assert context['geometry_history'][0]==contexts[0]['geometry_history'][0]
    assert all(v['occurrences']==first['occurrences'] and v['pending_evidence']==first['pending_evidence'] for v in versions)
    assert all(digest(Path(p))==h for p,h in protected.items())
    summaries = [dict(count_receipt=c['count_receipt'],relation_receipt=c['relation_receipt'],
                      geometry_receipt=c['geometry_receipt'],geometry_history=c['geometry_history']) for c in contexts]
    return dict(status='PASS_COUNT_RELATION_GEOMETRY_CHAIN',versions=versions,contexts=summaries,
                support_bindings=bindings,protected_sha256=protected,geometry_scope=['Q1490'],
                untouched_other_geometry='Outside this fragment; not withdrawn or replaced',real_decisions_changed=False,
                publisher_called=False,full_count_relation_recompute=True)


if __name__=='__main__':
    output = HERE/'geometry_chain_0001'
    output.mkdir()
    result = check(output)
    (output/'result.json').write_bytes(encoded(result))
    proof = dict(status=result['status'],checks=8,result_sha256=digest(output/'result.json'),code_sha256=digest(Path(__file__)),
                 support_links=[len(c['geometry_receipt']['projection']['links']) for c in result['contexts']],
                 active_geometry_counts=[len(c['geometry_receipt']['projection']['active_geometry']) for c in result['contexts']])
    (output/'verification.json').write_bytes(encoded(proof))
    print(json.dumps(proof))
