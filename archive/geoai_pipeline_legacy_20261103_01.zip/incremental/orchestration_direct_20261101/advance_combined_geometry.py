"""Preserve per-unit geometry provenance while naming the combined decision frontier correctly."""
from copy import deepcopy
from pathlib import Path
import json
from advance_full_geometry import advance_full
from check_one_unit import digest,read
from decision_revision_hook import require_current


def advance_combined(output,previous,handoff,source,**arguments):
    context=advance_full(output,previous,handoff,source,**arguments)
    if len(context['count_state'])==1:return context
    full=deepcopy(context['full_geometry'])
    original_path=Path(full['receipt_path'])
    receipt=dict(full['receipt'],decision_version=context['count_receipt']['projection']['decision_version'],
                 original_geometry_receipt=dict(path=str(original_path),sha256=full['receipt_sha256']))
    # The original merger keeps its first-unit scalar; its complete decision_binding is unchanged.
    require_current(receipt,context['count_state'])
    target=Path(output)/'combined_geometry_receipt.json'
    if target.exists():
        if read(target)!=receipt:raise ValueError('Combined geometry receipt changed')
    else:target.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    full.update(receipt=receipt,receipt_path=str(target),receipt_sha256=digest(target))
    full['component']['decision_version']=receipt['decision_version']
    result=deepcopy(context);result['full_geometry']=full
    return result
