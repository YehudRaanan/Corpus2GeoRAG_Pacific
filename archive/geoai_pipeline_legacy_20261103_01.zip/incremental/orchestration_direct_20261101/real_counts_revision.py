"""Version-aware owned adapter for the existing real_counts.py count calculation."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'counts_direct_20261101'))
from pair_counts import aggregate_units, pair_counts, SCOPE_FIELDS, encoded
from hashlib import sha256
from decision_revision_hook import decision_binding,content_hash
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'durable_units_direct_20261101'))
from durable_unit import encoded as unit_encoded


def recompute_counts(state, previous, history):
    # real_counts.py uses these same unmodified reducers; its fixed run() writes outside our ownership.
    if not state:
        raise ValueError('At least one closed source unit is required')
    if len(state)>1:
        aggregate=aggregate_units(state)
        frontier=[dict(scope=dict(zip(SCOPE_FIELDS,key)),decision_version=versions[-1]['version'],
                       unit_sha256=sha256(unit_encoded(versions[-1])).hexdigest()) for key,versions in sorted(state.items())]
        counts=dict(scope=None,scopes=[row['scope'] for row in frontier],pinned_unit_sha256=None,unit_frontier=frontier,
            decision_version='sha256:'+content_hash(decision_binding(state)),identity_counts=aggregate['identity_counts'],
            typed_counts=aggregate['typed_counts'],pairs=pair_counts(state),retained_occurrences=aggregate['unique_occurrences'],
            accepted_occurrences=sum(row['mention_count'] for row in aggregate['identity_counts']),
            pending_occurrences=sum(bool(row['pending_supports']) for row in aggregate['occurrences']),
            explicit_unmatched_occurrences=sum(None in row['decision_values'] for row in aggregate['occurrences']),
            conflicted_occurrences=sum(row['identity_conflict'] or 'page_or_type_conflict' in row['not_counted_reasons'] for row in aggregate['occurrences']),
            history_versions=sum(len(v) for v in state.values()),physical_pages=aggregate['unique_physical_pages'],
            occurrence_ids=sorted({s['member']['occurrence_id'] for row in aggregate['occurrences'] for s in row['supports']}),
            pending_evidence=[dict(scope=dict(zip(SCOPE_FIELDS,key)),decision_version=versions[-1]['version'],evidence=row)
                              for key,versions in sorted(state.items()) for row in versions[-1]['pending_evidence']],
            count_scope='Multiple closed units; unique original rows and physical-page support; full reference recomputation')
        history.append(dict(decision_version=counts['decision_version'],unit_frontier=frontier,
                            identity_counts=counts['identity_counts'],pairs=counts['pairs']))
        return counts
    key, versions = next(iter(state.items()))
    unit = versions[-1]
    aggregate = aggregate_units(state)
    counts = dict(scope=dict(zip(SCOPE_FIELDS, key)), decision_version=unit['version'],
                  pinned_unit_sha256=sha256(encoded(unit)).hexdigest(),
                  identity_counts=aggregate['identity_counts'], typed_counts=aggregate['typed_counts'],
                  pairs=pair_counts(state), retained_occurrences=aggregate['unique_occurrences'],
                  accepted_occurrences=sum(r['mention_count'] for r in aggregate['identity_counts']),
                  pending_occurrences=len(unit['pending_evidence']),
                  explicit_unmatched_occurrences=sum(r['qid'] is None for r in unit['decisions']),
                  history_versions=len(versions), occurrence_ids=[r['occurrence_id'] for r in unit['occurrences']],
                  pending_evidence=unit['pending_evidence'],
                  count_scope='Sandbox copy of one verified retained unit; full reference recomputation')
    history.append(dict(decision_version=unit['version'], pinned_unit_sha256=counts['pinned_unit_sha256'],
                        identity_counts=counts['identity_counts'], pairs=counts['pairs']))
    return counts
