"""Advance reconciliation to a verified source refresh without changing accepted decisions."""
from pathlib import Path
from run_ready_units import pinned,save,context_state
from check_one_unit import read,digest
from decision_revision_hook import require_current,content_hash


def adopt_source_cursor(state_path,new_cursor):
    state_path=Path(state_path).resolve()
    if not state_path.is_relative_to(Path(__file__).resolve().parent):raise ValueError('Use an owned reconciliation state')
    before=digest(state_path);state=read(state_path)
    old=pinned(state['cursor']);updated=pinned(new_cursor)
    previous=context_state(pinned(old['projection']));current=context_state(pinned(updated['projection']))
    if previous['count_state']!=current['count_state'] or previous['count_receipt']!=current['count_receipt']:
        raise ValueError('Source cursor must preserve every decision/history/count')
    registry=updated['native_registry'];pinned(registry)
    for name in ('count_receipt','relation_receipt'):require_current(current[name],current['count_state'])
    full=current['full_geometry']['receipt'];require_current(full,current['count_state'])
    if current['relation_receipt']['projection']['input_binding']['native_registry_sha256']!=registry['sha256']:
        raise ValueError('Relation receipt uses another registry')
    expected=dict(count_receipt_sha256=content_hash(current['count_receipt']),relation_receipt_sha256=content_hash(current['relation_receipt']))
    if full['projection']['source_binding']!=expected:raise ValueError('Full geometry uses stale dependency receipts')
    for path,expected in full['projection']['artifact_sha256'].items():
        if digest(path)!=expected:raise ValueError('Full geometry bytes changed')
    if state['cursor']==new_cursor:return False
    state.setdefault('source_updates',[]).append(dict(previous=state['cursor'],updated=new_cursor,native_registry=registry))
    state['cursor']=new_cursor
    if digest(state_path)!=before:raise ValueError('Concurrent reconciliation update; retry the read-only validation')
    save(state_path,state)
    return True
