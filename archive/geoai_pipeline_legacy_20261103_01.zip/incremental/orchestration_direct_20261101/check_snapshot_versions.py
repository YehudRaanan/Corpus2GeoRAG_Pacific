"""Read existing versioned snapshots and bind every projection to one decision receipt."""
import gzip
import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from check_one_unit import HERE, ROOT, WORK, check_ids, digest, read


def decision_binding(projection, unit_hash, version):
    assert projection["pinned_unit_sha256"] == unit_hash, "Stale decision content"
    assert projection["decision_version"] == version, "Stale decision version"


def inspect_versions():
    baseline_path = HERE / "run_0003/stage_status.json"
    baseline = read(baseline_path)
    assert baseline["status"] == "PASS_ONE_UNIT_RECEIPT_CHAIN"
    verified = {str(baseline_path): digest(baseline_path)}

    def require(path, expected):
        path = Path(path)
        actual = verified.setdefault(str(path), digest(path))
        assert actual == expected, "Changed dependency: " + str(path)

    # Reuse previous stage evidence; do not rerun earlier pipelines or consumer versions.
    for path, expected in baseline["receipt_sha256"].items():
        require(path, expected)
    handoff_dir = WORK / "real_handoff_0001"
    handoff = read(handoff_dir / "receipt.json")
    unit_path = handoff_dir / "sealed_v1/unit.private.json"
    require(unit_path, handoff["pinned_unit_sha256"])
    unit = read(unit_path)
    version, unit_hash = handoff["decision_version"], handoff["pinned_unit_sha256"]
    assert unit["version"] == version == "first-unit-exact-v1"
    check_ids([r["occurrence_id"] for r in unit["occurrences"]], baseline["occurrence_ids"])
    originals = {r["occurrence_id"]: r for r in unit["occurrences"]}
    mentions = Counter(f"{r['qid']}::{originals[r['occurrence_id']]['entity_group']}" for r in unit["decisions"])
    assert sum(mentions.values()) == 30 and len(unit["pending_evidence"]) == 106
    cpath = ROOT / "counts_direct_20261101/real_counts_20261101T202248289937Z/counts.json"
    require(cpath, baseline["verified_artifact_sha256"][str(cpath)])
    counts = read(cpath)
    decision_binding(counts, unit_hash, version)
    # Both a changed version and changed content invalidate old projections.
    for bad_hash, bad_version in ((unit_hash, "first-unit-model-v2"), ("0" * 64, version)):
        try:
            decision_binding(counts, bad_hash, bad_version)
        except AssertionError:
            pass
        else:
            raise AssertionError("Stale projection accepted")
    import geopandas as gpd
    from shapely import from_wkb
    sys.path[:0] = [r"D:\Projects\GeoAI", r"D:\Projects\GeoAI\Agent"]
    from geo_agent.graph_store import GraphStore
    publisher = ROOT / "publisher_direct_20261101"
    snapshots = []
    for number, expected_hash, qids in (
        (2, "70fcab875d2dae3a0ae5e448a45e53a83a442159c18c44baefdf5f80c8572917", {"Q1490"}),
        (3, "fc79c8977b0408d476b610dc8444afcfc2419bc9e19d6a115367462d4bf89edb", {"Q1490", "Q153732", "Q51679"}),
    ):
        folder = publisher / f"snapshot_{number:04d}"
        receipt_path = folder / "private/receipt.json"
        require(receipt_path, expected_hash)
        receipt = read(receipt_path)
        independent = read(folder / "private/independent_verification.json")
        verified[str(folder / "private/independent_verification.json")] = digest(folder / "private/independent_verification.json")
        assert independent["receipt_sha256"] == expected_hash and independent["status"].startswith("PASS_INDEPENDENT_")
        require(publisher / f"verify_snapshot_{number:04d}.py", independent["verification_code_sha256"])
        require(publisher / ("consume_tokyo.py" if number == 2 else "consume_islands.py"), receipt["stage_sha256"])
        assert receipt["inputs_sha256"][str(handoff_dir / "receipt.json")] == digest(handoff_dir / "receipt.json")
        assert receipt["inputs_sha256"][str(unit_path)] == unit_hash
        for path, expected in receipt["inputs_sha256"].items():
            require(path, expected)
        for relative, expected in receipt["artifact_sha256"].items():
            require(folder / relative, expected)
        graph = read(folder / "graph.json")
        assert {n["id"] for n in graph["nodes"]} == set(mentions) and len(graph["nodes"]) == 10
        assert set(graph) == {"metadata", "relation_catalog", "nodes", "edges"} and not graph["edges"]
        assert all(set(n) == {"id", "wikidata_id", "name", "type", "aliases"} for n in graph["nodes"])
        missing = read(folder / "private/missingness.json")
        assert {r["node_id"]: r["mention_count"] for r in missing["identity_mapping"]} == dict(mentions)
        assert (missing["accepted_occurrences"], missing["pending_occurrences"]) == (30, 106)
        frame = gpd.read_parquet(folder / "model/geometries.parquet")
        assert set(frame.place_id) == qids and len(frame) == len(qids) and frame.crs.to_epsg() == 4326
        assert frame.geometry.is_valid.all() and not frame.geometry.is_empty.any()
        tokyo = ROOT / "geometry_direct_20261101/tokyo_handoff_0001"
        islands = ROOT / "geometry_direct_20261101/islands_handoff_0001"
        for fragment in ([tokyo] if number == 2 else [tokyo, islands]):
            geo_handoff = read(fragment / "handoff.json")
            assert geo_handoff["decision_version"] == version
            assert (geo_handoff["page_id"], geo_handoff["processing_revision_id"]) == (48975579, 1375061414)
            fragment_frame = gpd.read_parquet(fragment / "model/geometries.parquet")
            for row in fragment_frame.itertuples():
                actual = frame.loc[frame.place_id == row.place_id].geometry.iloc[0]
                raw_path = fragment / ("private/source_osm_row.json" if row.place_id == "Q1490" else f"private/{row.place_id}_source_row.json")
                assert actual.wkb == row.geometry.wkb == from_wkb(bytes.fromhex(read(raw_path)["geometry_wkb"])).wkb
        with gzip.open(folder / "model/geography.json.gz", "rt", encoding="utf-8") as stream:
            geography = json.load(stream)
        assert len(geography) == 5
        for row in geography:
            ref = row["geometry_ref"]
            if row["place_id"] in qids:
                assert ref == {"file": "geometries.parquet", "place_id": row["place_id"], "sha256": digest(folder / "model/geometries.parquet")}
            else:
                assert ref is None
        store = GraphStore.from_json(folder / "graph.json", model_dir=folder / "model")
        assert set(store.nodes) == set(mentions) and not store.edges and set(store.geoms) == {q + "::LOC" for q in qids}
        assert not receipt["publication"] and not receipt["new_selection"]
        snapshots.append(dict(snapshot=folder.name, receipt_sha256=expected_hash, decision_version=version,
                              pinned_unit_sha256=unit_hash, nodes=10, edges=0, geometry_rows=len(qids),
                              geometry_bound_occurrences=sum(mentions[q + "::LOC"] for q in qids),
                              pending_occurrences=106, locations_without_geometry=5-len(qids)))
    pair_dir = ROOT / "pair_relations_direct_20261101/real_pair_views_20261101T203117785273Z"
    pair_receipt = read(pair_dir / "verification.json")
    for path, expected in pair_receipt["protected_sha256"].items():
        require(path, expected)
    require(pair_dir / "pair_views.json", pair_receipt["output_sha256"])
    pairs = read(pair_dir / "pair_views.json")
    decision_binding(pairs["counts"], unit_hash, version)
    assert pairs["counts"] == counts
    independent = read(pair_dir / "independent_readback.json")
    for path in (pair_dir / "verification.json", pair_dir / "independent_readback.json"):
        verified[str(path)] = digest(path)
    assert independent["status"] == "PASS_INDEPENDENT_REAL_PAIR_READBACK"
    assert independent["output_sha256"] == pair_receipt["output_sha256"] and independent["summary"] == pair_receipt["summary"]
    assert not pairs["consumer_export"] and not pairs["publication"]
    return dict(status="PASS_VERSIONED_SNAPSHOT_CHAIN", checked_utc=datetime.now(timezone.utc).isoformat(),
                page_id=48975579, processing_revision_id=1375061414, decision_version=version,
                pinned_unit_sha256=unit_hash, occurrence_ids=baseline["occurrence_ids"],
                upstream_stages={k: v for k, v in baseline["stages"].items() if k != "consumer_snapshot"},
                snapshots=snapshots, current_snapshot=snapshots[-1], pair_views=pair_receipt["summary"],
                pair_views_consumer_export=False, stale_version_and_content_rejected=True,
                freshness_scope="Explicit first-unit-exact-v1 dependency only; no mutable latest-version resolver exists",
                verified_artifact_sha256=verified, publication=False, pipeline_stages_executed=False,
                backup_status="Unprotected", code_sha256=digest(Path(__file__)))


if __name__ == "__main__":
    result = inspect_versions()
    output = HERE / "run_0005"
    output.mkdir()
    (output / "stage_status.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("status", "checked_utc", "decision_version", "snapshots", "pair_views")}))
