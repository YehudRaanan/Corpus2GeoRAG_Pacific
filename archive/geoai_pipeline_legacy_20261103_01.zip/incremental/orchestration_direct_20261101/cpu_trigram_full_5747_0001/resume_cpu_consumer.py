"""Resume only the failed compact consumer from immutable C2v3/C3/GEO receipts."""
import argparse,json,subprocess,sys
from pathlib import Path
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');OWN=ROOT/'orchestration_direct_20261101';RUN=OWN/'cpu_trigram_full_5747_0001';PHASE=RUN/'three_unit_v3_0001/native_projection_0001'
sys.path.insert(0,str(RUN))
from cpu_stage_smoke import read,digest,descriptor,atomic_save

def resume(args):
 if digest(args.manifest)!=args.sha256:raise ValueError('Resume manifest hash differs')
 materializer=ROOT/'publisher_direct_20261101/component_materializer_0001/materialize_components.py'
 if digest(materializer)!=args.materializer_sha256:raise ValueError('Use the exact released PUBLISHER fix; old/mutating code is not admitted')
 native=read(PHASE/'verification.json');cpu=read(RUN/'three_unit_v3_0001/verification.json')
 assert (cpu['occurrences'],cpu['assigned'],cpu['explicit_NONE'],cpu['pending'])==(347,131,80,136)
 assert native['store_stats']['pending_refreshes']==0
 for key in ['compact_frontier','count_receipt','relation_receipt','geometry_receipt','GEO_source_receipt']:
  d=native[key]
  if digest(d['path'])!=d['sha256']:raise ValueError('Completed projection changed: '+key)
 consumer=ROOT/'publisher_direct_20261101/proposed_strength_0001/consumer'
 sys.path.insert(0,str(ROOT/'publisher_direct_20261101/compact_checkpoint_0001'))
 from compact_checkpoint import materialize_compact_checkpoint
 print('RESUME_CONSUMER_ONLY no_policy_rerun units=3 occurrences=347',flush=True)
 made=materialize_compact_checkpoint(args.output,manifest=dict(path=str(args.manifest),sha256=args.sha256),consumer_root=consumer)
 receipt=dict(path=made['receipt_path'],sha256=made['receipt_sha256'])
 if digest(receipt['path'])!=receipt['sha256']:raise ValueError('Consumer receipt changed')
 root=Path(receipt['path']).parent.parent;c=read(receipt['path'])
 for name,value in c['artifact_sha256'].items():
  if digest(root/name)!=value:raise ValueError('Consumer artifact changed: '+name)
 gate=read(native['GEO_source_receipt']['path']);expected={r['qid'] for r in gate['decisions'] if r['allow_active_LOC']}
 graph=read(root/'graph.json');actual={n['wikidata_id'] for n in graph['nodes'] if n['type'] in ['LOC','location']}
 assert actual==expected and len(actual)==19
 counts=read(native['count_receipt']['path'])['projection'];expected_roles={(r['qid'],r['entity_group']) for r in counts['typed_counts'] if r['entity_group']!='LOC' or r['qid'] in expected}
 actual_roles={(n['wikidata_id'],n['type']) for n in graph['nodes'] if n['type']!='event'}
 assert actual_roles==expected_roles
 qids={n['wikidata_id'] for n in graph['nodes']};assert all(e['source'] in qids and e['target'] in qids for e in graph['edges'])
 reader='''import json,sys,gzip
from pathlib import Path
import geopandas as gpd
root=Path(sys.argv[1]);consumer=Path(sys.argv[2]);sys.path[:0]=[str(consumer),'D:/Projects/GeoAI']
import geo_agent.graph_store as module
assert Path(module.__file__).resolve()==(consumer/'geo_agent/graph_store.py').resolve()
store=module.GraphStore.from_json(root/'graph.json',model_dir=root/'model')
frame=gpd.read_parquet(root/'model/geometries.parquet');assert frame.crs.to_epsg()==4326
LOC={n.wikidata_id for n in store.nodes.values() if n.type in ['LOC','location']}
assert set(frame.place_id)==LOC
print(json.dumps(dict(status='PASS_FRESH_ACTIVE_LOC_CONSUMER',nodes=len(store.nodes),edges=len(store.edges),active_LOC=len(LOC),geometries=len(frame))))
'''
 checked=subprocess.run([sys.executable,'-B','-c',reader,str(root),str(consumer)],capture_output=True,text=True)
 if checked.returncode:raise RuntimeError(checked.stderr)
 verification=dict(status='PASS_RESUMED_CPU_THREE_UNIT_ORDINARY_ACTIVE_LOC_CONSUMER',consumer_receipt=receipt,
  manifest=dict(path=str(args.manifest),sha256=args.sha256),materializer_sha256=args.materializer_sha256,
  previous_native_projection=descriptor(PHASE/'verification.json'),fresh_consumer=json.loads(checked.stdout),
  CPU_policy_rerun=False,source_occurrences=347,assigned=131,explicit_NONE=80,pending=136,
  full_units_complete=0,remaining='Bind and verify all current-version DATE/Event/context plus native Event scope before full-unit completion/bulk admission',
  next_order_indices=list(range(3,13)),next_logical_units=[4,13],next_workers=2,canonical_writers=1,
  next_batch_started=False,publication=False)
 atomic_save(RUN/'three_unit_v3_0001/consumer_resume_verification.json',verification)
 print(json.dumps(verification,indent=2),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--manifest',type=Path,default=PHASE/'ordinary_contract_probe_manifest.json')
 p.add_argument('--sha256',default='7b0129ee5eee48b3a299abb7456266a1da538a466ba1ee9da5345643f56d1ff2')
 p.add_argument('--materializer-sha256',required=True)
 p.add_argument('--output',type=Path,default=ROOT/'publisher_direct_20261101/orchestration_refresh_0001/cpu_smoke3_v3_0001/consumer_resumed_0001')
 args=p.parse_args();resume(args)
