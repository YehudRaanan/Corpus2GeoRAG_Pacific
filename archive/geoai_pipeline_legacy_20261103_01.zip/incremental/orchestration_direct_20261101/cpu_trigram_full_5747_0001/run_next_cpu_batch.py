"""Finite CPU queue: independent source/policy workers, one seal/C3 writer, explicit blocked units."""
import argparse,gc,gzip,hashlib,importlib.util,json,os,shutil,sys,time,urllib.request
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
from datetime import datetime,timezone
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');OWN=ROOT/'orchestration_direct_20261101';RUN=OWN/'cpu_trigram_full_5747_0001'
sys.path[:0]=[str(RUN),str(OWN),str(OWN/'runtime_handoff_0001')]
from cpu_stage_smoke import read,digest,descriptor,atomic_save

def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
def saved_source_catalog():
 catalog={};base=ROOT/'runtime_model_inputs_direct_20261101/per_unit_builder_v1'
 for path in sorted(base.rglob('manifest.json')):
  folder=path.parent
  if not all((folder/n).is_file() for n in ['all_groups_and_members.json','exact_decision_patch.json','target_resolution_evidence.json']):continue
  m=read(path);s=m.get('scope',{})
  if not all(k in s for k in ['page_id','processing_revision_id','occurrences']):continue
  key=(s['page_id'],s['processing_revision_id']);catalog.setdefault(key,[]).append(dict(prepared_directory=str(folder),manifest_sha256=digest(path)))
 return catalog
def choose_source_evidence(candidates):
 if not candidates:return {}
 signatures={}
 for c in candidates:
  folder=Path(c['prepared_directory']);exact=read(folder/'exact_decision_patch.json')['decisions'];targets=read(folder/'target_resolution_evidence.json')
  facts=[(r.get('source_target'),r.get('current_title'),r.get('qid'),r.get('response_sha256')) for r in targets if r.get('resolved')]
  sig=hashlib.sha256(json.dumps([exact,sorted(facts)],sort_keys=True).encode()).hexdigest();signatures.setdefault(sig,c)
 if len(signatures)!=1:raise ValueError('AMBIGUOUS_SAME_SOURCE_EXACT_OR_TITLE_EVIDENCE')
 return next(iter(signatures.values()))
def worker(index,batch,catalog):
 batch=Path(batch);slot=batch/'units'/('unit_'+str(index).zfill(4));slot.mkdir(parents=True,exist_ok=True)
 completed=slot/'CPU_policy_receipt.json'
 if completed.exists():
  r=read(completed)
  for k in ['decision_patch','outcomes','group_scores']:
   if digest(r[k]['path'])!=r[k]['sha256']:raise ValueError('Completed worker output changed')
  return dict(order_index=index,slot=str(slot),receipt=descriptor(completed),replayed=True)
 claim=slot/'claim.json';fd=os.open(claim,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
 with os.fdopen(fd,'w',encoding='utf8') as f:json.dump(dict(pid=os.getpid(),order_index=index,started_utc=datetime.now(timezone.utc).isoformat()),f)
 def no_network(*a,**k):raise RuntimeError('NETWORK_NOT_PART_OF_CPU_SOURCE_POLICY_WORKER')
 urllib.request.urlopen=no_network
 try:
  prep=module('source_preparation_C2',ROOT/'cpu_trigram_inputs_v1/prepare_cpu_unit.py')
  source=slot/'source';prep.prepare_one(index,source);gc.collect()
  v3=ROOT/'cpu_trigram_inputs_v1/ordinary_pool_bridge_v3'
  base=module('source_pool_base_v3',v3/'base_bridge_cpu_pool.py');pool=base.prepare_pool(source);gc.collect()
  key=(pool['source_unit']['page_id'],pool['source_unit']['processing_revision_id']);evidence=choose_source_evidence(catalog.get(key,[]))
  adopter=module('explicit_source_evidence_v3',v3/'adopt_source_evidence.py');pool=adopter.adopt_source_evidence(pool,evidence);gc.collect()
  path=batch/'pools'/('unit_'+str(index).zfill(4)+'.json');atomic_save(path,pool)
  compute=module('verified_CPU_compute',RUN/'run_cpu_pool_smoke.py');compute.OUT=batch/'units'
  result=compute.compute(index,descriptor(path));result['source_evidence_used']=evidence
  return result
 except BaseException as e:
  atomic_save(slot/'failure.json',dict(status='BLOCKED_CPU_STAGE',exception=type(e).__name__,reason=str(e),order_index=index,canonical_commit=False));raise

def main(args):
 if not 0<=args.start_index<args.stop_index<=5747:raise ValueError('Finite sealed index range required')
 batch=RUN/('next_batch_'+str(args.start_index+1).zfill(4)+'_'+str(args.stop_index).zfill(4)+'_v1');batch.mkdir(exist_ok=True);(batch/'pools').mkdir(exist_ok=True)
 started=datetime.now(timezone.utc).isoformat();print('START_BOUNDED_CPU_BATCH pid='+str(os.getpid())+' utc='+started+' indices='+str(args.start_index)+'..'+str(args.stop_index-1)+' workers='+str(args.workers),flush=True)
 policy=Path('C:/Users/User/Documents/Codex/2026-11-01/task-5/runtime_trigram_policy_v1/MINIMAL_HANDOFF.json');release=read(policy)
 for d in release['files'].values():assert digest(d['path'])==d['sha256']
 v3=ROOT/'cpu_trigram_inputs_v1/ordinary_pool_bridge_v3/bridge_manifest.json';manifest=read(v3)
 assert digest(v3)=='2da712cbbc5c23563790e15db0a99c70ed8cc0da065dfd4a07b2fdc5685b7130'
 for name,value in manifest['code_sha256'].items():assert digest(v3.parent/name)==value
 old=RUN/'three_unit_v3_0001/contributions.sqlite';database=batch/'corpus.sqlite'
 if not database.exists():shutil.copy2(old,database)
 sys.path.insert(0,str(ROOT/'pair_relations_direct_20261101/compact_unit_store_0001'));from contribution_store import ContributionStore
 from decision_handoff import build_handoff
 store=ContributionStore(database);catalog=saved_source_catalog();statuses={};failures=[]
 registry=read(ROOT/'pair_relations_direct_20261101/accepted11_20_sources_0001/generation_014/native_registry.json')['selected_references']
 # Keep the original three-unit store frozen for its pending consumer fix.
 isolated=dict(order_index=0,logical_unit=1,page_id=48975579,status='BLOCKED_ACTIVE_NATIVE_SOURCE',missing_qids=['Q700727'],role='MISC',raw_words=['Nakajima','Ki-44'],ready_checkpoint=False,source_lookup_owner='RELATIONS')
 atomic_save(batch/'inherited_blocked_unit.json',isolated)
 request=dict(status='RUNNING_CPU_STAGES_ONLY',started_utc=started,pid=os.getpid(),range_indices=[args.start_index,args.stop_index-1],workers=args.workers,canonical_writers=1,prior347_frozen_store=str(old),canonical_working_store=str(database),blocked_units=[isolated],unit_statuses=statuses,full_units_complete=0,ready_checkpoint_units=[],publication=False)
 atomic_save(batch/'state.json',request)
 try:
  with ProcessPoolExecutor(max_workers=args.workers) as pool:
   futures={pool.submit(worker,i,str(batch),catalog):i for i in range(args.start_index,args.stop_index)}
   for future in as_completed(futures):
    index=futures[future]
    try:
     computed=future.result();slot=Path(computed['slot']);r=read(computed['receipt']['path']);s=r['source_pending_unit'];patch=read(r['decision_patch']['path'])
     built=build_handoff(slot/'sealed',current_sealed_dir=s['unit_directory'],current_unit_sha256=s['unit_sha256'],prior_history=[],supplied_decisions=patch['decisions'],decision_version=patch['decision_version'])
     baseline=read(Path(s['unit_directory'])/'unit.private.json');source=(Path(s['unit_directory'])/'source.private.bin').read_bytes()
     store.apply(baseline,source);store.apply(built['handoff'],source);assert store.apply(built['handoff'],source)['changed'] is False
     missing=sorted({d['qid'] for d in built['handoff']['decisions'] if d['qid'] and d['qid'] not in registry})
     value=dict(status='CPU_SEALED_SOURCE_PENDING' if missing else 'CPU_SEALED_PENDING_REQUIRED_ROUTES',order_index=index,logical_unit=index+1,
      page_id=built['handoff']['manifest']['page_id'],processing_revision_id=built['handoff']['manifest']['support_revision_id'],
      policy_receipt=computed['receipt'],sealed_unit=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256']),counts=r['counts'],
      missing_native_qids=missing,full_unit_complete=False,ready_checkpoint=False,remaining=['source/native relation refresh','DATE/Event/context','active_LOC/geometry','consumer readback'])
     atomic_save(slot/'unit_result.json',value);statuses[str(index)]=value;print('CPU_COMMITTED logical_unit='+str(index+1)+' counts='+str(r['counts'])+' source_gaps='+str(missing),flush=True)
    except Exception as e:
     value=dict(status='BLOCKED_CPU_STAGE',order_index=index,logical_unit=index+1,reason=type(e).__name__+': '+str(e),full_unit_complete=False);statuses[str(index)]=value;failures.append(value)
     print('UNIT_BLOCKED logical_unit='+str(index+1)+' '+value['reason'],flush=True)
    request['unit_statuses']=statuses;request['progress_utc']=datetime.now(timezone.utc).isoformat();request['store_stats']=store.stats()
    atomic_save(batch/'state.json',request)
  counts=store.counts(False);atomic_save(batch/'counts_snapshot.json',counts)
  request.update(status='BOUNDED_CPU_STAGE_ATTEMPT_TERMINAL',CPU_committed_units=sum(v['status'].startswith('CPU_SEALED') for v in statuses.values()),failed_units=failures,store_stats=store.stats(),counts_snapshot=descriptor(batch/'counts_snapshot.json'),full_units_complete=0)
  atomic_save(batch/'state.json',request);print('TERMINAL '+str(batch/'state.json')+' committed='+str(request['CPU_committed_units'])+' failed='+str(len(failures)),flush=True)
 finally:store.close()

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--start-index',type=int,default=3);p.add_argument('--stop-index',type=int,default=13);p.add_argument('--workers',type=int,choices=[1,2],default=2);main(p.parse_args())
