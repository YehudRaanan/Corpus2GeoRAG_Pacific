"""Finite CPU-frontier catch-up: one downstream owner, existing six-stage runner only."""
import argparse,json,os,shutil,sys,time
from pathlib import Path
import psutil
RUN=Path('D:/Projects/GeoAI-incremental-dev-20261101/orchestration_direct_20261101/cpu_trigram_full_5747_0001');sys.path.insert(0,str(RUN))
from cpu_stage_smoke import read,atomic_save,descriptor
from capture_cpu_frontier import capture
from run_downstream_chain import main as run_chain

def main(args):
 work=args.work.resolve();work.mkdir(parents=True,exist_ok=True);lock=work/'catchup_controller.lock.json'
 if lock.exists():
  if psutil.pid_exists(read(lock)['pid']):raise RuntimeError('Existing catch-up controller; no duplicate')
  lock.rename(work/('stale_controller_'+str(time.time_ns())+'.json'))
 fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
 with os.fdopen(fd,'w') as f:json.dump(dict(pid=os.getpid()),f)
 try:
  while True:
   owner=work/'downstream.lock.json'
   if owner.exists() and psutil.pid_exists(read(owner)['pid']):
    atomic_save(work/'catchup_status.json',dict(status='WAIT_EXISTING_DOWNSTREAM_OWNER',pid=os.getpid()));time.sleep(10);continue
   completion=read(work/'completion_state.json');last_ref=completion['last_frontier'];last=read(last_ref['path'])['active_units']
   cpu=read(args.cpu_work/'state.json');available=cpu['CPU_committed_units'];terminal=cpu['status']=='CPU_RANGE_TERMINAL'
   if available<=last or (available-last<args.minimum_new_units and not terminal):
    status='ALL_AVAILABLE_CPU_FRONTIERS_COMPLETED' if terminal else 'WAIT_MORE_COMMITTED_CPU_UNITS'
    atomic_save(work/'catchup_status.json',dict(status=status,pid=os.getpid(),CPU_committed_units=available,fully_completed_units=completion['fully_completed_units'],last_frontier_units=last,publication=False))
    if terminal:return
    time.sleep(10);continue
   args.snapshot_root.mkdir(parents=True,exist_ok=True)
   if min(shutil.disk_usage(work).free,shutil.disk_usage(args.snapshot_root).free)<5*1024**3:raise RuntimeError('Catch-up disk reserve below5GiB; no deletion or CPU termination')
   output=args.snapshot_root/('automatic_'+str(available).zfill(4)+'_'+str(time.time_ns()))
   try:frontier=capture(args.cpu_work,output)
   except RuntimeError as error:
    if 'raced CPU final receipt' not in str(error):raise
    atomic_save(work/'catchup_status.json',dict(status='RETRY_SNAPSHOT_COMMIT_RACE',preserved=str(output),pid=os.getpid()));time.sleep(5);continue
   atomic_save(work/'catchup_status.json',dict(status='RUNNING_AUTOMATIC_DOWNSTREAM_FRONTIER',frontier=descriptor(frontier),pid=os.getpid(),publication=False))
   print('AUTOMATIC_CATCHUP_START '+str(frontier),flush=True)
   run_chain(argparse.Namespace(recipe=args.recipe,frontier=Path(frontier),work=work,stop_after=None))
   print('AUTOMATIC_CATCHUP_FULL_COMPLETION '+str(read(work/'completion_state.json')['fully_completed_units']),flush=True)
 except BaseException as error:
  atomic_save(work/'catchup_status.json',dict(status='BLOCKED_CATCHUP_REQUIRED_STAGE',reason=type(error).__name__+': '+str(error),pid=os.getpid(),CPU_unchanged=True,publication=False));raise
 finally:
  if lock.exists():lock.rename(work/('finished_controller_'+str(time.time_ns())+'.json'))

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--recipe',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--cpu-work',type=Path,required=True);p.add_argument('--snapshot-root',type=Path,required=True);p.add_argument('--minimum-new-units',type=int,default=100)
 args=p.parse_args()
 if args.minimum_new_units<1:raise ValueError('Positive bounded catch-up threshold required')
 main(args)
