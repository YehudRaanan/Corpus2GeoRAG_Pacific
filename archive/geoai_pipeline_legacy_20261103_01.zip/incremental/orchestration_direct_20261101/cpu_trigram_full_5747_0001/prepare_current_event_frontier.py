"""Generic immutable frontier -> existing current Event refresh, no new Event logic."""
import importlib.util,json,sys
from pathlib import Path
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');RUN=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001';EVENT=ROOT/'pair_relations_direct_20261101/event_current_frontier_0001'
sys.path[:0]=[str(RUN),str(EVENT)]
from capture_cpu_frontier import read_active_units
from current_event_refresh import pin,read,write,desc,refresh,content_hash,FIELDS

def prepare_event(frontier_descriptor,count_preparation_descriptor,output_dir):
 frontier=pin(frontier_descriptor);prepared=pin(count_preparation_descriptor);output=Path(output_dir).resolve()
 if prepared['frontier_receipt']!=frontier_descriptor:raise ValueError('Count preparation belongs to another frontier')
 request=dict(frontier=frontier_descriptor,count_preparation=count_preparation_descriptor,producer=desc(__file__))
 marker=output/'HANDOFF.json'
 if marker.exists():
  hand=read(marker)
  if hand['request']!=request:raise ValueError('Changed Event request cannot overwrite generation')
  pin(hand['route']);pin(hand['count_receipt']);pin(hand['config'])
  return hand
 if output.exists():raise ValueError('Preserve partial Event output; use an explicitly new version')
 output.mkdir(parents=True)
 config=read(EVENT/'config_actual13.json');prior=pin(config['active_units'])
 baseline={tuple(pin(r['unit'])['manifest'][k] for k in FIELDS):r for r in prior['units']}
 frozen_state=read_active_units(frontier_descriptor['path']);entries=[]
 for row in frontier['frontier']:
  key=tuple(row['scope']);unit=frozen_state[key][-1]
  if row['active_head']!=dict(version=unit['version'],sha256=content_hash(unit)):raise ValueError('Frozen Event active head differs')
  if key in baseline:entry=baseline[key]
  else:
   commit=pin(row['evidence']);cpu=pin(commit['policy_receipt']);unit_ref=desc(Path(commit['sealed_unit']['unit_directory'])/'unit.private.json')
   if unit_ref['sha256']!=commit['sealed_unit']['unit_sha256']:raise ValueError('Sealed CPU unit changed')
   entry=dict(unit=unit_ref,outcomes=cpu['outcomes'],CPU_commit=row['evidence'],CPU_policy=commit['policy_receipt'])
  if pin(entry['unit'])!=unit:raise ValueError('Current Event source unit differs from frozen body')
  pin(entry['outcomes']);entries.append(entry)
 inventory=output/'active_units.json';write(inventory,dict(units=entries,frozen_frontier=frontier_descriptor))
 config.update(counts_snapshot=prepared['counts_snapshot'],count_receipt=prepared['consumer_inputs']['count_receipt'],active_units=desc(inventory),frozen_cpu_frontier=frontier_descriptor)
 config_path=output/'config.json';write(config_path,config);generated=refresh(desc(config_path),output/'generation_001')
 if pin(generated['artifacts']['count_receipt'])!=pin(config['count_receipt']):raise ValueError('Event changed the exact common count receipt')
 # All downstream stages use the same prepared count file, preserving its upstream binding.
 result=dict(status='VERIFIED_GENERIC_CURRENT_EVENT_FRONTIER',request=request,frozen_frontier=frontier_descriptor,route=desc(output/'generation_001/handoff.json'),
  count_receipt=config['count_receipt'],native_registry=config['native_registry'],source_policy=config['source_policy'],config=desc(config_path),
  units=len(entries),resolved_occurrences=generated['resolved_occurrences'],unresolved_occurrences=generated['unresolved_occurrences'],
  source_gaps=generated['source_gaps'],processor=generated['processor'],full_process_completion=False,publication=False)
 write(marker,result);return result
