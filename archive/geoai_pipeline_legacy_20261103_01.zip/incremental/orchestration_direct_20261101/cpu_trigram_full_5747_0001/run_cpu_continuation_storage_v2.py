"""Finite resumable CPU continuation. One store, two immutable workers; downstream is separate."""
import argparse,hashlib,json,os,shutil,sqlite3,sys,time
from concurrent.futures import ProcessPoolExecutor,wait,FIRST_COMPLETED
from datetime import datetime,timezone
from pathlib import Path
import psutil
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');OWN=ROOT/'orchestration_direct_20261101';RUN=OWN/'cpu_trigram_full_5747_0001'
sys.path[:0]=[str(RUN),str(OWN),str(OWN/'runtime_handoff_0001'),str(ROOT/'pair_relations_direct_20261101/compact_unit_store_0001')]
from cpu_stage_smoke import read,digest,descriptor,atomic_save
from run_next_cpu_batch import worker,saved_source_catalog
from decision_handoff import build_handoff
from contribution_store import ContributionStore,SCOPE_FIELDS,scope_key

def now():return datetime.now(timezone.utc).isoformat()
def hashed(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')).hexdigest()
def heads(store):
 return {row[0]:dict(version=row[1],sha256=row[2]) for row in store.db.execute('SELECT c.scope,c.version,c.sha256 FROM active a JOIN contributions c ON c.seq=a.seq ORDER BY c.scope')}
def expected_heads(snapshot):
 return {json.dumps([h['scope'][k] for k in SCOPE_FIELDS],ensure_ascii=False,separators=(',',':')):dict(version=h['decision_version'],sha256=h['contribution_sha256']) for h in snapshot['frontier']}
def check_pin(d):
 if digest(d['path'])!=d['sha256']:raise ValueError('SYSTEMIC_ARTIFACT_CHANGED: '+d['path'])

def select_attempt(work,index,compute_root):
 # Preserve interrupted inputs. Never start a duplicate live claimed worker.
 roots=list(dict.fromkeys([work/'compute',compute_root]))
 for attempt in [a for root in roots for a in sorted(root.glob('attempt_*'))]:
  slot=attempt/'units'/('unit_'+str(index).zfill(4));receipt=slot/'CPU_policy_receipt.json'
  if receipt.exists():return attempt
  claim=slot/'claim.json'
  if claim.exists() and psutil.pid_exists(read(claim)['pid']):raise RuntimeError('LIVE_PREVIOUS_WORKER: '+str(read(claim)['pid']))
  if not claim.exists() and attempt.parent==compute_root:return attempt
 n=len(list(compute_root.glob('attempt_*')));attempt=compute_root/('attempt_'+str(n).zfill(4))
 (attempt/'pools').mkdir(parents=True);return attempt

def verify_worker(computed,queue_unit,policy):
 check_pin(computed['receipt']);r=read(computed['receipt']['path'])
 for key in ['source_pool','policy','policy_code','decision_patch','outcomes','group_scores']:check_pin(r[key])
 if r['policy']!=policy['files']['policy.json'] or r['policy_code']!=policy['files']['runtime_trigram.py']:raise ValueError('SYSTEMIC_POLICY_VERSION_DIFFERS')
 if r['source_scope']!=queue_unit:raise ValueError('SYSTEMIC_SOURCE_UNIT_DIFFERS')
 source=r['source_pending_unit'];check_pin(dict(path=str(Path(source['unit_directory'])/'unit.private.json'),sha256=source['unit_sha256']))
 return r

def commit_unit(store,work,index,computed,queue_unit,policy):
 receipt=verify_worker(computed,queue_unit,policy);slot=Path(computed['slot']);src=receipt['source_pending_unit'];patch=read(receipt['decision_patch']['path'])
 built=build_handoff(slot/'sealed',current_sealed_dir=src['unit_directory'],current_unit_sha256=src['unit_sha256'],prior_history=[],supplied_decisions=patch['decisions'],decision_version=patch['decision_version'])
 final=built['handoff'];baseline=read(Path(src['unit_directory'])/'unit.private.json');source=(Path(src['unit_directory'])/'source.private.bin').read_bytes();key=scope_key(final['manifest'])
 current=heads(store).get(key);final_head=dict(version=final['version'],sha256=hashed(final));base_head=dict(version=baseline['version'],sha256=hashed(baseline))
 if current is None:
  store.apply(baseline,source);current=base_head
 if current==base_head:store.apply(final,source)
 elif current!=final_head:raise ValueError('SYSTEMIC_CONFLICTING_COMMITTED_UNIT_VERSION')
 assert heads(store)[key]==final_head and store.apply(final,source)['changed'] is False
 value=dict(schema='geoai-cpu-unit-commit-v1',status='CPU_COMMITTED_PENDING_DOWNSTREAM',order_index=index,logical_unit=index+1,
  source_scope=final['manifest'],policy_receipt=computed['receipt'],sealed_unit=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256']),
  active_head=final_head,counts=receipt['counts'],full_unit_complete=False,ready_checkpoint=False,
  downstream_required=['source/native relation refresh','DATE/Event/context','active_LOC/geometry','consumer readback'])
 path=work/'commits'/('unit_'+str(index).zfill(4)+'.json')
 if path.exists():
  if read(path)!=value:raise ValueError('SYSTEMIC_COMMIT_RECEIPT_DIFFERS')
 else:atomic_save(path,value)
 return value,descriptor(path)

def storage_migration(old_config,new_config,approved_old_driver_sha256):
 """Only code/storage placement may change; input, policy and source bindings stay pinned."""
 old=dict(old_config);new=dict(new_config)
 old_driver=old.pop('driver_code');new.pop('driver_code');new.pop('compute_root')
 if not approved_old_driver_sha256 or old_driver['sha256']!=approved_old_driver_sha256 or old!=new:
  raise ValueError('RESUME_CONFIG_DIFFERS_OUTSIDE_EXPLICIT_STORAGE_MIGRATION')
 check_pin(old_driver)

def advance_state(state,store,index,result):
 state['next_index']=index+1;state['heads']=heads(store);state['frontier_sha256']=hashed(state['heads']);state['CPU_committed_units']+=1
 state['last_commit']=result;state['progress_utc']=now();state['store_stats']=store.stats()

def execute(args):
 work=args.work.resolve();work.mkdir(parents=True,exist_ok=True);compute_root=args.compute_root.resolve()
 for d in ['commits','compute','exceptions','invocations']: (work/d).mkdir(exist_ok=True)
 lock=work/'writer.lock.json'
 if lock.exists():
  previous=read(lock)
  if psutil.pid_exists(previous['pid']):raise RuntimeError('ANOTHER_CANONICAL_WRITER: '+str(previous['pid']))
  lock.rename(work/('writer.stale.'+str(time.time_ns())+'.json'))
 fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
 with os.fdopen(fd,'w',encoding='utf8') as f:json.dump(dict(pid=os.getpid(),started_utc=now()),f)
 store=None
 try:
  policy_path=Path('C:/Users/User/Documents/Codex/2026-11-01/task-5/runtime_trigram_policy_v1/MINIMAL_HANDOFF.json');policy=read(policy_path)
  for d in policy['files'].values():check_pin(d)
  queue_path=RUN/'queue.jsonl.gz'
  import gzip
  with gzip.open(queue_path,'rt',encoding='utf8') as f:queue={r['order_index']:r['source_unit'] for r in map(json.loads,f)}
  base=read(args.base_counts);expected=expected_heads(base)
  config=dict(schema='geoai-cpu-continuation-v1',base_counts=descriptor(args.base_counts),base_frontier_sha256=hashed(expected),
   start_index=args.start_index,input_queue=descriptor(queue_path),policy_release=descriptor(policy_path),
   worker_code=descriptor(RUN/'run_next_cpu_batch.py'),bridge=descriptor(ROOT/'cpu_trigram_inputs_v1/ordinary_pool_bridge_v3/bridge_manifest.json'),driver_code=descriptor(Path(__file__)),compute_root=str(compute_root))
  state_path=work/'state.json';database=work/'corpus.sqlite';fresh=not state_path.exists()
  if fresh:
   if database.exists():raise ValueError('Unclaimed working store already exists; inspect before initialization')
   source_db=sqlite3.connect(args.base_store.resolve().as_uri()+'?mode=ro',uri=True);target=sqlite3.connect(database)
   try:source_db.backup(target)
   finally:target.close();source_db.close()
   store=ContributionStore(database)
   if heads(store)!=expected or len(expected)!=args.start_index:raise ValueError('BASE_STORE_FRONTIER_DIFFERS_FROM_VERIFIED_CURRENT13')
   state=dict(schema='geoai-cpu-continuation-state-v1',status='INITIALIZED',config=config,config_sha256=hashed(config),next_index=args.start_index,
    heads=expected,frontier_sha256=hashed(expected),CPU_committed_units=len(expected),exceptions=[],full_units_complete=0,ready_checkpoint_units=[],store_stats=store.stats(),publication=False)
   atomic_save(state_path,state)
  else:
   state=read(state_path)
   if state['config_sha256']!=hashed(state['config']):raise ValueError('SAVED_CONFIG_INTEGRITY_DIFFERS')
   if state['config_sha256']!=hashed(config):storage_migration(state['config'],config,args.storage_migration_from)
   store=ContributionStore(database)
  # A crash can leave only the next committed unit ahead of the cursor. Other differences block.
  actual=heads(store);cursor=state['next_index'];extra=set(actual)-set(state['heads'])
  if any(actual.get(k)!=v for k,v in state['heads'].items()) or extra-{scope_key(queue[cursor]) if cursor<len(queue) else ''}:raise ValueError('SYSTEMIC_WORKING_FRONTIER_CHANGED')
  if state['config_sha256']!=hashed(config):
   migration=dict(schema='geoai-cpu-storage-migration-v1',utc=now(),cursor=cursor,old_config=state['config'],new_config=config,
    old_config_sha256=state['config_sha256'],new_config_sha256=hashed(config),frontier_sha256=hashed(actual),canonical_store=str(database),old_evidence_preserved=True)
   path=work/'invocations'/('storage_migration_'+str(time.time_ns())+'.json');atomic_save(path,migration)
   state.setdefault('storage_migrations',[]).append(descriptor(path));state['config']=config;state['config_sha256']=hashed(config);atomic_save(state_path,state)
  compute_root.mkdir(parents=True,exist_ok=True)
  catalog=saved_source_catalog();started=now();pid=os.getpid()
  invocation=dict(pid=pid,started_utc=started,stop_index=args.stop_index,chunk_size=args.chunk_size,workers=args.workers,
   plan_hashes=[descriptor(Path('C:/Users/User/Documents/Codex/2026-11-01/task')/n) for n in ['GEOAI_RUNTIME_BATCH_PLAN.md','GEOAI_DEVELOPMENT_PLAN.md']])
  atomic_save(work/'invocations'/(str(time.time_ns())+'.json'),invocation)
  print('START_CONTINUATION pid='+str(pid)+' utc='+started+' next_index='+str(cursor)+' stop='+str(args.stop_index)+' base_active='+str(store.stats()['active_units']),flush=True)
  state.update(status='RUNNING_CPU_ONLY',pid=pid,stop_index=args.stop_index,workers=args.workers,canonical_writers=1)
  atomic_save(state_path,state)
  with ProcessPoolExecutor(max_workers=args.workers) as pool:
   while state['next_index']<args.stop_index:
    if min(shutil.disk_usage(work).free,shutil.disk_usage(compute_root).free)<args.min_free_gib*1024**3:
     state.update(status='PAUSED_DISK_BOUND',reason='Free disk below configured '+str(args.min_free_gib)+'GiB');atomic_save(state_path,state);return
    start=state['next_index'];stop=min(start+args.chunk_size,args.stop_index);jobs={};done={};failed={}
    for i in range(start,stop):jobs[pool.submit(worker,i,str(select_attempt(work,i,compute_root)),catalog)]=i
    heartbeat=0
    while jobs:
     completed,pending=wait(jobs,timeout=1,return_when=FIRST_COMPLETED)
     for f in completed:
      i=jobs.pop(f)
      try:done[i]=f.result()
      except Exception as e:failed[i]=e
     while state['next_index'] in done or state['next_index'] in failed:
      i=state['next_index']
      if i in failed:
       e=failed.pop(i)
       if 'AMBIGUOUS_SAME_SOURCE_EXACT_OR_TITLE_EVIDENCE' not in str(e):raise e
       exception=dict(schema='geoai-data-exceptions-v1',status='QUARANTINED_UNRESOLVED',resolved=False,order_index=i,qid=None,
        source=queue[i],occurrences=dict(lookup='sealed expected_row_indices',input_sha256=queue[i]['input_sha256']),
        reason=str(e),needed_remedy='Reconcile source-proven exact/title snapshots; do not copy learned decisions',raw_identity_and_counts_preserved=True,full_unit_complete=False)
       p=work/'exceptions'/('unit_'+str(i).zfill(4)+'.json');atomic_save(p,exception);state['exceptions'].append(descriptor(p));state['next_index']=i+1
       print('QUARANTINED_INPUT unit='+str(i+1),flush=True)
      else:
       value,ref=commit_unit(store,work,i,done.pop(i),queue[i],policy)
       if args.test_stop_after_index==i:
        state.update(status='PAUSED_TEST_AFTER_PERSISTED_UNIT_RECORD',test_index=i);atomic_save(state_path,state)
        print('TEST_STOP after persisted unit='+str(i+1)+' before cursor; resume must reconcile',flush=True);return
       advance_state(state,store,i,ref);print('COMMITTED_CPU unit='+str(i+1)+' active='+str(state['store_stats']['active_units']),flush=True)
      atomic_save(state_path,state)
     if time.monotonic()-heartbeat>=10:
      atomic_save(work/'heartbeat.json',dict(pid=pid,utc=now(),next_index=state['next_index'],active_worker_indices=list(jobs.values()),CPU_committed_units=state['CPU_committed_units'],full_units_complete=0,free_bytes=shutil.disk_usage(work).free,compute_root=str(compute_root),compute_free_bytes=shutil.disk_usage(compute_root).free))
      heartbeat=time.monotonic()
    state.update(progress_utc=now(),store_stats=store.stats());atomic_save(state_path,state)
  state.update(status='CPU_RANGE_TERMINAL',progress_utc=now(),store_stats=store.stats());atomic_save(state_path,state)
  print('TERMINAL CPU_active='+str(state['store_stats']['active_units'])+' next_index='+str(state['next_index'])+' full_units=0',flush=True)
 except BaseException as e:
  if (work/'state.json').exists():
   state=read(work/'state.json');state.update(status='SYSTEMIC_PAUSE',error=type(e).__name__+': '+str(e),progress_utc=now());atomic_save(work/'state.json',state)
  raise
 finally:
  if store is not None:store.close()
  if lock.exists():lock.rename(work/('writer.finished.'+str(time.time_ns())+'.json'))

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--base-store',type=Path,required=True);p.add_argument('--base-counts',type=Path,required=True);p.add_argument('--work',type=Path,required=True)
 p.add_argument('--start-index',type=int,default=13);p.add_argument('--stop-index',type=int,default=5747);p.add_argument('--chunk-size',type=int,default=10);p.add_argument('--workers',type=int,choices=[1,2],default=2)
 p.add_argument('--min-free-gib',type=float,default=3);p.add_argument('--test-stop-after-index',type=int,default=-1)
 p.add_argument('--compute-root',type=Path,required=True);p.add_argument('--storage-migration-from',default='')
 args=p.parse_args()
 if not 0<=args.start_index<args.stop_index<=5747 or args.chunk_size<1:raise ValueError('Bounded sealed index range required')
 execute(args)
