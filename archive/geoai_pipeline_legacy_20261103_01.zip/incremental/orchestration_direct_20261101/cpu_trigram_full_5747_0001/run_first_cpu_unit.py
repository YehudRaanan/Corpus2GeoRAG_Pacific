"""One real new-policy unit, source-pending -> pure C1 -> E2 seal -> C3/native counts."""
import json,sys,os,time
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');OWN=ROOT/'orchestration_direct_20261101';RUN=OWN/'cpu_trigram_full_5747_0001'
sys.path[:0]=[str(RUN),str(OWN),str(OWN/'runtime_handoff_0001')]
from cpu_stage_smoke import read,digest,descriptor,run_stage,atomic_save,verify_patch_membership

def run():
 out=RUN/'real_cpu_unit3_0001';out.mkdir(exist_ok=True)
 started=datetime.now(timezone.utc).isoformat();print('START_REAL_CPU_UNIT pid='+str(os.getpid())+' utc='+started+' page=64096955 revision=1372397745',flush=True)
 release_path=Path('C:/Users/User/Documents/Codex/2026-11-01/task-5/runtime_trigram_policy_v1/MINIMAL_HANDOFF.json');release=read(release_path)
 for d in release['files'].values():assert digest(d['path'])==d['sha256']
 assert release['files']['policy.json']['sha256']=='bbf3329f1a560946b6f82cf48c964d3b5fcce6211bbc291f0391a1f8117e6ac5'
 data=Path(release['unit3_data_directory']);assert digest(data/'manifest.json')==release['unit3_manifest_sha256']
 sys.path.insert(0,str(release_path.parent));from apply_unit import apply_prepared_unit
 source=ROOT/'cpu_trigram_inputs_v1/unit_0002';source_receipt=read(source/'receipt.json');unit=read(source/'sealed_pending/unit.private.json')
 assert unit['decisions']==[] and len(unit['occurrences'])==121
 assert read(data/'all_groups_and_members.json')['groups']==read(source/'groups.json')['groups']
 value=apply_prepared_unit(data,expected_manifest_sha256=release['unit3_manifest_sha256'])
 assert value['summary']['after']=={'IDENTITY':55,'PENDING':66}
 assert value['summary']['declared_list_complete'] and value['summary']['model_calls']==0
 assert {r['occurrence_id'] for r in value['results']}=={r['occurrence_id'] for r in unit['occurrences']}
 membership=verify_patch_membership(unit,value['patch'])
 for name,x in [('policy_result.json',value),('decision_patch.json',value['patch']),('occurrence_outcomes.json',value['results'])]:atomic_save(out/name,x)
 print('POLICY_DONE assigned55 pending66 NONE0 exact25',flush=True)
 from decision_handoff import build_handoff
 built=build_handoff(out/'sealed',current_sealed_dir=source/'sealed_pending',current_unit_sha256=source_receipt['unit_sha256'],prior_history=[],supplied_decisions=value['patch']['decisions'],decision_version=value['patch']['decision_version'])
 assert len(built['handoff']['decisions'])==55 and len(built['handoff']['pending_evidence'])==66
 atomic_save(out/'seal_receipt.json',{k:v for k,v in built.items() if k not in ['handoff','prior_history']})
 print('SEALED '+built['unit_sha256'],flush=True)
 c3=ROOT/'pair_relations_direct_20261101/compact_unit_store_0001';h=read(c3/'C3_HANDOFF_0001.json')
 for name,expected in h['files_sha256'].items():assert digest(c3/name)==expected
 sys.path.insert(0,str(c3));from contribution_store import ContributionStore
 database=out/'contributions.sqlite';store=ContributionStore(database)
 raw=(source/'sealed_pending/source.private.bin').read_bytes()
 try:
  store.apply(unit,raw);store.apply(built['handoff'],raw);counts=store.counts(False);stats=store.stats()
  assert counts['unique_occurrences']==121 and counts['pending_occurrences']==66 and counts['explicit_unmatched_occurrences']==0
  assert sum(r['mention_count'] for r in counts['identity_counts'])==55
  assert store.apply(built['handoff'],raw)['changed'] is False and store.stats()==stats
  atomic_save(out/'compact_counts.json',counts)
  print('COUNTS_DONE identities='+str(len(counts['identity_counts']))+' db_bytes='+str(database.stat().st_size),flush=True)
  from advance_count_relations import advance
  native=ROOT/'pair_relations_direct_20261101/accepted11_20_sources_0001/generation_014/native_registry.json';native_sha='f1bf0d890542e63557d18af13e6067e3e8da3768e0a50543432516c0db5fb0dc'
  initial=advance(None,unit,raw,native,native_sha);context=advance(initial,built['handoff'],raw,native,native_sha)
  assert advance(context,built['handoff'],raw,native,native_sha) is context
  for name in ['count_receipt','relation_receipt']:atomic_save(out/(name+'.json'),context[name])
  atomic_save(out/'active_unit.json',built['handoff'])
  def actual_relations(state,current_counts):
   assert current_counts['frontier_sha256']==counts['frontier_sha256']
   assert [v[-1] for v in state.values()]==[built['handoff']]
   return dict(native_source=dict(path=str(native),sha256=native_sha),relation_receipt=descriptor(out/'relation_receipt.json'))
  refresh=store.refresh_relations(actual_relations);assert refresh['refreshed'];assert store.refresh_relations(actual_relations)['refreshed'] is False
  atomic_save(out/'C3_relation_refresh.json',refresh);stats=store.stats()
 finally:store.close()
 relations=context['relation_receipt']['projection']
 policy_receipt=dict(schema='geoai-cpu-trigram-execution-v1',status='VERIFIED_CPU_TRIGRAM_EXECUTION',execution='EXECUTED_LOCAL_CPU',pid=os.getpid(),started_utc=started,
  policy_release=descriptor(release_path),policy=release['files']['policy.json'],input_manifest=descriptor(data/'manifest.json'),source_pending_unit=dict(unit_directory=str(source/'sealed_pending'),unit_sha256=source_receipt['unit_sha256']),
  source_scope=unit['manifest'],decision_patch=descriptor(out/'decision_patch.json'),outcomes=descriptor(out/'occurrence_outcomes.json'),summary=value['summary'],learned_decisions_reused=False,model_calls=0,membership=membership)
 atomic_save(out/'CPU_policy_receipt.json',policy_receipt)
 result=dict(status='ONE_REAL_CPU_UNIT_POLICY_SEAL_COUNTS_RELATIONS_SAVED',started_utc=started,pid=os.getpid(),page_id=64096955,processing_revision_id=1372397745,
  occurrences=121,assigned=55,explicit_NONE=0,pending=66,protected_exact=25,policy_receipt=descriptor(out/'CPU_policy_receipt.json'),sealed_unit=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256']),
  compact_counts=descriptor(out/'compact_counts.json'),relation_receipt=descriptor(out/'relation_receipt.json'),C3_stats=stats,native_source_missing=relations['missing_qids'],native_pending_pairs=len(relations['pending_pairs']),
  native_views=len(relations['active_views']),completed_stages=['source','CPU_policy','sealed_decision_handoff','compact_counts','native_relations'],
  remaining_stages=['GEO active LOC successor/filter','per-unit DATE/Event/context receipts for new decision version','consumer materialization/readback'],
  full_unit_complete=False,bulk_started=False,previous_generations_preserved=True,publication=False)
 atomic_save(out/'unit_result.json',result)
 print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':run()
