"""Run current-unit DATE/context checks and native Event acceptance; expose real remaining joins."""
import ast,html,importlib.util,json,sys
from pathlib import Path
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');OWN=ROOT/'orchestration_direct_20261101';RUN=OWN/'cpu_trigram_full_5747_0001';UNIT=RUN/'real_cpu_unit3_0001'
sys.path[:0]=[str(RUN),str(OWN)]
from cpu_stage_smoke import read,digest,descriptor,atomic_save
from decision_revision_hook import content_hash
from route_completion import route_completion
FIELDS=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def main():
 out=UNIT/'routes_0001';out.mkdir(exist_ok=True)
 unit=read(UNIT/'sealed/unit.private.json');source=(UNIT/'sealed/source.private.bin').read_bytes();scope={k:unit['manifest'][k] for k in FIELDS}
 assert digest(UNIT/'sealed/source.private.bin')==scope['source_sha256']
 result=read(UNIT/'policy_result.json');rows={r['occurrence_id']:r for r in unit['occurrences']}
 registry_path=ROOT/'pair_relations_direct_20261101/accepted11_20_sources_0001/generation_014/native_registry.json'
 assert digest(registry_path)=='f1bf0d890542e63557d18af13e6067e3e8da3768e0a50543432516c0db5fb0dc'
 registry=read(registry_path)['selected_references'];processor=descriptor(Path(__file__))
 def receipt(name,members,outcomes,artifacts,**extra):
  value=dict(status='COMPLETED_UNRESOLVED' if any(r['status']=='UNRESOLVED' for r in outcomes) else 'COMPLETED',execution='EXECUTED',
   source_scope=scope,input_occurrences_sha256=content_hash(sorted(members,key=lambda r:r['occurrence_id'])),outcomes=outcomes,
   decision_version=unit['version'],source_unit=descriptor(UNIT/'sealed/unit.private.json'),processor=processor,
   artifacts=artifacts,**extra)
  path=out/(name+'.json');atomic_save(path,value);return descriptor(path)
 date_code=ROOT/'runtime_model_inputs_direct_20261101/date_route/structured_temporal_v1/execute_date_route_v1.py'
 dates=load('approved_DATE_decide',date_code);date_rows=[r for r in unit['occurrences'] if r['entity_group']=='DATE']
 detailed=[dates.decide(r,unit['decisions'],unit['manifest'],registry) for r in date_rows]
 assert len(detailed)==25 and all(r['reason']=='NO_SAME_PAGE_REVISION_RESOLVED_QID' for r in detailed)
 p=out/'date_outcomes.json';atomic_save(p,detailed)
 date=receipt('date_route',date_rows,[{k:r[k] for k in ['occurrence_id','status','method','reason']} for r in detailed],
  [descriptor(p),descriptor(date_code),descriptor(registry_path)],temporal_basis='STRUCTURED_QID_WIKIDATA',raw_text_parsed=False)
 # Run the same extracted DATA validator used by the earlier independent context audit.
 builder=ROOT/'runtime_model_inputs_direct_20261101/per_unit_builder_v1/prepare_unit.py';tree=ast.parse(builder.read_text(encoding='utf8'))
 basis=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='basis')
 loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='member' and any(isinstance(v,ast.Constant) and v.value=='PREPARED_SPAN_NOT_VERIFIED' for v in ast.walk(n)))
 code=compile(ast.fix_missing_locations(ast.Module(body=[basis,loop],type_ignores=[])),str(builder),'exec')
 prepared=Path(read(UNIT/'CPU_policy_receipt.json')['input_manifest']['path']).parent;deferred=read(prepared/'deferred_routes.json')
 context_evidence=[];context_outcomes=[];context_rows=[]
 for group in deferred['unusable_groups']:
  members=[rows[r['occurrence_id']] for r in group['members']]
  env=dict(json=json,html=html,raw_source=source.decode('utf8'),g=dict(members=members),word=group['name'],
   REV=unit['manifest']['support_revision_id'],unit=dict(source_sha256=unit['manifest']['source_sha256']),usable=[],bad=[])
  exec(code,env);assert env['usable']==[] and env['bad']==group['members']
  context_evidence.append(dict(original=members,repeated=env['bad']));context_rows+=members
  context_outcomes += [dict(occurrence_id=r['occurrence_id'],status='UNRESOLVED',method='PINNED_EXISTING_DATA_CONTEXT_VALIDATOR',reason=';'.join(r['reasons'])) for r in env['bad']]
 assert len(context_outcomes)==4
 p=out/'context_outcomes.json';atomic_save(p,context_evidence)
 context=receipt('context_route',context_rows,context_outcomes,[descriptor(p),descriptor(builder),descriptor(prepared/'deferred_routes.json')])
 # Native root identity acceptance is independent of ordinary lexical decisions.
 root_handoff=ROOT/'pair_relations_direct_20261101/event_root_fix_0001/RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001.json';h=read(root_handoff)
 native_desc=h['source_graph'];assert digest(native_desc['path'])==native_desc['sha256'];native=read(native_desc['path'])
 rule=load('actual_root_rule_v2',h['rule']['path']);assert digest(h['rule']['path'])==h['rule']['sha256']
 event_ids={r['occurrence_id'] for r in result['results'] if any('EVENT' in reason for reason in r['reason'])}
 old=read(next(x['event_route']['path'] for x in h['per_unit_receipts'] if x['page_id']==scope['page_id']))
 prior={r['occurrence_id']:r for r in old['outcomes']};assert event_ids==set(prior) and len(event_ids)==2
 d=rule.evaluate_wwii('Q362',native);assert d['keep_event'] and d['reason']=='ROOT_EVENT_IDENTITY' and d['p361_chain']==[]
 p=out/'event_acceptance.json';atomic_save(p,dict(decision=d,occurrence_ids=sorted(event_ids),source_graph=native_desc))
 event=receipt('event_route',[rows[oid] for oid in sorted(event_ids)],
  [dict(occurrence_id=oid,status='RESOLVED',method=h['version'],reason='ROOT_EVENT_IDENTITY',accepted_event_qids=['Q362']) for oid in sorted(event_ids)],
  [descriptor(p),native_desc,descriptor(root_handoff)],
  executed_scope='CURRENT_UNIT_NATIVE_EVENT_IDENTITY_ACCEPTANCE',not_completed_operations=['NATIVE_EVENT_SCOPE_AND_ACTIVE_LOC_CONSUMER_BOUND_TO_NEW_TRIGRAM_FRONTIER'],
  does_not_certify_full_process_completion=True)
 atomic_save(UNIT/'all_occurrence_decision_evidence.json',result['results'])
 routing=out/'CPU_routing_context.json';atomic_save(routing,dict(kind='CPU_ROUTE_CONTEXT_NO_MODEL_EXECUTION_CLAIM',policy_verification=descriptor(UNIT/'CPU_policy_receipt.json')))
 check=route_completion(dict(date_route=date,event_route=event,context_route=context),unit,descriptor(routing))
 assert set(check['verified'])=={'date_route','context_route'} and check['missing']['event_route']['status']=='PARTIAL_EXECUTION'
 report=dict(status='CURRENT_CPU_UNIT_DATE_CONTEXT_EXECUTED_EVENT_IDENTITY_VERIFIED_SCOPE_CONSUMER_PENDING',
  source_unit=descriptor(UNIT/'sealed/unit.private.json'),date_processed_unresolved=25,context_processed_unresolved=4,event_identity_resolved=2,
  route_receipts=dict(date_route=date,context_route=context,event_route=event),route_verification=check,
  full_unit_complete=False,model_calls=0,publication=False)
 atomic_save(out/'verification.json',report)
 requests=dict(status='READY_EXACT_CURRENT_UNIT_RUNTIME_HANDOFF',active_unit=descriptor(UNIT/'active_unit.json'),
  count_receipt=descriptor(UNIT/'count_receipt.json'),relation_receipt=descriptor(UNIT/'relation_receipt.json'),compact_counts=descriptor(UNIT/'compact_counts.json'),
  CPU_policy=descriptor(UNIT/'CPU_policy_receipt.json'),native_registry=descriptor(registry_path),route_verification=descriptor(out/'verification.json'),
  current_LOC_qids=[r['qid'] for r in read(UNIT/'count_receipt.json')['projection']['typed_counts'] if r['entity_group']=='LOC'],
  GEO_needed='Reuse verified shapes, P625 point fallback, polygon-before-outside decision, approved activeLOC gate; source-bound full geometry/filter receipt for current count frontier',
  RELATIONS_needed='Native Event scope receipt bound to this actual new one-unit decision/count frontier, reusing approved ROOT/P361 and all-hop1/LOC-hop2 logic; old17 count-bound receipt must not be relabelled',
  PUBLISHER_needed='C4 actual compact materialization accepting approved active LOC population/filter distinct from raw identity counts, plus current native Event route; no blind reuse of fixed17 producer receipt')
 atomic_save(out/'runtime_handoff_request.json',requests)
 print('PASS current-unit DATE25/context4 terminal unresolved; Event2 root identity verified; actual scope/activeLOC/consumer still required')
 print('route_receipt_SHA='+digest(out/'verification.json'))

if __name__=='__main__':main()
