"""Small CPU-run boundaries; no inference or threshold policy is implemented here."""
import hashlib,json,os,re
from pathlib import Path

def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(4194304),b''):h.update(b)
 return h.hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf8'))
def descriptor(path):return dict(path=str(Path(path).resolve()),sha256=digest(path))
def atomic_save(path,value):
 path=Path(path);temporary=path.with_suffix(path.suffix+'.tmp')
 with temporary.open('wb') as f:f.write(encoded(value));f.flush();os.fsync(f.fileno())
 os.replace(temporary,path)

def run_stage(directory,name,bindings,operation):
 """One writer, immutable bindings, output verified before receipt commits. No global cursor."""
 directory=Path(directory)
 if not re.fullmatch('[a-z][a-z0-9_]*',name):raise ValueError('Invalid stage name')
 directory.mkdir(parents=True,exist_ok=True);path=directory/(name+'.json')
 key=hashlib.sha256(encoded(bindings)).hexdigest()
 if path.exists():
  receipt=read(path)
  if receipt['binding_sha256']!=key:raise ValueError('Stage belongs to another policy/input/config')
  for artifact in receipt['artifacts']:
   if digest(artifact['path'])!=artifact['sha256']:raise ValueError('Persisted stage artifact changed')
  return receipt
 result,artifacts=operation()
 if not artifacts:raise ValueError('Stage must persist verifiable evidence')
 for artifact in artifacts:
  if digest(artifact['path'])!=artifact['sha256']:raise ValueError('Stage output hash differs')
 receipt=dict(schema='geoai-cpu-stage-v1',binding_sha256=key,bindings=bindings,result=result,artifacts=artifacts)
 atomic_save(path,receipt)
 return receipt

def verify_patch_membership(unit,patch):
 """Membership only. The future E2 execution receipt must independently certify CPU policy."""
 if unit['decisions']:raise ValueError('New policy must start from source-pending, not learned decisions')
 ids=[r['occurrence_id'] for r in unit['occurrences']]
 if len(ids)!=len(set(ids)) or set(ids)!={r['occurrence_id'] for r in unit['pending_evidence']}:raise ValueError('Source partition differs')
 if len(ids)!=unit['manifest']['retained_count']:raise ValueError('Source membership count differs')
 if not isinstance(patch.get('decision_version'),str) or not patch['decision_version']:raise ValueError('Explicit policy decision version required')
 seen=set();assigned=none=0
 for row in patch['decisions']:
  oid=row['occurrence_id']
  if oid not in ids or oid in seen:raise ValueError('Unknown or duplicate occurrence decision')
  seen.add(oid);qid=row['qid']
  if qid is not None and (not isinstance(qid,str) or not re.fullmatch('Q[1-9][0-9]*',qid)):raise ValueError('Invalid QID')
  if not isinstance(row.get('evidence'),dict) or not row['evidence']:raise ValueError('Explicit decision/NONE evidence required')
  if qid is None:none+=1
  else:assigned+=1
 return dict(status='CPU_PATCH_MEMBERSHIP_VERIFIED_NOT_EXECUTION',occurrences=len(ids),assigned=assigned,
  explicit_NONE=none,pending=len(ids)-len(seen),decision_version=patch['decision_version'],execution_certified=False,
  model_questions_required=False,learned_identity_seed=False)

if __name__=='__main__':
 import copy,tempfile,unittest
 class BoundaryChecks(unittest.TestCase):
  def setUp(self):
   self.unit=dict(manifest=dict(retained_count=3),occurrences=[dict(occurrence_id=str(i)) for i in range(3)],
    decisions=[],pending_evidence=[dict(occurrence_id=str(i)) for i in range(3)])
   self.patch=dict(decision_version='SYNTHETIC_CPU_TEST_ONLY',decisions=[dict(occurrence_id='0',qid='Q1',evidence=dict(test_only=True)),dict(occurrence_id='1',qid=None,evidence=dict(test_only=True))])
  def test_unsupplied_stays_pending(self):
   r=verify_patch_membership(self.unit,self.patch);self.assertEqual((r['assigned'],r['explicit_NONE'],r['pending']),(1,1,1));self.assertFalse(r['execution_certified'])
  def test_learned_baseline_rejected(self):
   self.unit['decisions']=[self.patch['decisions'][0]]
   with self.assertRaisesRegex(ValueError,'source-pending'):verify_patch_membership(self.unit,self.patch)
  def test_duplicate_and_unknown_rejected(self):
   for oid in ['0','unknown']:
    bad=copy.deepcopy(self.patch);bad['decisions'].append(dict(bad['decisions'][0],occurrence_id=oid))
    with self.assertRaises(ValueError):verify_patch_membership(self.unit,bad)
  def test_invalid_qid_and_evidenceless_NONE_rejected(self):
   for changes in [dict(qid='notqid'),dict(qid=None,evidence={})]:
    bad=copy.deepcopy(self.patch);bad['decisions'][0].update(changes)
    with self.assertRaises(ValueError):verify_patch_membership(self.unit,bad)
  def test_stage_replay_skips_operation_and_rejects_new_binding(self):
   with tempfile.TemporaryDirectory() as d:
    evidence=Path(d)/'out.json';evidence.write_bytes(b'{}');calls=[]
    def operation():calls.append(1);return dict(test_only=True),[descriptor(evidence)]
    first=run_stage(d,'policy',dict(version='test-v1'),operation)
    self.assertEqual(first,run_stage(d,'policy',dict(version='test-v1'),operation));self.assertEqual(len(calls),1)
    with self.assertRaisesRegex(ValueError,'another policy'):run_stage(d,'policy',dict(version='test-v2'),operation)
  def test_tampered_artifact_rejected_on_restart(self):
   with tempfile.TemporaryDirectory() as d:
    p=Path(d)/'out';p.write_bytes(b'one');run_stage(d,'handoff',{},lambda:({},[descriptor(p)]));p.write_bytes(b'two')
    with self.assertRaisesRegex(ValueError,'artifact changed'):run_stage(d,'handoff',{},lambda:None)
  def test_failure_never_commits_completed_receipt(self):
   with tempfile.TemporaryDirectory() as d:
    def fail():raise RuntimeError('synthetic interruption')
    with self.assertRaises(RuntimeError):run_stage(d,'policy',{},fail)
    self.assertFalse((Path(d)/'policy.json').exists())
 unittest.main()
