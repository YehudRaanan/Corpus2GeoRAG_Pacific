"""One synchronous downstream owner; fixed stages, immutable receipts, resumable calls."""
import argparse,gc,hashlib,importlib.util,json,os,sys,time
from pathlib import Path
import psutil
RUN=Path('D:/Projects/GeoAI-incremental-dev-20261101/orchestration_direct_20261101/cpu_trigram_full_5747_0001')
sys.path.insert(0,str(RUN))
from cpu_stage_smoke import read,digest,descriptor,atomic_save
STAGES=('counts','event','ordinary','geometry','consumer','eligibility')

def content_hash(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')).hexdigest()
def pin(ref):
 if digest(ref['path'])!=ref['sha256']:raise ValueError('Pinned artifact changed: '+ref['path'])
 return read(ref['path'])
def references(value):
 if isinstance(value,dict):
  if {'path','sha256'}<=value.keys():
   if digest(value['path'])!=value['sha256']:raise ValueError('Receipt artifact changed: '+value['path'])
  else:
   for item in value.values():references(item)
 elif isinstance(value,list):
  for item in value:references(item)
def resolve(value,context):
 if isinstance(value,dict) and set(value)=={'ref'}:
  result=context
  for part in value['ref'].split('.'):result=result[part]
  return result
 if isinstance(value,dict):return {k:resolve(v,context) for k,v in value.items()}
 if isinstance(value,list):return [resolve(v,context) for v in value]
 return value

def admission_rows(eligibility,frontier):
 expected={(r['scope'][1],r['scope'][2],r['scope'][3]):r['active_head']['version'] for r in frontier['frontier']};seen=set()
 for row in eligibility['eligible_units']:
  key=tuple(row['unit_key'])
  if key in seen or expected.get(key)!=row['decision_version'] or row['all_required_stages_executed'] is not True:raise ValueError('E2 eligibility scope/version/execution differs')
  seen.add(key)
  if not row['receipts']:raise ValueError('Missing actual stage receipts')
  references(row['receipts'])
 return eligibility['eligible_units']

def run_frontier(recipe_path,frontier_ref,work,stop_after=None):
 recipe=read(recipe_path);frontier=pin(frontier_ref);recipe_ref=descriptor(recipe_path)
 if frontier['schema']!='geoai-immutable-cpu-frontier-v1' or frontier['status']!='READY_CPU_ONLY':raise ValueError('Verified immutable CPU frontier required')
 if set(recipe['stages'])!=set(STAGES):raise ValueError('All six fixed required stages must be configured; driver supplies their order')
 job_id=frontier_ref['sha256'][:16]+'_'+recipe['pipeline_version'];job=work/'frontiers'/job_id;job.mkdir(parents=True,exist_ok=True)
 recipe_epoch=job/('recipe_'+recipe_ref['sha256']+'.json')
 if not recipe_epoch.exists():atomic_save(recipe_epoch,recipe)
 context=dict(frontier=frontier_ref,outputs={s:str(Path(recipe['output_roots'][s])/job_id) for s in STAGES},stages={},receipts={})
 context['outputs'].update(recipe.get('reusable_outputs',{}).get(frontier_ref['sha256'],{}))
 for name in STAGES:
  spec=recipe['stages'][name];producer=spec['producer'];arguments=resolve(spec['arguments'],context)
  if digest(producer['path'])!=producer['sha256']:raise ValueError('Producer code changed: '+name)
  stage_path=job/(name+'.json');binding=dict(frontier=frontier_ref,pipeline_version=recipe['pipeline_version'],stage_spec_sha256=content_hash(spec),stage=name,producer=producer,function=spec['function'],arguments=arguments)
  if stage_path.exists():
   saved=read(stage_path)
   if saved['binding']!=binding:raise ValueError('Changed stage cannot overwrite completed generation: '+name)
   result=pin(saved['result_receipt']);references(result)
  else:
   atomic_save(work/'progress.json',dict(status='RUNNING_STAGE',job_id=job_id,stage=name,frontier=frontier_ref,pid=os.getpid()))
   Path(context['outputs'][name]).parent.mkdir(parents=True,exist_ok=True)
   module_spec=importlib.util.spec_from_file_location('_downstream_'+name,producer['path']);module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
   getattr(module,spec['function'])(**arguments)
   if digest(producer['path'])!=producer['sha256']:raise ValueError('Producer changed during call: '+name)
   result_path=Path(context['outputs'][name])/spec['receipt_name'];result=read(result_path);references(result)
   if result.get('status') not in spec['success_statuses']:raise ValueError('Stage has no successful terminal receipt: '+name)
   if result.get('test_only') is True or result.get('fixture') is True:raise ValueError('Fixture is not runtime execution: '+name)
   atomic_save(stage_path,dict(status='VERIFIED_STAGE_RECEIPT',binding=binding,result_receipt=descriptor(result_path)))
   del module;gc.collect()
  if result.get('status') not in spec['success_statuses']:raise ValueError('Saved stage not successful: '+name)
  if result.get('test_only') is True or result.get('fixture') is True:raise ValueError('Fixture is not runtime execution: '+name)
  context['stages'][name]=result
  context['receipts'][name]=read(stage_path)['result_receipt']
  print('DOWNSTREAM_STAGE '+name+' verified frontier='+str(frontier['active_units']),flush=True)
  if stop_after==name:
   return dict(status='VERIFIED_PREFIX_PENDING_REQUIRED_STAGES',frontier=frontier_ref,last_verified_stage=name,full_process_completion=False,publication=False)
 # E2's fixed pinned validator supplies this normalized admission result after real routes.
 eligibility=context['stages']['eligibility'];eligible=admission_rows(eligibility,frontier)
 state_path=work/'completion_state.json';state=read(state_path) if state_path.exists() else dict(schema='geoai-canonical-full-unit-completion-v1',units={},publication=False)
 for row in eligible:
  key=tuple(row['unit_key']);encoded_key=json.dumps(key,separators=(',',':'))
  if encoded_key in state['units'] and state['units'][encoded_key]['decision_version']!=row['decision_version']:raise ValueError('Explicit supersession required for completed decision revision')
  state['units'][encoded_key]=dict(decision_version=row['decision_version'],eligibility=read(job/'eligibility.json')['result_receipt'],consumer=read(job/'consumer.json')['result_receipt'],frontier=frontier_ref)
 state['fully_completed_units']=len(state['units']);state['last_frontier']=frontier_ref
 if not state_path.exists() or read(state_path)!=state:atomic_save(state_path,state)
 admission=job/'completion_admission.json';atomic_save(admission,dict(frontier=frontier_ref,eligible_unit_keys=[r['unit_key'] for r in eligible],eligibility=read(job/'eligibility.json')['result_receipt'],fully_completed_units_when_admitted=state['fully_completed_units']))
 result=dict(status='VERIFIED_DOWNSTREAM_FRONTIER_WITH_E2_ADMISSION',CPU_units=frontier['active_units'],eligible_units_this_frontier=len(eligible),fully_completed_units=state['fully_completed_units'],
  frontier=frontier_ref,stages={s:descriptor(job/(s+'.json')) for s in STAGES},completion_admission=descriptor(admission),canonical_completion_state_path=str(state_path),publication=False,publication_gate='hour AND100 newly fully completed units; actual PR/merge confirmation only')
 atomic_save(job/'receipt.json',result);atomic_save(work/'progress.json',dict(status='FRONTIER_VERIFIED',job_id=job_id,result=descriptor(job/'receipt.json'),pid=os.getpid()))
 return result

def main(args):
 work=args.work.resolve();work.mkdir(parents=True,exist_ok=True);lock=work/'downstream.lock.json'
 if lock.exists():
  if psutil.pid_exists(read(lock)['pid']):raise RuntimeError('One downstream owner already active')
  lock.rename(work/('previous_lock_'+str(time.time_ns())+'.json'))
 fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL)
 with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(dict(pid=os.getpid()),f)
 try:
  result=run_frontier(args.recipe,descriptor(args.frontier),work,args.stop_after);print(json.dumps(result),flush=True)
 except BaseException as error:
  atomic_save(work/'error.json',dict(status='BLOCKED_REQUIRED_STAGE',error=type(error).__name__+': '+str(error),pid=os.getpid(),publication=False));raise
 finally:
  if lock.exists():lock.rename(work/('finished_lock_'+str(time.time_ns())+'.json'))

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--recipe',type=Path,required=True);p.add_argument('--frontier',type=Path,required=True);p.add_argument('--work',type=Path,required=True)
 p.add_argument('--stop-after',choices=STAGES)
 main(p.parse_args())
