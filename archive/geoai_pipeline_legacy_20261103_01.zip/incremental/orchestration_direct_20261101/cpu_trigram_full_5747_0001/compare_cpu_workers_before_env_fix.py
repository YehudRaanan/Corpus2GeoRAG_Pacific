"""Compare only immutable source preparation; no policy, SQLite, inference or publication."""
import hashlib,importlib.util,json,os,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,wait,FIRST_COMPLETED
import psutil
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');RUN=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001';OUT=RUN/'worker_compare_0001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def worker(case,index):
 output=Path(case)/('unit_'+str(index));claim=Path(case)/('claim_'+str(index)+'.json')
 fd=os.open(claim,os.O_WRONLY|os.O_CREAT|os.O_EXCL)
 with os.fdopen(fd,'w',encoding='utf8') as f:json.dump(dict(pid=os.getpid(),index=index,stage='SOURCE_ONLY'),f)
 builder=ROOT/'cpu_trigram_inputs_v1/prepare_cpu_unit.py';spec=importlib.util.spec_from_file_location('isolated_source_builder',builder);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 start=time.perf_counter();r=module.prepare_one(index,output)
 ledger=read(output/'candidate_inputs_0001/ledger.json');ledger.pop('original_groups');ledger.pop('source_members')
 result=dict(index=index,page_id=r['page_id'],occurrences=r['occurrences'],groups=r['groups'],candidates=r['candidates'],
  source_sha256=r['source_sha256'],members_sha256=sha(output/'source_members.json'),groups_sha256=sha(output/'groups.json'),
  source_unit_sha256=sha(output/'sealed_pending/unit.private.json'),candidate_semantics_sha256=canonical(ledger))
 return dict(result=result,pid=os.getpid(),compute_seconds=time.perf_counter()-start,output_bytes=sum(p.stat().st_size for p in output.rglob('*') if p.is_file()))

def sample_rss():
 p=psutil.Process();total=p.memory_info().rss
 for child in p.children(recursive=True):
  try:total+=child.memory_info().rss
  except psutil.NoSuchProcess:pass
 return total

if __name__=='__main__':
 OUT.mkdir(exist_ok=True);cases=[];baseline=None
 for count in [1,2,4]:
  case=OUT/('workers_'+str(count));case.mkdir(exist_ok=False);started=time.perf_counter();peak=sample_rss();results=[]
  print('START source-only workers='+str(count)+' parent_pid='+str(os.getpid()),flush=True)
  with ProcessPoolExecutor(max_workers=count) as pool:
   futures={pool.submit(worker,str(case),i) for i in [0,1,2,3]}
   while futures:
    done,futures=wait(futures,timeout=.1,return_when=FIRST_COMPLETED);peak=max(peak,sample_rss())
    for future in done:
     r=future.result();results.append(r);print('DONE workers='+str(count)+' unit_index='+str(r['result']['index'])+' pid='+str(r['pid']),flush=True)
  comparable=[r['result'] for r in sorted(results,key=lambda r:r['result']['index'])]
  if baseline is None:baseline=comparable
  assert comparable==baseline,'Different worker count changed prepared source semantics'
  row=dict(workers=count,wall_seconds=time.perf_counter()-started,peak_parent_and_children_RSS_bytes=peak,
   output_bytes=sum(r['output_bytes'] for r in results),occurrences=sum(r['result']['occurrences'] for r in results),
   result_semantics_sha256=canonical(comparable),results=results)
  cases.append(row);(case/'verification.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf8')
  print('PASS workers='+str(count)+' wall_seconds='+str(round(row['wall_seconds'],3))+' peakRSS='+str(peak),flush=True)
 proof=dict(status='PASS_SOURCE_ONLY_1_2_4_WORKERS_EQUIVALENT',cases=cases,indices=[0,1,2,3],semantics_identical=True,
  source_builder=dict(path=str(ROOT/'cpu_trigram_inputs_v1/prepare_cpu_unit.py'),sha256=sha(ROOT/'cpu_trigram_inputs_v1/prepare_cpu_unit.py')),
  scope='IMMUTABLE_SOURCE_PREPARATION_ONLY',actual_policy_run=False,production_workers_selected=False,
  canonical_SQLite_writers=0,canonical_state_changed=False,bulk_started=False,
  limitation='Four source units; source-only and process-startup timings do not estimate whole policy/Event/reducer/consumer runtime')
 (OUT/'verification.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
 print('FINAL '+str(OUT/'verification.json')+' SHA='+sha(OUT/'verification.json'),flush=True)
