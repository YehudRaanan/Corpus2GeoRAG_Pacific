"""Admit existing immutable C2 source preparations; no policy/model execution."""
import argparse,gzip,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101')
RUN=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001'
sys.path[:0]=[str(RUN),str(ROOT/'durable_units_direct_20261101')]
from cpu_stage_smoke import read,digest,descriptor,run_stage,atomic_save
from durable_unit import recover

def prepare(config_path,input_path):
 config=read(config_path);inputs=read(input_path)
 if digest(input_path)!='dd9e1b62bbb17ef2c06f36438408fb9a7b83919b93fb8d58cbe4411b9211f405':raise ValueError('Unapproved C2 manifest version')
 if digest(config['queue']['path'])!=config['queue']['sha256']:raise ValueError('Queue changed')
 if digest(config['input_seal']['path'])!=config['input_seal']['sha256']:raise ValueError('Source seal changed')
 with gzip.open(config['queue']['path'],'rt',encoding='utf8') as f:queue={r['order_index']:r for r in map(json.loads,f)}
 expected=config['smoke_order_indices'];assert [r['order_index'] for r in inputs['units']]==expected
 results=[];seen=set()
 for item in inputs['units']:
  index=item['order_index'];folder=Path(item['output']);raw=read(folder/'unit.json')
  if raw!=queue[index]['source_unit']:raise ValueError('Source belongs to another ordered unit')
  artifacts=[]
  for name,value in item['file_sha256'].items():
   p=(folder/name).resolve()
   if not p.is_relative_to(folder.resolve()) or digest(p)!=value:raise ValueError('Prepared artifact changed')
   artifacts.append(dict(path=str(p),sha256=value))
  receipt=read(folder/'receipt.json');loaded=recover(folder/'sealed_pending',receipt['unit_sha256'])
  unit=loaded['handoff'];occ=unit['occurrences'];ids={r['occurrence_id'] for r in occ}
  assert len(ids)==len(occ)==item['occurrences']==raw['retained_count']
  assert not unit['decisions'] and len(unit['pending_evidence'])==len(ids)
  assert ids=={r['occurrence_id'] for r in unit['pending_evidence']} and not seen&ids;seen.update(ids)
  assert digest(folder/'sealed_pending/source.private.bin')==raw['source_sha256']
  groups=read(folder/'groups.json');members=[m['occurrence_id'] for g in groups['groups'] for m in g['members']]
  assert len(members)==len(ids) and set(members)==ids and not groups['unresolved']
  ledger=read(folder/'candidate_inputs_0001/ledger.json')
  active={r['qid'] for r in ledger['active_cached_candidates']}
  backed={q for r in ledger['all_raw_targets_with_inclusion_evidence'] if r['included_from_relevant_component'] for q in r['candidate_qids']}
  assert active==backed and len(active)==item['candidates']
  binding=dict(input_seal=config['input_seal'],C2_manifest=descriptor(input_path),source_unit_sha256=receipt['unit_sha256'],order_index=index)
  value=dict(status='VERIFIED_SOURCE_ONLY_PREPARATION',order_index=index,page_id=raw['page_id'],processing_revision_id=raw['processing_revision_id'],
   occurrences=len(ids),groups=len(groups['groups']),candidates=len(active),unknown_targets=len(ledger['unresolved_relevant_targets']),
   pending_source=dict(unit_directory=str(folder/'sealed_pending'),unit_sha256=receipt['unit_sha256']),
   source_directory=str(folder),learned_decisions_reused=False,policy_executed=False,model_calls=0,global_candidate_coverage='UNKNOWN')
  path=RUN/'smoke'/('unit_'+str(index).zfill(4))/'stages'
  first=run_stage(path,'source',binding,lambda value=value,artifacts=artifacts:(value,artifacts))
  results.append(dict(**value,source_stage=descriptor(path/'source.json')))
 assert len(results)==3 and len(seen)==347
 output=RUN/'source_admission.json'
 summary=dict(status='THREE_IMMUTABLE_SOURCE_STAGES_VERIFIED_POLICY_NOT_RUN',units=results,occurrences=347,
  source_manifest=descriptor(input_path),policy_executed=False,bulk_started=False,model_calls=0,
  next_stage='E2_CPU_POLICY_HANDOFF',canonical_identity_state_changed=False)
 if output.exists():
  if read(output)!=summary:raise ValueError('Existing source admission belongs to another input')
 else:atomic_save(output,summary)
 return summary

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',type=Path,required=True);parser.add_argument('--inputs',type=Path,required=True)
 args=parser.parse_args();result=prepare(args.config,args.inputs)
 print(json.dumps(dict(status=result['status'],occurrences=result['occurrences'],receipt=descriptor(RUN/'source_admission.json')),indent=2))
