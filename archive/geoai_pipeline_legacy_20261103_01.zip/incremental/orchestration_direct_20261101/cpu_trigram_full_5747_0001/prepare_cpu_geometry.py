"""Current LOC source projection: reuse GEO's verified shapes/point gate, never choose conflicts."""
import gzip,importlib.util,json,sys
from pathlib import Path
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');OWN=ROOT/'orchestration_direct_20261101';RUN=OWN/'cpu_trigram_full_5747_0001'
sys.path.insert(0,str(RUN))
from cpu_stage_smoke import read,digest,descriptor,atomic_save

def prepare(counts_path,registry_descriptor,output):
 import geopandas as gpd
 import pandas as pd
 output=Path(output);output.mkdir(exist_ok=True)
 handoff_path=ROOT/'geometry_direct_20261101/runtime_geometry_audit_20261102_0001/INTEGRATION_HANDOFF_0001.json'
 assert digest(handoff_path)=='6c90a42677cea33ff41141cd96266a9dfba666a898d87fd437da7639061fde52'
 h=read(handoff_path)
 for key in ['code','audit','verification']:assert digest(h[key]['path'])==h[key]['sha256']
 assert digest(registry_descriptor['path'])==registry_descriptor['sha256'];registry=read(registry_descriptor['path'])['selected_references']
 spec=importlib.util.spec_from_file_location('verified_GEO_active_gate',h['code']['path']);geo=importlib.util.module_from_spec(spec);spec.loader.exec_module(geo)
 counts=read(counts_path);typed=counts['typed_counts'];locs=sorted({r['qid'] for r in typed if r['entity_group']=='LOC'})
 existing=h['source_feed']['existing_verified_shapes'];assert digest(existing['path'])==existing['sha256']
 baseline=gpd.read_parquet(existing['path']);assert baseline.crs.to_epsg()==4326
 selected={r['place_id']:(r.geometry,dict(r.drop(labels=['geometry']))) for _,r in baseline.iterrows() if r['place_id'] in locs}
 # Only GEO's explicitly source-QID/shape-verified historical selections are reused.
 allowed={h['small_actual_unit_example']['qid']}
 allowed.update(r['qid'] for r in h['outside_point_checks'] if r.get('source_QID_and_geometry_exact'))
 audit=read(h['audit']['path'])
 allowed.update(r['qid'] for r in audit['examples'] if r.get('historical_cached_shape',{}).get('source_shape_exact'))
 polygon_path=next(Path(p) for p in h['polygon_source_pins'] if p.endswith('geometries.parquet'))
 for p,sha in h['polygon_source_pins'].items():assert digest(p)==sha
 history=gpd.read_parquet(polygon_path,filters=[('place_id','in',locs)])
 assert history.crs.to_epsg()==4326
 for _,r in history.iterrows():
  if r['place_id'] in allowed and r['place_id'] not in selected:selected[r['place_id']]=(r.geometry,dict(r.drop(labels=['geometry'])))
 decisions=[];geometry_rows=[];geography=[]
 for qid in locs:
  ref=registry.get(qid);native=ref['envelope']['entity'] if ref else None
  shape=None;metadata={};candidates=[];unusable=[]
  if qid in selected:
   shape,metadata=selected[qid];before=shape.wkb;gate=geo.active_loc_gate(shape,entity_type='LOC');assert shape.wkb==before
   method='REUSED_GEO_VERIFIED_SOURCE_GEOMETRY'
  elif native is not None:
   assert native['id']==qid
   shape,candidates,unusable=geo.native_point_fallback(qid,native.get('claims',{}).get('P625',[]))
   if shape is not None:
    gate=geo.active_loc_gate(shape,entity_type='LOC');method='VERIFIED_NATIVE_P625_SINGLE_POINT_FALLBACK'
   elif candidates:
    gate=geo.candidate_scope(candidates);method='ALL_SOURCE_COORDINATE_CANDIDATES_RETAINED_NO_POSITION_WINNER'
   else:gate=geo.active_loc_gate(None,entity_type='LOC');method='NO_SUPPORTED_SOURCE_LOCATION_AT_THIS_FRONTIER'
  else:gate=geo.active_loc_gate(None,entity_type='LOC');method='MISSING_NATIVE_SOURCE_RECORD'
  assert gate['mask_result'] in ['INCLUDE','EXCLUDE','UNKNOWN']
  labels=native.get('labels',{}) if native else {};name=(labels.get('en') or labels.get('mul') or {}).get('value',qid)
  row=dict(place_id=qid,name=name,place_type='LOC',geometry_ref=None)
  if shape is not None:
   row.update({k:v for k,v in metadata.items() if k not in ['place_id','geometry_ref']})
   row.update(place_id=qid,place_type='LOC')
   geometry_rows.append(dict(place_id=qid,geometry=shape))
  geography.append(row)
  decisions.append(dict(qid=qid,entity_type='LOC',method=method,mask_result=gate['mask_result'],allow_active_LOC=gate['mask_result']=='INCLUDE',
   pending=gate['mask_result']=='UNKNOWN',source_native_revision=native.get('lastrevid') if native else None,
   source_provenance=ref.get('provenance') if ref else None,source_coordinate_candidates=candidates,unusable_source_statements=unusable,
   position_selected=shape is not None,position_selection_pending=shape is None and bool(candidates),source_claims_changed=False))
 frame=gpd.GeoDataFrame(geometry_rows,geometry='geometry',crs='EPSG:4326');parquet=output/'geometries.parquet';assert not parquet.exists();frame.to_parquet(parquet,index=False)
 for row in geography:
  if row['place_id'] in set(frame['place_id']):row['geometry_ref']=dict(file='geometries.parquet',place_id=row['place_id'],sha256=digest(parquet))
 gpath=output/'geography.json.gz';assert not gpath.exists();gpath.write_bytes(gzip.compress(json.dumps(geography,ensure_ascii=False).encode('utf8'),mtime=0))
 gate_by_qid={r['qid']:r['allow_active_LOC'] for r in decisions}
 # Typed-role gate: a separate PER/ORG/MISC role sharing the QID remains available.
 before_nodes=[dict(id=r['qid']+'::'+r['entity_group'],wikidata_id=r['qid'],type=r['entity_group']) for r in typed]
 after_nodes=[r for r in before_nodes if r['type']!='LOC' or gate_by_qid[r['wikidata_id']]]
 assert [r for r in after_nodes if r['type']!='LOC']==[r for r in before_nodes if r['type']!='LOC']
 active_qids={r['wikidata_id'] for r in after_nodes}
 probe_path=RUN/'real_cpu_unit3_0001/relation_receipt.json';probe=read(probe_path)['projection']['active_views']
 filtered=[e for e in probe if e['source'] in active_qids and e['target'] in active_qids]
 assert all(e['source'] in active_qids and e['target'] in active_qids for e in filtered)
 result=dict(status='PASS_REAL_THREE_UNIT_GEO_SOURCE_AND_TYPED_FILTER_WIRING',counts_snapshot=descriptor(counts_path),
  GEO_handoff=descriptor(handoff_path),GEO_code=h['code'],native_registry=registry_descriptor,mask_version=geo.MASK_VERSION,mask_sha256=geo.MASK_SHA256,
  scope_kind='FULL_LOC_POPULATION',scope_qids=locs,decisions=decisions,artifacts=dict(geography=descriptor(gpath),geoparquet=descriptor(parquet)),
  source_typed_nodes=len(before_nodes),active_typed_nodes=len(after_nodes),source_LOC=len(locs),active_LOC=sum(r['allow_active_LOC'] for r in decisions),
  outside_LOC=sum(r['mask_result']=='EXCLUDE' for r in decisions),unknown_LOC=sum(r['mask_result']=='UNKNOWN' for r in decisions),
  position_geometries=len(frame),typed_role_filter_test_passed=True,non_LOC_unchanged=True,
  edge_filter_test=dict(source=descriptor(probe_path),scope='EXISTING_ONE_UNIT_EDGES_FOR_WIRING_ONLY_NOT_CURRENT_THREE_UNIT_RELATIONS',before=len(probe),after=len(filtered)),
  consumer_materialized=False,final_relation_binding='AWAIT_COMPACT_C3_RELATION_FIX',publication=False)
 atomic_save(output/'geometry_source_receipt.json',result)
 assert len(gpd.read_parquet(parquet))==len(frame)
 print(json.dumps({k:result[k] for k in ['status','source_typed_nodes','active_typed_nodes','source_LOC','active_LOC','outside_LOC','unknown_LOC','position_geometries','edge_filter_test']},indent=2))
 print('receipt_SHA='+digest(output/'geometry_source_receipt.json'))
 return result

if __name__=='__main__':
 prepare(RUN/'three_unit_v3_0001/counts_snapshot.json',dict(path=str(ROOT/'pair_relations_direct_20261101/accepted11_20_sources_0001/generation_014/native_registry.json'),sha256='f1bf0d890542e63557d18af13e6067e3e8da3768e0a50543432516c0db5fb0dc'),RUN/'three_unit_v3_0001/GEO_source_0001')
