"""Read-only SQLite backup for downstream catch-up; never writes the CPU store."""
import argparse,hashlib,json,sqlite3,zlib,sys
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,'D:/Projects/GeoAI-incremental-dev-20261101/pair_relations_direct_20261101/compact_unit_store_0001')
from contribution_store import SCOPE_FIELDS

def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')
def pin(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def readonly(path):return sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True)

def read_active_units(receipt_path):
 receipt=load(receipt_path);database=receipt['database'];assert sha(database['path'])==database['sha256'],'Snapshot hash changed'
 with readonly(database['path']) as db:
  rows=db.execute('SELECT c.scope,c.sha256,c.payload FROM active a JOIN contributions c ON a.seq=c.seq ORDER BY c.scope').fetchall()
 units={}
 for scope,digest,payload in rows:
  raw=zlib.decompress(payload);assert hashlib.sha256(raw).hexdigest()==digest,'Stored contribution hash differs'
  units[tuple(json.loads(scope))]=[json.loads(raw)]
 assert len(units)==receipt['active_units']
 return units

def capture(work,output):
 # New destination only. SQLite's backup API provides one consistent committed DB view.
 output.mkdir(parents=True,exist_ok=False);source=work/'corpus.sqlite';database=output/'corpus.sqlite'
 state=load(work/'state.json');base=state['config']['base_counts'];assert sha(base['path'])==base['sha256']
 fields=SCOPE_FIELDS
 baseline={json.dumps([r['scope'][k] for k in fields],ensure_ascii=False,separators=(',',':')):dict(version=r['decision_version'],sha256=r['contribution_sha256']) for r in load(base['path'])['frontier']}
 with readonly(source) as origin,sqlite3.connect(database) as target:origin.backup(target,pages=128,sleep=0.01)
 with readonly(database) as db:
  assert db.execute('PRAGMA quick_check').fetchone()[0]=='ok'
  rows=db.execute('SELECT c.scope,c.version,c.sha256 FROM active a JOIN contributions c ON a.seq=c.seq ORDER BY c.scope').fetchall()
  history_count=db.execute('SELECT COUNT(*) FROM contributions').fetchone()[0]
 commits={}
 for path in (work/'commits').glob('unit_*.json'):
  item=load(path);manifest=item['source_scope'];key=json.dumps([manifest[k] for k in fields],ensure_ascii=False,separators=(',',':'))
  commits[key]=(item,pin(path))
 frontier=[]
 for scope,version,digest in rows:
  head=dict(version=version,sha256=digest)
  if scope in baseline:
   assert head==baseline[scope],'Prior CPU contribution changed'
   frontier.append(dict(scope=json.loads(scope),active_head=head,evidence=base))
  else:
   if scope not in commits or commits[scope][0]['active_head']!=head:
    (output/'NOT_READY.json').write_text(json.dumps(dict(status='RETRY_AFTER_CPU_FINAL_COMMIT',reason='Snapshot raced a source baseline/final receipt; no downstream admission'),indent=2),encoding='utf-8')
    raise RuntimeError('Snapshot raced CPU final receipt; retry into a new unique directory')
   item,ref=commits[scope]
   frontier.append(dict(scope=json.loads(scope),active_head=head,order_index=item['order_index'],evidence=ref))
 assert set(baseline)<=set(r[0] for r in rows),'Prior units lost'
 receipt=dict(schema='geoai-immutable-cpu-frontier-v1',status='READY_CPU_ONLY',captured_utc=datetime.now(timezone.utc).isoformat(),database=pin(database),
  canonical_source_store=str(source),active_units=len(rows),history_contributions=history_count,frontier=frontier,frontier_sha256=hashlib.sha256(encoded(frontier)).hexdigest(),
  full_process_completion_asserted=False,canonical_store_write_allowed=False,policy_config_sha256=state['config_sha256'],
  downstream_required=['source/native relation refresh','DATE/Event/context','active_LOC/geometry','consumer readback'],reader=pin(__file__))
 path=output/'receipt.json';path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
 units=read_active_units(path);assert len(units)==len(rows)
 assert sha(database)==receipt['database']['sha256'],'Readback mutated snapshot'
 print(json.dumps(dict(receipt=pin(path),active_units=len(rows),history_contributions=history_count,frontier_sha256=receipt['frontier_sha256'],status=receipt['status']),ensure_ascii=False))
 return path

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--work',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
 args=parser.parse_args();capture(args.work.resolve(),args.output.resolve())
