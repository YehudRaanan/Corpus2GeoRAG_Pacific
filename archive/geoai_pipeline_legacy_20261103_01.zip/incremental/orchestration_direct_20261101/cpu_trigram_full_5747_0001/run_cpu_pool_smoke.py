"""Three actual C2v3/C1 CPU units: parallel pure compute, one durable C3 writer."""
import json,sys,os,time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
from collections import Counter
from datetime import datetime,timezone
ROOT=Path('D:/Projects/GeoAI-incremental-dev-20261101');OWN=ROOT/'orchestration_direct_20261101';RUN=OWN/'cpu_trigram_full_5747_0001';OUT=RUN/'three_unit_v3_0001'
sys.path[:0]=[str(RUN),str(OWN),str(OWN/'runtime_handoff_0001')]
from cpu_stage_smoke import read,digest,descriptor,atomic_save,verify_patch_membership
POLICY=Path('C:/Users/User/Documents/Codex/2026-11-01/task-5/runtime_trigram_policy_v1')

def check_cooperative_storage_stop(pool_descriptor,request_path=None):
 request_path=Path(request_path) if request_path else RUN/'cpu_corpus_v2/storage_transition_request.json'
 if not request_path.exists():return
 request=read(request_path)
 if os.getpid() in request['allowed_worker_pids'] and Path(pool_descriptor['path']).resolve().is_relative_to(Path(request['compute_root']).resolve()):
  raise RuntimeError('CPU_STORAGE_TRANSITION_REQUESTED: immutable prepared inputs preserved; no policy decision executed')

def compute(index,pool_descriptor):
 check_cooperative_storage_stop(pool_descriptor)
 assert digest(pool_descriptor['path'])==pool_descriptor['sha256']
 pool=read(pool_descriptor['path']);release=read(POLICY/'MINIMAL_HANDOFF.json')
 for d in release['files'].values():assert digest(d['path'])==d['sha256']
 sys.path.insert(0,str(POLICY));import runtime_trigram as core
 start=time.perf_counter();group=core.decide_pool(pool['groups'],pool['entities'],complete=pool['complete'])
 value=core.merge_occurrences(pool['all_occurrence_mapping'],group['groups'],pool['protected_exact'],pool['occurrence_holds'])
 source=Path(pool['source_directory']);unit=read(source/'sealed_pending/unit.private.json')
 assert not unit['decisions'] and {r['occurrence_id'] for r in value['results']}=={r['occurrence_id'] for r in unit['occurrences']}
 for path,h in pool['source_sha256'].items():assert digest(path)==h
 version=core.POLICY['version']+':C2v3:'+str(unit['manifest']['page_id'])+':'+str(unit['manifest']['support_revision_id'])
 value['patch']['decision_version']=version
 for r in value['patch']['decisions'][len(pool['protected_exact']):]:r['evidence'].update(source_pool=pool_descriptor,source_group=next(x['group_id'] for x in pool['all_occurrence_mapping'] if x['occurrence_id']==r['occurrence_id']),source_sha256=unit['manifest']['source_sha256'])
 assert value['patch']['decisions'][:len(pool['protected_exact'])]==pool['protected_exact']
 membership=verify_patch_membership(unit,value['patch']);counts=dict(Counter(r['status'] for r in value['results']))
 slot=OUT/('unit_'+str(index).zfill(4));slot.mkdir(exist_ok=True)
 for name,x in [('decision_patch.json',value['patch']),('occurrence_outcomes.json',value['results']),('group_scores.json',group)]:atomic_save(slot/name,x)
 receipt=dict(schema='geoai-cpu-trigram-execution-v1',status='VERIFIED_CPU_TRIGRAM_EXECUTION',execution='EXECUTED_LOCAL_CPU',worker_pid=os.getpid(),
  order_index=index,source_pool=pool_descriptor,source_pending_unit=dict(unit_directory=str(source/'sealed_pending'),unit_sha256=digest(source/'sealed_pending/unit.private.json')),
  source_scope=unit['manifest'],policy=release['files']['policy.json'],policy_code=release['files']['runtime_trigram.py'],source_evidence_descriptor=pool['source_evidence_descriptor'],
  decision_patch=descriptor(slot/'decision_patch.json'),outcomes=descriptor(slot/'occurrence_outcomes.json'),group_scores=descriptor(slot/'group_scores.json'),
  counts=counts,protected_exact=len(pool['protected_exact']),membership=membership,seconds=time.perf_counter()-start,model_calls=0,learned_decisions_reused=False)
 atomic_save(slot/'CPU_policy_receipt.json',receipt)
 return dict(order_index=index,slot=str(slot),receipt=descriptor(slot/'CPU_policy_receipt.json'))

def main():
 started=datetime.now(timezone.utc).isoformat();OUT.mkdir(exist_ok=True)
 print('START3_CPU_V3 parent_pid='+str(os.getpid())+' utc='+started+' workers=2 single_commit_writer',flush=True)
 manifest_path=ROOT/'cpu_trigram_inputs_v1/ordinary_pool_bridge_v3/bridge_manifest.json'
 assert digest(manifest_path)=='2da712cbbc5c23563790e15db0a99c70ed8cc0da065dfd4a07b2fdc5685b7130'
 manifest=read(manifest_path);assert [r['order_index'] for r in manifest['units']]==[0,1,2]
 for name,value in manifest['code_sha256'].items():assert digest(manifest_path.parent/name)==value
 completed=[]
 with ProcessPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(compute,r['order_index'],dict(path=r['path'],sha256=r['sha256'])) for r in manifest['units']]
  for future in as_completed(futures):
   r=future.result();completed.append(r);print('CPU_DONE index='+str(r['order_index'])+' '+str(read(r['receipt']['path'])['counts']),flush=True)
 from decision_handoff import build_handoff
 c3=ROOT/'pair_relations_direct_20261101/compact_unit_store_0001';h=read(c3/'C3_HANDOFF_0001.json')
 for name,expected in h['files_sha256'].items():assert digest(c3/name)==expected
 sys.path.insert(0,str(c3));from contribution_store import ContributionStore
 store=ContributionStore(OUT/'contributions.sqlite');units=[]
 try:
  for worker in sorted(completed,key=lambda x:x['order_index']):
   receipt=read(worker['receipt']['path']);source=receipt['source_pending_unit'];slot=Path(worker['slot']);patch=read(receipt['decision_patch']['path'])
   built=build_handoff(slot/'sealed',current_sealed_dir=source['unit_directory'],current_unit_sha256=source['unit_sha256'],prior_history=[],supplied_decisions=patch['decisions'],decision_version=patch['decision_version'])
   baseline=read(Path(source['unit_directory'])/'unit.private.json');raw=(Path(source['unit_directory'])/'source.private.bin').read_bytes()
   store.apply(baseline,raw);store.apply(built['handoff'],raw)
   replay=store.apply(built['handoff'],raw);assert replay['changed'] is False
   stage=dict(status='CPU_POLICY_AND_DURABLE_CONTRIBUTION_SAVED',order_index=worker['order_index'],policy_receipt=worker['receipt'],
    sealed_unit=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256']),counts=receipt['counts'],protected_exact=receipt['protected_exact'],
    replay_changed=False,full_unit_complete=False,remaining=['DATE/Event/context current-version routes','native relation/source projection','activeLOC geometry filter','consumer readback'])
   atomic_save(slot/'unit_result.json',stage);units.append(stage)
   atomic_save(OUT/'commit_cursor.json',dict(single_writer_pid=os.getpid(),committed_units=[r['order_index'] for r in units],last_unit_result=descriptor(slot/'unit_result.json')))
  counts=store.counts(False);stats=store.stats();assert counts['unique_occurrences']==347 and stats['active_units']==3 and stats['contributions']==6
  assigned=sum(r['mention_count'] for r in counts['identity_counts']);totals=Counter()
  for u in units:totals.update(u['counts'])
  assert assigned==totals['IDENTITY'] and counts['pending_occurrences']==totals['PENDING'] and counts['explicit_unmatched_occurrences']==totals['NONE']
  atomic_save(OUT/'counts_snapshot.json',counts)
 finally:store.close()
 # Verify the two known C2 regressions on the actual new policy outputs.
 a=read(OUT/'unit_0000/occurrence_outcomes.json');pool0=read(manifest['units'][0]['path']);gids={g['id'] for g in pool0['groups'] if g['name']=='Japan'}
 japan=[r for r in a if r['group_id'] in gids];assert len(japan)==14 and all(r['status']=='PENDING' for r in japan)
 assert units[2]['protected_exact']==25 and sum(u['protected_exact'] for u in units)==61
 result=dict(status='PASS_ACTUAL_C2V3_CPU_POLICY_SEAL_C3_THREE_UNITS',started_utc=started,parent_pid=os.getpid(),compute_workers=2,canonical_writers=1,
  source_manifest=descriptor(manifest_path),units=units,occurrences=347,assigned=totals['IDENTITY'],explicit_NONE=totals['NONE'],pending=totals['PENDING'],protected_exact=61,
  Japan14_pending_preserved=True,unit3_exact25_preserved=True,store_stats=stats,counts_snapshot=descriptor(OUT/'counts_snapshot.json'),
  SQLite_bytes=(OUT/'contributions.sqlite').stat().st_size,full_units_complete=0,bulk_started=False,model_calls=0,previous_generations_preserved=True,publication=False)
 atomic_save(OUT/'verification.json',result)
 print(json.dumps({k:v for k,v in result.items() if k!='units'},indent=2),flush=True)
 print('verification_SHA='+digest(OUT/'verification.json'),flush=True)

if __name__=='__main__':main()
