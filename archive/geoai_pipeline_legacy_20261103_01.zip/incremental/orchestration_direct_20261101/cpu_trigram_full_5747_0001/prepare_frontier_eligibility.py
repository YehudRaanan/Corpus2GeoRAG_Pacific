"""Run E2's verified generic routes, then bind their results to actual consumer success."""
import importlib.util,sys
from pathlib import Path
R=Path('D:/Projects/GeoAI-incremental-dev-20261101/orchestration_direct_20261101/cpu_trigram_full_5747_0001');sys.path.insert(0,str(R))
from cpu_stage_smoke import read,digest,descriptor,atomic_save
from run_downstream_chain import pin,references,admission_rows
E2=Path('C:/Users/User/Documents/Codex/2026-11-01/task-5/frontier_route_checks_v1')

def prepare_eligibility(frontier_descriptor,event_handoff,consumer_handoff,output_dir):
 frontier=pin(frontier_descriptor);event=pin(event_handoff);consumer=pin(consumer_handoff);references(consumer)
 if consumer['status']!='PASS_FROZEN_FULL_ORDINARY_EVENT_ACTIVE_GEO_CONSUMER' or consumer['CPU_units']!=frontier['active_units']:raise ValueError('Required verified consumer missing')
 if consumer['request']['event_handoff']!=event_handoff or event['frozen_frontier']!=frontier_descriptor:raise ValueError('Consumer/Event/frontier differ')
 proof=read(E2/'independent_verification.json');assert proof['status']=='PASS_TWO_EXISTING_FRONTIERS_AND_PRIOR_OUTCOME_EQUIVALENCE'
 tested=pin(proof['frontiers'][0]['handoff']);processor=tested['callable'];assert digest(processor['path'])==processor['sha256']
 output=Path(output_dir);marker=output/'HANDOFF.json';request=dict(frontier=frontier_descriptor,event=event_handoff,consumer=consumer_handoff,processor=processor,adapter=descriptor(__file__))
 if marker.exists():
  saved=read(marker)
  if saved['request']!=request:raise ValueError('Changed eligibility request')
  references(saved);return saved
 if output.exists():raise ValueError('Preserve incomplete eligibility generation; assign a new output')
 output.mkdir(parents=True)
 spec=read(E2/'spec_frozen90.json');old_cpu={}
 fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
 for ref in spec['cpu_receipts']:
  cpu=pin(ref);old_cpu[tuple(cpu['source_scope'][k] for k in fields)]=ref
 config=pin(event['config']);inventory=pin(config['active_units']);cpus=[]
 for entry in inventory['units']:
  unit=pin(entry['unit']);key=tuple(unit['manifest'][k] for k in fields);ref=entry.get('CPU_policy',old_cpu.get(key))
  if ref is None:raise ValueError('Missing exact current CPU receipt')
  pin(ref);cpus.append(ref)
 spec.update(frontier=frontier_descriptor,cpu_receipts=cpus,event_handoff=event['route'],native_registry=event['native_registry'])
 module_spec=importlib.util.spec_from_file_location('_verified_e2_routes',processor['path']);module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
 routes=module.run_frontier(spec,output/'routes')
 if routes['status']!='PASS_REQUIRED_ROUTES' or routes['counts']['routes_complete_units']!=frontier['active_units']:raise ValueError('Unrun required routes remain')
 heads={tuple(row['scope']):row['active_head'] for row in frontier['frontier']};eligible=[]
 for row in routes['units']:
  scope=row['source_scope'];key=tuple(scope[k] for k in fields)
  if heads[key]!=dict(version=row['decision_version'],sha256=row['frozen_contribution_sha256']) or not row['route_verification']['complete']:raise ValueError('Route head/version differs')
  eligible.append(dict(unit_key=[scope['wiki_site'],scope['page_id'],scope['support_revision_id']],decision_version=row['decision_version'],all_required_stages_executed=True,receipts=[row['CPU_receipt'],*row['routes'].values(),consumer_handoff]))
 result=dict(status='VERIFIED_GENERIC_FULL_FRONTIER_ELIGIBILITY',request=request,route_handoff=descriptor(output/'routes/route_completion_handoff.json'),eligible_units=eligible,route_counts=routes['counts'],identity_changes=0,publication=False)
 admission_rows(result,frontier);atomic_save(marker,result);return result
