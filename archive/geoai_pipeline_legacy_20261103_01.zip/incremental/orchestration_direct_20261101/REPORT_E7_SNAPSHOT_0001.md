# E7 snapshot_0001 receipt-chain extension

**PASS**, 2026-11-01 20:32:18 UTC. check_one_unit.py now verifies six completed existing boundaries: INPUT seal, grouping, supported partial exact, sealed handoff, private counts and local partial consumer snapshot. New status is run_0003/stage_status.json. Earlier run_0001/run_0002 reports and exact checker source archives remain unchanged.

Read-only publisher input: snapshot_0001/private/receipt.json, pinned SHA256 3f60c48f3f26f978bab92fabde901bb71f2a63d3ae725c50cc05b32a9a84b2c3, and its independent_verification.json. All receipt input/output/adapter/verification hashes match. The publisher's source handoff hashes bind the same processing revision, first-unit-exact-v1 and 136 IDs used by the other stages.

Consumer node IDs equal exactly the ten accepted `(QID,raw_type)` identities from 30 accepted occurrences. Every mapping's mention count matches those source records. There are no SYN or pending-derived nodes. The 106 pending occurrence records remain hash-bound upstream and are reported as pending, never NONE. Required graph fields/vocabulary remain unchanged.

Actual unchanged GraphStore consumer load passes. Graph and model contain no relation/event assertions, graph edges or geometry. Five LOC Geography rows have explicit null geometry_ref; the separate empty GeoParquet has place_id/geometry columns and EPSG:4326. Missing geometry is reported as missing coverage, not fabricated or a technical join failure.

A first checker run failed before output creation because only the Agent path, not the MAIN project root, was on sys.path. The consumer trace showed its lazy GG_Data import. Adding the existing MAIN path fixed the checker environment; no publisher/source code changed. No run_0003 directory existed after the failed attempt.

Independent fresh-process verification reran only inspect_chain, compared the complete status to saved run_0003, checked consumer loading, receipt/source hashes, empty Events/Relations and the preceding run's exact source archive. No publisher pipeline, adapter writer or readback script was rerun; no publisher file was modified. No model, relation inference, geometry selection, consumer contract change or publication occurred. Backup: Unprotected.

## Remaining real pipeline work

- This snapshot is coherent and locally loadable; 106 pending and absent geometry are explicit partial coverage, not blanket delivery vetoes.
- Source-backed native-relation availability/linkability for these represented IDs remains a separate E5 frontier. Private counts alone do not establish relations or select G11 weight serialization.
- Residual/type/Event-route decisions remain scoped to their existing policies; missing candidate targets stay unknown, not NONE. A trained-model artifact/accepted residual policy is needed only for its model-dependent branch.
- The parent delivered snapshot_0002 with one Tokyo geometry while this check was finishing. Its receipt/version is the next bounded verification, not silently substituted into this snapshot_0001 result. Other LOC coverage stays separately reported; new ranking/projection decisions are not inferred.
- Actual publication/release and canonical batch/cadence semantics remain unexecuted. This checker dispatches no additional unit and proves no corpus runtime/resource sizing or power-loss recovery.
