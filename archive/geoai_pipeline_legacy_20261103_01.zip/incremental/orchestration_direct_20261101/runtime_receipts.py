"""Technical input/version checks and the explicit, pinned source-provider boundary."""
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import sys
from check_one_unit import read,digest
from run_approved_unit import pinned

ROOT=Path(__file__).resolve().parent.parent


def verify_matching(descriptor,patch_descriptor,expected_scope=None):
    receipt=pinned(descriptor)
    if receipt['decision_patch']!=patch_descriptor:raise ValueError('Policy receipt belongs to another decision patch')
    if expected_scope is not None:
        fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
        if receipt['source_scope']!={field:expected_scope[field] for field in fields}:
            raise ValueError('Inference receipt belongs to another sealed source scope')
    seen=set()
    for direction in ('forward','reverse'):
        item=receipt['directions'][direction]
        bindings=pinned(item['bindings'])
        expected={row['id']:row for row in bindings}
        if len(expected)!=len(bindings):raise ValueError('Duplicate request binding')
        path=Path(item['proposals']['path'])
        if digest(path)!=item['proposals']['sha256']:raise ValueError('Proposal bytes changed')
        actual=set()
        for line in path.read_text(encoding='utf-8').splitlines():
            row=json.loads(line);request=row['request'];raw=request['raw'];key=raw['id']
            if key in actual or key in seen or key not in expected or raw['direction']!=direction:
                raise ValueError('Unexpected/duplicate inference question or direction')
            binding=expected[key]
            if request['input_version']!=binding['input_version'] or row['artifact']['input_version']!=binding['input_version']:
                raise ValueError('Inference input versions differ')
            if row['input_sha256']!=binding['input_sha256'] or row['encoded_sha256']!=binding['encoded_sha256']:
                raise ValueError('Inference request/encoded binding differs')
            actual.add(key);seen.add(key)
        if actual!=set(expected):raise ValueError('Inference questions are incomplete')
    return dict(status='VERIFIED_BIDIRECTIONAL_INPUT_BINDING',questions=len(seen),receipt=descriptor)


def accepted_sources(adapter,output,registry,qids):
    previous=pinned(registry)
    missing=sorted(set(qids)-set(previous['selected_references']))
    if not missing:return registry
    if adapter is None:return registry  # Explicit pending source coverage remains in the relation receipt.
    path=Path(adapter['path']).resolve()
    if not path.is_relative_to(ROOT/'pair_relations_direct_20261101') or digest(path)!=adapter['sha256']:
        raise ValueError('Source provider must be the pinned RELATIONS-owned callable')
    specification=importlib.util.spec_from_file_location('runtime_sources_'+adapter['sha256'][:16],path)
    module=importlib.util.module_from_spec(specification);sys.modules[specification.name]=module
    specification.loader.exec_module(module)
    limit=adapter.get('max_public_qids',0)
    if type(limit) is not int or not 0<=limit<=5:raise ValueError('Source public scope must be explicitly bounded from zero to five')
    # The producer writes its own new generation; the caller keeps its stage pointer separately.
    target_root=Path(adapter.get('output_root',ROOT/'pair_relations_direct_20261101/orchestration_registry_0001')).resolve()
    if not target_root.is_relative_to(ROOT/'pair_relations_direct_20261101'):
        raise ValueError('Registry generations must remain in RELATIONS ownership')
    target=target_root/sha256(str(Path(output).resolve()).encode()).hexdigest()[:20]
    completed=module.complete_registry(missing,prior_registry=registry['path'],prior_sha256=registry['sha256'],
        output_dir=target,max_public_qids=min(limit,len(missing)))
    result=completed['native_registry']
    updated=pinned(result)
    for qid,value in previous['selected_references'].items():
        if updated['selected_references'].get(qid)!=value:raise ValueError('Source provider changed an existing selected source')
    for qid in set(missing)&set(updated['selected_references']):
        envelope=updated['selected_references'][qid]['envelope']
        if envelope['requested_qid']!=qid or envelope['entity']['id']!=qid or 'claims' not in envelope['entity']:
            raise ValueError('Source provider returned an incompatible whole native record')
    return result
