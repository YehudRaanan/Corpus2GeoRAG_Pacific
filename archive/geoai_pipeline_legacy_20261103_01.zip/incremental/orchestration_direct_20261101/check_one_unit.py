"""Verify one completed receipt chain; do not dispatch or rerun pipeline stages."""
import hashlib
import gzip
import json
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WORK = ROOT / "integration_direct_20261101"
INPUT = ROOT / "review_treatments/first_run_input_20261101_v1"


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def check_ids(actual, expected):
    assert len(actual) == len(set(actual)) == 136, "Lost or duplicated occurrence ID"
    assert set(actual) == set(expected), "Occurrence membership differs"


def inspect_chain():
    verified = {}

    def require_hash(path, expected):
        path = Path(path)
        actual = verified.setdefault(str(path), digest(path)) if str(path) not in verified else verified[str(path)]
        assert actual == expected, "Artifact hash differs: " + str(path)

    require_hash(INPUT / "seal.json", "03cd6fd90d609815c431ea234d9c32f0c10e98287b60d515439f15305b5e4089")
    seal = read(INPUT / "seal.json")
    assert seal["source_input_ready"] and seal["seal_status"] == "SEALED_DECLARED_RETAINED_SCOPE"
    fields = {"readback_receipt.json": "readback_receipt_sha256", "writer_receipt.json": "writer_receipt_sha256",
              "retained_mentions.parquet": "retained_parquet_sha256", "omitted_mentions.parquet": "omission_ledger_sha256",
              "sealed_units.jsonl.gz": "sealed_units_sha256", "first_unit.json": "first_unit_sha256"}
    for name, field in fields.items():
        require_hash(INPUT / name, seal[field])
    unit = read(INPUT / "first_unit.json")
    assert (unit["page_id"], unit["processing_revision_id"], unit["retained_count"]) == (48975579, 1375061414, 136)
    assert read(INPUT / "readback_receipt.json")["full_independent_readback"]
    require_hash(Path(unit["source_path"]), unit["source_sha256"])

    r2dir, exdir, hdir = WORK / "real_unit_0001", WORK / "exact_unit_0001", WORK / "real_handoff_0001"
    grouping, exact, handoff = read(r2dir / "run_receipt.json"), read(exdir / "receipt.json"), read(hdir / "receipt.json")
    for receipt in (grouping, exact, handoff):
        assert (receipt["page_id"], receipt["processing_revision_id"]) == (unit["page_id"], unit["processing_revision_id"])
    assert grouping["status"] == "PASS_ONE_REAL_R2_GROUPING_UNIT"
    assert grouping["input_seal_sha256"] == verified[str(INPUT / "seal.json")]
    for receipt in (grouping, exact, handoff):
        for name in ("artifact_sha256", "protected_sha256"):
            for path, expected in receipt.get(name, {}).items():
                require_hash(Path(path), expected)
    for directory, receipt in ((r2dir, grouping), (hdir, handoff)):
        for relative, expected in receipt["output_sha256"].items():
            require_hash(directory / relative, expected)
    require_hash(exdir / "decisions.json", exact["decisions_sha256"])
    source = read(r2dir / "source_members.json")
    expected_ids = grouping["expected_occurrence_ids"]
    check_ids([r["occurrence_id"] for r in source], expected_ids)
    assert {r["source_row_index"] for r in source} == set(unit["expected_row_indices"])
    assert all(r["input_sha256"] == unit["input_sha256"] and r["processing_revision_sha256"] == unit["source_sha256"] for r in source)
    grouped = read(r2dir / "groups.json")
    members = [m for g in grouped["groups"] for m in g["members"]]
    check_ids([m["occurrence_id"] for m in members], expected_ids)
    assert len(grouped["groups"]) == 69 and not grouped["unresolved"]
    originals = {r["occurrence_id"]: r for r in source}
    for member in members:
        original = originals[member["occurrence_id"]]
        assert member["word_original"] == original["word"] and member["word"] == original["processing_surface"] == original["prepared_word"]

    assert exact["status"] == "PASS_FIRST_UNIT_SUPPORTED_UNIQUE_EXACT"
    decisions = read(exdir / "decisions.json")
    rows = decisions["occurrence_decisions"]
    check_ids([r["occurrence_id"] for r in rows], expected_ids)
    accepted = {r["occurrence_id"]: r for r in rows if r["accepted_qid"] is not None}
    pending = {r["occurrence_id"] for r in rows if r["accepted_qid"] is None}
    assert len(accepted) == 30 and len(pending) == 106 and not any(r["none_decision"] for r in rows)
    group_qids = defaultdict(set)
    for row in accepted.values():
        group_qids[row["group_id"]].add(row["accepted_qid"])
    assert len(group_qids) == 10 and all(len(qids) == 1 for qids in group_qids.values())
    assert handoff["status"] == "PASS_REAL_FIRST_VERSION_E2_E4_HANDOFF"
    slot = hdir / "sealed_v1"
    private, private_seal = read(slot / "unit.private.json"), read(slot / "seal.json")
    require_hash(slot / "unit.private.json", handoff["pinned_unit_sha256"])
    assert private_seal["unit_sha256"] == handoff["pinned_unit_sha256"]
    assert private["manifest"] == unit and private["input_seal_sha256"] == grouping["input_seal_sha256"]
    assert private["version"] == private_seal["decision_version"] == handoff["decision_version"] == "first-unit-exact-v1"
    assert private["prior_version"] is None
    check_ids([r["occurrence_id"] for r in private["occurrences"]], expected_ids)
    assert {r["occurrence_id"]: r["qid"] for r in private["decisions"]} == {key: row["accepted_qid"] for key, row in accepted.items()}
    assert {r["occurrence_id"] for r in private["pending_evidence"]} == set(private_seal["pending_occurrence_ids"]) == pending
    assert private_seal["explicit_unmatched_occurrence_ids"] == []
    aggregate = read(hdir / "aggregate.json")
    assert aggregate["unique_occurrences"] == aggregate["support_records"] == 136 and aggregate["unique_physical_pages"] == 1
    assert len(aggregate["identity_counts"]) == 10 and sum(r["mention_count"] for r in aggregate["identity_counts"]) == 30
    # Hook only the explicitly delivered and verified real-counts receipt.
    cdir = ROOT / "counts_direct_20261101/real_counts_20261101T202248289937Z"
    require_hash(cdir / "verification.json", "590cfa27e187541d9b155857d5979089a8b89a842684d198bd3d92c5fe535b4b")
    counts_receipt = read(cdir / "verification.json")
    assert counts_receipt["status"] == "PASS_REAL_COUNTS"
    assert counts_receipt["input_receipt_sha256"] == digest(hdir / "receipt.json")
    for path, expected in counts_receipt["protected_sha256"].items():
        require_hash(Path(path), expected)
    for relative, expected in counts_receipt["output_sha256"].items():
        require_hash(cdir / relative, expected)
    require_hash(ROOT / "counts_direct_20261101/real_counts.py", counts_receipt["code_sha256"])
    counts, saved_pending = read(cdir / "counts.json"), read(cdir / "pending.json")
    assert counts["pinned_unit_sha256"] == handoff["pinned_unit_sha256"]
    assert counts["decision_version"] == private["version"] and counts["history_versions"] == 1
    for field in ("input_sha256", "wiki_site", "page_id", "support_revision_id", "source_sha256", "policy_version"):
        assert counts["scope"][field] == unit[field]
    assert (counts["retained_occurrences"], counts["accepted_occurrences"], counts["pending_occurrences"]) == (136, 30, 106)
    assert counts["identity_counts"] == aggregate["identity_counts"]
    assert {r["occurrence_id"]: r for r in saved_pending} == {r["occurrence_id"]: r for r in private["pending_evidence"]}
    pairs = counts["pairs"]
    assert len(pairs) == len({tuple(sorted((p["source_qid"], p["target_qid"]))) for p in pairs}) == 45
    for pair in pairs:
        assert pair["source_qid"] != pair["target_qid"]
        assert all(type(pair[key]) is int and pair[key] == 1 for key in ("shared_page_count", "source_page_count", "target_page_count"))
    independent = read(cdir / "independent_verification.json")
    assert independent["status"] == "PASS" and independent["fresh_process"]
    assert (independent["accepted_occurrences"], independent["pending_occurrences"], independent["pairs"]) == (30, 106, 45)
    assert not counts_receipt["consumer_export"] and not counts_receipt["relations_created"]
    # Read the existing partial E7 snapshot only; never call its writer/verifier scripts.
    publisher = ROOT / "publisher_direct_20261101"
    snapshot = publisher / "snapshot_0001"
    private_dir = snapshot / "private"
    publisher_receipt_path = private_dir / "receipt.json"
    require_hash(publisher_receipt_path, "3f60c48f3f26f978bab92fabde901bb71f2a63d3ae725c50cc05b32a9a84b2c3")
    publisher_receipt = read(publisher_receipt_path)
    assert publisher_receipt["status"] == "PASS_LOCAL_PARTIAL_CONSUMER_LOAD" and not publisher_receipt["publication"]
    for path, expected in publisher_receipt["inputs_sha256"].items():
        require_hash(Path(path), expected)
    for relative, expected in publisher_receipt["artifact_sha256"].items():
        require_hash(snapshot / relative, expected)
    require_hash(private_dir / "missingness.json", publisher_receipt["missingness_sha256"])
    require_hash(publisher / "consumer_adapter.py", publisher_receipt["adapter_sha256"])
    publisher_independent = read(private_dir / "independent_verification.json")
    assert publisher_independent["status"] == "PASS_FRESH_PROCESS_READBACK"
    assert publisher_independent["snapshot_receipt_sha256"] == verified[str(publisher_receipt_path)]
    require_hash(publisher / "verify_readback.py", publisher_independent["verification_code_sha256"])
    graph, missingness = read(snapshot / "graph.json"), read(private_dir / "missingness.json")
    expected_nodes = {f"{r['accepted_qid']}::{r['raw_type']}" for r in accepted.values()}
    assert len(expected_nodes) == len(graph["nodes"]) == 10
    assert {n["id"] for n in graph["nodes"]} == expected_nodes
    assert set(graph) == {"metadata", "relation_catalog", "nodes", "edges"}
    assert graph["edges"] == [] and graph["relation_catalog"] == {}
    assert all(set(n) == {"id", "wikidata_id", "name", "type", "aliases"} for n in graph["nodes"])
    assert all(n["wikidata_id"] == n["id"].split("::")[0] for n in graph["nodes"])
    expected_mentions = defaultdict(int)
    for row in accepted.values():
        expected_mentions[f"{row['accepted_qid']}::{row['raw_type']}"] += 1
    assert {r["node_id"]: r["mention_count"] for r in missingness["identity_mapping"]} == dict(expected_mentions)
    assert (missingness["accepted_occurrences"], missingness["pending_occurrences"]) == (30, 106)
    with gzip.open(snapshot / "model/geography.json.gz", "rt", encoding="utf-8") as stream:
        geography = json.load(stream)
    assert len(geography) == 5 and all(r["geometry_ref"] is None for r in geography)
    import geopandas as gpd
    geometries = gpd.read_parquet(snapshot / "model/geometries.parquet")
    assert geometries.empty and set(geometries.columns) == {"place_id", "geometry"} and geometries.crs.to_epsg() == 4326
    sys.path[:0] = [r"D:\Projects\GeoAI", r"D:\Projects\GeoAI\Agent"]
    from geo_agent.graph_store import GraphStore
    store = GraphStore.from_json(snapshot / "graph.json", model_dir=snapshot / "model")
    assert set(store.nodes) == expected_nodes and not store.edges and not store.geoms
    assert all(store.resolve_ids(row["accepted_qid"]) == [f"{row['accepted_qid']}::{row['raw_type']}"] for row in accepted.values())
    # Negative checks are in-memory/read-only: reject corrupted linkage and changed membership.
    for operation in (lambda: require_hash(INPUT / "seal.json", "0" * 64),
                      lambda: check_ids(expected_ids[:-1] + [expected_ids[0]], expected_ids)):
        try:
            operation()
        except AssertionError:
            pass
        else:
            raise AssertionError("Corrupt lineage/membership was accepted")
    stages = dict(input=dict(status="COMPLETED_SEALED", retained_scope=seal["retained_occurrences"], unit_members=136),
                  grouping=dict(status="COMPLETED", groups=69, members=136),
                  exact=dict(status="COMPLETED_PARTIAL", accepted_groups=10, accepted_occurrences=30, pending_occurrences=106,
                             pending_positive_MISC_groups=5, unresolved_target_count=6, none_decisions=0),
                  handoff=dict(status="COMPLETED_SEALED_FIRST_VERSION", version=private["version"], physical_pages=1, history_versions=1),
                  counts=dict(status="COMPLETED_PRIVATE_COUNTS", accepted_occurrences=30, accepted_identities=10,
                              physical_pages=1, unordered_pairs=45, pending_occurrences=106,
                              consumer_weights=False, native_relations_inferred=False),
                  consumer_snapshot=dict(status="COMPLETED_LOCAL_PARTIAL_READBACK", nodes=10, accepted_occurrences=30,
                                         pending_occurrences=106, edges=0, geometry_rows=0, locations_without_geometry=5,
                                         pending_delivered_as_identity=False, publication=False))
    receipts = {str(path): digest(path) for path in (INPUT / "seal.json", r2dir / "run_receipt.json", exdir / "receipt.json", hdir / "receipt.json",
                                                    cdir / "verification.json", cdir / "independent_verification.json",
                                                    publisher_receipt_path, private_dir / "independent_verification.json")}
    return dict(status="PASS_ONE_UNIT_RECEIPT_CHAIN", page_id=unit["page_id"], processing_revision_id=unit["processing_revision_id"],
                occurrence_ids=expected_ids, stages=stages, receipt_sha256=receipts, verified_artifact_sha256=verified,
                negative_hash_and_membership_checks="PASS", pipeline_stages_executed=False,
                closure_scope=unit["coverage_scope"], consumer_export=False, publication=False, backup_status="Unprotected")


if __name__ == "__main__":
    result = inspect_chain()
    output = HERE / "run_0003"
    output.mkdir()
    result["checked_utc"] = datetime.now(timezone.utc).isoformat()
    result["code_sha256"] = digest(Path(__file__))
    path = output / "stage_status.json"
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    assert read(path) == result
    print(json.dumps({key: result[key] for key in ("status", "checked_utc", "page_id", "processing_revision_id", "stages")}))
