"""Record current real v2 progress and the controlling structured-time correction."""
from datetime import datetime,timezone
from pathlib import Path
from check_one_unit import read,digest
from run_ready_units import save

HERE=Path(__file__).resolve().parent;OUT=HERE/'v2_status_0001';TASK=Path('C:/Users/User/Documents/Codex/2026-11-01/task')

def update():
    OUT.mkdir(exist_ok=True)
    proof=read(HERE/'policy_v2_integration_0001/independent_verification.json')
    semantics=HERE/'route_receipt_generation_0002/receipt.json';assert read(semantics)['process_completed_units']==0
    state_path=HERE/'reconciliation_units11_20_v2/state.json';state=read(state_path)
    status=dict(status='V2_DECISIONS_SAVED_STRUCTURED_TIME_AND_EVENT_INCOMPLETE',observed_utc=datetime.now(timezone.utc).isoformat(),
        first_nine=dict(assigned=449,explicit_NONE=329,pending=232,occurrences=1010,source_units=9,
            proof=dict(path=str(HERE/'policy_v2_integration_0001/independent_verification.json'),sha256=digest(HERE/'policy_v2_integration_0001/independent_verification.json')),
            missing_consumed_sources=['Q218932'],current_frontier_consumer_materialized=False),
        eight_new=dict(sealed_units=[11,12,13,14,15,17,18,20],assigned=386,explicit_NONE=270,pending=188,occurrences=844,
            proof=dict(path=str(HERE/'reconciliation_units11_20_v2/sealed_successors.json'),sha256=digest(HERE/'reconciliation_units11_20_v2/sealed_successors.json')),
            projected_units={key:row['status'] for key,row in state['units'].items()},cursor=state['cursor']),
        temporal=dict(approved_basis='STRUCTURED_QID_WIKIDATA',structured_stage='NOT_YET_VERIFIED',raw_DATE_pending=334,
            parser_diagnostics=dict(processed=334,normalized=242,unsupported=92,approved_for_enrichment=False)),
        event=dict(executed_cache_classification=25,full_route_complete=False,remaining=['native ancestry','approved G6/G7 input bindings','Event selection','Event consumer wiring']),
        process_completed_units=0,publication_eligible_units=0,publication=False,capacity_blocked=[6,16,19],
        route_semantics=dict(path=str(semantics),sha256=digest(semantics)),
        source_request=dict(path=str(HERE/'reconciliation_units11_20_v2/combined_source_request.json'),sha256=digest(HERE/'reconciliation_units11_20_v2/combined_source_request.json')))
    save(OUT/'CURRENT_STATUS.json',status)
    current=HERE/'reconciliation_first10_v1/CURRENT_STATUS.json'
    backup=OUT/'CURRENT_STATUS_before.json'
    if not backup.exists():backup.write_bytes(current.read_bytes())
    save(current,dict(status='SUPERSEDED_BY_V2_STATUS',current_status=dict(path=str(OUT/'CURRENT_STATUS.json'),sha256=digest(OUT/'CURRENT_STATUS.json')),
        completed_units=0,consumer_materializations_historical=9,prior_status_backup=dict(path=str(backup),sha256=digest(backup))))
    note='''### Superseding v2 integration and structured-time correction — 2026-11-02 UTC

E2's pinned v2 release was adopted, not merely proposed. Nine immutable successor seals preserve all446 existing identities and1010 occurrence IDs; current counts/relation/full-geometry projections independently read back449 identities,329 explicitNONE and232 pending. All nine projection jobs finished. Native source Q218932 is missing from the consumed registry194; consumer readback for the full v2 frontier remains pending this source refresh. Previous readable consumer generations remain preserved. See policy_v2_integration_0001/independent_verification.json.

Eight complete-input units11-15,17,18,20 are sealed under corrected policy:844 IDs,386 identity assignments,270 explicitNONE,188 pending;165 protected exact decisions retained. The generic CPU loop is running from the completed nine-unit v2 cursor using reconciliation_units11_20_v2_config.json; it saves each stage and includes provided DATE diagnostic receipts. Source completion is solely RELATIONS-owned. combined_source_request.json contains146 actual accepted-QID gaps relative to consumed registry194, not speculative candidates. Units6/16/19 remain capacity-blocked/pending and are not counted complete.

Controlling owner instruction,2026-11-01 09:55:09UTC, Sentinel_ccf8866d54208191bd1af18a88e1df6e: time must come from structured QID-linked Wikidata values, not direct text decoding. The delivered334 raw-DATE parser outcomes (242 normalized,92 unsupported) are DIAGNOSTICS ONLY; every original DATE remains pending and no parsed date is promoted to temporal enrichment. route_receipt_generation_0002 supersedes generation0001's parser-based admission interpretation; both historical artifacts remain. The proper structured-time route is awaiting DATA's verified handoff. The admission guard now rejects diagnostic-only dates as completion;8 focused checks passed.

Event's actual cache-only classification executed for25 occurrences and retained179 assertions from4records. These executed substeps are preserved, but runtime selection, G6 anchors/predicates, G7 LOC inputs and Event consumer materialization did not run. The four first-missing hierarchy nodes were absent from the searched local registry194, country hierarchy archive and entity archive; this bounded check does not establish global absence or imply only four records close the ancestry. Public source work remains RELATIONS-owned. No policy was invented. Full process completions and publication-eligible units remainZERO; no PR/merge/publication or clock advancement.

Evidence: v2_status_0001/CURRENT_STATUS.json, policy_v2_integration_0001/independent_verification.json, route_receipt_generation_0002/receipt.json, and the per-unit CPU stage journals. Existing snapshots and all earlier statements are retained as historical evidence, superseded where stated. New delivery requires a fresh profile bound to the final approved decision and route frontier; do not reuse the historical v1 publication profile.
'''
    plans=[]
    for name in ('GEOAI_DEVELOPMENT_PLAN.md','GEOAI_RUNTIME_BATCH_PLAN.md'):
        path=TASK/name;backup=OUT/(name+'.before')
        if not backup.exists():backup.write_bytes(path.read_bytes())
        before=path.read_bytes()
        if note.splitlines()[0] not in before.decode('utf-8'):
            with path.open('ab') as stream:stream.write(('\n\n'+note).encode('utf-8'))
        assert path.read_bytes().startswith(before)
        plans.append(dict(path=str(path),before_sha256=digest(backup),after_sha256=digest(path)))
    for name in ('MORNING_RUN_SUMMARY_20261102.md','AUTOMATIC_QUEUE.md'):
        path=HERE/name;backup=OUT/(name+'.before')
        if not backup.exists():backup.write_bytes(path.read_bytes())
        path.write_text(note,encoding='utf-8')
    save(OUT/'status_receipt.json',dict(status_sha256=digest(OUT/'CURRENT_STATUS.json'),plans=plans,old_generations_preserved=True,publication=False))
    print('UPDATED: two plans/current status; correct v2 counts; raw DATE diagnostic only; full completion0')
    print('status_sha256='+digest(OUT/'CURRENT_STATUS.json'))

if __name__=='__main__':update()
