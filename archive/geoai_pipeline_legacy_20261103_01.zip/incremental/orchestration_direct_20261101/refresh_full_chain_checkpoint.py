"""Fresh full-GEO components -> refresh -> confirm a LOCAL simulation checkpoint only."""
import json
import sys
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CADENCE = ROOT/'publisher_direct_20261101/cadence_caller_0001'
sys.path.insert(0,str(CADENCE))
from cadence_caller import initialize, evaluate, confirm
from call_publisher_refresh import refresh_once,verified_previous_snapshot
from check_one_unit import digest, read
from decision_revision_hook import content_hash


def refresh_checkpoint(output, state_path, *, manifest_path, manifest_sha256, previous_snapshot,
                       references, decision_time, completed_at, final_flush=False, previous_result=None):
    manifest_path,state_path = Path(manifest_path),Path(state_path)
    if digest(manifest_path)!=manifest_sha256:raise ValueError('Selected component manifest changed')
    manifest = read(manifest_path)
    prior = Path(previous_snapshot['path'])
    verified_previous_snapshot(prior,previous_snapshot['receipt_sha256'])
    stamp = lambda value:value.isoformat() if hasattr(value,'isoformat') else str(value)
    request = dict(output=str(Path(output).resolve()),manifest_path=str(manifest_path.resolve()),manifest_sha256=manifest_sha256,
                   previous_snapshot=previous_snapshot,references=references,decision_time=stamp(decision_time),
                   completed_at=stamp(completed_at),final_flush=final_flush)
    request_hash = content_hash(request)
    if previous_result is not None:
        if previous_result['request_sha256']!=request_hash:raise ValueError('Different checkpoint cannot reuse prior result')
        refresh_once(output,previous_result['refresh_parameters'],previous_result['refresh_result'])
        confirm(state_path,Path(previous_result['attempt_path']),Path(previous_result['refresh_result']['receipt_path']),
                previous_result['refresh_result']['receipt_sha256'])
        return previous_result
    due = evaluate(state_path,decision_time,references,final_flush=final_flush)
    if not due['due']:return dict(status='WAIT_LOCAL_CADENCE',decision=due,request_sha256=request_hash)
    # Multiple units have distinct decision versions; match each to the pinned component frontier.
    identity_source=manifest['source_receipts']['identities']
    if digest(Path(identity_source['path']))!=identity_source['sha256']:raise ValueError('Identity source receipt changed')
    bindings=read(Path(identity_source['path'])).get('decision_binding')
    if bindings:
        version=bindings[0]['decision_version'] if len(bindings)==1 else 'sha256:'+content_hash(bindings)
        if version!=manifest['frontier']['identity_version']:raise ValueError('Aggregate identity frontier differs')
    for reference in references:
        unit_path = Path(reference['unit_directory'])/'unit.private.json'
        unit=read(unit_path)
        if digest(unit_path)!=reference['unit_sha256']:
            raise ValueError('Admitted unit bytes changed')
        if bindings:
            fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
            scope=[unit['manifest'][field] for field in fields]
            matches=[row for row in bindings if row['scope']==scope]
            valid=len(matches)==1 and matches[0]['decision_version']==unit['version'] and matches[0]['decision_content_sha256']==content_hash(unit)
        else:
            valid=unit['version']==manifest['frontier']['identity_version']
        if not valid:
            raise ValueError('Component identities differ from the admitted sealed decision version')
    attempt = Path(due['attempt'])
    parameters = {k:manifest[k] for k in ('frontier','identities','relations','geometries','source_receipts','consumer_root')}
    parameters['frontier'] = dict(parameters['frontier'],previous_receipt_sha256=previous_snapshot['receipt_sha256'])
    parameters.update(previous_snapshot=str(prior),cadence_attempt=dict(path=str(attempt),sha256=digest(attempt)),
                      completed_at=stamp(completed_at))
    state_before = digest(state_path)
    refreshed = refresh_once(output,parameters)
    if digest(state_path)!=state_before:raise ValueError('Publisher changed caller cadence state')
    confirm(state_path,attempt,Path(refreshed['receipt_path']),refreshed['receipt_sha256'])
    return dict(status=refreshed['status'],request_sha256=request_hash,request=request,attempt_path=str(attempt),
                refresh_parameters=parameters,refresh_result=refreshed,state_before_confirm_sha256=state_before,
                state_after_confirm_sha256=digest(state_path),simulation=True,publication=False)


def check(audit):
    producer = ROOT/'publisher_direct_20261101/component_materializer_0001'
    manifest_path = producer/'full_geometry_baseline_0001/private/refresh_inputs.json'
    manifest = read(manifest_path)
    assert manifest['receipt_sha256']=='c1987f5de6e06fe1bc6d486a0a4983d1d0938a67c6bbe554470435fd72fad9e0'
    assert digest(Path(manifest['receipt_path']))==manifest['receipt_sha256']
    prior = dict(path=str(ROOT/'publisher_direct_20261101/proposed_strength_0001/snapshot_0007_retry_0001'),
                 receipt_sha256='defdbb6d7bc327fc3c82f188a343f4855def9db4f3c4e00a3da749e72eea3157')
    existing_attempt = next((CADENCE/'simulation_0001').glob('attempt-*.json'))
    references = read(existing_attempt)['verified_references']
    protected = {str(p):digest(p) for p in [manifest_path,Path(manifest['receipt_path']),
        producer/'consume_full_geometry.py',producer/'materialize_components.py',CADENCE/'cadence_caller.py',
        ROOT/'geometry_direct_20261101/full_projection_0001/version_1/receipt.json']}
    start = datetime(2026,11,1,18,tzinfo=timezone.utc)
    state_path = audit/'cadence_state.json'
    initialize(state_path,start,['input','grouping','exact','handoff','counts','consumer_snapshot'])
    before = digest(state_path)
    arguments = dict(manifest_path=manifest_path,manifest_sha256=digest(manifest_path),previous_snapshot=prior,
                     references=references,decision_time=start,completed_at=start+timedelta(minutes=2),final_flush=True)
    bad = deepcopy(manifest)
    bad['relations']['decision_version']='NOT_ACCEPTED_NEW_IDENTITY_FRONTIER'
    bad_path = audit/'stale_inputs.json'
    bad_path.write_text(json.dumps(bad,indent=2),encoding='utf-8')
    target_root = ROOT/'publisher_direct_20261101/orchestration_refresh_0001'
    try:
        refresh_checkpoint(target_root/'stale_full_chain',state_path,**dict(arguments,manifest_path=bad_path,manifest_sha256=digest(bad_path)))
    except ValueError:
        pass
    else:
        raise AssertionError('Stale component checkpoint succeeded')
    assert digest(state_path)==before and not (target_root/'stale_full_chain').exists()
    result = refresh_checkpoint(target_root/'snapshot_0002',state_path,**arguments)
    state = read(state_path)
    assert result['status']=='SUCCESS_LOCAL_CHECKPOINT_SIMULATION'
    assert state['last_successful_checkpoint']==(start+timedelta(minutes=2)).isoformat()
    assert state['acknowledged_units']==[['enwiki',48975579,1375061414]]
    assert result['state_before_confirm_sha256']==before
    assert result['refresh_result']['consumer_checks']==dict(nodes=10,edges=90,geometries=5,support_identities=45,strength_query_views=82)
    frozen = digest(state_path)
    assert refresh_checkpoint(target_root/'snapshot_0002',state_path,**arguments,previous_result=result) is result
    assert digest(state_path)==frozen
    assert all(digest(Path(p))==h for p,h in protected.items())
    return dict(status='PASS_FULL_GEO_MATERIALIZER_REFRESH_CADENCE',checkpoint=result,protected_sha256=protected,
                verified_full_component_manifest=str(manifest_path),stale_failure_no_clock_advance=True,
                replay_no_clock_advance=True,checks=6,actual_model_decisions=False,publication=False)


if __name__=='__main__':
    audit = HERE/'full_chain_checkpoint_0001';audit.mkdir()
    result = check(audit)
    (audit/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    proof = dict(status=result['status'],checks=result['checks'],code_sha256=digest(Path(__file__)),
                 result_sha256=digest(audit/'result.json'),consumer_checks=result['checkpoint']['refresh_result']['consumer_checks'],publication=False)
    (audit/'verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof))
