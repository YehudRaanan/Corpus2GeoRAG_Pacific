"""Admit real DATE output and partial Event execution against immutable v2 occurrence rows."""
from pathlib import Path
from run_ready_units import pinned,save
from check_one_unit import read,digest
from route_completion import route_completion

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
OUT=HERE/'route_receipt_generation_0001'

def adopt():
    date_pin=dict(path=str(ROOT/'runtime_model_inputs_direct_20261101/date_route/v1/handoff.json'),sha256='37837c804df60f1eaee1d078012fcf3ec1f405f470e5b4c5feec387a1f15e8f0')
    dates=pinned(date_pin)
    event_root=ROOT/'pair_relations_direct_20261101/event_execution_0001'
    event_release=read(event_root/'HANDOFF.json');events=pinned(event_release['handoff']);pinned(event_release['verification'])
    for item in events['input_pins']:
        assert digest(item['path'])==item['sha256']
    date_index={row['page_id']:row for row in dates['units']};event_index={row['page_id']:row for row in events['receipts']}
    sealed=read(HERE/'policy_v2_integration_0001/sealed_receipt.json');rows=[]
    for item in sealed['units']:
        source=item['sealed_unit'];path=Path(source['unit_directory'])/'unit.private.json'
        assert digest(path)==source['unit_sha256'];unit=read(path);page=unit['manifest']['page_id']
        stages=dict(date_index[page]['route_receipts'],event_route=event_index[page]['event_route'])
        matching=HERE/'policy_v2_integration_0001'/('unit_'+str(item['unit']))/'matching_receipt.json'
        result=route_completion(stages,unit,dict(path=str(matching),sha256=digest(matching)))
        assert 'date_route' in result['verified'] and result['missing']['event_route']['status']=='PARTIAL_EXECUTION'
        assert not result['complete']
        rows.append(dict(unit=item['unit'],source_unit=source,decision_version=unit['version'],page_id=page,
            route_receipts=stages,completion=result,process_completed=False))
    OUT.mkdir(exist_ok=True)
    receipt=dict(status='DATE_ADOPTED_EVENT_PARTIAL_EXECUTION_PRESERVED',units=rows,date=dates['counts'],event_executed=25,
        event_unresolved=25,process_completed_units=0,publication=False,date_handoff=date_pin,
        event_handoff=event_release['handoff'],event_remaining=events['blockers'],
        route_verifier_sha256=digest(HERE/'route_completion.py'))
    save(OUT/'receipt.json',receipt)
    print('PASS: nine v2 source bindings; DATE176 verified, Event25 partial, full completion remains zero')
    print('receipt_sha256='+digest(OUT/'receipt.json'))

if __name__=='__main__':adopt()
