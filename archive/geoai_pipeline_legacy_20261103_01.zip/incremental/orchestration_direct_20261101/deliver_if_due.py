"""Actual merge-clock gate -> existing refresh/package/PR/merge calls. No early upload."""
import argparse
from datetime import datetime,timezone
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
PUBLISHER=HERE.parent/'publisher_direct_20261101'
sys.path.insert(0,str(PUBLISHER/'delivery_0001'))
from runtime_unit_admission import verified_runtime_unit
from run_ready_units import pinned,save
from check_one_unit import read,digest
from decision_revision_hook import content_hash
from cadence_caller import checkpoint_decision,verified_unit,instant,CADENCE
from publish_checkpoint import initialize_publication_clock,publish_checkpoint,confirm_merge
from delivery_package import prepare_package
from publisher_refresh import refresh_snapshot


def deliver_if_due(profile_path,profile_sha256,execute=False):
    profile=pinned(dict(path=str(profile_path),sha256=profile_sha256))
    clock=Path(profile['publication_clock']).resolve()
    namespace=(PUBLISHER/'orchestration_delivery_0001').resolve()
    if not clock.is_relative_to(namespace):raise ValueError('Use a caller-owned merged-only clock')
    clock.parent.mkdir(parents=True,exist_ok=True)
    state=initialize_publication_clock(clock,run_start=profile['run_start'],required_stages=profile['required_stages'])
    references=[pinned(descriptor) for descriptor in profile['references']]
    records=[verified_runtime_unit(ref) if ref.get('kind')=='runtime_unit' else verified_unit(ref) for ref in references]
    geometry=profile.get('approved_geometry_or_correction',False);final=profile.get('final_flush',False)
    if type(geometry) is not bool or type(final) is not bool:raise ValueError('Cadence options must be explicit booleans')
    if geometry:
        approval=pinned(profile['exception_receipt'])
        if approval['status']!='APPROVED_GEOMETRY_OR_CORRECTION':raise ValueError('Approved correction evidence required')
    if final:
        finished=pinned(profile['run_finished_receipt'])
        actual={tuple(record['receipt']['scope'][field] for field in ('wiki_site','page_id','support_revision_id')) for record in records if record['status']=='sealed'}
        if finished['status']!='RUN_COMPLETED' or not finished['planned_unit_keys'] or not set(map(tuple,finished['planned_unit_keys']))<=actual:
            raise ValueError('Final flush requires actual completion of the declared run')
    now=instant(profile['decision_time']) if profile.get('decision_time') else datetime.now(timezone.utc)
    previous=instant(state['last_successful_checkpoint']) if state['last_successful_checkpoint'] else None
    options=dict(run_start=instant(state['run_start']),required_stages=state['required_stages'])
    decision=checkpoint_decision(now,previous,records,state['acknowledged_units'],geometry,final,**options)
    if not decision['due']:return dict(status='WAIT_PUBLICATION_CADENCE',decision=decision,publication=False)
    # PUBLISHER must independently admit every reference; never disguise a runtime unit as the old first-unit checker.
    for ref in references:
        try:verified_unit(ref)
        except (KeyError,ValueError) as error:
            return dict(status='WAIT_PUBLISHER_RUNTIME_ADMISSION',reason=str(error),decision=decision,publication=False)
    output=Path(profile['output_directory']).resolve()
    if not output.is_relative_to(namespace) or output.exists():raise ValueError('Use a fresh delivery generation; inspect interrupted operations first')
    output.mkdir(parents=True)
    eligible=[]
    for record in records:
        if checkpoint_decision(now,previous,[record],state['acknowledged_units'],final_flush=True,**options)['new_completed_units']:
            eligible.append([record['receipt']['scope'][field] for field in ('wiki_site','page_id','support_revision_id')])
    attempt=dict(simulation=True,before_state_sha256=digest(clock),decision_time=now.isoformat(),decision=decision,
        eligible_units=sorted(set(map(tuple,eligible))),verified_references=references,cadence_code_sha256=digest(CADENCE))
    attempt_path=output/'attempt.json';save(attempt_path,attempt)
    inputs=pinned(profile['refresh_manifest']);prior=profile['previous_snapshot']
    parameters={key:inputs[key] for key in ('frontier','identities','relations','geometries','source_receipts','consumer_root')}
    parameters['frontier']=dict(parameters['frontier'],previous_receipt_sha256=prior['receipt_sha256'])
    refreshed=refresh_snapshot(output/'snapshot',**parameters,previous_snapshot=prior['path'],
        cadence_attempt=dict(path=str(attempt_path),sha256=digest(attempt_path)),completed_at=datetime.now(timezone.utc).isoformat())
    package=prepare_package(output/'snapshot',output/'package',checkpoint_id=profile['checkpoint_id'],
        source_receipt=refreshed['receipt_path'],source_receipt_sha256=refreshed['receipt_sha256'],consumer_root=inputs['consumer_root'],test_only=False)
    gate=dict(schema='geoai-upload-checkpoint-v1',status='VERIFIED_UPLOAD_CHECKPOINT',checkpoint_id=profile['checkpoint_id'],
        manifest_sha256=package['manifest_sha256'],contents_final=True,fixture=False,
        snapshot_receipt=dict(path=refreshed['receipt_path'],sha256=refreshed['receipt_sha256']),
        cadence_attempt=dict(path=str(attempt_path),sha256=digest(attempt_path)),publication_clock=dict(path=str(clock),sha256=digest(clock)),
        approved_geometry_or_correction=geometry,final_flush=final)
    gate_path=output/'checkpoint.json';save(gate_path,gate)
    published=publish_checkpoint(package['package_dir'],manifest_sha256=package['manifest_sha256'],
        checkpoint_receipt=dict(path=str(gate_path),sha256=digest(gate_path)),work_dir=output/'remote_work',execute=execute)
    if execute:
        if published['status']!='MERGED_VERIFIED_PUBLIC_CHECKPOINT':raise ValueError('No verified merge receipt')
        confirm_merge(clock,receipt_path=published['receipt_path'],receipt_sha256=published['receipt_sha256'])
    return published


if __name__=='__main__':
    import json
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('profile');parser.add_argument('sha256');parser.add_argument('--execute',action='store_true')
    args=parser.parse_args();print(json.dumps(deliver_if_due(args.profile,args.sha256,args.execute)))
