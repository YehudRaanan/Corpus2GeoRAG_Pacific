"""Synthetic admission checks; these do not execute a production DATE/Event route."""
import tempfile
import unittest
from pathlib import Path
from route_completion import route_completion,content_hash,digest
from run_ready_units import save

class RouteCompletionTest(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory();self.addCleanup(self.directory.cleanup)
        self.path=Path(self.directory.name)
        self.unit=dict(manifest=dict(input_sha256='input',wiki_site='test',page_id=1,
            support_revision_id=2,source_sha256='source',policy_version='fixture'),
            occurrences=[dict(occurrence_id='fixture-date',entity_group='DATE')])
    def stages(self,status='COMPLETED_UNRESOLVED',**changes):
        artifact=self.path/'outcome.json';save(artifact,dict(fixture=True))
        receipt=dict(status=status,execution='EXECUTED',source_scope=self.unit['manifest'],temporal_basis='STRUCTURED_QID_WIKIDATA',
            input_occurrences_sha256=content_hash(self.unit['occurrences']),
            outcomes=[dict(occurrence_id='fixture-date',status='UNRESOLVED',method='synthetic-test',reason='fixture only')],
            processor=dict(path=__file__,sha256=digest(__file__)),artifacts=[dict(path=str(artifact),sha256=digest(artifact))])
        receipt.update(changes);path=self.path/'receipt.json';save(path,receipt)
        return dict(date_route=dict(path=str(path),sha256=digest(path)))
    def test_missing_is_unrun(self):
        result=route_completion({},self.unit)
        self.assertFalse(result['complete']);self.assertEqual(result['missing']['date_route']['status'],'NOT_RUN')
    def test_deferred_does_not_finish(self):
        self.assertFalse(route_completion(self.stages('DEFERRED'),self.unit)['complete'])
    def test_executed_documented_unresolved_can_finish(self):
        self.assertTrue(route_completion(self.stages(),self.unit)['complete'])
    def test_executed_partial_route_cannot_finish_unrun_operations(self):
        result=route_completion(self.stages(not_completed_operations=['Event expansion'],does_not_certify_full_process_completion=True),self.unit)
        self.assertFalse(result['complete'])
        self.assertEqual(result['missing']['date_route']['status'],'PARTIAL_EXECUTION')
    def test_text_date_normalization_is_diagnostic_only(self):
        result=route_completion(self.stages(temporal_basis='RAW_TEXT_NORMALIZATION'),self.unit)
        self.assertFalse(result['complete'])
        self.assertEqual(result['missing']['date_route']['status'],'DIAGNOSTIC_ONLY')
    def test_missing_occurrence_outcome_does_not_finish(self):
        self.assertFalse(route_completion(self.stages(outcomes=[]),self.unit)['complete'])
    def test_wrong_input_rejected(self):
        with self.assertRaisesRegex(ValueError,'source/input'):
            route_completion(self.stages(input_occurrences_sha256='wrong'),self.unit)
    def test_changed_artifact_rejected(self):
        stages=self.stages();(self.path/'outcome.json').write_text('{}')
        with self.assertRaisesRegex(ValueError,'artifact changed'):route_completion(stages,self.unit)

if __name__=='__main__':unittest.main()
