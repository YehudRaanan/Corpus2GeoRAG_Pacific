"""Require actual per-occurrence execution evidence for routes skipped by ordinary matching."""
from pathlib import Path
from run_approved_unit import pinned
from check_one_unit import read,digest
from decision_revision_hook import content_hash

ROUTES=('date_route','event_route','context_route')


def required_routes(unit,matching_receipt=None):
    result={name:set() for name in ROUTES}
    result['date_route']={row['occurrence_id'] for row in unit['occurrences'] if row['entity_group']=='DATE'}
    if matching_receipt:
        matching=pinned(matching_receipt);folder=Path(matching['policy_verification']['path']).parent
        path=next((folder/name for name in ('all_occurrence_decision_evidence.json','all90_decision_evidence.json','pending_and_decision_evidence_106.json') if (folder/name).exists()),None)
        if path is None:raise ValueError('Policy occurrence routing evidence is missing')
        for row in read(path):
            reasons=row.get('reason',[])
            if any('EVENT' in str(reason).upper() for reason in reasons):result['event_route'].add(row['occurrence_id'])
            if 'PENDING_NO_VERIFIED_CONTEXT' in reasons:result['context_route'].add(row['occurrence_id'])
    return {name:sorted(ids) for name,ids in result.items() if ids}


def route_completion(stages,unit,matching_receipt=None):
    required=required_routes(unit,matching_receipt);missing={};verified=[]
    fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
    scope={field:unit['manifest'][field] for field in fields}
    for name,ids in required.items():
        if name not in stages:
            missing[name]=dict(status='NOT_RUN',occurrences=len(ids));continue
        receipt=pinned(stages[name]);rows=sorted((row for row in unit['occurrences'] if row['occurrence_id'] in set(ids)),key=lambda row:row['occurrence_id'])
        if receipt.get('source_scope')!=scope or receipt.get('input_occurrences_sha256')!=content_hash(rows):raise ValueError('Route receipt source/input differs: '+name)
        outcomes=receipt.get('outcomes',[])
        valid=(receipt.get('status') in {'COMPLETED','COMPLETED_UNRESOLVED'} and receipt.get('execution') in {'EXECUTED','REUSED_VERIFIED_OUTPUT'}
            and len(outcomes)==len(ids) and {row['occurrence_id'] for row in outcomes}==set(ids)
            and all(row.get('status') in {'RESOLVED','UNRESOLVED','NOT_APPLICABLE'} and row.get('method') and row.get('reason') for row in outcomes))
        if not valid:
            missing[name]=dict(status='NO_VERIFIED_TERMINAL_OUTCOMES',occurrences=len(ids));continue
        processor=receipt['processor']
        if digest(processor['path'])!=processor['sha256']:raise ValueError('Route processor changed: '+name)
        if not receipt.get('artifacts'):raise ValueError('Persisted route outputs are missing: '+name)
        for artifact in receipt['artifacts']:
            if digest(artifact['path'])!=artifact['sha256']:raise ValueError('Route artifact changed: '+name)
        # Owner instruction: time comes from QID-linked structured Wikidata, never parsed raw DATE text.
        if name=='date_route' and receipt.get('temporal_basis')!='STRUCTURED_QID_WIKIDATA':
            missing[name]=dict(status='DIAGNOSTIC_ONLY',occurrences=len(ids),
                required_basis='STRUCTURED_QID_WIKIDATA',executed_scope=receipt.get('executed_scope','DATE parser diagnostics'))
            continue
        if receipt.get('not_completed_operations') or receipt.get('does_not_certify_full_process_completion'):
            missing[name]=dict(status='PARTIAL_EXECUTION',occurrences=len(ids),
                not_completed_operations=receipt.get('not_completed_operations',[]),
                executed_scope=receipt.get('executed_scope'))
            continue
        verified.append(name)
    return dict(complete=not missing,required={name:len(ids) for name,ids in required.items()},missing=missing,verified=verified)
