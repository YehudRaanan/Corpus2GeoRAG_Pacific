"""Synchronous, in-memory refresh after a validated decision handoff. No dispatcher service."""
import hashlib
import json
import sys
from copy import deepcopy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'integration_direct_20261101'))
from occurrence_decisions import replace_unit


def content_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def decision_binding(state):
    # Bind every active unit: another page can change a shared identity's denominator.
    return [dict(scope=list(key), decision_version=versions[-1]['version'],
                 decision_content_sha256=content_hash(versions[-1]))
            for key, versions in sorted(state.items())]


def require_current(receipt, state):
    if receipt['decision_binding'] != decision_binding(state):
        raise ValueError('Stale projection: decision frontier changed')
    if receipt['projection_sha256'] != content_hash(receipt['projection']):
        raise ValueError('Projection content differs from its private receipt')


def refresh_for_decision(state, handoff, source_bytes, previous, history, recompute):
    """Validate/replay E4, then synchronously call an explicitly supplied refresh function."""
    working, pair_history = deepcopy(state), deepcopy(history)
    replace_unit(working, handoff, source_bytes)
    stale = False
    if previous is not None:
        try:
            require_current(previous, working)
        except ValueError:
            stale = True
        else:
            return previous  # Same complete dependency and projection: no recomputation/history append.
    projection = recompute(working, None if previous is None else previous['projection'], pair_history)
    result = dict(decision_binding=decision_binding(working), projection=projection,
                  projection_sha256=content_hash(projection), stale_previous_projection_rejected=stale,
                  recomputation='EXPLICIT_SYNCHRONOUS_FULL_REFERENCE', consumer_export=False)
    require_current(result, working)
    # Commit only after successful recomputation. This is not an on-disk cross-stage transaction.
    state.clear()
    state.update(working)
    history[:] = pair_history
    return result
