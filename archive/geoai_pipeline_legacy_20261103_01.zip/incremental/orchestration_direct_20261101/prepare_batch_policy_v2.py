"""Apply corrected policy to verified complete inputs; this does not move the reducer cursor."""
from pathlib import Path
from reconcile_ready_units import discover,record
from apply_available_policy import apply_policy_output,CALLABLE
from check_one_unit import read,digest
from run_ready_units import save

HERE=Path(__file__).resolve().parent
OUT=HERE/'reconciliation_units11_20_v2'

def prepare():
    config=read(HERE/'reconciliation_units11_20_config.json')
    release=read(HERE.parent/'candidate_check_fix_direct_20261102/patch_manifest.json')
    expected=next(row['after_sha256'] for row in release['patches'] if Path(row['path'])==CALLABLE)
    assert digest(CALLABLE)==expected
    index=read(Path(config['readiness_index']['path']))
    available=discover(config);OUT.mkdir(exist_ok=True)
    units=[];accepted=set()
    for choices in available.values():
        assert len(choices)==1
        candidate=next(iter(choices.values()));data=read(Path(candidate['data']))
        # DATA persists the original sealed order in each preparation manifest.
        ordinal=data['order_index'] if 'order_index' in data else int(Path(candidate['data']).parent.name.split('_')[1])-1
        number=ordinal+1
        folder=OUT/('unit_'+str(number)+'_'+candidate['proposals']['sha256'][:12]);folder.mkdir(exist_ok=True)
        manifest=dict(schema='geoai-existing-opening-policy-unit-v1',data_directory=str(Path(candidate['data']).parent),
            policy_directory=config['policy_directory'],mapping_filename='all_occurrence_mapping.json',
            decision_version='unit'+str(number)+'-owner-approved-opening-v1',result_files=[candidate['proposals']],
            model_manifests=[candidate['model']],policy_callable_sha256=expected)
        pin=record(folder/'policy_manifest.json',manifest)
        summary=apply_policy_output(pin,folder/'policy')
        patch=read(folder/'policy/decision_patch.json')
        qids={row['qid'] for row in patch['decisions'] if row['qid'] is not None};accepted.update(qids)
        units.append(dict(unit=number,page_id=data['scope']['page_id'],summary=summary,policy_manifest=pin,
            accepted_qids=sorted(qids),decision_patch=dict(path=str(folder/'policy/decision_patch.json'),sha256=digest(folder/'policy/decision_patch.json'))))
        print('POLICY unit '+str(number)+' '+str({key:summary[key] for key in ('combined_identity_occurrences','pending') if key in summary}),flush=True)
        save(OUT/'policy_preparation.json',dict(status='CORRECTED_POLICY_APPLIED_NO_CANONICAL_WRITES',units=units,accepted_qids=sorted(accepted),publication=False))
    assert len(units)==8
    registry=read(HERE.parent/'pair_relations_direct_20261101/unit9_sources_0001/generation_003/native_registry.json')
    save(OUT/'accepted_source_request.json',dict(accepted_qids=sorted(accepted),missing_from_registry194=sorted(accepted-set(registry['selected_references'])),units=[dict(unit=row['unit'],accepted_qids=row['accepted_qids']) for row in units],public_calls=0))
    print('READY eight corrected policies; no canonical cursor, public source or publication change',flush=True)

if __name__=='__main__':prepare()
