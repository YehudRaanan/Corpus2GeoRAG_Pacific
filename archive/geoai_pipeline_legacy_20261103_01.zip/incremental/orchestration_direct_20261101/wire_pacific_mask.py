"""Approved GEO classifier -> Event scope's bool/unknown map, with original source evidence."""
import sys
from pathlib import Path
from check_one_unit import read,digest
from run_ready_units import pinned,save

HERE=Path(__file__).resolve().parent
GEO=HERE.parent/'geometry_direct_20261101/pacific_loc_mask_v1'
CODE_SHA='14c48cc8d95a5835bd6abd879783a7c85310706fbe54498a0dfe3ed00dee9ea6'
MASK_SHA='8bb675894f9eca241517ba582960afe99e0be034e607906c3a77de1fee17f85f'
sys.path.insert(0,str(GEO))
from pacific_loc_mask import classify_loc,MASK_VERSION


def scope_geo_map(kinds,geometries,provenance,*,crs='EPSG:4326'):
    """Caller supplies endpoint types/geometry; this function selects neither."""
    if digest(GEO/'pacific_loc_mask.py')!=CODE_SHA or digest(GEO/'pacific_loc_mask_v1.geojson')!=MASK_SHA:
        raise ValueError('Approved GEO implementation or mask changed')
    geo={};decisions=[]
    for qid,kind in kinds.items():
        source=provenance[qid]
        if digest(source['path'])!=source['sha256']:raise ValueError('Geometry source changed')
        geometry=geometries.get(qid);before=geometry.wkb if geometry is not None else None
        result=classify_loc(geometry,entity_type=kind,crs=crs)
        if geometry is not None and geometry.wkb!=before:raise ValueError('Mask changed source geometry')
        if kind=='LOC':geo[qid]={'INCLUDE':True,'EXCLUDE':False,'UNKNOWN':None}[result]
        decisions.append(dict(qid=qid,entity_type=kind,mask_result=result,source=source))
    return dict(mask_version=MASK_VERSION,mask_sha256=MASK_SHA,mask_code_sha256=CODE_SHA,
        geo=geo,decisions=decisions,source_geometry_changed=False,Event_selection_performed=False)


def check_existing_five():
    import geopandas as gpd
    output=HERE/'pacific_mask_integration_0001';output.mkdir(exist_ok=True)
    status=pinned(read(HERE/'reconciliation_first10_v1/CURRENT_STATUS.json')['current_status'])
    component=pinned(status['consumer_receipt']);root=Path(status['consumer_receipt']['path']).parent.parent
    geometry_path=root/'model/geometries.parquet';source=dict(path=str(geometry_path),sha256=digest(geometry_path))
    protected={str(path):digest(path) for path in [Path(status['consumer_receipt']['path']),root/'graph.json',geometry_path]}
    frame=gpd.read_parquet(geometry_path);assert frame.crs.to_epsg()==4326 and len(frame)==5
    geometries=dict(zip(frame['place_id'],frame.geometry));kinds={qid:'LOC' for qid in geometries}
    result=scope_geo_map(kinds,geometries,{qid:source for qid in geometries})
    assert len(result['geo'])==5 and all(value is True for value in result['geo'].values())
    assert all(digest(path)==expected for path,expected in protected.items())
    proof=read(GEO/'verification.json');independent=read(GEO/'independent_readback.json')
    assert proof['status']=='PASS' and proof['code_sha256']==CODE_SHA and independent['mask_sha256']==MASK_SHA
    result.update(status='PASS_MASK_ADAPTER_EXISTING_FIVE_SHAPES_ONLY',protected_consumer_sha256=protected,
        GEO_verification=dict(path=str(GEO/'verification.json'),sha256=digest(GEO/'verification.json')),
        GEO_independent_readback=dict(path=str(GEO/'independent_readback.json'),sha256=digest(GEO/'independent_readback.json')),
        integration_code_sha256=digest(Path(__file__)),actual_Event_scope_activated=False,
        remaining='Await RELATIONS versioned actual endpoint/selection/scope handoff; five baseline shapes are not full Event LOC coverage',publication=False)
    save(output/'receipt.json',result)
    print('PASS:approved mask/code verified; existing5 source shapes INCLUDE; consumer unchanged; no Event activation')
    print('receipt_sha256='+digest(output/'receipt.json'))

if __name__=='__main__':check_existing_five()
