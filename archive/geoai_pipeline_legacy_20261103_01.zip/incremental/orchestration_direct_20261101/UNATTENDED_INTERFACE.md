# Bounded unattended CPU application and delivery handoff

Run from D:/Projects/GeoAI-incremental-dev-20261101 using the existing bridge Python:

    contract_fixtures/.venv-bridge/Scripts/python.exe -B orchestration_direct_20261101/run_ready_units.py MANIFEST_JSON EXPECTED_MANIFEST_SHA256

Working actual unit2 invocation is described by actual_second_unit_policy_v1/manifest.json, SHA009ff5854b20e3cc10f7397e27f14e2c728fee7f07c700bdd6c390265c79a941. Current application code is pinned in each cursor; an application-code change requires a separately named cursor, keeping completed generations intact. Actual unit2 finished both directions/policy/E2/sources/counts/relations/full geometry/consumer, independently verified and replayed. Its25 assigned65pending combine with alias-bound unit1 into71assigned155pending over226 source occurrences. Consumer30nodes408edges5geometries. See actual_second_unit_policy_v1/independent_readback.json.

The next-three jobs are generated from DATA's verified next_three_index.json, not hardcoded pages. Exact-only continuation command:

    contract_fixtures/.venv-bridge/Scripts/python.exe -B orchestration_direct_20261101/run_ready_units.py orchestration_direct_20261101/first_five_ready_cpu_v1/manifest_resume_v2.json c8ecffec9904e0f46e3bac3fa1f236db0569b35a5c7115c07cde5f0f6030f142

This command has actually run. Units3/4 exact decisions and projections are saved, but matching remains incomplete and consumer waits for missing sources. Unit5 exact handoff is sealed but its source stage failed on Q60198049's missing/conflicting approved name. Do not rerun its incomplete producer generation blindly. Retain its handoff and request RELATIONS' explicit-gap recovery/new source generation. Neither a source-only seal nor capacity-pending inference is counted complete.

Manifest fields: pinned initial_projection, native_registry, full_geometry_baseline and geometry_bindings; fragment_artifact_root; consumer_root; owned output_directory; ordered jobs=[{path,sha256}]; optional source_refresher={path,sha256,max_public_qids:0..5,output_root(optional)}. Source code is pinned and must be RELATIONS-owned. complete_registry is called only for accepted QIDs of the current unit missing from the prior registry, public bound capped by actual missing count and5. It writes new RELATIONS-owned generations; old selected references must remain exact. Explicit source gaps keep consumer waiting and never change identity decisions.

Each job supplies mode ADD_PENDING/EVIDENCE_ONLY/REPLAY_CURRENT; approved_decisions path/hash; current_unit={unit_directory,unit_sha256,prior_history:[pinned earlier seals]}; owned output_directory; caller-owned publisher_output_directory; matching_receipt when actual inference is complete. ADD_PENDING accepts only currently pending occurrences. EVIDENCE_ONLY changes supplied evidence/version with identical occurrence-to-QID mapping. REPLAY_CURRENT refreshes source/projections without a decision mutation. New-unit source history is admitted before its successor. Each stage is hash-journaled; unit_result is persisted before the global index. Matching/consumer completion is recorded independently from upload cadence.

The normalized matching receipt is private glue, not a new consumer field:

    {decision_patch:{path,sha256},
     source_scope:{input_sha256,wiki_site,page_id,support_revision_id,source_sha256,policy_version},
     policy_verification:{path,sha256},
     directions:{forward:{bindings:{path,sha256},proposals:{path,sha256}},
                 reverse:{bindings:{path,sha256},proposals:{path,sha256}}}}

Each bindings JSON list contains {id,input_version,input_sha256,encoded_sha256}, obtained from the pinned requests/encoded items and actual model manifest. The loop rejects missing/duplicate questions, wrong directions, mixed versions and mismatched hashes. Raw logits remain proposals; only the explicitly supplied existing-policy decision artifact is applied. actual_second_unit_policy_v1/matching_receipt.json is a working70-question example. Old alias inputs/reused predictions preserve their original versions. No inference is run by this CPU loop.

For residual model decisions of units3–5, supply the sealed exact output as current_unit, its ordered source history, the actual residual decision patch and matching receipt, and append separately named jobs to the same code/config-bound loop. Completed exact jobs replay without rewriting. Unit3 head-capacity work and unit5 capacity-pending work remain INFERENCE/TRAIN dependencies; DATA owns prepare_unit(order_index,output_directory), not this loop. This is the precise remaining artifact boundary for all first five units, rather than a claim that their model results exist.

Delivery is a separate command:

    contract_fixtures/.venv-bridge/Scripts/python.exe -B orchestration_direct_20261101/deliver_if_due.py PUBLICATION_PROFILE_JSON EXPECTED_PROFILE_SHA256 --execute

The profile supplies explicit persisted run_start, publication_clock under publisher/orchestration_delivery_0001, required_stages, pinned admission references, optional actual decision_time, and the fresh component refresh_manifest/previous_snapshot/checkpoint_id/output_directory required only when due. Ordinary delivery requires one hour AND100 newly completed logical units. Approved correction/final flush flags require their explicit supporting receipt; final flush also requires every declared planned unit to be actually complete. The code calls existing refresh_snapshot -> prepare_package(test_only=False) -> publish_checkpoint -> confirm_merge. It never turns local simulation into remote success. The merged-only clock advances only after MERGED_VERIFIED_PUBLIC_CHECKPOINT. No package or remote operation occurs on WAIT. Publication gate connection was tested on one actual unit and remained waiting with unchanged clock.

One PUBLISHER seam remains: cadence_caller.verified_unit currently accepts only check_one_unit.py's first-unit code hash. Add a fixed runtime_unit branch calling orchestration_direct_20261101/runtime_unit_admission.py::verified_runtime_unit(reference), keeping legacy validation. Reference contains kind=runtime_unit,runtime_verifier_sha256,unit_result:{path,sha256},preparation_manifest:{path,sha256}. The verifier rechecks source preparation pins, E2 history, exact preservation, both model directions/policy sources and actual consumer materialization. A real unit2 reference and dedup check are saved at actual_second_unit_policy_v1/runtime_admission_reference.json and admission_verification.json. It returns the existing pure-cadence sealed record/chain schema. No arbitrary caller code is accepted. Until PUBLISHER recognizes this branch, due delivery returns WAIT_PUBLISHER_RUNTIME_ADMISSION before package or GitHub calls. It does not fake a legacy first-unit reference.

No upload-eligible real checkpoint has occurred. PR URL and verified merge SHA remain absent. No branch rules, permissions or PR review approval are changed.

## Current continuation after all five policy outputs arrived

All five actual decision units are now saved:517 unique source occurrences,204assigned313pending0NONE. FIRST_FIVE_CURRENT_STATUS.json and FIRST_FIVE_ACCEPTED_QIDS.json bind the latest aggregate and per-unit accepted sets. Unit3/4/5 full model-policy patches were applied; earlier capacity-pending notes above describe historical stages and no longer mean those model questions are unrun. Their current consumer wait is source coverage:43 accepted QIDs absent from the connected registry while RELATIONS' naming repair is pending handoff. The incomplete Q60198049 producer generation was preserved and not reused.

Generic policy application command is now prepare_matching_receipt.py CONFIG_JSON EXPECTED_CONFIG_SHA256 [--prepare-only]. Config contains policy_manifest,current_job,current_result (or current_stage_journal after a source failure),base_manifest,cursor as pinned descriptors, plus policy_output,output_directory,publisher_output_directory. Working actual configurations are actual_unit3_policy_preparation_v1/config.json and actual_unit5_policy_preparation_v1/config.json. The call normalizes actual request/encoded/model evidence, prepares a residual-only job against canonical exact history, then runs the existing per-stage CPU loop. No page ID or threshold is embedded.

PUBLISHER's runtime_unit admission branch is now connected and independently checked; the earlier admission seam described above is resolved. The merged-only ordinary gate remains WAIT, with no package or network call. Next: use the repaired source callable on FIRST_FIVE_ACCEPTED_QIDS.json, refresh the latest aggregate and materialize/read back current components before qualifying additional units as completed.
