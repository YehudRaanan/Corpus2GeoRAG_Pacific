"""Resume the existing generic CPU loop from the completed nine-unit v2 cursor."""
import argparse
from pathlib import Path
from run_ready_units import pinned
from check_one_unit import read,digest
from reconcile_ready_units import reconcile,record
from apply_available_policy import CALLABLE

HERE=Path(__file__).resolve().parent

def prepare():
    cursor_path=HERE/'policy_v2_integration_0001/state/index.json';cursor=read(cursor_path)
    if len(cursor['jobs'])!=9:raise ValueError('First-nine v2 projection refresh still running; preserve its single writer')
    for descriptor in cursor['jobs'].values():pinned(descriptor)
    config=read(HERE/'reconciliation_units11_20_config.json')
    config.update(initial_cursor=dict(path=str(cursor_path),sha256=digest(cursor_path)),
        output_directory=str(HERE/'reconciliation_units11_20_v2'),policy_callable_sha256=digest(CALLABLE),
        publisher_output_root=str(HERE.parent/'publisher_direct_20261101/orchestration_refresh_0001/reconciliation_units11_20_v2'))
    date_pin=dict(path=str(HERE.parent/'runtime_model_inputs_direct_20261101/date_route/v1/units11_20_eight_v1/handoff.json'),
        sha256='abcdf065a7612d168fcfb7127c41faa7154ee0c078361cf76759c614a6211352')
    dates=pinned(date_pin)
    config['route_receipts']={str('enwiki:'+str(row['page_id'])+':'+str(row['processing_revision_id'])):row['route_receipts'] for row in dates['units']}
    config['route_handoffs']=[date_pin]
    config['policy_release']=dict(path=str(HERE.parent/'candidate_check_fix_direct_20261102/patch_manifest.json'),sha256=digest(HERE.parent/'candidate_check_fix_direct_20261102/patch_manifest.json'))
    return record(HERE/'reconciliation_units11_20_v2_config.json',config)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    pin=prepare();print(pin,flush=True)
    if args.run:
        result=reconcile(pin['path'],pin['sha256'])
        print(dict(status=result['status'],state_path=result['state_path'],units=len(result['units']),cursor=result['cursor'],publication=False))
