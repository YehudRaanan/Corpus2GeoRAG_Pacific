"""Apply DATA's approved exact subset, preserving all pending model routes."""
import json
import sys
from pathlib import Path
from copy import deepcopy

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(HERE/'runtime_handoff_0001'))
from decision_handoff import build_handoff
from run_approved_unit import pinned,context_state,context_json
from advance_combined_geometry import advance_combined
from check_one_unit import read,digest
from decision_revision_hook import content_hash,require_current


def run():
    data=ROOT/'runtime_model_inputs_direct_20261101/second_unit_8385178_1360005623_v1'
    manifest=read(data/'manifest.json')
    for path,expected in manifest['protected_source_sha256'].items():
        if digest(path)!=expected:raise ValueError('DATA protected input changed: '+path)
    for name,expected in manifest['output_sha256'].items():
        if digest(data/name)!=expected:raise ValueError('DATA output changed: '+name)
    patch_path=data/'exact_decision_patch.json'
    assert digest(patch_path)=='c63985f06b3cff2ad214602a9b48701c8b04a3c3d1700ea3cfd4066e4f198d10'
    patch=read(patch_path)
    assert len(patch['decisions'])==6 and len({d['evidence']['group_id'] for d in patch['decisions']})==5
    current=HERE/'second_unit_0001/sealed_pending'
    baseline=read(current/'unit.private.json')
    for decision in patch['decisions']:
        evidence=decision['evidence']
        assert evidence['page_id']==8385178 and evidence['processing_revision_id']==1360005623
        assert evidence['source_sha256']==digest(current/'source.private.bin')
        assert evidence['source_seal_sha256']==digest(current/'seal.json')
    output=HERE/'second_unit_exact_0001';output.mkdir(exist_ok=True)
    built=build_handoff(output/'sealed_exact',current_sealed_dir=current,
        current_unit_sha256='40d55f468e36895ac99b380793caa2d0a6856518ec745bac3f584aa47c952eed',
        prior_history=[],supplied_decisions=patch['decisions'],decision_version=patch['decision_version'])
    assert built['handoff']['occurrences']==baseline['occurrences']
    assert len(built['handoff']['decisions'])==6 and len(built['handoff']['pending_evidence'])==84
    previous=context_state(read(HERE/'combined_projection_0001/projection.json'))
    original=deepcopy(previous)
    first=read(HERE/'actual_first_unit_registry17/manifest.json')
    bindings=pinned(first['geometry_bindings'])
    arguments=dict(native_path=first['native_registry']['path'],native_hash=first['native_registry']['sha256'],
        geometry_bindings=bindings,geometry_bindings_sha256=content_hash(bindings),
        baseline=pinned(first['full_geometry_baseline']),fragment_artifact_root=first['fragment_artifact_root'])
    source=(current/'source.private.bin').read_bytes()
    context=advance_combined(output/'full_geometry',previous,built['handoff'],source,**arguments)
    assert previous==original
    counts=context['count_receipt']['projection']
    assert counts['accepted_occurrences']==52 and counts['pending_occurrences']==174
    assert len(context['count_state'])==2
    for name in ['count_receipt','relation_receipt']:require_current(context[name],context['count_state'])
    require_current(context['full_geometry']['receipt'],context['count_state'])
    for key,versions in original['count_state'].items():
        if versions[-1]['manifest']['page_id']==48975579:assert context['count_state'][key]==versions
    path=output/'projection.json';serialized=context_json(context)
    if path.exists():assert read(path)==serialized
    else:path.write_text(json.dumps(serialized,indent=2),encoding='utf-8')
    frozen={str(p):(digest(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
    assert advance_combined(output/'full_geometry',context,built['handoff'],source,**arguments)==context
    assert all((digest(p),Path(p).stat().st_mtime_ns)==value for p,value in frozen.items())
    relation=context['relation_receipt']['projection']
    proof=dict(status='PASS_SECOND_UNIT_EXACT_SEALED_AND_AGGREGATED',
        decision_patch=dict(path=str(patch_path),sha256=digest(patch_path)),
        second_unit_sealed_dir=built['sealed_dir'],second_unit_sha256=built['unit_sha256'],
        second_unit_occurrences=90,second_unit_assigned=6,second_unit_pending=84,
        total_occurrences=226,total_assigned=52,total_pending=174,physical_pages=2,
        missing_native_qids=relation['missing_qids'],source_pending_pairs=len(relation['pending_pairs']),
        active_views=len(relation['active_views']),projection_sha256=digest(path),
        decision_frontier=counts['decision_version'],first_unit_unchanged=True,replay_unchanged=True,
        matching_completed=False,second_unit_completed=False,publication=False)
    (output/'verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof))


if __name__=='__main__':run()
