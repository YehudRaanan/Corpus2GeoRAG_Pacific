"""Explicit one-unit count -> relation revision call. No geometry or publisher work."""
import json
import sys
from copy import deepcopy
from pathlib import Path
from shutil import copyfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT / 'pair_relations_direct_20261101/revision_dispatch_0001'), str(ROOT / 'durable_units_direct_20261101')]
from relation_revision import dispatch_relations
from decision_revision_hook import refresh_for_decision, require_current
from real_counts_revision import recompute_counts
from durable_unit import recover, seal_unit, encoded, sha
from check_one_unit import digest, read


def advance(previous, handoff, source, native_path, native_hash):
    current = deepcopy(previous) if previous is not None else dict(count_state={}, relation_state={},
              count_history=[], relation_history=[], count_receipt=None, relation_receipt=None)
    current['count_receipt'] = refresh_for_decision(current['count_state'], handoff, source,
              current['count_receipt'], current['count_history'], recompute_counts)
    current['relation_receipt'] = dispatch_relations(current['relation_state'], handoff, source,
              current['count_receipt'], current['relation_receipt'], current['relation_history'], native_path, native_hash)
    # Caller receives both successful projections together, or keeps its untouched prior context.
    # This is in-memory only, not an atomic disk commit or background revision watcher.
    return previous if previous is not None and current == previous else current


def check(output):
    original = ROOT / 'integration_direct_20261101/real_handoff_0001'
    manifest = read(original / 'receipt.json')
    protected = dict(manifest['protected_sha256'])
    protected.update({str(original / p): h for p,h in manifest['output_sha256'].items()})
    protected[str(original / 'receipt.json')] = '67f7867fa76e8f411f444c3e0ab242212717cf764baf4e4b2687475d33355b7d'
    native = ROOT / 'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    native_hash = '1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4'
    protected[str(native)] = native_hash
    protected[str(ROOT / 'pair_relations_direct_20261101/revision_dispatch_0001/relation_revision.py')] = 'ae41d13af1833cf3040fce27bde75c428aaae0888ada64d8eb411553ca6e5af1'
    for path in (HERE / 'decision_revision_hook.py', HERE / 'real_counts_revision.py', ROOT / 'counts_direct_20261101/pair_counts.py'):
        protected[str(path)] = digest(path)
    assert all(digest(Path(p)) == h for p,h in protected.items())
    copied = output / 'copied_v1'
    copied.mkdir()
    for name in ('seal.json', 'unit.private.json', 'source.private.bin'):
        copyfile(original / 'sealed_v1' / name, copied / name)
    first = recover(copied, manifest['pinned_unit_sha256'])['handoff']
    source = (copied / 'source.private.bin').read_bytes()
    before = advance(None, first, source, native, native_hash)
    assert len(before['relation_receipt']['projection']['active_views']) == 90
    assert advance(before, first, source, native, native_hash) is before
    second = deepcopy(first)
    second.update(version='SANDBOX_ORCHESTRATED_MISSING_SOURCE_v2', prior_version=first['version'])
    changed = []
    for decision in second['decisions']:
        if decision['qid'] == 'Q131347':
            changed.append(decision['occurrence_id'])
            decision.update(qid='Q999999991', evidence=dict(simulated=True, prior=deepcopy(decision['evidence'])))
    assert len(changed) == 1
    second_hash = sha(encoded(second))
    seal_unit(output / 'synthetic_v2', second, source, second_hash, prior_history=[first])
    second = recover(output / 'synthetic_v2', second_hash, prior_history=[first])['handoff']
    failed_state, failed_history = deepcopy(before['relation_state']), deepcopy(before['relation_history'])
    frozen = deepcopy((failed_state, failed_history))
    try:
        dispatch_relations(failed_state, second, source, before['count_receipt'], before['relation_receipt'], failed_history, native, native_hash)
    except ValueError as error:
        assert 'Stale projection' in str(error)
    else:
        raise AssertionError('Stale counts reached relation projection')
    assert (failed_state, failed_history) == frozen
    before_frozen = deepcopy(before)
    after = advance(before, second, source, native, native_hash)
    assert before == before_frozen
    relation = after['relation_receipt']['projection']
    assert relation['counts'] == after['count_receipt']['projection']
    assert relation['missing_qids'] == ['Q999999991'] and len(relation['pending_pairs']) == 9
    assert all(r['reason'] == 'MISSING_FULL_NATIVE_RECORD' for r in relation['pending_pairs'])
    assert len(relation['active_views']) == 72
    assert all('Q999999991' not in (r['source'], r['target']) for r in relation['active_views'])
    assert len(after['count_history']) == len(after['relation_history']) == 2
    assert next(iter(after['count_state'].values())) == next(iter(after['relation_state'].values())) == [first,second]
    assert first['occurrences'] == second['occurrences'] and first['pending_evidence'] == second['pending_evidence']
    assert advance(after, second, source, native, native_hash) is after
    require_current(after['count_receipt'], after['count_state'])
    require_current(after['relation_receipt'], after['relation_state'])
    try:
        advance(before, second, source, native, '0'*64)
    except ValueError:
        pass
    else:
        raise AssertionError('Bad source accepted')
    assert before == before_frozen  # Count update is not exposed when relation validation fails.
    assert all(digest(Path(p)) == h for p,h in protected.items())
    def serializable(context):
        result = {k:v for k,v in context.items() if not k.endswith('_state')}
        result['units'] = list(context['count_state'].values())
        return result
    return dict(status='PASS_COUNT_THEN_RELATION_ORCHESTRATION',before=serializable(before),after=serializable(after),
                changed_occurrence_ids=changed,protected_sha256=protected,real_decisions_changed=False,
                full_recompute=True,geometry_or_publisher_called=False)


if __name__ == '__main__':
    output = HERE / 'count_relation_chain_0001'
    output.mkdir()
    result = check(output)
    (output / 'result.json').write_bytes(encoded(result))
    proof = dict(status=result['status'], checks=8, code_sha256=digest(Path(__file__)), result_sha256=digest(output/'result.json'))
    (output / 'verification.json').write_bytes(encoded(proof))
    print(json.dumps(proof))
