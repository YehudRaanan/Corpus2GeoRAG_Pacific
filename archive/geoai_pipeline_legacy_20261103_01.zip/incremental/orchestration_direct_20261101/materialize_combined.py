"""Materialize a pinned combined projection; B may remain explicitly source-pending."""
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'publisher_direct_20261101/component_materializer_0001'))
from materialize_components import materialize_components
from run_approved_unit import context_state,pinned
from check_one_unit import digest,read


def run():
    projection=HERE/'combined_projection_0001/projection.json'
    expected='85276273c3a413423e33bddf723ebf8693d2a428a219c41560783a3839e3c824'
    context=context_state(pinned(dict(path=str(projection),sha256=expected)))
    manifest=read(HERE/'actual_first_unit_registry17/manifest.json')
    output=ROOT/'publisher_direct_20261101/orchestration_refresh_0001/combined_source_pending_0001/components'
    output.parent.mkdir(exist_ok=True)
    receipt=output/'private/refresh_inputs.json'
    if receipt.exists():
        result=read(receipt);saved=pinned(dict(path=result['receipt_path'],sha256=result['receipt_sha256']))
        assert saved['decision_binding']==context['count_receipt']['decision_binding']
        for name,expected in saved['artifact_sha256'].items():assert digest(output/name)==expected
        return dict(status='PASS_REPLAY_NO_REWRITE',result=result,second_unit_complete=False)
    sources=[projection,Path(context['full_geometry']['receipt_path']),
        HERE/'actual_first_unit_registry17/run/sealed_successor/seal.json',HERE/'second_unit_0001/sealed_pending/seal.json']
    result=materialize_components(output,identity_state=context['count_state'],count_receipt=context['count_receipt'],
        relation_receipt=context['relation_receipt'],geometry_receipt=context['full_geometry']['receipt'],
        native_registry=manifest['native_registry'],consumer_root=manifest['consumer_root'],
        source_receipts=[dict(path=str(p),sha256=digest(p)) for p in sources])
    return dict(status='PASS_COMBINED_MATERIALIZED_WITH_UNIT2_PENDING',result=result,second_unit_complete=False,publication=False)


if __name__=='__main__':
    target=HERE/'combined_projection_0001/materialization_status.json'
    try:result=run()
    except ValueError as error:
        result=dict(status='BLOCKED_MATERIALIZER_INTERFACE',action='materialize pinned two-unit projection',
            reason=str(error),second_unit_complete=False,publication=False)
    target.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))
