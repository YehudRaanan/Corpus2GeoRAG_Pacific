"""Seal prepared real exact/residual decisions without waiting for source acquisition."""
from pathlib import Path
from run_ready_units import save,pinned
from runtime_handoff_0001.decision_handoff import build_handoff
from check_one_unit import read,digest
from integrate_policy_v2 import record

HERE=Path(__file__).resolve().parent
OUT=HERE/'reconciliation_units11_20_v2'

def seal():
    preparation=read(OUT/'policy_preparation.json');units=[];totals=dict(IDENTITY=0,NONE=0,PENDING=0)
    for item in preparation['units']:
        manifest=pinned(item['policy_manifest']);data=Path(manifest['data_directory']);source=read(data/'manifest.json')
        for path,expected in item['summary']['protected_source_sha256'].items():assert digest(path)==expected
        folder=Path(item['policy_manifest']['path']).parent
        baseline=Path(source['source_directory'])/'sealed_pending';base=read(baseline/'unit.private.json')
        exact_patch=read(data/'exact_decision_patch.json');(folder/'exact').mkdir(exist_ok=True)
        exact=build_handoff(folder/'exact/sealed',current_sealed_dir=baseline,current_unit_sha256=digest(baseline/'unit.private.json'),
            prior_history=[],supplied_decisions=exact_patch['decisions'],decision_version=exact_patch['decision_version'])
        patch=read(folder/'policy/residual_decision_patch.json');(folder/'model/unit').mkdir(parents=True,exist_ok=True)
        built=build_handoff(folder/'model/unit/sealed',current_sealed_dir=exact['sealed_dir'],current_unit_sha256=exact['unit_sha256'],
            prior_history=[base],supplied_decisions=patch['decisions'],decision_version=patch['decision_version'])
        unit=built['handoff'];counts=dict(IDENTITY=sum(r['qid'] is not None for r in unit['decisions']),NONE=sum(r['qid'] is None for r in unit['decisions']),PENDING=len(unit['pending_evidence']))
        assert counts==dict(IDENTITY=item['summary']['combined_identity_occurrences'],NONE=item['summary']['explicit_NONE'],PENDING=item['summary']['pending'])
        assert unit['occurrences']==base['occurrences'] and len(unit['occurrences'])==sum(counts.values())
        for key,value in counts.items():totals[key]+=value
        units.append(dict(unit=item['unit'],counts=counts,sealed_unit=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256']),
            source_directory=str(baseline),exact_unit=dict(unit_directory=exact['sealed_dir'],unit_sha256=exact['unit_sha256']),
            decision_version=unit['version'],projection='NOT_RUN',consumer='NOT_RUN',unit_completed=False))
        save(OUT/'sealed_successors.json',dict(status='EIGHT_REAL_CORRECTED_POLICY_UNITS_SEALED',units=units,totals=totals,process_completed_units=0,publication=False))
        print('SEALED batch unit '+str(item['unit'])+' '+str(counts),flush=True)
    assert len(units)==8 and sum(totals.values())==844
    request=read(OUT/'accepted_source_request.json');request['first_nine_new_qids']=['Q218932']
    request['all_missing_qids']=sorted(set(request['missing_from_registry194'])|{'Q218932'})
    request['sealed_successors']=dict(path=str(OUT/'sealed_successors.json'),sha256=digest(OUT/'sealed_successors.json'))
    record(OUT/'combined_source_request.json',request)
    print('READY sources: '+str(len(request['all_missing_qids']))+' actual missing accepted QIDs',flush=True)

if __name__=='__main__':seal()
