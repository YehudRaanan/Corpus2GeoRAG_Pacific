"""Discover completed GPU receipts, apply the existing policy and reconcile sealed CPU jobs.

Run again with the same config when new GPU artifacts arrive. No GPU launch or publication.
"""
import argparse
import gzip
import json
from pathlib import Path
from run_ready_units import run_ready_units,pinned,save,context_state
from check_one_unit import read,digest
from decision_revision_hook import content_hash
from apply_available_policy import apply_policy_output,CALLABLE
from prepare_matching_receipt import prepare_policy_run
from durable_unit import encoded,sha

HERE=Path(__file__).resolve().parent


def record(path,value):
    if not path.exists() or read(path)!=value:save(path,value)
    return dict(path=str(path),sha256=digest(path))


def discover(config):
    packages=[]
    for path in Path(config['data_root']).glob('*/manifest.json'):
        value=read(path)
        if value.get('execution_mode')=='MATERIALIZED_INPUTS':packages.append((path,value))
    found={}
    for root in config['gpu_result_roots']:
        for path in Path(root).rglob('local_verification_receipt.json'):
            local=read(path)
            if local.get('status') not in ('LOCAL_HASH_VERIFIED','COMPLETE_LOCAL_HASH_VERIFIED'):continue
            model_path=path.parent/'model_manifest.json'
            if not model_path.exists():continue
            model=read(model_path);unit=model.get('runtime_unit',{})
            for data_path,data in packages:
                scope=data['scope']
                if (unit.get('page_id'),unit.get('processing_revision_id'),model.get('input_version'))!=(scope['page_id'],scope['processing_revision_id'],data['input_version']):continue
                source_bound=(unit.get('source_data_manifest_sha256')==digest(data_path) or unit.get('source_handoff_sha256')==digest(data_path.parent/'inference_handoff.json'))
                if not source_bound or local.get('records')!=scope['questions']:continue
                counts={row['direction']:row['records'] for row in local.get('counts',[])}
                if counts!={'forward':scope['ordinary_QIDs'],'reverse':scope['ordinary_raw_groups']}:continue
                for proposals in path.parent.glob('*.jsonl'):
                    if digest(proposals)!=local['sha256']:continue
                    key=(scope['page_id'],scope['processing_revision_id'])
                    value=dict(data=str(data_path),proposals=dict(path=str(proposals),sha256=local['sha256']),model=dict(path=str(model_path),sha256=digest(model_path)),gpu_receipt=dict(path=str(path),sha256=digest(path)))
                    found.setdefault(key,{})[(local['sha256'],value['model']['sha256'])]=value
    return found


def reconcile(config_path,config_sha256):
    config=pinned(dict(path=str(config_path),sha256=config_sha256))
    output=Path(config['output_directory']).resolve()
    if not output.is_relative_to(HERE):raise ValueError('Use caller-owned reconciliation output')
    output.mkdir(parents=True,exist_ok=True)
    state_path=output/'state.json'
    code_hash=content_hash({str(path):digest(path) for path in (Path(__file__),HERE/'apply_available_policy.py',HERE/'prepare_matching_receipt.py',HERE/'run_ready_units.py',HERE/'runtime_receipts.py')})
    if state_path.exists():
        state=read(state_path)
        if (state['config_sha256'],state['code_sha256'])!=(config_sha256,code_hash):raise ValueError('Reconciliation configuration/code changed')
    else:
        cursor=pinned(config['initial_cursor'])
        state=dict(config_sha256=config_sha256,code_sha256=code_hash,cursor=config['initial_cursor'],units={})
        record(state_path,state)
    order_path=Path(config['sealed_order']['path'])
    if digest(order_path)!=config['sealed_order']['sha256']:raise ValueError('Sealed unit order changed')
    with gzip.open(order_path,'rt',encoding='utf-8') as stream:
        ordered=[json.loads(line) for index,line in enumerate(stream) if config['order_start']<=index<config['order_end']]
    available=discover(config)
    if digest(CALLABLE)!=config['policy_callable_sha256']:raise ValueError('Policy release changed')
    for ordinal,source in enumerate(ordered,start=config['order_start']):
        key=source['wiki_site']+':'+str(source['page_id'])+':'+str(source['support_revision_id'])
        if str(ordinal) in config.get('blocked_orders',{}):
            state['units'][key]=dict(order_index=ordinal,status=config['blocked_orders'][str(ordinal)])
            record(state_path,state);continue
        choices=list(available.get((source['page_id'],source['support_revision_id']),{}).values())
        if len(choices)!=1:
            state['units'][key]=dict(order_index=ordinal,status='WAIT_GPU_RECEIPT' if not choices else 'AMBIGUOUS_GPU_VERSIONS')
            record(state_path,state);continue
        candidate=choices[0];folder=output/('unit_'+str(ordinal+1)+'_'+candidate['proposals']['sha256'][:12]);folder.mkdir(exist_ok=True)
        policy_manifest=dict(schema='geoai-existing-opening-policy-unit-v1',data_directory=str(Path(candidate['data']).parent),policy_directory=config['policy_directory'],mapping_filename='all_occurrence_mapping.json',decision_version='unit'+str(ordinal+1)+'-owner-approved-opening-v1',result_files=[candidate['proposals']],model_manifests=[candidate['model']],policy_callable_sha256=config['policy_callable_sha256'])
        policy_pin=record(folder/'policy_manifest.json',policy_manifest)
        summary=apply_policy_output(policy_pin,folder/'policy')
        cursor=pinned(state['cursor']);context=context_state(pinned(cursor['projection']))
        active=next((versions[-1] for versions in context['count_state'].values() if (versions[-1]['manifest']['page_id'],versions[-1]['manifest']['support_revision_id'])==(source['page_id'],source['support_revision_id'])),None)
        patch=read(folder/'policy/decision_patch.json');expected={row['occurrence_id']:row for row in patch['decisions']}
        if active is not None:
            if {row['occurrence_id']:row for row in active['decisions']}!=expected:raise ValueError('Existing unit needs an explicit decision revision, not another initial patch')
            details=dict(state['units'].get(key,{}),order_index=ordinal,status='CANONICAL_POLICY_APPLIED',decision_version=active['version'],unit_sha256=sha(encoded(active)),assigned=summary['combined_identity_occurrences'],pending=summary['pending'],gpu=candidate)
        else:
            base=pinned(config['base_manifest']);base.pop('source_refresher',None)
            base.update(initial_projection=cursor['projection'],native_registry=cursor.get('native_registry',base['native_registry']))
            data=Path(policy_manifest['data_directory']);prepared=read(data/'manifest.json');sealed=Path(prepared['source_directory'])/'sealed_pending'
            exact=dict(mode='ADD_PENDING',approved_decisions=dict(path=str(data/'exact_decision_patch.json'),sha256=digest(data/'exact_decision_patch.json')),current_unit=dict(unit_directory=str(sealed),unit_sha256=digest(sealed/'unit.private.json'),prior_history=[]),output_directory=str(folder/'exact'),publisher_output_directory=str(Path(config['publisher_output_root'])/('unit_'+str(ordinal+1)+'_exact_'+candidate['proposals']['sha256'][:12])))
            exact_pin=record(folder/'exact_job.json',exact)
            base.update(output_directory=str(folder/'exact_state'),jobs=[exact_pin]);exact_manifest=record(folder/'exact_manifest.json',base)
            exact_result=run_ready_units(exact_manifest['path'],exact_manifest['sha256'])
            exact_cursor=dict(path=exact_result['index_path'],sha256=digest(exact_result['index_path']))
            preparation=dict(policy_manifest=policy_pin,policy_output=str(folder/'policy'),current_job=exact_pin,current_result=dict(path=str(folder/'exact/unit_result.json'),sha256=digest(folder/'exact/unit_result.json')),base_manifest=exact_manifest,cursor=exact_cursor,output_directory=str(folder/'model'),publisher_output_directory=str(Path(config['publisher_output_root'])/('unit_'+str(ordinal+1)+'_model_'+candidate['proposals']['sha256'][:12])))
            configuration=record(folder/'policy_config.json',preparation)
            manifest=prepare_policy_run(configuration);result=run_ready_units(manifest['path'],manifest['sha256'])
            state['cursor']=dict(path=result['index_path'],sha256=digest(result['index_path']))
            unit=read(folder/'model/unit/unit_result.json')
            details=dict(order_index=ordinal,status='CANONICAL_POLICY_APPLIED',decision_version=unit['decision_version'],unit_sha256=unit['sealed_unit']['unit_sha256'],assigned=summary['combined_identity_occurrences'],pending=summary['pending'],gpu=candidate,unit_result=dict(path=str(folder/'model/unit/unit_result.json'),sha256=digest(folder/'model/unit/unit_result.json')))
        state['units'][key]=details;record(state_path,state)
        print(json.dumps(dict(unit=ordinal+1,status=details['status'],assigned=details['assigned'],pending=details['pending'])),flush=True)
    cursor=pinned(state['cursor']);context=context_state(pinned(cursor['projection']))
    accepted=[]
    for versions in context['count_state'].values():
        unit=versions[-1];accepted.append(dict(scope=unit['manifest'],unit_sha256=sha(encoded(unit)),decision_version=unit['version'],accepted_qids=sorted({row['qid'] for row in unit['decisions'] if row['qid'] is not None})))
    record(output/'accepted_sources.json',dict(projection=cursor['projection'],units=accepted,missing_native_qids=context['relation_receipt']['projection']['missing_qids']))
    result=dict(status='RECONCILED_AVAILABLE_GPU_RESULTS',state_path=str(state_path),cursor=state['cursor'],units=state['units'],counts=context['count_receipt']['projection'],publication=False)
    record(output/'result.json',result)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('config');parser.add_argument('sha256')
    args=parser.parse_args();result=reconcile(args.config,args.sha256)
    print(json.dumps(dict(status=result['status'],state_path=result['state_path'],units=len(result['units']),publication=False)))
