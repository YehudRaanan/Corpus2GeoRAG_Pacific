"""Adopt E2's verified nine-unit deltas as immutable successors using the existing CPU loop."""
import argparse
from copy import deepcopy
from pathlib import Path
from run_ready_units import run_ready_units,pinned,save
from runtime_handoff_0001.decision_handoff import build_handoff
from check_one_unit import read,digest
from decision_revision_hook import content_hash

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OUT=HERE/'policy_v2_integration_0001'
E2=ROOT/'candidate_check_fix_direct_20261102'

def record(path,value):
    if path.exists():
        if read(path)!=value:raise ValueError('Immutable prepared artifact differs: '+str(path))
    else:save(path,value)
    return dict(path=str(path),sha256=digest(path))

def prepare():
    OUT.mkdir(exist_ok=True)
    release=read(E2/'patch_manifest.json');summary=pinned(release['dry_run'])
    independent=E2/'independent_verification.json'
    assert digest(independent)==release['independent_verification_sha256']
    for item in release['patches']:
        assert digest(item['path'])==digest(item['snapshot'])==item['after_sha256']
    assert read(independent)['original_446_identities_unchanged']
    for path,expected in summary['protected_sha256'].items():assert digest(path)==expected
    inventory=read(HERE/'completion_semantics_audit_v1/route_inventory.json')
    results={row['page']:pinned(row['unit_result']) for row in inventory['units']}
    old_jobs={}
    for folder in ('first_five_consumer_completion_v1','consumer_units7_8_10_registry164_v1','consumer_unit9_registry194_v1'):
        manifest=read(HERE/folder/'manifest.json')
        for descriptor in manifest['jobs']:
            job=pinned(descriptor);unit=read(Path(job['current_unit']['unit_directory'])/'unit.private.json')
            old_jobs[unit['manifest']['page_id']]=job
    profile=read(HERE/'consumer_unit9_registry194_v1/manifest.json');profile.pop('policy_preparation_config',None)
    cursor=read(HERE/'consumer_unit9_registry194_v1/state/index.json')
    profile.update(initial_projection=cursor['projection'],native_registry=cursor['native_registry'],output_directory=str(OUT/'state'))
    registry=pinned(cursor['native_registry']);known=set(registry['selected_references'])
    jobs=[];sealed=[];totals=dict(IDENTITY=0,NONE=0,PENDING=0);missing=set()
    for item in summary['units']:
        number=item['unit'];delta=pinned(item['decision_delta']);old=results[item['page_id']]
        previous=pinned(old['stages']['handoff']);current=previous['handoff'];job=old_jobs[item['page_id']]
        assert delta['source_unit_sha256']==old['sealed_unit']['unit_sha256']
        assert delta['prior_version']==current['version']
        history=deepcopy(job['current_unit'].get('prior_history',[]))
        if job['current_unit']['unit_sha256']!=old['sealed_unit']['unit_sha256']:
            history.append({key:job['current_unit'][key] for key in ('unit_directory','unit_sha256')})
        folder=OUT/('unit_'+str(number));folder.mkdir(exist_ok=True)
        built=build_handoff(folder/'sealed',current_sealed_dir=previous['sealed_dir'],current_unit_sha256=previous['unit_sha256'],
            prior_history=previous['prior_history'],supplied_decisions=delta['decisions'],decision_version=delta['decision_version'])
        unit=built['handoff'];before={r['occurrence_id']:r for r in current['decisions']}
        after={r['occurrence_id']:r for r in unit['decisions']}
        assert unit['occurrences']==current['occurrences'] and all(after[key]==value for key,value in before.items())
        counts=dict(IDENTITY=sum(r['qid'] is not None for r in unit['decisions']),NONE=sum(r['qid'] is None for r in unit['decisions']),PENDING=len(unit['pending_evidence']))
        assert counts==item['after']
        for key,value in counts.items():totals[key]+=value
        missing.update({r['qid'] for r in unit['decisions'] if r['qid'] is not None}-known)
        # Reuse the original exact input/result bindings; v2 changes adjudication, not model execution.
        matching=pinned(pinned(old['stages']['matching'])['receipt'])
        policy=pinned(matching['policy_verification'])
        evidence_folder=Path(matching['policy_verification']['path']).parent
        evidence_path=next(evidence_folder/name for name in ('all_occurrence_decision_evidence.json','all90_decision_evidence.json','pending_and_decision_evidence_106.json') if (evidence_folder/name).exists())
        evidence=deepcopy(read(evidence_path));changed={r['occurrence_id']:r for r in delta['decisions']}
        for row in evidence:
            if row['occurrence_id'] in changed:
                decision=changed[row['occurrence_id']];row.update(status='NONE' if decision['qid'] is None else 'IDENTITY',qid=decision['qid'],v2_decision=decision)
        record(folder/'all_occurrence_decision_evidence.json',evidence)
        protected=dict(policy['protected_source_sha256']);protected.update({str(E2/'patch_manifest.json'):digest(E2/'patch_manifest.json'),str(E2/'independent_verification.json'):digest(independent),item['decision_delta']['path']:item['decision_delta']['sha256']})
        for patch in release['patches']:protected[patch['path']]=patch['after_sha256']
        proof=record(folder/'policy_receipt.json',dict(status='VERIFIED_SUPPLIED_V2_DELTA',protected_source_sha256=protected,
            original_matching_receipt=pinned(old['stages']['matching'])['receipt'],delta=item['decision_delta'],policy_version=release['policy_version'],counts=counts))
        matching.update(decision_patch=item['decision_delta'],policy_verification=proof)
        matching_pin=record(folder/'matching_receipt.json',matching)
        next_job=dict(mode='ADD_PENDING',approved_decisions=item['decision_delta'],matching_receipt=matching_pin,
            current_unit=dict(old['sealed_unit'],prior_history=history),output_directory=str(folder),
            publisher_output_directory=str(ROOT/'publisher_direct_20261101/orchestration_refresh_0001'/('policy_v2_unit_'+str(number))))
        jobs.append(record(folder/'job.json',next_job))
        sealed.append(dict(unit=number,counts=counts,sealed_unit=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256']),prior_version=current['version'],decision_version=unit['version']))
        print('SEALED unit '+str(number)+' '+str(counts),flush=True)
    assert totals==summary['after']
    profile['jobs']=jobs
    manifest=record(OUT/'manifest.json',profile)
    record(OUT/'sealed_receipt.json',dict(status='NINE_REAL_V2_SUCCESSORS_SEALED',totals=totals,units=sealed,
        preserved_prior_identities=446,actual_missing_accepted_qids=sorted(missing),manifest=manifest,process_completed_units=0,publication=False))
    print('READY '+str(manifest)+' missing_sources='+str(sorted(missing)),flush=True)
    return manifest

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    manifest=prepare()
    if args.run:print(run_ready_units(manifest['path'],manifest['sha256']))
