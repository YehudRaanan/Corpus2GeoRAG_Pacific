"""Supersede parser-based DATE admission with the owner's structured-QID time requirement."""
from pathlib import Path
from run_ready_units import pinned,save
from check_one_unit import read,digest
from route_completion import route_completion

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;OUT=HERE/'route_receipt_generation_0002'

def reconcile():
    OUT.mkdir(exist_ok=True)
    handoffs=[dict(path=str(ROOT/'runtime_model_inputs_direct_20261101/date_route/v1/handoff.json'),sha256='37837c804df60f1eaee1d078012fcf3ec1f405f470e5b4c5feec387a1f15e8f0'),
        dict(path=str(ROOT/'runtime_model_inputs_direct_20261101/date_route/v1/units11_20_eight_v1/handoff.json'),sha256='abcdf065a7612d168fcfb7127c41faa7154ee0c078361cf76759c614a6211352')]
    dates={row['page_id']:row['route_receipts'] for pin in handoffs for row in pinned(pin)['units']}
    event_release=read(ROOT/'pair_relations_direct_20261101/event_execution_0001/HANDOFF.json')
    events={row['page_id']:row['event_route'] for row in pinned(event_release['handoff'])['receipts']}
    sets=[(read(HERE/'policy_v2_integration_0001/sealed_receipt.json')['units'],'old'),
        (read(HERE/'reconciliation_units11_20_v2/sealed_successors.json')['units'],'new')]
    policies={row['unit']:row for row in read(HERE/'reconciliation_units11_20_v2/policy_preparation.json')['units']}
    units=[];totals=dict(IDENTITY=0,NONE=0,PENDING=0);date_count=0
    for rows,kind in sets:
        for item in rows:
            source=item['sealed_unit'];path=Path(source['unit_directory'])/'unit.private.json'
            assert digest(path)==source['unit_sha256'];unit=read(path);page=unit['manifest']['page_id']
            stages=dict(dates[page])
            if page in events:stages['event_route']=events[page]
            if kind=='old':
                matching=HERE/'policy_v2_integration_0001'/('unit_'+str(item['unit']))/'matching_receipt.json'
            else:
                folder=Path(policies[item['unit']]['policy_manifest']['path']).parent
                policy=folder/'policy/receipt.json';matching=OUT/('unit_'+str(item['unit'])+'_routing_context.json')
                save(matching,dict(kind='ROUTE_CONTEXT_ONLY_NO_NEW_INFERENCE_CLAIM',policy_verification=dict(path=str(policy),sha256=digest(policy))))
            result=route_completion(stages,unit,dict(path=str(matching),sha256=digest(matching)))
            assert result['missing']['date_route']['status']=='DIAGNOSTIC_ONLY' and not result['complete']
            date_ids={row['occurrence_id'] for row in unit['occurrences'] if row['entity_group']=='DATE'}
            assert date_ids<={row['occurrence_id'] for row in unit['pending_evidence']}
            date_count+=len(date_ids)
            for key,value in item['counts'].items():totals[key]+=value
            units.append(dict(unit=item['unit'],page_id=page,source_unit=source,route_receipts=stages,
                current_completion=result,structured_temporal_enrichment='NOT_VERIFIED',process_completed=False))
    assert len(units)==17 and date_count==334 and totals==dict(IDENTITY=835,NONE=599,PENDING=420)
    receipt=dict(status='TEXT_DATE_DIAGNOSTICS_NOT_TEMPORAL_ENRICHMENT',controlling_user_message='Sentinel_ccf8866d54208191bd1af18a88e1df6e',
        controlling_user_time_utc='2026-11-01T09:55:09Z',time_requirement='Structured QID-linked Wikidata values with provenance; never infer dates from raw text',
        supersedes=HERE.joinpath('route_receipt_generation_0001/receipt.json').as_posix(),
        parser_diagnostics=dict(processed=334,normalized=242,unsupported=92,approved_for_enrichment=False),
        raw_DATE_pending_preserved=334,units=units,identity_totals=totals,process_completed_units=0,publication=False,
        date_handoffs=handoffs,event_handoff=event_release['handoff'],verifier_sha256=digest(HERE/'route_completion.py'))
    save(OUT/'receipt.json',receipt)
    print('PASS:17 sealed units;334 raw DATE IDs remain pending;242 parsed values diagnostic only; full completion zero')
    print('receipt_sha256='+digest(OUT/'receipt.json'))

if __name__=='__main__':reconcile()
