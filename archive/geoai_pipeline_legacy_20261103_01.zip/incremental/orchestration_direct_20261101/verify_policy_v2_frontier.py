"""Independent occurrence/page count readback of the nine-unit corrected frontier."""
from collections import Counter,defaultdict
from pathlib import Path
from check_one_unit import read,digest
from run_ready_units import pinned,save

HERE=Path(__file__).resolve().parent;OUT=HERE/'policy_v2_integration_0001'

def verify():
    sealed=read(OUT/'sealed_receipt.json');state=read(OUT/'state/index.json')
    assert len(state['jobs'])==9
    mentions=Counter();pages=defaultdict(set);occurrences=set();none=0;pending=0
    versions={};protected=[]
    for item in sealed['units']:
        descriptor=item['sealed_unit'];path=Path(descriptor['unit_directory'])/'unit.private.json'
        assert digest(path)==descriptor['unit_sha256'];unit=read(path)
        ids={row['occurrence_id'] for row in unit['occurrences']}
        assert len(ids)==len(unit['occurrences']) and not ids&occurrences;occurrences|=ids
        decisions={row['occurrence_id']:row for row in unit['decisions']}
        unresolved={row['occurrence_id'] for row in unit['pending_evidence']}
        assert not unresolved&set(decisions) and unresolved|set(decisions)==ids
        page=(unit['manifest']['wiki_site'],unit['manifest']['page_id'])
        for row in decisions.values():
            if row['qid'] is None:none+=1
            else:mentions[row['qid']]+=1;pages[row['qid']].add(page)
        pending+=len(unresolved);versions[unit['manifest']['page_id']]=unit['version']
        protected.append(dict(path=str(path),sha256=descriptor['unit_sha256']))
    last=read(OUT/'unit_10/unit_result.json');counts=last['counts']
    assert (len(occurrences),sum(mentions.values()),none,pending)==(1010,449,329,232)
    assert (counts['accepted_occurrences'],counts['explicit_unmatched_occurrences'],counts['pending_occurrences'])==(449,329,232)
    assert {row['qid']:(row['mention_count'],row['page_count']) for row in counts['identity_counts']}=={qid:(mentions[qid],len(pages[qid])) for qid in mentions}
    for item in state['jobs'].values():
        result=pinned(item)
        for path,expected in result['verified_artifact_sha256'].items():assert digest(path)==expected
        assert not result['unit_completed'] and result['publication'] is False
    relations=pinned(last['stages']['relation_receipt'])
    assert relations['projection']['missing_qids']==['Q218932']
    assert {row['scope'][2]:row['decision_version'] for row in relations['decision_binding']}==versions
    route=read(HERE/'route_receipt_generation_0001/receipt.json')
    assert route['date']==dict(RESOLVED=125,UNRESOLVED=51,NOT_APPLICABLE=0)
    result=dict(status='PASS_INDEPENDENT_V2_NINE_UNIT_FRONTIER',source_units=9,occurrences=1010,assigned=449,
        explicit_NONE=329,pending=232,original_identities_preserved=446,missing_source_qids=['Q218932'],
        date_normalized=125,date_unresolved=51,event_partial_execution=25,process_completed_units=0,publication=False,
        protected_units=protected,cursor=dict(path=str(OUT/'state/index.json'),sha256=digest(OUT/'state/index.json')),
        relation_receipt=last['stages']['relation_receipt'],route_receipt=dict(path=str(HERE/'route_receipt_generation_0001/receipt.json'),sha256=digest(HERE/'route_receipt_generation_0001/receipt.json')))
    save(OUT/'independent_verification.json',result)
    print('PASS: 1010 IDs; 449 identities +329 NONE +232 pending; page counts/version bindings exact; no full-process completion')
    print('verification_sha256='+digest(OUT/'independent_verification.json'))

if __name__=='__main__':verify()
