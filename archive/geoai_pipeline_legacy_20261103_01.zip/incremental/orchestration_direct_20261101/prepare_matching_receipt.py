"""Normalize a pinned generic policy handoff into the existing CPU loop's input contract."""
from pathlib import Path
from run_ready_units import pinned,save
from check_one_unit import read,digest
from decision_revision_hook import content_hash
import json


def prepare_matching(policy_manifest,policy_output,patch,source_manifest,output):
    manifest=pinned(policy_manifest);folder=Path(policy_output)
    receipt=read(folder/'receipt.json')
    for path,expected in receipt['protected_source_sha256'].items():
        if digest(path)!=expected:raise ValueError('Policy source evidence changed')
    if patch['sha256']!=receipt['residual_patch_sha256']:raise ValueError('Use the verified residual patch after canonical exact decisions')
    pinned(patch)
    if (receipt['page_id'],receipt['processing_revision_id'])!=(source_manifest['page_id'],source_manifest['support_revision_id']):
        raise ValueError('Policy source scope differs from the sealed unit')
    data=Path(manifest['data_directory'])
    requests={row['raw']['id']:row for name in ('capacity_ready_requests.json','capacity_pending_requests.json') for row in read(data/name)}
    items={row['id']:row for row in read(data/'full_untruncated_encoded_items.json')}
    model_hashes={item['sha256'] for item in manifest['model_manifests']}
    for descriptor in manifest['model_manifests']:pinned(descriptor)
    rows=[]
    for descriptor in manifest['result_files']:
        path=Path(descriptor['path'])
        if digest(path)!=descriptor['sha256']:raise ValueError('Model result bytes changed')
        rows.extend(json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip())
    if len(rows)!=len(requests) or {row['request']['raw']['id'] for row in rows}!=set(requests):
        raise ValueError('Policy result does not cover the declared question domain')
    output=Path(output);output.mkdir(parents=True)
    fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
    normalized=dict(decision_patch=patch,source_scope={key:source_manifest[key] for key in fields},
        policy_verification=dict(path=str(folder/'receipt.json'),sha256=digest(folder/'receipt.json')),directions={})
    for direction in ('forward','reverse'):
        subset=[row for row in rows if row['request']['raw']['direction']==direction];bindings=[]
        for row in subset:
            key=row['request']['raw']['id'];request=requests[key];model_hash=row['artifact']['manifest_sha256']
            if row['request']!=request or model_hash not in model_hashes:raise ValueError('Result/request/model provenance differs')
            encoded={key:items[request['raw']['id']][key] for key in ('id','direction','candidate_ids','ids','markers','qtype')}
            encoded.update(unlabelled=True,artifact_manifest_sha256=model_hash)
            bindings.append(dict(id=key,input_version=request['input_version'],input_sha256=content_hash(request),encoded_sha256=content_hash(encoded)))
        proposals=output/(direction+'.jsonl');proposals.write_text(''.join(json.dumps(row)+'\n' for row in subset),encoding='utf-8')
        binding_path=output/(direction+'_bindings.json');save(binding_path,bindings)
        normalized['directions'][direction]=dict(proposals=dict(path=str(proposals),sha256=digest(proposals)),bindings=dict(path=str(binding_path),sha256=digest(binding_path)))
    target=output/'receipt.json';save(target,normalized)
    return dict(path=str(target),sha256=digest(target))


def prepare_policy_run(config_descriptor):
    config=pinned(config_descriptor);output=Path(config['output_directory']).resolve()
    if not output.is_relative_to(Path(__file__).resolve().parent):raise ValueError('Use an owned policy-run directory')
    target=output/'manifest.json'
    if target.exists():
        if read(target)['policy_preparation_config']!=config_descriptor:raise ValueError('Prepared run belongs to another config')
        return dict(path=str(target),sha256=digest(target))
    old_job=pinned(config['current_job'])
    if 'current_result' in config:
        current=pinned(config['current_result'])
        if current['job_sha256']!=content_hash(old_job):raise ValueError('Current job/result differ')
        built=pinned(current['stages']['handoff']);sealed=current['sealed_unit']
    else:
        journal=pinned(config['current_stage_journal'])
        if journal['job_sha256']!=content_hash(old_job):raise ValueError('Current job/stage journal differ')
        built=pinned(journal['stages']['handoff'])
        sealed=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256'])
    profile=pinned(config['base_manifest']);cursor=pinned(config['cursor'])
    policy_folder=Path(config['policy_output']);receipt=read(policy_folder/'receipt.json')
    patch=dict(path=str(policy_folder/'residual_decision_patch.json'),sha256=receipt['residual_patch_sha256'])
    matching=prepare_matching(config['policy_manifest'],policy_folder,patch,built['handoff']['manifest'],output/'matching')
    prior=[*old_job['current_unit'].get('prior_history',[]),
        {key:old_job['current_unit'][key] for key in ('unit_directory','unit_sha256')}]
    job=dict(mode='ADD_PENDING',approved_decisions=patch,matching_receipt=matching,
        current_unit=dict(sealed,prior_history=prior),output_directory=str(output/'unit'),
        publisher_output_directory=config['publisher_output_directory'])
    if config.get('route_receipts'):job['route_receipts']=config['route_receipts']
    path=output/'job.json';save(path,job)
    profile.update(initial_projection=cursor['projection'],native_registry=cursor.get('native_registry',profile['native_registry']),
        output_directory=str(output/'state'),jobs=[dict(path=str(path),sha256=digest(path))],policy_preparation_config=config_descriptor)
    save(target,profile)
    return dict(path=str(target),sha256=digest(target))


if __name__=='__main__':
    import argparse
    from run_ready_units import run_ready_units
    parser=argparse.ArgumentParser(description='Versioned policy output -> journaled unit CPU/consumer run; no inference')
    parser.add_argument('config');parser.add_argument('sha256');parser.add_argument('--prepare-only',action='store_true')
    args=parser.parse_args();manifest=prepare_policy_run(dict(path=str(Path(args.config).resolve()),sha256=args.sha256))
    print(json.dumps(manifest if args.prepare_only else run_ready_units(manifest['path'],manifest['sha256'])))
