"""Verify an actually completed runtime unit for the unchanged pure cadence rule."""
from pathlib import Path
from run_ready_units import pinned
from check_one_unit import read,digest
from durable_unit import recover
from runtime_receipts import verify_matching
from route_completion import route_completion


def verified_runtime_unit(reference):
    if reference['runtime_verifier_sha256']!=digest(Path(__file__)):
        raise ValueError('Runtime admission verifier changed')
    result=pinned(reference['unit_result'])
    if result['unit_completed'] is not True:
        return dict(status='pending',reason='Runtime required stages are incomplete')
    for path,expected in result['verified_artifact_sha256'].items():
        if digest(path)!=expected:raise ValueError('Runtime unit artifact changed')
    stages={name:pinned(descriptor) for name,descriptor in result['stages'].items()}
    if stages['matching']['status']!='VERIFIED_BIDIRECTIONAL_INPUT_BINDING':
        raise ValueError('Both inference directions were not verified')
    built=stages['handoff']
    loaded=recover(built['sealed_dir'],built['unit_sha256'],built['prior_history'])
    unit=loaded['handoff'];manifest=unit['manifest']
    preparation=pinned(reference['preparation_manifest'])
    folder=Path(reference['preparation_manifest']['path']).parent
    for name,expected in preparation['output_sha256'].items():
        if digest(folder/name)!=expected:raise ValueError('Preparation artifact changed')
    for path,expected in preparation.get('protected_source_sha256',{}).items():
        if digest(path)!=expected:raise ValueError('Preparation source changed')
    if (preparation['page_id'],preparation['processing_revision_id'],preparation['scope']['occurrences'])!=(manifest['page_id'],manifest['support_revision_id'],len(unit['occurrences'])):
        raise ValueError('Preparation belongs to another source unit')
    protected_count=preparation['scope']['protected_exact_occurrences']
    protected=next((old['decisions'] for old in built['prior_history'] if old['decisions']),[])
    decisions={row['occurrence_id']:row for row in unit['decisions']}
    if len(protected)!=protected_count or any(decisions.get(row['occurrence_id'])!=row for row in protected):
        raise ValueError('Original protected exact decisions differ')
    matching_reference=stages['matching']['receipt']
    matching=pinned(matching_reference)
    verify_matching(matching_reference,matching['decision_patch'],manifest)
    routes=route_completion(result['stages'],unit,matching_reference)
    if not routes['complete']:
        return dict(status='pending',reason='Required occurrence routes have not executed',missing_routes=routes['missing'],
                    consumer_materialization_succeeded=True,scope=manifest)
    policy=pinned(matching['policy_verification'])
    for path,expected in policy['protected_source_sha256'].items():
        if digest(path)!=expected:raise ValueError('Policy source evidence changed')
    consumer=stages['materialize'];receipt=pinned(dict(path=consumer['receipt_path'],sha256=consumer['receipt_sha256']))
    if consumer['status']!='PASS_NEW_FRONTIER_COMPONENT_MATERIALIZATION':raise ValueError('Consumer stage is incomplete')
    artifacts=dict(result['verified_artifact_sha256'])
    artifacts[reference['preparation_manifest']['path']]=reference['preparation_manifest']['sha256']
    # These statuses attest actual source preparation, verified supplied policy and local consumer readback.
    names=('input','grouping','exact','matching','approved_decisions','handoff','counts','relations','full_geometry','components')
    chain=dict(status='PASS_ONE_UNIT_RECEIPT_CHAIN',page_id=manifest['page_id'],processing_revision_id=manifest['support_revision_id'],
        code_sha256=digest(Path(__file__)),stages={name:dict(status='COMPLETED',version=unit['version']) for name in names},
        receipt_sha256={consumer['receipt_path']:consumer['receipt_sha256']},verified_artifact_sha256=artifacts)
    loaded['stage_chain']=chain
    return loaded
