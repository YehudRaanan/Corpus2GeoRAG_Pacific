"""Count/relation/scoped support -> FULL_LOC_POPULATION and a publisher component receipt."""
import json
import sys
from copy import deepcopy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MERGER = ROOT/'geometry_direct_20261101/full_projection_0001'
sys.path.insert(0,str(MERGER))
from full_projection import merge_projection
from advance_with_geometry import advance_geometry
from decision_revision_hook import content_hash, require_current
from check_one_unit import read,digest


def advance_full(output, previous, handoff, source, *, native_path, native_hash,
                 geometry_bindings, geometry_bindings_sha256, baseline, fragment_artifact_root):
    current = advance_geometry(previous,handoff,source,native_path,native_hash,
                               geometry_bindings,geometry_bindings_sha256)
    fragment = dict(current['geometry_receipt'],artifact_root=str(Path(fragment_artifact_root).resolve()))
    output = Path(output).resolve()
    output.mkdir(parents=True,exist_ok=True)
    merged = merge_projection(output/'model',baseline,fragment,current['count_state'],content_hash(fragment))
    require_current(merged,current['count_state'])
    source_binding = dict(count_receipt_sha256=content_hash(current['count_receipt']),
                          relation_receipt_sha256=content_hash(current['relation_receipt']))
    request = dict(baseline=baseline,fragment=fragment,source_binding=source_binding)
    request_path, receipt_path = output/'request.json',output/'full_geometry_receipt.json'
    if request_path.exists():
        if read(request_path)!=request:raise ValueError('Different component request cannot overwrite this output')
    else:
        request_path.write_text(json.dumps(request,indent=2),encoding='utf-8')
    # Reconcile the merger schema with PUBLISHER's explicit private GEO_INPUT_INTERFACE.
    projection = dict(scope_kind='FULL_LOC_POPULATION',scope_qids=merged['scope']['place_ids'],
                      geography_path=merged['artifacts']['geography'],geoparquet_path=merged['artifacts']['geoparquet'],
                      artifact_sha256=merged['artifact_sha256'],source_binding=source_binding)
    receipt = dict(decision_binding=merged['decision_binding'],projection=projection,
                   projection_sha256=content_hash(projection),decision_version=merged['decision_version'],
                   version=merged['version'],source_sha256=dict(merged['source_sha256'],**{
                       str(request_path):digest(request_path),str(output/'model/receipt.json'):digest(output/'model/receipt.json'),
                       str(MERGER/'full_projection.py'):digest(MERGER/'full_projection.py'),str(Path(__file__)):digest(Path(__file__))}),
                   proposed_contract=True,daniel_approval='not recorded',publication=False)
    require_current(receipt,current['count_state'])
    if receipt_path.exists():
        if read(receipt_path)!=receipt:raise ValueError('Saved full component receipt changed')
    else:
        receipt_path.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    for path,expected in {**receipt['source_sha256'],**projection['artifact_sha256']}.items():
        if digest(Path(path))!=expected:raise ValueError('Full component source/output changed: '+path)
    full = dict(receipt=receipt,receipt_path=str(receipt_path),receipt_sha256=digest(receipt_path),
                merger_receipt=merged,component=dict(version=merged['version'],decision_version=merged['decision_version'],
                scope=merged['scope'],artifacts=merged['artifacts']))
    if current.get('full_geometry')==full:return current
    result = deepcopy(current)
    result['full_geometry'] = full
    return result


def check(output):
    chain_path = HERE/'geometry_chain_0001/result.json'
    chain = read(chain_path)
    assert digest(chain_path)==read(chain_path.parent/'verification.json')['result_sha256']
    proof = read(MERGER/'verification.json')
    assert digest(MERGER/'requests.json')==proof['requests_sha256']
    assert digest(MERGER/'full_projection.py')==proof['code_sha256']
    baseline = read(MERGER/'requests.json')[0]['baseline']
    source = (ROOT/'integration_direct_20261101/real_handoff_0001/sealed_v1/source.private.bin').read_bytes()
    native = ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    arguments = dict(native_path=native,native_hash='1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4',
                     geometry_bindings=chain['support_bindings'],geometry_bindings_sha256=content_hash(chain['support_bindings']),
                     baseline=baseline,fragment_artifact_root=ROOT/'geometry_direct_20261101/tokyo_handoff_0001/model')
    protected = dict(chain['protected_sha256'])
    protected.update({str(chain_path):digest(chain_path),str(MERGER/'full_projection.py'):proof['code_sha256'],
                      str(MERGER/'requests.json'):proof['requests_sha256'],str(HERE/'advance_with_geometry.py'):digest(HERE/'advance_with_geometry.py')})
    assert all(digest(Path(p))==h for p,h in protected.items())
    import geopandas as gpd
    original = gpd.read_parquet(baseline['artifacts']['geoparquet'])
    previous,results = None,[]
    for index,unit in enumerate(chain['versions']):
        slot = output/f'version_{index+1}'
        current = advance_full(slot,previous,unit,source,**arguments)
        receipt = current['full_geometry']['receipt']
        require_current(receipt,current['count_state'])
        component = current['full_geometry']['component']
        rows = read_gzip(component['artifacts']['geography'])
        frame = gpd.read_parquet(component['artifacts']['geoparquet'])
        assert len(rows)==[5,6,5][index] and len(frame)==[5,5,4][index]
        for qid in ('Q11751','Q131347','Q153732','Q51679'):
            assert frame.loc[frame.place_id==qid].geometry.iloc[0].wkb==original.loc[original.place_id==qid].geometry.iloc[0].wkb
        if index:assert next(r for r in rows if r['place_id']=='Q999999991')['geometry_ref'] is None
        if index==2:assert 'Q1490' not in {r['place_id'] for r in rows}
        before = {str(p):(digest(p),p.stat().st_mtime_ns) for p in slot.rglob('*') if p.is_file()}
        replay = advance_full(slot,current,unit,source,**arguments)
        assert replay is current
        assert before=={str(p):(digest(p),p.stat().st_mtime_ns) for p in slot.rglob('*') if p.is_file()}
        results.append(current['full_geometry']);previous=current
    assert len(previous['geometry_history'])==len(previous['count_history'])==len(previous['relation_history'])==3
    assert all(digest(Path(p))==h for p,h in protected.items())
    return dict(status='PASS_ORCHESTRATED_FULL_GEOMETRY',components=results,versions=chain['versions'],
                baseline=baseline,protected_sha256=protected,LOC_rows=[5,6,5],shapes=[5,5,4],
                publisher_called=False,actual_model_decisions=False,checks=7)


def read_gzip(path):
    import gzip
    with gzip.open(path,'rt',encoding='utf-8') as stream:return json.load(stream)


if __name__=='__main__':
    output = HERE/'full_geometry_chain_0001';output.mkdir()
    result = check(output)
    (output/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    proof = dict(status=result['status'],checks=result['checks'],code_sha256=digest(Path(__file__)),
                 result_sha256=digest(output/'result.json'),LOC_rows=result['LOC_rows'],shapes=result['shapes'],publisher_called=False)
    (output/'verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof))
