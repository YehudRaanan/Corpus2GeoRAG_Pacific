"""Read the second sealed unit only: preserve original rows, group prepared surfaces, seal PENDING source custody."""
import gzip,json,sys
from pathlib import Path
import pyarrow.parquet as pq

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path[:0]=[str(ROOT/'integration_direct_20261101'),str(ROOT/'durable_units_direct_20261101')]
from run_first_real_unit import processing_record,mention_id,group_mentions
from durable_unit import seal_unit,recover,sha,encoded
from check_one_unit import digest,read


def prepare(output):
    source_root=ROOT/'review_treatments/first_run_input_20261101_v1'
    seal=read(source_root/'seal.json')
    assert digest(source_root/'seal.json')=='03cd6fd90d609815c431ea234d9c32f0c10e98287b60d515439f15305b5e4089'
    assert digest(source_root/'sealed_units.jsonl.gz')==seal['sealed_units_sha256']
    assert digest(source_root/'retained_mentions.parquet')==seal['retained_parquet_sha256']
    with gzip.open(source_root/'sealed_units.jsonl.gz','rt',encoding='utf-8') as stream:
        unit=next(json.loads(line) for line in stream if json.loads(line)['page_id']==8385178 and json.loads(line)['processing_revision_id']==1360005623)
    source=Path(unit['source_path']).read_bytes();assert sha(source)==unit['source_sha256']
    rows=pq.read_table(source_root/'retained_mentions.parquet',filters=[('wiki_site','=',unit['wiki_site']),('page_id','=',unit['page_id']),
        ('processing_revision_id','=',unit['processing_revision_id'])],use_threads=False).to_pylist()
    rows.sort(key=lambda row:row['source_row_index'])
    assert len(rows)==unit['retained_count']==90 and {r['source_row_index'] for r in rows}==set(unit['expected_row_indices'])
    assert {r['occurrence_id'] for r in rows}=={mention_id(unit['input_sha256'],i) for i in unit['expected_row_indices']}
    assert all(r['processing_revision_sha256']==unit['source_sha256'] and r['first_run_scope_member'] for r in rows)
    groups=group_mentions([processing_record(r) for r in rows])
    assert not groups['unresolved'] and sum(len(g['members']) for g in groups['groups'])==90
    shard={k:unit[k] for k in ('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')}
    shard['row_indices']=unit['expected_row_indices']
    handoff=dict(manifest=unit,shards=[shard],occurrences=[dict(r,original_row_index=r['source_row_index']) for r in rows],
        decisions=[],pending_evidence=[dict(occurrence_id=r['occurrence_id'],source_row_index=r['source_row_index'],raw_type=r['entity_group'],
        status='PENDING_MATCHING_NOT_RUN',none_decision=False) for r in rows],version='unit-8385178-1360005623-source-pending-v1',prior_version=None,
        input_seal_sha256=digest(source_root/'seal.json'))
    output.mkdir()
    for name,value in [('unit.json',unit),('source_members.json',rows),('groups.json',groups)]:
        (output/name).write_bytes(encoded(value))
    unit_hash=sha(encoded(handoff));seal_unit(output/'sealed_pending',handoff,source,unit_hash)
    assert recover(output/'sealed_pending',unit_hash)['handoff']==handoff
    proof=dict(status='PASS_SECOND_UNIT_SOURCE_AND_GROUPING_ONLY',page_id=unit['page_id'],processing_revision_id=unit['processing_revision_id'],
        occurrences=90,groups=len(groups['groups']),identity_decisions=0,pending=90,none=0,matching_stage='NOT_RUN',
        unit_sha256=unit_hash,sealed_dir=str(output/'sealed_pending'),input_seal_sha256=digest(source_root/'seal.json'),
        output_sha256={str(p.relative_to(output)):digest(p) for p in output.rglob('*') if p.is_file()},publication=False,unit_completed=False)
    (output/'receipt.json').write_bytes(encoded(proof))
    return proof


if __name__=='__main__':
    print(json.dumps(prepare(HERE/'second_unit_0001')))
