"""Execute the existing DATA context validator for seven preserved unresolved source rows."""
import ast
import html
import json
from copy import deepcopy
from pathlib import Path
from run_ready_units import save,pinned
from check_one_unit import read,digest
from decision_revision_hook import content_hash
from route_completion import route_completion

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;OUT=HERE/'context_validation_0001'

def verify():
    builder=ROOT/'runtime_model_inputs_direct_20261101/per_unit_builder_v1/prepare_unit.py'
    tree=ast.parse(builder.read_text(encoding='utf8'))
    basis=next(node for node in ast.walk(tree) if isinstance(node,ast.FunctionDef) and node.name=='basis')
    loop=next(node for node in ast.walk(tree) if isinstance(node,ast.For) and isinstance(node.target,ast.Name) and node.target.id=='member'
        and any(isinstance(value,ast.Constant) and value.value=='PREPARED_SPAN_NOT_VERIFIED' for value in ast.walk(node)))
    code=compile(ast.fix_missing_locations(ast.Module(body=[basis,loop],type_ignores=[])),str(builder),'exec')
    semantics=read(HERE/'route_receipt_generation_0002/receipt.json');updated=deepcopy(semantics)
    OUT.mkdir(exist_ok=True);receipts=[];total=0
    for item in updated['units']:
        required=item['current_completion']['required'].get('context_route',0)
        if not required:continue
        source=item['source_unit'];unit_path=Path(source['unit_directory'])/'unit.private.json'
        assert digest(unit_path)==source['unit_sha256'];unit=read(unit_path)
        matching=HERE/'policy_v2_integration_0001'/('unit_'+str(item['unit']))/'matching_receipt.json'
        policy=pinned(pinned(dict(path=str(matching),sha256=digest(matching)))['policy_verification'])
        paths=[Path(path) for path in policy['protected_source_sha256'] if path.endswith('deferred_routes.json')]
        assert len(paths)==1;deferred_path=paths[0]
        assert digest(deferred_path)==policy['protected_source_sha256'][str(deferred_path)]
        deferred=read(deferred_path);members={row['occurrence_id']:row for row in unit['occurrences']}
        pending={row['occurrence_id'] for row in unit['pending_evidence']};outcomes=[];evidence=[]
        source_path=Path(source['unit_directory'])/'source.private.bin'
        assert digest(source_path)==unit['manifest']['source_sha256'];raw=source_path.read_text(encoding='utf8')
        for group in deferred['unusable_groups']:
            rows=[members[row['occurrence_id']] for row in group['members']]
            environment=dict(json=json,html=html,raw_source=raw,g=dict(members=rows),word=group['name'],
                REV=unit['manifest']['support_revision_id'],unit=dict(source_sha256=unit['manifest']['source_sha256']),usable=[],bad=[])
            exec(code,environment)
            assert environment['usable']==[] and environment['bad']==group['members']
            for row in environment['bad']:
                assert row['occurrence_id'] in pending
                outcomes.append(dict(occurrence_id=row['occurrence_id'],status='UNRESOLVED',
                    method='PINNED_EXISTING_DATA_CONTEXT_VALIDATOR',reason=';'.join(row['reasons'])))
            evidence.append(dict(group=group,original_rows=rows,repeated_context_validation=environment['bad']))
        assert len(outcomes)==required
        folder=OUT/('unit_'+str(item['unit']));folder.mkdir(exist_ok=True)
        artifact=folder/'outcomes_evidence.json';save(artifact,evidence)
        ids={row['occurrence_id'] for row in outcomes};rows=sorted((row for row in unit['occurrences'] if row['occurrence_id'] in ids),key=lambda row:row['occurrence_id'])
        fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
        receipt=dict(status='COMPLETED_UNRESOLVED',execution='EXECUTED',source_scope={key:unit['manifest'][key] for key in fields},
            input_occurrences_sha256=content_hash(rows),outcomes=outcomes,processor=dict(path=str(Path(__file__)),sha256=digest(__file__)),
            reused_validator=dict(path=str(builder),sha256=digest(builder)),
            artifacts=[dict(path=str(artifact),sha256=digest(artifact)),dict(path=str(deferred_path),sha256=digest(deferred_path))],
            new_identity_or_NONE_decisions=False,model_calls=0)
        receipt_path=folder/'context_route.json';save(receipt_path,receipt)
        pin=dict(path=str(receipt_path),sha256=digest(receipt_path));item['route_receipts']['context_route']=pin
        current=route_completion(item['route_receipts'],unit,dict(path=str(matching),sha256=digest(matching)))
        assert 'context_route' in current['verified'] and not current['complete']
        item['current_completion']=current;receipts.append(dict(unit=item['unit'],context_route=pin));total+=len(outcomes)
    assert total==7
    updated['status']='STRUCTURED_TIME_PENDING_EVENT_PARTIAL_CONTEXT_VALIDATION_EXECUTED'
    updated['context_validation']=dict(processed=7,unresolved=7,model_calls=0,receipts=receipts)
    updated['supersedes']=str(HERE/'route_receipt_generation_0002/receipt.json')
    target=HERE/'route_receipt_generation_0003';target.mkdir(exist_ok=True);save(target/'receipt.json',updated)
    save(OUT/'receipt.json',dict(status='PASS_SEVEN_REAL_CONTEXT_VALIDATIONS',executed=7,unresolved=7,
        receipts=receipts,route_generation=dict(path=str(target/'receipt.json'),sha256=digest(target/'receipt.json')),
        model_calls=0,identity_decisions_changed=False,process_completed_units=0))
    print('PASS:7 real context validations executed with the existing validator;7 documented unresolved; no QID/NONE/model changes')

if __name__=='__main__':verify()
