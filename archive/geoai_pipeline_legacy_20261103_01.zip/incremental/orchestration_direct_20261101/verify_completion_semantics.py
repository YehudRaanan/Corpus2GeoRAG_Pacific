"""Re-admit preserved consumer results without treating skipped routes as executed."""
from pathlib import Path
from check_one_unit import read,digest
from run_ready_units import save
from runtime_unit_admission import verified_runtime_unit
from deliver_if_due import deliver_if_due

HERE=Path(__file__).resolve().parent
OUT=HERE/'completion_semantics_audit_v1'

def verify():
    profile=read(HERE/'consumer_unit9_registry194_v1/publication_profile.json')
    refs=[];results=[]
    for number,old in enumerate(profile['references']):
        reference=read(Path(old['path']))
        reference['runtime_verifier_sha256']=digest(HERE/'runtime_unit_admission.py')
        path=OUT/('admission_'+str(number+1)+'.json');save(path,reference)
        refs.append(dict(path=str(path),sha256=digest(path)))
        result=verified_runtime_unit(reference)
        assert result['status']=='pending',result
        assert result['missing_routes']['date_route']['status']=='NOT_RUN'
        assert result['missing_routes']['event_route']['status']=='NOT_RUN'
        results.append(result)
    profile['references']=refs
    path=OUT/'publication_profile.json';save(path,profile)
    before=digest(profile['publication_clock'])
    gate=deliver_if_due(path,digest(path),execute=False)
    assert gate['decision']['new_completed_units']==0 and gate['publication'] is False
    assert digest(profile['publication_clock'])==before
    inventory=read(OUT/'route_inventory.json')
    status=dict(status='CONSUMER_SUCCESS_PROCESS_INCOMPLETE',consumer_materializations=len(results),
        completed_units=0,publication_eligible_units=0,unrun_occurrences=inventory['totals'],
        admissions=results,publication_gate=gate,clock_unchanged=True,publication=False,
        units11_to20='GPU_VERIFIED823_POLICY_REVISION_HANDOFF_PENDING',
        protected_results=[row['unit_result'] for row in inventory['units']],
        code_sha256={str(HERE/name):digest(HERE/name) for name in ('route_completion.py','runtime_unit_admission.py','run_ready_units.py')})
    save(OUT/'current_completion_status.json',status)
    print('PASS: nine consumer receipts remain preserved; zero complete units; cadence WAIT; publication clock unchanged')

if __name__=='__main__':verify()
