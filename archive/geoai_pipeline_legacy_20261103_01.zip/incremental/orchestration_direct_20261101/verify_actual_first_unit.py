"""Read saved artifacts independently; never rerun inference or a producer."""
from pathlib import Path
from hashlib import sha256
import gzip
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
def read(path):return json.loads(Path(path).read_bytes())
def digest(path):return sha256(Path(path).read_bytes()).hexdigest()

def verify():
    run=HERE/'actual_first_unit_registry17/run'
    snapshot=ROOT/'publisher_direct_20261101/orchestration_refresh_0001/actual_first_unit_registry17/snapshot'
    journal=read(run/'runner_state.json')
    assert set(journal['stages'])=={'handoff','projection','materialize','checkpoint'}
    for record in journal['stages'].values():assert digest(record['path'])==record['sha256']
    success=read(snapshot/'private/success_receipt.json')
    verified={**success['source_sha256'],**success['artifact_sha256']}
    for path,expected in verified.items():assert digest(path)==expected,path
    unit=read(run/'sealed_successor/unit.private.json')
    old=read(ROOT/'integration_direct_20261101/real_handoff_0001/sealed_v1/unit.private.json')
    patch=read(ROOT/'runtime_model_inputs_direct_20261101/policy_evaluation_v1/first_unit_policy_v1/decision_patch.json')
    assert unit['occurrences']==old['occurrences']
    occurrences={row['occurrence_id']:row for row in unit['occurrences']}
    decisions={row['occurrence_id']:row for row in unit['decisions']}
    assert len(occurrences)==136 and len(decisions)==46
    assert len(decisions)==len(unit['decisions']) and set(decisions)<=set(occurrences)
    for decision in old['decisions']+patch['decisions']:assert decisions[decision['occurrence_id']]==decision
    assert not any(row['qid'] is None for row in decisions.values())
    graph=read(snapshot/'graph.json')
    expected={row['qid']+'::'+occurrences[key]['entity_group'] for key,row in decisions.items()}
    assert {node['id'] for node in graph['nodes']}==expected and len(expected)==17
    assert len(graph['edges'])==272
    assert len([node for node in graph['nodes'] if node['id'].endswith('::MISC')])==3
    projection=read(run/'projection.json')
    assert projection['count_receipt']['projection']['pending_occurrences']==90
    assert projection['relation_receipt']['projection']['pending_pairs']==[]
    checks=success['consumer_checks']
    assert checks==dict(nodes=17,edges=272,geometries=5,support_identities=136,strength_query_views=260)
    return dict(status='PASS_INDEPENDENT_ACTUAL_FIRST_UNIT_SAVED_READBACK',
        original_occurrences=136,assigned_occurrences=46,pending_occurrences=90,explicit_NONE=0,
        consumer_checks=checks,protected_exact_decisions=30,actual_policy_patch_occurrences=16,
        verified_saved_files=len(verified),success_receipt_sha256=digest(snapshot/'private/success_receipt.json'),
        inference_input_version='first-unit-old-input; NOT alias-enriched',
        proposed_contract=True,local_only=True,publication=False,PR=None,merge_sha=None)

if __name__=='__main__':
    proof=verify()
    destination=HERE/'actual_first_unit_registry17/independent_readback.json'
    if destination.exists():assert read(destination)==proof
    else:destination.write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof))
