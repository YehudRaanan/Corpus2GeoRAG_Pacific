"""Bounded local receipt polling; no GPU, uploader, source fetch or publication."""
import argparse
from datetime import datetime,timezone
from pathlib import Path
import time
import traceback
from reconcile_ready_units import reconcile
from run_ready_units import pinned,save
from check_one_unit import read


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('config');parser.add_argument('sha256');parser.add_argument('--until',required=True)
    parser.add_argument('--interval',type=int,default=60)
    args=parser.parse_args()
    if args.interval<60:raise ValueError('Use at least a minute between local receipt scans')
    deadline=datetime.fromisoformat(args.until)
    if deadline.utcoffset() is None:raise ValueError('Use an explicit timezone for the watch deadline')
    config=pinned(dict(path=args.config,sha256=args.sha256));output=Path(config['output_directory'])
    status_path=output/'watch_status.json';control_path=output/'watch_control.json'
    while datetime.now(timezone.utc)<deadline:
        if control_path.exists() and read(control_path).get('paused'):
            save(status_path,dict(status='PAUSED',observed_utc=datetime.now(timezone.utc).isoformat()))
        else:
            try:
                result=reconcile(args.config,args.sha256)
                states={key:value['status'] for key,value in result['units'].items()}
                status=dict(status='WATCH_PASS_COMPLETE',observed_utc=datetime.now(timezone.utc).isoformat(),units=states,cursor=result['cursor'],publication=False)
                save(status_path,status)
                print(status,flush=True)
                if states and all(value in {'CANONICAL_POLICY_APPLIED','CAPACITY_BLOCKED','CAPACITY_PENDING'} for value in states.values()):
                    break  # Consumer/source waits remain explicit in the saved per-unit results.
            except Exception as error:
                save(status_path,dict(status='STOPPED_ERROR',action='reconcile available local receipts',reason=str(error),traceback=traceback.format_exc(),observed_utc=datetime.now(timezone.utc).isoformat()))
                raise
        time.sleep(min(args.interval,max(0,(deadline-datetime.now(timezone.utc)).total_seconds())))
