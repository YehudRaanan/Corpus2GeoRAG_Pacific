"""Fixed CPU-only completion verifier for existing cadence; no clock/state writes."""
import hashlib,json
from pathlib import Path

REQUIRED_STAGES=('input','grouping','exact','matching','approved_decisions','handoff','counts','relations','full_geometry','components','date_route','event_route','context_route')
_CACHE={}
def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def verify_frontier(reference):
 """Verify shared immutable evidence once per module instance; changes invalidate the cache."""
 if reference['cpu_verifier_sha256']!=sha(__file__):raise ValueError('Fixed CPU verifier changed')
 ref=reference['completion'];cached=_CACHE.get(ref['sha256'])
 if cached and all((Path(p).stat().st_size,Path(p).stat().st_mtime_ns)==v for p,v in cached[1].items()):return cached[0]
 pins={}
 def pin(d):
  if sha(d['path'])!=d['sha256']:raise ValueError('CPU completion artifact changed: '+d['path'])
  p=Path(d['path']);pins[str(p)]=(p.stat().st_size,p.stat().st_mtime_ns);return read(p)
 def nested(value):
  if isinstance(value,dict):
   if {'path','sha256'}<=value.keys():
    if sha(value['path'])!=value['sha256']:raise ValueError('CPU evidence reference changed')
    p=Path(value['path']);pins[str(p)]=(p.stat().st_size,p.stat().st_mtime_ns)
   else:
    for item in value.values():nested(item)
  elif isinstance(value,list):
   for item in value:nested(item)
 completion=pin(ref)
 if completion['status']=='VERIFIED_CANONICAL_ADOPTION_OF_EXECUTED_FROZEN90_ROUTES':
  frontier_ref=completion['frontier'];eligibility_ref=completion['eligibility'];consumer_ref=completion['consumer']
 elif completion['status']=='VERIFIED_DOWNSTREAM_FRONTIER_WITH_E2_ADMISSION':
  admission=pin(completion['completion_admission']);frontier_ref=completion['frontier'];eligibility_ref=admission['eligibility'];consumer_ref=pin(completion['stages']['consumer'])['result_receipt']
 else:raise ValueError('Consumer/CPU success alone is not complete route admission')
 frontier=pin(frontier_ref);eligibility=pin(eligibility_ref);consumer=pin(consumer_ref);nested(consumer);nested(eligibility)
 if frontier['status']!='READY_CPU_ONLY' or consumer['CPU_units']!=frontier['active_units']:raise ValueError('Consumer/frozen unit scope differs')
 heads={tuple(row['scope'][1:4]):row for row in frontier['frontier']};records={}
 rows=eligibility.get('eligible_units',eligibility.get('units',[]))
 if not rows:raise ValueError('Required route receipts missing')
 for unit in rows:
  if 'unit_key' in unit:
   key=tuple(unit['unit_key']);finished=unit['all_required_stages_executed'] is True;receipts=unit['receipts']
  else:
   scope=unit['source_scope'];key=(scope['wiki_site'],scope['page_id'],scope['support_revision_id'])
   finished=unit['full_attempted_stage_evidence'] is True and unit['route_verification']['complete'] is True and not unit['route_verification']['missing'];receipts=[unit['CPU_receipt'],*unit['routes'].values()]
  if not finished:raise ValueError('Required routes have not run')
  row=heads[key]
  if unit['decision_version']!=row['active_head']['version'] or key in records:raise ValueError('Wrong/duplicate completed unit version')
  if not receipts:raise ValueError('Missing persisted unit receipts')
  nested(receipts);s=row['scope'];scope=dict(zip(('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version'),s))
  records[key]=dict(status='sealed',receipt=dict(scope=scope,decision_version=unit['decision_version'],unit_sha256=row['active_head']['sha256']),
   stage_chain=dict(status='PASS_ONE_UNIT_RECEIPT_CHAIN',page_id=key[1],processing_revision_id=key[2],
    stages={name:dict(status='COMPLETED_PARTIAL',version=unit['decision_version']) for name in REQUIRED_STAGES},
    receipt_sha256={ref['path']:ref['sha256'],eligibility_ref['path']:eligibility_ref['sha256'],consumer_ref['path']:consumer_ref['sha256']},
    verified_artifact_sha256={frontier_ref['path']:frontier_ref['sha256']}))
 _CACHE[ref['sha256']]=(records,pins);return records

def verified_cpu_unit(reference):
 if reference.get('kind')!='cpu_frontier_unit':raise ValueError('Fixed CPU admission kind required')
 records=verify_frontier(reference);key=tuple(reference['unit_key'])
 if key not in records:raise ValueError('Requested logical unit lacks complete evidence')
 return records[key]
