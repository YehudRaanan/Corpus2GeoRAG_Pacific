"""Current full geometry receipt -> fresh components -> local refresh/cadence confirmation."""
import json
import sys
from copy import deepcopy
from datetime import datetime,timedelta,timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PRODUCER = ROOT/'publisher_direct_20261101/component_materializer_0001'
sys.path.insert(0,str(PRODUCER))
from consume_full_geometry import bind_full_geometry
from materialize_components import materialize_components
from refresh_full_chain_checkpoint import refresh_checkpoint,initialize,CADENCE
from decision_revision_hook import require_current
from check_one_unit import read,digest


def materialize_then_refresh(components_dir,snapshot_dir,cadence_state,*,component_inputs,checkpoint_inputs):
    components = materialize_components(components_dir,**component_inputs)
    manifest_path = Path(components['receipt_path']).parent/'refresh_inputs.json'
    checkpoint = refresh_checkpoint(snapshot_dir,cadence_state,manifest_path=manifest_path,
                                    manifest_sha256=digest(manifest_path),**checkpoint_inputs)
    return dict(components=components,checkpoint=checkpoint)


def check(audit):
    context_path = HERE/'count_relation_chain_0001/result.json'
    assert digest(context_path)==read(context_path.parent/'verification.json')['result_sha256']
    context = read(context_path)['before']
    identity_state = {tuple(row['scope']):versions for row,versions in zip(context['count_receipt']['decision_binding'],context['units'])}
    geo_root = HERE/'full_geometry_chain_0001'
    geo_proof = read(geo_root/'verification.json')
    assert digest(geo_root/'result.json')==geo_proof['result_sha256']
    geo_entry = read(geo_root/'result.json')['components'][0]
    geo_path = Path(geo_entry['receipt_path'])
    assert digest(geo_path)==geo_entry['receipt_sha256']
    geometry = read(geo_path)
    require_current(geometry,identity_state)
    raw_geo_path = geo_path.parent/'model/receipt.json'
    adapted = bind_full_geometry(raw_geo_path,digest(raw_geo_path),identity_state=identity_state,
                count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'])
    # Existing adapter verifies the raw merger. Our emitted materializer receipt is already field-compatible.
    for key in ('scope_kind','scope_qids','geography_path','geoparquet_path','artifact_sha256','source_binding'):
        assert geometry['projection'][key]==adapted['projection'][key]
    native = ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    source_files = [context_path,context_path.parent/'verification.json',geo_path,raw_geo_path,
                    geo_root/'result.json',geo_root/'verification.json',native,
                    ROOT/'integration_direct_20261101/real_handoff_0001/sealed_v1/unit.private.json']
    protected = {str(p):digest(p) for p in source_files+[PRODUCER/'materialize_components.py',PRODUCER/'consume_full_geometry.py']}
    component_inputs = dict(identity_state=identity_state,count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'],
        geometry_receipt=geometry,native_registry=dict(path=str(native),sha256='1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4'),
        source_receipts=[dict(path=str(p),sha256=digest(p)) for p in source_files],
        consumer_root=ROOT/'publisher_direct_20261101/proposed_strength_0001/consumer')
    namespace = ROOT/'publisher_direct_20261101/orchestration_refresh_0001'
    invalid = deepcopy(component_inputs)
    invalid['geometry_receipt']['decision_binding'][0]['decision_version']='STALE_NOT_ACCEPTED'
    try:materialize_components(namespace/'stale_own_geometry',**invalid)
    except ValueError:pass
    else:raise AssertionError('Stale new geometry receipt accepted')
    assert not (namespace/'stale_own_geometry').exists()
    state_path = audit/'cadence_state.json'
    start = datetime(2026,11,1,20,tzinfo=timezone.utc)
    initialize(state_path,start,['input','grouping','exact','handoff','counts','consumer_snapshot'])
    before = digest(state_path)
    references = read(next((CADENCE/'simulation_0001').glob('attempt-*.json')))['verified_references']
    checkpoint_inputs = dict(previous_snapshot=dict(path=str(ROOT/'publisher_direct_20261101/proposed_strength_0001/snapshot_0007_retry_0001'),
        receipt_sha256='defdbb6d7bc327fc3c82f188a343f4855def9db4f3c4e00a3da749e72eea3157'),
        references=references,decision_time=start,completed_at=start+timedelta(minutes=2),final_flush=True)
    result = materialize_then_refresh(namespace/'components_0003',namespace/'snapshot_0003',state_path,
                                      component_inputs=component_inputs,checkpoint_inputs=checkpoint_inputs)
    materialized = read(Path(result['components']['receipt_path']))
    assert materialized['new_materialization'] and materialized['geometry_projection_sha256']==geometry['projection_sha256']
    assert materialized['decision_binding']==geometry['decision_binding'] and materialized['inputs_sha256'][str(geo_path)]==digest(geo_path)
    assert result['checkpoint']['state_before_confirm_sha256']==before
    assert result['checkpoint']['refresh_result']['consumer_checks']==dict(nodes=10,edges=90,geometries=5,support_identities=45,strength_query_views=82)
    assert read(state_path)['last_successful_checkpoint']==(start+timedelta(minutes=2)).isoformat()
    refresh_args = result['checkpoint']['refresh_parameters']
    manifest_path = Path(result['components']['receipt_path']).parent/'refresh_inputs.json'
    after = digest(state_path)
    assert refresh_checkpoint(namespace/'snapshot_0003',state_path,manifest_path=manifest_path,manifest_sha256=digest(manifest_path),
               **checkpoint_inputs,previous_result=result['checkpoint']) is result['checkpoint']
    assert digest(state_path)==after
    for role,filename in [('geography_path','geography.json.gz'),('geoparquet_path','geometries.parquet')]:
        assert digest(Path(geometry['projection'][role]))==digest(namespace/'components_0003/model'/filename)==digest(namespace/'snapshot_0003/model'/filename)
    assert all(digest(Path(p))==h for p,h in protected.items())
    return dict(status='PASS_OWN_FULL_GEO_FRESH_MATERIALIZATION_REFRESH',result=result,protected_sha256=protected,
                full_geometry_receipt=str(geo_path),full_geometry_receipt_sha256=digest(geo_path),
                source_adapter_reused=True,stale_rejected=True,shapes_unchanged=True,checks=7,actual_model_decisions=False,publication=False)


if __name__=='__main__':
    audit = HERE/'own_geo_checkpoint_0001';audit.mkdir()
    result = check(audit)
    (audit/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    proof = dict(status=result['status'],checks=result['checks'],code_sha256=digest(Path(__file__)),
                 result_sha256=digest(audit/'result.json'),component_receipt_sha256=result['result']['components']['receipt_sha256'],
                 success_receipt_sha256=result['result']['checkpoint']['refresh_result']['receipt_sha256'],publication=False)
    (audit/'verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof))
