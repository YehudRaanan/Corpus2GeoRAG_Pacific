"""Retained-component-only cached candidates for unit two. No policy, inference, or new source request."""
import gzip,json,sys
from pathlib import Path
from collections import defaultdict,Counter
import pyarrow.parquet as pq

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'integration_direct_20261101'))
from build_unit_candidate_ledger import raw_links,template_targets,policy,decision,digest,POLICY,PILOT


def run():
    directory=HERE/'second_unit_0001';unit=json.loads((directory/'unit.json').read_text(encoding='utf-8'))
    raw_path=Path(unit['source_path']);assert digest(raw_path)==unit['source_sha256']
    raw=raw_path.read_text(encoding='utf-8');view=policy.build_view(raw)
    assert digest(POLICY)==json.loads((ROOT/'integration_direct_20261101/candidate_cache_0002/ledger.json').read_text(encoding='utf-8'))['policy_code_sha256']
    links=[dict(row,component=decision(view,row)) for row in raw_links(raw)]
    templates=[dict(row,component=decision(view,row)) for row in template_targets(raw,include_unsupported=True)]
    by_title=defaultdict(list)
    for row in links:by_title[row['target_title']].append(row)
    retained={t for t,rows in by_title.items() if any(r['component']['status']=='IN' for r in rows)}
    mappings=defaultdict(list)
    files=[PILOT/'Data/external/hundred_page_pilot_20261028/collection_titles_final/title_qid_mapping.parquet',
           PILOT/'Data/external/hundred_page_pilot_20261028/template_name_pilot_20261029/recovery_100_v2/title_qid_mapping.parquet']
    protected={str(POLICY):digest(POLICY),str(raw_path):digest(raw_path),str(directory/'groups.json'):digest(directory/'groups.json')}
    for path in files:
        protected[str(path)]=digest(path)
        for row in pq.read_table(path,filters=[('target_title','in',sorted(retained))],use_threads=False).to_pylist():
            if isinstance(row.get('qid'),str) and row['qid'].startswith('Q'):
                mappings[row['target_title']].append(dict(cache_file=str(path),assertion=row))
    needed={m['assertion']['qid'] for rows in mappings.values() for m in rows}
    metadata={};meta=Path(r'C:\Users\User\.cache\geoai_bigquery_20261018/entity_metadata.json.gz')
    protected[str(meta)]=digest(meta)
    import ijson
    with gzip.open(meta,'rb') as stream:
        for qid,record in ijson.kvitems(stream,''):
            title=record.get('sitelinks',{}).get('enwiki',{}).get('title')
            if title in retained:
                mappings[title].append(dict(cache_file=str(meta),assertion=dict(target_title=title,qid=qid,
                    qid_status='CACHED_EXACT_ENWIKI_SITELINK',mapping_temporal_basis='CACHED_CURRENT_TITLE_RESOLUTION')))
            if qid in needed or title in retained:
                metadata[qid]=dict(cache_file=str(meta),assertion=dict(qid=qid,label=record.get('label'),aliases=record.get('aliases',[]),
                    native_types=record.get('direct_types',[]),parents=record.get('parents',[]),metadata_revision=record.get('revision'),
                    metadata_modified=record.get('modified'),metadata_source=record.get('reference_source'),
                    metadata_temporal_basis='CACHED_METADATA_SEPARATE_FROM_PROCESSING_REVISION',metadata_path=str(meta)))
    targets=[];active=set()
    for title,rows in sorted(by_title.items()):
        assertions=mappings.get(title,[]) if title in retained else []
        qids=sorted({r['assertion']['qid'] for r in assertions});active.update(qids)
        targets.append(dict(target_title=title,source_links=rows,included_from_relevant_component=title in retained,
            cached_title_assertions=assertions,candidate_qids=qids,mapping_conflict=len(qids)>1,
            cache_status='RESOLVED_CACHED_MAPPING' if qids else 'UNRESOLVED' if title in retained else 'EXCLUDED_COMPONENT_ONLY'))
    payload=dict(source_unit=unit,source_temporal_basis='VERIFIED_PROCESSING_REVISION_NOT_EXTRACTION_REVISION',policy_code_sha256=digest(POLICY),
        all_raw_targets_with_inclusion_evidence=targets,template_evidence=templates,
        active_cached_candidates=[dict(qid=q,cached_metadata=[metadata[q]] if q in metadata else [],type_policy_applied=False,accepted_identity=False) for q in sorted(active)],
        unresolved_relevant_targets=[r['target_title'] for r in targets if r['included_from_relevant_component'] and not r['candidate_qids']],
        completeness='NOT_ESTABLISHED; unsupported templates and uncached/unlinked targets remain unknown, not NONE',
        original_groups=str(directory/'groups.json'),source_members=str(directory/'source_members.json'))
    output=directory/'candidate_inputs_0001';output.mkdir()
    (output/'ledger.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    assert all(digest(Path(p))==h for p,h in protected.items())
    proof=dict(status='PASS_SECOND_UNIT_RETAINED_CACHED_CANDIDATES',page_id=unit['page_id'],processing_revision_id=unit['processing_revision_id'],
        raw_links=len(links),retained_link_occurrences=sum(r['component']['status']=='IN' for r in links),retained_targets=len(retained),
        candidate_qids=len(active),unresolved_targets=payload['unresolved_relevant_targets'],mapping_conflicts=sum(r['mapping_conflict'] for r in targets),
        template_records=len(templates),template_component_counts=dict(Counter(r['component']['status'] for r in templates)),
        template_candidates_applied=False,identity_decisions=0,model_calls=0,external_calls=0,protected_sha256=protected,
        ledger_sha256=digest(output/'ledger.json'),code_sha256=digest(Path(__file__)),publication=False)
    (output/'receipt.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in proof.items() if k!='protected_sha256'}))


if __name__=='__main__':run()
