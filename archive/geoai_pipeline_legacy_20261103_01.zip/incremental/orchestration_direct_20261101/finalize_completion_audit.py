"""Save the corrected current status while keeping earlier consumer evidence immutable."""
import json
from datetime import datetime,timezone
from pathlib import Path
from check_one_unit import read,digest
from run_ready_units import save
from reconcile_ready_units import discover

HERE=Path(__file__).resolve().parent
OUT=HERE/'completion_semantics_audit_v1'
TASK=Path('C:/Users/User/Documents/Codex/2026-11-01/task')
GPU=Path('C:/Users/User/Documents/Codex/2026-11-01/task-2')

def preserve(path):
    target=OUT/((path.parent.name+'_' if path.name=='state.json' else '')+path.name+'.before')
    if not target.exists():target.write_bytes(path.read_bytes())

def stamp(path):return datetime.fromtimestamp(Path(path).stat().st_mtime,timezone.utc).isoformat()

def main():
    status=read(OUT/'current_completion_status.json');inventory=read(OUT/'route_inventory.json')
    config=read(HERE/'reconciliation_units11_20_config.json')
    # Discovery only: no old-policy evaluation while its owner prepares the correction.
    available=discover(config)
    batch_path=GPU/'units11_20_ready823_results_v1/batch_result_receipt.json';batch=read(batch_path)
    for row in batch['units']:
        assert digest(row['proposal_path'])==row['sha256']
        receipt=read(Path(row['receipt_path']))
        assert receipt['records']==row['records'] and receipt['sha256']==row['sha256']
    assert sum(row['records'] for row in batch['units'])==823
    save(OUT/'gpu_discovery.json',dict(status='VERIFIED_DISCOVERY_POLICY_HANDOFF_PENDING',complete_input_matches=len(available),
        matches=[candidate for choices in available.values() for candidate in choices.values()],batch_receipt=dict(path=str(batch_path),sha256=digest(batch_path)),
        capacity_pending={'unit6':'CAPACITY_BLOCKED','unit16':70,'unit19':63},policy_applied=False))
    control=HERE/'reconciliation_units11_20_v1/watch_control.json'
    save(control,dict(paused=True,reason='Await versioned corrected candidate-coverage/tie policy handoff; GPU823 verified; do not apply prior wrapper'))
    current=HERE/'reconciliation_first10_v1/CURRENT_STATUS.json';preserve(current)
    value=read(current);value.update(completed_units=0,consumer_materializations=9,status=status['status'],
        completion_correction=dict(path=str(OUT/'current_completion_status.json'),sha256=digest(OUT/'current_completion_status.json')),
        units11_to20='GPU_VERIFIED823_CORRECTED_POLICY_HANDOFF_PENDING')
    save(current,value)
    for name in ('reconciliation_first10_v1','reconciliation_units11_20_v1'):
        path=HERE/name/'state.json';preserve(path)
        state=read(path);state.update(process_completed_units=0,completed_consumer_units=9,
            completion_correction=value['completion_correction'])
        save(path,state)
    paragraphs='''Completion-semantics correction, 2026-11-02 UTC

Nine consumer materializations succeeded for units 1-5 and 7-10. Full-process completions and publication-eligible units are ZERO. The missing dedicated routes affect DATE176 and Event25 across all nine units; seven context skips lack a verified terminal route result. One Event occurrence ran ordinary matching, which does not execute Event expansion. Old consumer receipts and their 1010 IDs/446 assigned/564 pending are preserved as historical evidence; the former nine-complete claim is superseded. These identity counts are awaiting the separately owned candidate-coverage/NONE policy correction.

The corrected runtime admission checks require actual version-bound route outputs; merely DEFERRED is not terminal unresolved. current_completion_status.json verifies all nine references return pending and the normal cadence gate counts zero, WAIT, with no publication-clock change. No package, PR or merge ran. Hour AND100 genuinely complete units remains binding; no artificial final flush.

Units11-20 were specifically authorized at02:14:56UTC, and all823 supported model questions are now locally SHA256 verified. This does not mean policy acceptance or process completion. Units16/19 still have70/63 capacity-pending questions; unit6 remains capacity-blocked. Discovery found eight full-input matches; partial16/19 remain explicit. Policy application/watcher is paused until E2 releases the corrected coverage and approved tie implementation. No GPU, uploader or source calls were made by this session.

Smallest independent missing tasks: DATE occurrence/context processing adapter with real persisted per-ID outcomes; real Event-route adapter using approved anchors/predicates and LOC scope; context-validation outcome receipts for seven missing-context IDs. Existing Event scope code is synthetic-only. R6 fixes approved Event anchors -> direct entities -> second-hop LOC only; no third hop, geography only LOC. Production anchor/predicate/mask bindings are not established by the fixture. No new date interpretation policy or Event population choice is made here.

Evidence: completion_semantics_audit_v1/route_inventory.json, current_completion_status.json, gpu_discovery.json. Full consumer remains204 typed nodes/5994 relation views/5 geometries, with194 verified source QIDs and no pending native-source pairs. These structural successes do not complete the unrun routes.
'''
    for name in ('MORNING_RUN_SUMMARY_20261102.md','AUTOMATIC_QUEUE.md'):
        path=HERE/name;preserve(path);path.write_text(paragraphs,encoding='utf-8')
    additions='\n\n### Superseding completion-semantics audit — 2026-11-02 UTC\n\n'+paragraphs+'\n'
    backups=[]
    for name in ('GEOAI_DEVELOPMENT_PLAN.md','GEOAI_RUNTIME_BATCH_PLAN.md'):
        path=TASK/name;preserve(path);before=path.read_bytes()
        if '### Superseding completion-semantics audit' not in before.decode('utf-8'):
            with path.open('ab') as stream:stream.write(additions.encode('utf-8'))
        assert path.read_bytes().startswith(before)
        backups.append(dict(path=str(path),before_sha256=digest(OUT/(path.name+'.before')),after_sha256=digest(path)))
    timeline=[]
    for row in inventory['units']:
        result=read(Path(row['unit_result']['path']));stages=result['stages']
        matching=read(Path(stages['matching']['path']));receipt=read(Path(matching['receipt']['path']))
        registry=Path(result['native_registry']['path']);native_receipt=registry.parent/'completion_receipt.json'
        timeline.append(dict(page=row['page'],revision=row['revision'],policy_receipt_mtime_utc=stamp(receipt['policy_verification']['path']),
            handoff_receipt_mtime_utc=stamp(stages['handoff']['path']),
            registry_receipt_mtime_utc=stamp(native_receipt) if native_receipt.exists() else None,
            consumer_result_mtime_utc=stamp(row['unit_result']['path'])))
    unit9=read(GPU/'unit9_full131_results_v1/local_verification_receipt.json')
    timing=dict(method='Artifact mtimes are persisted-stage proxies, not measured CPU/kernel durations; intervals include scheduling, checks and waiting.',
        first_nine=timeline,unit9_local_verified_utc=unit9['verified_utc'],
        upload_authorization_hold=dict(remote_absence_verified_utc='2026-11-02T01:04:06Z',specific_approval_utc='2026-11-02T02:14:56Z',observed_interval_seconds=4250,note='70m50s observed hold, approximately71minutes; overlaps other authorized work, not GPU compute'),
        batch11_20=dict(controller_start_utc=batch['controller_start_utc'],completion_observed_utc=batch['completion_observed_utc'],controller_elapsed_seconds=1348,supported_questions=823,note='22m28s controller window including execution overhead; not individual GPU kernel time'),
        remaining_delays=['Required DATE/Event route implementation not executed','Policy coverage and tie correction handoff pending','Source generations are serialized through RELATIONS after rate-limit backoff'],
        scheduling_fix='Receipt-count dictionary/list compatibility and per-unit discovery are ready; policy watcher intentionally paused until corrected handoff')
    save(OUT/'timing_breakdown.json',timing)
    save(OUT/'status_update_receipt.json',dict(plans=backups,completion_status_sha256=digest(OUT/'current_completion_status.json'),gpu_discovery_sha256=digest(OUT/'gpu_discovery.json'),timing_sha256=digest(OUT/'timing_breakdown.json'),old_receipts_preserved=True))
    print(json.dumps(dict(process_complete=0,consumer_success=9,gpu_verified=823,full_input_matches=len(available),policy_applied=False)))

if __name__=='__main__':main()
