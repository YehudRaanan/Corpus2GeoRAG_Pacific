"""First sealed real unit copied privately; only the version is synthetically revised."""
import json
import sys
from copy import deepcopy
from pathlib import Path
from shutil import copyfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT / 'counts_direct_20261101'), str(ROOT / 'durable_units_direct_20261101')]
from check_one_unit import read, digest
from durable_unit import recover, encoded, sha, seal_unit
from decision_revision_hook import refresh_for_decision, require_current
from real_counts_revision import recompute_counts


def check(output):
    original = ROOT / 'integration_direct_20261101/real_handoff_0001'
    receipt = read(original / 'receipt.json')
    protected = {str(original / 'receipt.json'): '67f7867fa76e8f411f444c3e0ab242212717cf764baf4e4b2687475d33355b7d'}
    protected.update(receipt['protected_sha256'])
    protected.update({str(original / p): h for p, h in receipt['output_sha256'].items()})
    protected[str(ROOT / 'counts_direct_20261101/real_counts.py')] = digest(ROOT / 'counts_direct_20261101/real_counts.py')
    protected[str(ROOT / 'counts_direct_20261101/pair_counts.py')] = '6efcce0b21f8133b810aa616ab70ecb04c543f3d89db4ef7f197a891d44ec8ea'
    assert all(digest(Path(p)) == h for p, h in protected.items())
    sandbox = output / 'copied_v1'
    sandbox.mkdir()
    for name in ('seal.json', 'unit.private.json', 'source.private.bin'):
        copyfile(original / 'sealed_v1' / name, sandbox / name)
    loaded = recover(sandbox, receipt['pinned_unit_sha256'])
    first, source = loaded['handoff'], (sandbox / 'source.private.bin').read_bytes()
    baseline_path = ROOT / 'counts_direct_20261101/real_counts_20261101T202248289937Z/counts.json'
    assert digest(baseline_path) == '6fde44762c0418a98f6105a1e6b8e8c1eca20d2c767e9edc1c3e39edaf02b150'
    baseline = read(baseline_path)
    state, history, calls = {}, [], []
    def count(current, previous, count_history):
        calls.append(True)
        return recompute_counts(current, previous, count_history)
    before = refresh_for_decision(state, first, source, None, history, count)
    for field in ('identity_counts', 'typed_counts', 'pairs', 'retained_occurrences', 'accepted_occurrences', 'pending_occurrences', 'history_versions'):
        assert before['projection'][field] == baseline[field], field
    assert refresh_for_decision(state, first, source, before, history, count) is before and len(calls) == 1
    revised = deepcopy(first)
    revised.update(version='SANDBOX_VERSION_ONLY_v2', prior_version=first['version'])
    new_hash = sha(encoded(revised))
    seal_unit(output / 'synthetic_v2', revised, source, new_hash, prior_history=[first])
    revised = recover(output / 'synthetic_v2', new_hash, prior_history=[first])['handoff']
    after = refresh_for_decision(state, revised, source, before, history, count)
    assert len(calls) == 2 and after['stale_previous_projection_rejected']
    assert after['projection']['history_versions'] == 2
    assert before['projection']['pairs'] == after['projection']['pairs'] and len(after['projection']['pairs']) == 45
    assert len(history) == 2
    assert refresh_for_decision(state, revised, source, after, history, count) is after and len(calls) == 2
    try:
        require_current(before, state)
    except ValueError:
        pass
    else:
        raise AssertionError('Old count projection accepted')
    require_current(after, state)
    assert len(state) == 1
    versions = next(iter(state.values()))
    assert versions == [first, revised] and first['occurrences'] == revised['occurrences']
    assert first['decisions'] == revised['decisions'] and first['pending_evidence'] == revised['pending_evidence']
    assert all(digest(Path(p)) == h for p, h in protected.items())
    return dict(status='PASS_SANDBOX_REAL_COUNTS_REVISION', before=before, after=after,
                count_calls=len(calls), count_history=history, units=versions,
                protected_sha256=protected, actual_QID_changes=False, consumer_export=False)


if __name__ == '__main__':
    output = HERE / 'real_counts_revision_0001'
    output.mkdir()
    result = check(output)
    (output / 'result.json').write_bytes(encoded(result))
    proof = dict(status=result['status'], count_calls=result['count_calls'], checks=8,
                 result_sha256=digest(output / 'result.json'), code_sha256=digest(HERE / 'real_counts_revision.py'),
                 hook_sha256=digest(HERE / 'decision_revision_hook.py'), test_sha256=digest(Path(__file__)))
    (output / 'verification.json').write_bytes(encoded(proof))
    print(json.dumps(proof))
