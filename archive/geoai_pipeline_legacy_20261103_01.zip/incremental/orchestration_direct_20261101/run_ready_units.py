"""Finite CPU loop over pinned approved decision jobs; save each unit before any upload.

No inference, thresholds, publication or background polling. Matching completion is external.
"""
from pathlib import Path
import argparse
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'runtime_handoff_0001'))
from decision_handoff import build_handoff
from refresh_decision_evidence import refresh_evidence
from run_approved_unit import pinned,context_state,context_json
from advance_combined_geometry import advance_combined
from check_one_unit import read,digest
from decision_revision_hook import content_hash
from durable_unit import recover
from cadence_caller import save
from runtime_receipts import verify_matching,accepted_sources
from route_completion import route_completion,ROUTES


def own_directory(value):
    path=Path(value).resolve()
    if not path.is_relative_to(HERE):raise ValueError('CPU results must remain in owned orchestration')
    path.mkdir(parents=True,exist_ok=True)
    return path


def run_ready_units(manifest_path,manifest_sha256,stop_after_result=False):
    manifest=pinned(dict(path=str(manifest_path),sha256=manifest_sha256))
    directory=own_directory(manifest['output_directory']);index_path=directory/'index.json'
    configuration={key:manifest[key] for key in ['initial_projection','native_registry','full_geometry_baseline','geometry_bindings','fragment_artifact_root']}
    configuration.update({key:manifest[key] for key in ('consumer_root','source_refresher') if key in manifest})
    configuration['caller_code_sha256']={str(path):digest(path) for path in (Path(__file__),HERE/'runtime_receipts.py')}
    configuration_hash=content_hash(configuration)
    if index_path.exists():
        index=read(index_path)
        if index['configuration_sha256']!=configuration_hash:raise ValueError('Resume configuration changed')
    else:
        pinned(manifest['initial_projection'])
        index=dict(configuration_sha256=configuration_hash,projection=manifest['initial_projection'],jobs={})
        save(index_path,index)
    bindings=pinned(manifest['geometry_bindings'])
    baseline=pinned(manifest['full_geometry_baseline'])
    if digest(manifest['native_registry']['path'])!=manifest['native_registry']['sha256']:raise ValueError('Native registry changed')
    for descriptor in manifest['jobs']:
        job=pinned(descriptor);job_hash=content_hash(job)
        if job_hash in index['jobs']:
            result=pinned(index['jobs'][job_hash])
            for path,expected in result['verified_artifact_sha256'].items():
                if digest(path)!=expected:raise ValueError('Completed per-unit artifact changed')
            continue
        output=own_directory(job['output_directory']);result_path=output/'unit_result.json'
        if result_path.exists():
            result=read(result_path)
            if result['job_sha256']!=job_hash:raise ValueError('Result directory belongs to another job')
            if result['previous_projection']!=index['projection']:raise ValueError('Interrupted result belongs to another frontier')
            for path,expected in result['verified_artifact_sha256'].items():
                if digest(path)!=expected:raise ValueError('Interrupted result artifact changed')
        else:
            patch=pinned(job['approved_decisions']);current=job['current_unit'];history=[]
            stage_path=output/'stage_receipts.json'
            stages=read(stage_path) if stage_path.exists() else dict(job_sha256=job_hash,stages={})
            if stages['job_sha256']!=job_hash:raise ValueError('Stage journal belongs to another job')
            def stage(name,operation):
                if name in stages['stages']:return pinned(stages['stages'][name])
                value=operation();path=output/(name+'.json');save(path,value)
                stages['stages'][name]=dict(path=str(path),sha256=digest(path));save(stage_path,stages)
                return value
            matching=stage('matching',lambda:verify_matching(job['matching_receipt'],job['approved_decisions'],
                read(Path(current['unit_directory'])/'unit.private.json')['manifest'])) if job.get('matching_receipt') else dict(status='EXTERNAL_NOT_CERTIFIED')
            for previous in current.get('prior_history',[]):
                history.append(recover(previous['unit_directory'],previous['unit_sha256'],history)['handoff'])
            arguments=dict(current_unit_sha256=current['unit_sha256'],current_sealed_dir=current['unit_directory'],
                prior_history=history,supplied_decisions=patch['decisions'],decision_version=patch['decision_version'])
            if job['mode']=='ADD_PENDING':built=stage('handoff',lambda:build_handoff(output/'sealed',**arguments))
            elif job['mode']=='EVIDENCE_ONLY':
                built=stage('handoff',lambda:refresh_evidence(output/'sealed',current_directory=current['unit_directory'],current_sha256=current['unit_sha256'],prior_history=history,patch=patch))
            elif job['mode']=='REPLAY_CURRENT':
                def current_handoff():
                    loaded=recover(current['unit_directory'],current['unit_sha256'],history)
                    if loaded['handoff']['version']!=patch['decision_version']:raise ValueError('Replay decision artifact version differs')
                    return dict(sealed_dir=current['unit_directory'],unit_sha256=current['unit_sha256'],handoff=loaded['handoff'],prior_history=history)
                built=stage('handoff',current_handoff)
            else:raise ValueError('Unknown explicit decision job mode')
            previous=context_state(pinned(index['projection']))
            source=(Path(built['sealed_dir'])/'source.private.bin').read_bytes()
            qids={row['qid'] for row in built['handoff']['decisions'] if row['qid'] is not None}
            registry=stage('sources',lambda:accepted_sources(manifest.get('source_refresher'),output/'sources',index.get('native_registry',manifest['native_registry']),qids))
            projection_arguments=dict(native_path=registry['path'],native_hash=registry['sha256'],
                geometry_bindings=bindings,geometry_bindings_sha256=content_hash(bindings),baseline=baseline,
                fragment_artifact_root=manifest['fragment_artifact_root'])
            def project():
                context=previous
                fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
                scope=tuple(built['handoff']['manifest'][field] for field in fields)
                # A new unit's successor requires its real sealed source lineage, just as E2 recovery does.
                if scope not in context['count_state']:
                    for number,earlier in enumerate(built['prior_history']):
                        context=advance_combined(output/'source_admission'/str(number),context,earlier,source,**projection_arguments)
                return context_json(advance_combined(output/'full_geometry',context,built['handoff'],source,**projection_arguments))
            context=context_state(stage('projection',project))
            projection=output/'projection.json'  # The projection stage already saved and pinned this exact file.
            for name in ('count_receipt','relation_receipt'):
                stage(name,lambda name=name:context[name])
            stage('full_geometry_receipt',lambda:context['full_geometry']['receipt'])
            artifacts=[projection,Path(built['sealed_dir'])/'seal.json',Path(built['sealed_dir'])/'unit.private.json',
                Path(built['sealed_dir'])/'source.private.bin',Path(context['full_geometry']['receipt_path']),Path(job['approved_decisions']['path'])]
            artifacts.extend(Path(path) for path in context['full_geometry']['receipt']['projection']['artifact_sha256'])
            materialization=dict(status='NOT_RUN')
            if manifest.get('consumer_root') and job.get('publisher_output_directory'):
                missing=context['relation_receipt']['projection']['missing_qids']
                if missing:materialization=dict(status='WAIT_QID_SOURCES',qids=missing)
                else:
                    from materialize_components import materialize_components
                    publisher=Path(job['publisher_output_directory']).resolve()
                    if not publisher.is_relative_to(HERE.parent/'publisher_direct_20261101/orchestration_refresh_0001'):
                        raise ValueError('Use a new caller-owned publisher generation')
                    publisher.mkdir(parents=True,exist_ok=True)
                    materialization=stage('materialize',lambda:materialize_components(publisher/'components',identity_state=context['count_state'],
                        count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'],geometry_receipt=context['full_geometry']['receipt'],
                        native_registry=registry,source_receipts=[dict(path=str(path),sha256=digest(path)) for path in artifacts],consumer_root=manifest['consumer_root']))
                    receipt=pinned(dict(path=materialization['receipt_path'],sha256=materialization['receipt_sha256']))
                    for path,expected in receipt['inputs_sha256'].items():
                        if digest(path)!=expected:raise ValueError('Materialization source changed before result persistence')
                    for name,expected in receipt['artifact_sha256'].items():
                        if digest(Path(materialization['receipt_path']).parent.parent/name)!=expected:
                            raise ValueError('Materialization artifact changed before result persistence')
                    artifacts.append(Path(materialization['receipt_path']))
                    artifacts.extend(Path(materialization['receipt_path']).parent.parent/name for name in receipt['artifact_sha256'])
            for name,descriptor in job.get('route_receipts',{}).items():
                if name not in ROUTES:raise ValueError('Unknown required route receipt: '+name)
                stage(name,lambda descriptor=descriptor:pinned(descriptor))
            routes=route_completion(stages['stages'],built['handoff'],job.get('matching_receipt'))
            completed=matching['status']=='VERIFIED_BIDIRECTIONAL_INPUT_BINDING' and materialization['status']=='PASS_NEW_FRONTIER_COMPONENT_MATERIALIZATION' and routes['complete']
            result=dict(status='APPROVED_DECISIONS_AND_PROJECTIONS_SAVED',job_sha256=job_hash,
                previous_projection=index['projection'],projection=dict(path=str(projection),sha256=digest(projection)),
                sealed_unit=dict(unit_directory=built['sealed_dir'],unit_sha256=built['unit_sha256']),
                decision_version=patch['decision_version'],scope=built['handoff']['manifest'],
                counts=context['count_receipt']['projection'],matching_completion=matching['status'],native_registry=registry,
                stages=stages['stages'],required_route_completion=routes,
                consumer_materialization=materialization,unit_completed=completed,checkpoint='NOT_ATTEMPTED',publication=False,
                verified_artifact_sha256={str(path):digest(path) for path in artifacts})
            save(result_path,result)
        # The per-unit result exists before the global cursor moves; restart recovers this boundary.
        if stop_after_result:raise RuntimeError('TEST_STOP_AFTER_PERSISTED_UNIT_RESULT')
        index['jobs'][job_hash]=dict(path=str(result_path),sha256=digest(result_path))
        if 'native_registry' in result:index['native_registry']=result['native_registry']
        index['projection']=result['projection'];save(index_path,index)
    return dict(status='READY_CPU_JOBS_SAVED',jobs=len(index['jobs']),projection=index['projection'],
        index_path=str(index_path),publication=False,unit_completion_not_certified=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest');parser.add_argument('sha256')
    args=parser.parse_args();print(json.dumps(run_ready_units(args.manifest,args.sha256)))
