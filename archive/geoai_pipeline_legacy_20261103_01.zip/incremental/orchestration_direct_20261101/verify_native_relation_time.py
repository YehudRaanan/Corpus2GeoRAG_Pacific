"""Verify the existing approved relation qualifier-time projection, without adding fields/routes."""
from pathlib import Path
from run_ready_units import pinned,save
from check_one_unit import read,digest
from GG_Data.pipeline.relations import statement_time

HERE=Path(__file__).resolve().parent;OUT=HERE/'structured_temporal_integration_0001'

def verify():
    source=HERE/'policy_v2_integration_0001/unit_10/relation_receipt.json'
    receipt=read(source);projection=receipt['projection'];cases=[]
    function=Path('D:/Projects/GeoAI/GG_Data/pipeline/relations.py')
    assert digest(function)=='3fc60f352ebc2bd34f9d50235b3810114422b6504c34ed736fded8938a7106db'
    for relation in projection['relations']:
        case=relation['input_assertion']['raw_source'];statement=case['raw_statement']
        computed=statement_time(statement)
        assert all(case[key]==value for key,value in computed.items())
        cases.append(dict(source_qid=case['subject_qid'],target_qid=case['object_qid'],
            statement_id=case['source_record_id'],source=case['source_record'],raw_statement=statement,
            temporal=computed,allowed_properties=['P580','P582','P585']))
    with_values=[row for row in cases if any(row['temporal'].get('time_'+key) for key in ('from','to','point'))]
    OUT.mkdir(exist_ok=True)
    proof=dict(status='PASS_EXISTING_NATIVE_RELATION_QUALIFIER_TIME_READBACK',native_relation_statements=len(cases),
        statements_with_selected_time=len(with_values),cases=cases,scope='Only existing catalog-eligible accepted-QID relation statements; not Event population or a full temporal-route completion',
        raw_DATE_parsing_used=False,new_time_fields_added=False,Event_selection_performed=False,process_completion_claimed=False,
        source_receipt=dict(path=str(source),sha256=digest(source)),function=dict(path=str(function),sha256=digest(function)))
    save(OUT/'relation_time_readback.json',proof)
    print('PASS: '+str(len(cases))+' existing native relation time projections, '+str(len(with_values))+' selected time values; no text-derived dates')

if __name__=='__main__':verify()
