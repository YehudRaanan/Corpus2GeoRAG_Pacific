"""Call the verified full-baseline publisher once; reuse its receipt for an exact replay."""
import hashlib
import json
import sys
from copy import deepcopy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROVIDER = ROOT / 'publisher_direct_20261101/publisher_refresh_0001'
sys.path.insert(0, str(PROVIDER))
from publisher_refresh import refresh_snapshot, verified_previous_snapshot
from check_one_unit import digest, read
from decision_revision_hook import content_hash

PROVIDER_HASH = '9ac2907d11a98b7987df0a0036728a482479e257cbc83fe87e99ce6994e857bf'


def refresh_once(output, parameters, previous=None):
    output = Path(output).resolve()
    assigned = (ROOT/'publisher_direct_20261101/orchestration_refresh_0001').resolve()
    if not output.is_relative_to(assigned):
        raise ValueError('Output leaves this caller-owned snapshot namespace')
    if digest(PROVIDER/'publisher_refresh.py')!=PROVIDER_HASH:
        raise ValueError('Publisher provider changed')
    request_hash = content_hash(dict(output=str(output),parameters=parameters))
    if previous is not None:
        if previous['request_sha256']!=request_hash:
            raise ValueError('Stale/different request cannot reuse this receipt')
        receipt_path = Path(previous['receipt_path'])
        if receipt_path!=output/'private/success_receipt.json' or digest(receipt_path)!=previous['receipt_sha256']:
            raise ValueError('Replay success receipt differs')
        receipt = read(receipt_path)
        if receipt['frontier']!=parameters['frontier'] or not receipt['proposed_contract'] or receipt['publication']:
            raise ValueError('Replay frontier/contract differs')
        for field in ('source_sha256','artifact_sha256'):
            if any(digest(Path(p))!=h for p,h in receipt[field].items()):
                raise ValueError('Replay source/output changed')
        return previous  # Exact read-only replay: never call materialization or cadence confirm again.
    output.parent.mkdir(parents=True,exist_ok=True)
    result = refresh_snapshot(output,**parameters)
    return dict(result,request_sha256=request_hash)


def check(audit):
    manifest = PROVIDER / 'simulation_0002/baseline_inputs.json'
    parameters = read(manifest)
    assert parameters['geometries']['scope']['kind']=='FULL_LOC_POPULATION'
    assert len(parameters['geometries']['scope']['place_ids'])==5
    assert parameters['frontier']['identity_version']=='first-unit-exact-v1'
    output = ROOT / 'publisher_direct_20261101/orchestration_refresh_0001/snapshot_0001'
    state = PROVIDER / 'simulation_0002/cadence_state.json'
    protected = {str(manifest):digest(manifest),str(state):digest(state),str(PROVIDER/'publisher_refresh.py'):PROVIDER_HASH}
    result = refresh_once(output,parameters)
    assert result['consumer_checks']==dict(nodes=10,edges=90,geometries=5,support_identities=45,strength_query_views=82)
    receipt = read(Path(result['receipt_path']))
    assert receipt['proposed_contract'] and receipt['daniel_approval']=='not recorded' and not receipt['publication']
    assert receipt['decision_version']=='first-unit-exact-v1'
    before = {str(p):(digest(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
    assert refresh_once(output,parameters,result) is result
    assert before=={str(p):(digest(p),p.stat().st_mtime_ns) for p in output.rglob('*') if p.is_file()}
    stale = deepcopy(parameters)
    stale['relations']['decision_version']='unaccepted-model-v2'
    for target,prior in ((output,result),(output.parent/'stale_rejected',None)):
        try:
            refresh_once(target,stale,prior)
        except ValueError:
            pass
        else:
            raise AssertionError('Stale identity/component frontier accepted')
    assert not (output.parent/'stale_rejected').exists()
    assert all(digest(Path(p))==h for p,h in protected.items())
    (audit/'inputs.json').write_text(json.dumps(parameters,indent=2),encoding='utf-8')
    return dict(status='PASS_ORCHESTRATED_FULL_BASELINE_REFRESH',call=result,protected_sha256=protected,
                full_LOC_population=parameters['geometries']['scope']['place_ids'],baseline_materializations=1,
                replay_file_bytes_and_mtimes_unchanged=True,stale_rejected=True,new_real_model_decisions=False,
                proposed_contract=True,daniel_approval='not recorded',cadence_confirm_called=False,publication=False)


if __name__=='__main__':
    audit = HERE/'publisher_call_0001'
    audit.mkdir()
    result = check(audit)
    (audit/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    proof = dict(status=result['status'],checks=6,code_sha256=digest(Path(__file__)),result_sha256=digest(audit/'result.json'),
                 consumer_checks=result['call']['consumer_checks'],publication=False)
    (audit/'verification.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof))
