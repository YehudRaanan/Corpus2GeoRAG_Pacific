"""Independent final-cohort readback; no producer, inference, source fetch or publication rerun."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
import gzip
import geopandas as gpd
from run_ready_units import pinned,save
from check_one_unit import read,digest
from GG_Data.pipeline.relations import statement_time
from GG_Data.pipeline.graph_contract import endpoint_index
from cadence_caller import checkpoint_decision,instant

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;OUT=HERE/'policy_v2_all17_sources_0340_0001'

def verify():
    queue=read(HERE/'reconciliation_units11_20_v2/state.json')
    assert sum(row['status']=='CANONICAL_POLICY_APPLIED' for row in queue['units'].values())==8
    assert sum(row['status']=='CAPACITY_PENDING' for row in queue['units'].values())==2
    result=read(OUT/'unit/unit_result.json');counts=result['counts'];mat=result['consumer_materialization']
    assert mat['status']=='PASS_NEW_FRONTIER_COMPONENT_MATERIALIZATION'
    component=pinned(dict(path=mat['receipt_path'],sha256=mat['receipt_sha256']));root=Path(mat['receipt_path']).parent.parent
    source=HERE/'policy_v2_integration_0001/sealed_receipt.json'
    units=read(source)['units']+read(HERE/'reconciliation_units11_20_v2/sealed_successors.json')['units']
    by_page={row['scope']['page_id']:row for row in counts['unit_frontier']}
    ids=set();pending=set();date_ids=set();mentions=Counter();pages=defaultdict(set);none=0;statuses=[]
    for item in units:
        descriptor=item['sealed_unit'];path=Path(descriptor['unit_directory'])/'unit.private.json'
        assert digest(path)==descriptor['unit_sha256'];unit=read(path);manifest=unit['manifest']
        rows={row['occurrence_id']:row for row in unit['occurrences']};decisions={row['occurrence_id']:row for row in unit['decisions']}
        unknown={row['occurrence_id'] for row in unit['pending_evidence']}
        assert len(rows)==len(unit['occurrences']) and len(decisions)==len(unit['decisions']) and not ids&set(rows)
        assert set(decisions)|unknown==set(rows) and not set(decisions)&unknown
        assert by_page[manifest['page_id']]['unit_sha256']==descriptor['unit_sha256']
        assert by_page[manifest['page_id']]['decision_version']==unit['version']
        ids.update(rows);pending.update(unknown)
        date_ids.update(oid for oid,row in rows.items() if row['entity_group']=='DATE')
        for oid,row in decisions.items():
            if row['qid'] is None:none+=1
            else:mentions[row['qid']]+=1;pages[row['qid']].add((manifest['wiki_site'],manifest['page_id']))
        statuses.append(dict(unit=item['unit'],scope=manifest,decision_version=unit['version'],sealed_unit=descriptor,
            source_stage='COMPLETED_REGISTRY340',count_relation_stage='COMPLETED_CURRENT_FRONTIER',
            consumer_stage='COMPLETED_COHORT_MATERIALIZATION',consumer_receipt=dict(path=mat['receipt_path'],sha256=mat['receipt_sha256']),
            legacy_WAIT_QID_SOURCES_superseded=True,full_process_completed=False))
    assert len(ids)==1854 and len(pending)==420 and sum(mentions.values())==835 and none==599
    assert len(units)==17 and len(date_ids)==334 and date_ids<=pending
    assert (counts['accepted_occurrences'],counts['explicit_unmatched_occurrences'],counts['pending_occurrences'])==(835,599,420)
    assert {r['qid']:(r['mention_count'],r['page_count']) for r in counts['identity_counts']}=={q:(mentions[q],len(pages[q])) for q in mentions}
    graph=read(root/'graph.json');node_ids={row['id'] for row in graph['nodes']};edge_ids={row['id'] for row in graph['edges']}
    expected={row['qid']+'::'+row['entity_group'] for row in counts['typed_counts']}
    assert node_ids==expected and len(node_ids)==len(graph['nodes'])==363 and len(edge_ids)==len(graph['edges'])==11933
    assert set(endpoint_index(graph['nodes'],graph['edges']))==set(mentions)  # Approved edges keep QID endpoints.
    assert all(not row.get('source_edge_id') or row['source_edge_id'] in edge_ids for row in graph['edges'])
    registry=pinned(result['native_registry']);assert set(registry['selected_references'])==set(mentions) and len(mentions)==340
    relations=pinned(result['stages']['relation_receipt'])
    assert relations['projection']['missing_qids']==[] and relations['projection']['pending_pairs']==[]
    assert component['decision_binding']==relations['decision_binding']
    temporal=[]
    for relation in relations['projection']['relations']:
        case=relation['input_assertion']['raw_source'];computed=statement_time(case['raw_statement'])
        assert all(case[key]==value for key,value in computed.items())
        temporal.append(dict(statement_id=case['source_record_id'],source_qid=case['subject_qid'],target_qid=case['object_qid'],
            temporal=computed,source=case['source_record']))
    timed=sum(any(row['temporal'].get('time_'+key) for key in ('from','to','point')) for row in temporal)
    geometries=gpd.read_parquet(root/'model/geometries.parquet');assert len(geometries)==5 and geometries.crs.to_epsg()==4326
    baseline=read(HERE/'approved_runner_0001/baseline.json');old=gpd.read_parquet(baseline['artifacts']['geoparquet'])
    assert dict(zip(old['place_id'],old.geometry.to_wkb()))==dict(zip(geometries['place_id'],geometries.geometry.to_wkb()))
    for name,expected_hash in component['artifact_sha256'].items():assert digest(root/name)==expected_hash
    for descriptor in result['stages'].values():assert digest(descriptor['path'])==descriptor['sha256']
    assert not result['unit_completed'] and result['publication'] is False
    context=read(HERE/'context_validation_0001/receipt.json');assert context['executed']==context['unresolved']==7
    clock_path=ROOT/'publisher_direct_20261101/orchestration_delivery_0001/first_runtime_publication_clock.json'
    clock_hash=digest(clock_path);clock=read(clock_path)
    gate=checkpoint_decision(datetime.now(timezone.utc),instant(clock['last_successful_checkpoint']) if clock['last_successful_checkpoint'] else None,
        [],clock['acknowledged_units'],False,False,run_start=instant(clock['run_start']),required_stages=clock['required_stages'])
    assert not gate['due'] and gate['new_completed_units']==0 and digest(clock_path)==clock_hash
    first_manifest=HERE/'reconciliation_units11_20_v2/unit_11_48a5e9fc89f3/exact_manifest.json'
    elapsed=(HERE/'reconciliation_units11_20_v2/state.json').stat().st_mtime-first_manifest.stat().st_mtime
    proof=dict(status='PASS_INDEPENDENT_ALL17_V2_COHORT',source_units=17,physical_pages=len({row['scope']['page_id'] for row in statuses}),
        occurrences=1854,assigned=835,explicit_NONE=599,pending=420,QIDs=340,nodes=363,edges=11933,geometries=5,
        native_source_gaps=0,pending_native_pairs=0,history_versions=counts['history_versions'],raw_DATE_pending=334,
        raw_DATE_parsing='DIAGNOSTIC_ONLY_NOT_ENRICHMENT',context_validation_executed=7,context_unresolved=7,
        native_relation_time=dict(statements=len(temporal),with_selected_time=timed,properties=['P580','P582','P585'],raw_text_used=False),
        process_completed_units=0,publication=False,publication_gate=gate,clock_unchanged=True,proposed_contract=True,
        consumer_receipt=dict(path=mat['receipt_path'],sha256=mat['receipt_sha256']),native_registry=result['native_registry'],
        source_cursor=dict(path=str(OUT/'state/index.json'),sha256=digest(OUT/'state/index.json')),unit_status_successors=statuses,
        CPU_loop_window_seconds=elapsed,CPU_loop_timing_note='First exact manifest persistence to terminal queue state, including policy/orchestration/IO; not pure CPU execution time',
        Event_remaining=['approved runtime Event selection/WWII evidence','G6 anchors/predicates and endpoint type evidence','G7 mask/type/boundary/unknown inputs','native Event ancestry source closure','Event native-link population beyond node/date adapter'])
    save(OUT/'native_relation_time_readback.json',dict(status='VERIFIED_EXISTING_STRUCTURED_RELATION_TIME',cases=temporal,full_temporal_Event_route_complete=False))
    save(OUT/'latest_unit_stage_status.json',dict(status='SUCCESSOR_STATUS_SUPERSEDES_HISTORICAL_SOURCE_WAITS',units=statuses,proof=dict(path=str(OUT/'independent_verification.json'))))
    save(OUT/'independent_verification.json',proof)
    print('PASS:17 units/1854 IDs/835 assigned/599 NONE/420 pending;363 nodes11933 edges5 geometries; source gaps0; full completion0')
    print('Structured relation time:'+str(len(temporal))+' statements,'+str(timed)+' with selected times')
    print('CPU loop observed window seconds:'+str(round(elapsed,3)))
    print('verification_sha256='+digest(OUT/'independent_verification.json'))

if __name__=='__main__':verify()
