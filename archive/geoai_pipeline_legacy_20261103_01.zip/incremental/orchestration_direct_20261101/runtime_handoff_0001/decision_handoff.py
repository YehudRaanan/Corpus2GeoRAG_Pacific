"""Explicit accepted-decision patch -> sealed unit successor. No inference or thresholds."""
import json
import sys
from copy import deepcopy
from pathlib import Path
from shutil import copyfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT/'durable_units_direct_20261101'),str(HERE.parent)]
from durable_unit import recover, receipt_for, seal_unit, encoded, sha
from check_one_unit import read, digest

# Historical first-unit test pin only; runtime recovery uses the caller's per-unit pin.
BASE_UNIT_SHA = '35d0edd3f0eb17aa0e468f25a25dbfd1daf257bec938f05bb510e848ec5ae0f6'


def expected_membership(manifest):
    indices=manifest['expected_row_indices']
    count=manifest.get('retained_count',len(indices))
    if type(count) is not int or count!=len(indices) or len(set(indices))!=count:
        raise ValueError('Sealed manifest count and membership disagree')
    return count


def build_handoff(output_dir, *, current_sealed_dir, current_unit_sha256, prior_history,
                  supplied_decisions, decision_version):
    prior = deepcopy(list(prior_history))
    loaded = recover(current_sealed_dir,current_unit_sha256,prior_history=prior)
    if loaded['status']!='sealed':
        raise ValueError('Current source unit is not sealed')
    current = loaded['handoff']
    # recover checked the supplied unit hash and linked history; their first version is this unit's baseline.
    baseline = prior[0] if prior else current
    expected_count=expected_membership(baseline['manifest'])
    if not isinstance(decision_version,str) or not decision_version or decision_version in {u['version'] for u in [*prior,current]}:
        raise ValueError('Supply a new explicit decision version')
    exact = {d['occurrence_id']:d for d in baseline['decisions']}
    existing = {d['occurrence_id']:d for d in current['decisions']}
    if len(exact)!=len(baseline['decisions']) or any(existing.get(o)!=d for o,d in exact.items()):
        raise ValueError('Protected baseline decisions changed')
    pending = {r['occurrence_id']:r for r in current['pending_evidence']}
    members = [r['occurrence_id'] for r in current['occurrences']]
    if len(members)!=expected_count or len(pending)!=len(current['pending_evidence']) or set(pending)&set(existing) or set(pending)|set(existing)!=set(members):
        raise ValueError('Current accepted/pending partition differs from source membership')
    supplied = {}
    for decision in supplied_decisions:
        if not isinstance(decision,dict) or not {'occurrence_id','qid','evidence'}<=decision.keys():
            raise ValueError('Explicit occurrence/QID/evidence required; absence is not NONE')
        occurrence = decision['occurrence_id']
        if occurrence in supplied or occurrence not in pending:
            raise ValueError('Only unique currently pending occurrence IDs can be patched')
        if not isinstance(decision['evidence'],dict) or not decision['evidence']:
            raise ValueError('Supplied decision evidence must be explicit')
        supplied[occurrence] = deepcopy(decision)
    updated = deepcopy(current)
    updated.update(version=decision_version,prior_version=current['version'])
    # Keep all existing decisions exact; preserve raw rows/source and only remove explicitly patched pending IDs.
    updated['decisions'].extend(supplied[o] for o in members if o in supplied)
    updated['pending_evidence'] = [r for r in current['pending_evidence'] if r['occurrence_id'] not in supplied]
    history = [*prior,current]
    source = (Path(current_sealed_dir)/'source.private.bin').read_bytes()
    receipt_for(updated,source,prior_history=history)  # Validate QID/cardinality/source/history before writing.
    unit_hash = sha(encoded(updated))
    seal_unit(output_dir,updated,source,unit_hash,prior_history=history)
    recovered = recover(output_dir,unit_hash,prior_history=history)
    return dict(status='SEALED_EXPLICIT_DECISION_HANDOFF',sealed_dir=str(Path(output_dir)),unit_sha256=unit_hash,
                decision_version=decision_version,prior_version=current['version'],handoff=recovered['handoff'],
                prior_history=history,seal_receipt=recovered['receipt'])


def self_check(output):
    original = ROOT/'integration_direct_20261101/real_handoff_0001'
    original_receipt = read(original/'receipt.json')
    protected = dict(original_receipt['protected_sha256'])
    protected.update({str(original/p):h for p,h in original_receipt['output_sha256'].items()})
    assert all(digest(Path(p))==h for p,h in protected.items())
    copied = output/'copied_v1';copied.mkdir()
    for name in ('seal.json','unit.private.json','source.private.bin'):
        copyfile(original/'sealed_v1'/name,copied/name)
    first = recover(copied,BASE_UNIT_SHA)['handoff']
    eligible = [r for r in first['pending_evidence'] if r['raw_type'] in ('LOC','PER','ORG')]
    patch = [dict(occurrence_id=eligible[0]['occurrence_id'],qid='Q999999991',
                  evidence=dict(origin='SYNTHETIC_TEST_ONLY',accepted_decision_supplied=True)),
             dict(occurrence_id=eligible[1]['occurrence_id'],qid=None,
                  evidence=dict(origin='SYNTHETIC_EXPLICIT_NONE_ONLY',accepted_decision_supplied=True))]
    arguments = dict(current_sealed_dir=copied,current_unit_sha256=BASE_UNIT_SHA,prior_history=[],
                     supplied_decisions=patch,decision_version='SYNTHETIC_EXPLICIT_HANDOFF_v2')
    built = build_handoff(output/'sealed_v2',**arguments)
    second = recover(built['sealed_dir'],built['unit_sha256'],prior_history=[first])['handoff']
    assert second['occurrences']==first['occurrences'] and second['manifest']==first['manifest']
    assert second['decisions'][:30]==first['decisions']
    assert second['decisions'][30:]==patch
    assert len(second['pending_evidence'])==104 and len(second['decisions'])==32
    assert built['seal_receipt']['explicit_unmatched_occurrence_ids']==[patch[1]['occurrence_id']]
    before = {p.name:(digest(p),p.stat().st_mtime_ns) for p in (output/'sealed_v2').iterdir()}
    assert build_handoff(output/'sealed_v2',**arguments)['unit_sha256']==built['unit_sha256']
    assert before=={p.name:(digest(p),p.stat().st_mtime_ns) for p in (output/'sealed_v2').iterdir()}
    invalid = [('overwrite_exact',[dict(patch[0],occurrence_id=first['decisions'][0]['occurrence_id'])]),
               ('unknown_occurrence',[dict(patch[0],occurrence_id='unknown-id')]),
               ('duplicate',[patch[0],patch[0]]),('missing_evidence',[dict(occurrence_id=patch[0]['occurrence_id'],qid='Q2')]),
               ('invalid_qid',[dict(patch[0],qid='not-a-qid')])]
    for name,bad_patch in invalid:
        try:
            build_handoff(output/name,**dict(arguments,supplied_decisions=bad_patch))
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid supplied patch accepted: '+name)
        assert not (output/name).exists()
    try:
        build_handoff(output/'wrong_history',**dict(arguments,current_sealed_dir=output/'sealed_v2',current_unit_sha256=built['unit_sha256']))
    except ValueError:
        pass
    else:
        raise AssertionError('Successor recovered without required prior history')
    assert all(digest(Path(p))==h for p,h in protected.items())
    return dict(status='PASS_EXPLICIT_RUNTIME_HANDOFF_BUILDER',built=built,patch=patch,versions=[first,second],
                protected_sha256=protected,checks=9,actual_model_decisions=False,thresholds_chosen=False)


if __name__=='__main__':
    output = HERE/'fixture_0001';output.mkdir()
    result = self_check(output)
    (output/'result.json').write_bytes(encoded(result))
    proof = dict(status=result['status'],checks=result['checks'],code_sha256=digest(Path(__file__)),
                 result_sha256=digest(output/'result.json'),original_occurrences=136,unchanged_exact=30,
                 supplied_accepted=1,supplied_explicit_NONE=1,pending=104)
    (output/'verification.json').write_bytes(encoded(proof))
    print(json.dumps(proof))
