# One-unit receipt orchestration — verification only

**PASS**, 2026-11-01 20:26:33 UTC. One simple standard-library file, check_one_unit.py, verifies the already completed INPUT seal -> grouping -> exact -> E2/E4 handoff -> private real counts. It does not dispatch/rerun a pipeline stage, create a queue/service, load a model or publish anything.

Unit: page 48975579 / processing revision 1375061414. All 136 source IDs and row-index bindings match across the five stages. Original/prepared words, exact accepted/pending records and source hashes agree. Grouping: 69 groups. Exact: ten accepted groups / 30 occurrences, 106 pending, five positive MISC groups unchanged, six unknown target mappings and zero NONE decisions. Handoff: first-unit-exact-v1, one physical page/history version. Counts: ten identities, 45 unique unordered pairs, integer shared-page/source/target denominators all one; pending records equal the handoff's pending evidence.

The counts hook was added only after the parent delivered its verified receipt. Counts input_receipt_sha256, pinned_unit_sha256, decision_version and six-field scope match the exact handoff. Counts output/code/protected hashes and its independent readback receipt pass. No count is interpreted as a native relation or consumer weight representation.

run_0001 retains the earlier four-stage status awaiting a verified counts receipt. Before modifying the checker, its exact source bytes were archived as checker_source_v1.txt and verified against that run's code hash. run_0002/stage_status.json records the five-stage status. Existing output directories are never overwritten.

Checks: all receipt-linked artifact hashes; common source/page/revision/version; 136 exact unique IDs at source/group/exact/handoff boundaries; accepted one-QID cardinality; pending equality/no NONE; count denominator/pair integrity; in-memory negative checks reject incorrect hash and duplicate IDs. Independent fresh-process inspection reproduced the complete run_0002 status, rechecked the current code hash and verified the old source archive. Only owned orchestration status files were written; completed stage code/data remained unchanged.

Partial status is explicit: exact is COMPLETED_PARTIAL while counts is COMPLETED_PRIVATE_COUNTS. Full page/corpus matching, native relation readiness, consumer output, canonical batch/publication semantics and production runtime robustness are not inferred. Backup: Unprotected.

## Plan evidence added by the sole documentation writer

The separate Q84 historical replay and input-scale metadata audit are reviewed evidence, not additional stage executions here. The exact proposed append is PLAN_STATUS_APPEND.md; previous plan bytes and appended hashes are recorded by plan_status_receipt.json. G16 member counts do not establish token lengths, GPU fit, throughput or worker sizing.

Both plan appends completed and independent readback confirmed prior-byte prefixes and final hashes. A later parent handoff reports E7's partial snapshot under publisher_direct_20261101; verifying that receipt is the next bounded increment, not part of this completed five-stage chain. No complete delivery is claimed.
