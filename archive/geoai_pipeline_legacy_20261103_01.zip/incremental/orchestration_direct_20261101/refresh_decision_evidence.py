"""Seal supplied evidence changes only when every occurrence/QID decision stays identical."""
from copy import deepcopy
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'durable_units_direct_20261101'))
from durable_unit import recover,receipt_for,seal_unit,encoded,sha


def refresh_evidence(output,*,current_directory,current_sha256,prior_history,patch):
    current=recover(current_directory,current_sha256,prior_history)['handoff']
    version=patch['decision_version']
    if not version or version in {unit['version'] for unit in [*prior_history,current]}:
        raise ValueError('Evidence refresh needs a new explicit version')
    existing={row['occurrence_id']:row for row in current['decisions']}
    protected={row['occurrence_id'] for row in prior_history[0]['decisions']} if prior_history else set()
    supplied={row['occurrence_id']:row for row in patch['decisions']}
    if len(supplied)!=len(patch['decisions']):raise ValueError('Duplicate evidence occurrence')
    for occurrence,row in supplied.items():
        if occurrence in protected:raise ValueError('Protected baseline evidence cannot be replaced')
        if occurrence not in existing or row['qid']!=existing[occurrence]['qid']:
            raise ValueError('Evidence-only refresh cannot add, remove or change a QID decision')
        if not isinstance(row.get('evidence'),dict) or not row['evidence']:
            raise ValueError('Explicit replacement evidence is required')
    updated=deepcopy(current)
    updated.update(version=version,prior_version=current['version'])
    updated['decisions']=[deepcopy(supplied.get(row['occurrence_id'],row)) for row in current['decisions']]
    history=[*prior_history,current]
    source=(Path(current_directory)/'source.private.bin').read_bytes()
    receipt_for(updated,source,history)
    expected=sha(encoded(updated))
    seal_unit(output,updated,source,expected,prior_history=history)
    loaded=recover(output,expected,history)
    return dict(sealed_dir=str(output),unit_sha256=expected,handoff=loaded['handoff'],prior_history=history)
