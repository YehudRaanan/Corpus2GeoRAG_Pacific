"""Save output from the existing INFERENCE policy function in caller-owned space."""
from pathlib import Path
import importlib.util
import json
from check_one_unit import read,digest
from run_ready_units import pinned,save
from decision_revision_hook import content_hash

HERE=Path(__file__).resolve().parent
CALLABLE=HERE.parent/'runtime_inference_direct_20261101/per_unit_policy_v1/apply_policy.py'


def apply_policy_output(manifest_descriptor,output):
    manifest=pinned(manifest_descriptor)
    expected=manifest['policy_callable_sha256']
    if digest(CALLABLE)!=expected:raise ValueError('Policy callable differs from the pinned release')
    spec=importlib.util.spec_from_file_location('approved_policy_'+expected[:16],CALLABLE)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    value=module.apply_manifest(manifest_descriptor['path'])
    if content_hash(module.apply_manifest(manifest_descriptor['path']))!=content_hash(value):raise ValueError('Policy replay differed')
    if digest(CALLABLE)!=expected:raise ValueError('Policy callable changed while applying')
    payload={'decision_patch.json':value['patch'],'residual_decision_patch.json':value['residual_patch'],
        'all_occurrence_decision_evidence.json':value['results'],'group_policy_cases.json':value['group_cases'],
        'accepted_qids.json':value['summary']['combined_qid_occurrences']}
    output=Path(output).resolve()
    if not output.is_relative_to(HERE):raise ValueError('Policy outputs must remain caller-owned')
    if output.exists():
        for name,obj in payload.items():
            if read(output/name)!=obj:raise ValueError('Saved policy output differs')
        return read(output/'receipt.json')
    output.mkdir(parents=True)
    for name,obj in payload.items():save(output/name,obj)
    receipt=dict(value['summary'],patch_sha256=digest(output/'decision_patch.json'),
        residual_patch_sha256=digest(output/'residual_decision_patch.json'),accepted_qids_sha256=digest(output/'accepted_qids.json'),
        policy_callable_sha256=expected,in_memory_replay_equal=True,canonical_state_read_or_written=False)
    save(output/'receipt.json',receipt)
    return receipt
