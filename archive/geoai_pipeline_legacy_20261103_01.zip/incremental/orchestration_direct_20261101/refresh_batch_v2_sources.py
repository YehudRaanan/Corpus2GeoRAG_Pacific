"""Use the released complete source registry after the single eight-unit writer finishes."""
import argparse
from copy import deepcopy
from pathlib import Path
from run_ready_units import run_ready_units,pinned
from reconcile_ready_units import record
from check_one_unit import read,digest

HERE=Path(__file__).resolve().parent;OUT=HERE/'policy_v2_all17_sources_0340_0001'

def prepare():
    queue=read(HERE/'reconciliation_units11_20_v2/state.json')
    complete=[row for row in queue['units'].values() if row['status']=='CANONICAL_POLICY_APPLIED']
    if len(complete)!=8:raise ValueError('Eight-unit writer is still running; no concurrent cursor change')
    release_path=HERE.parent/'pair_relations_direct_20261101/accepted11_20_sources_0001/HANDOFF.json'
    release=read(release_path)
    assert release['status']=='READY_FOR_INTEGRATION' and release['covered']==340 and release['remaining_qids']==[]
    pinned(release['verification']);registry=pinned(release['native_registry'])
    prior=read(HERE.parent/'pair_relations_direct_20261101/unit9_sources_0001/generation_003/native_registry.json')
    assert all(registry['selected_references'][qid]==value for qid,value in prior['selected_references'].items())
    current=max(complete,key=lambda row:row['order_index']);result=pinned(current['unit_result'])
    old_job=read(Path(current['unit_result']['path']).parent.parent/'job.json')
    assert result['sealed_unit']['unit_sha256']==current['unit_sha256']
    history=deepcopy(old_job['current_unit']['prior_history'])
    history.append({key:old_job['current_unit'][key] for key in ('unit_directory','unit_sha256')})
    OUT.mkdir(exist_ok=True)
    job=dict(old_job,mode='REPLAY_CURRENT',current_unit=dict(result['sealed_unit'],prior_history=history),
        output_directory=str(OUT/'unit'),publisher_output_directory=str(HERE.parent/'publisher_direct_20261101/orchestration_refresh_0001/policy_v2_all17_registry340'))
    job_pin=record(OUT/'job.json',job)
    profile=pinned(read(HERE/'reconciliation_units11_20_v2_config.json')['base_manifest'])
    cursor=pinned(queue['cursor']);profile.update(initial_projection=cursor['projection'],native_registry=release['native_registry'],
        jobs=[job_pin],output_directory=str(OUT/'state'))
    profile.pop('policy_preparation_config',None);profile.pop('source_refresher',None)
    manifest=record(OUT/'manifest.json',profile)
    record(OUT/'source_release.json',dict(release=dict(path=str(release_path),sha256=digest(release_path)),
        native_registry=release['native_registry'],queue_cursor=queue['cursor'],queue_state_sha256=digest(HERE/'reconciliation_units11_20_v2/state.json'),
        prior194_unchanged=True,source_fetches_performed=0,manifest=manifest))
    return manifest

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');args=parser.parse_args()
    pin=prepare();print(pin,flush=True)
    if args.run:print(run_ready_units(pin['path'],pin['sha256']),flush=True)
