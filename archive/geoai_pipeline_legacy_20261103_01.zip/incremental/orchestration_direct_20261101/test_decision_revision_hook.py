"""Generated-only acceptance tests for a synchronous decision refresh."""
import json
import sys
from copy import deepcopy
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path[:0] = [str(ROOT / 'pair_relations_direct_20261101'), str(ROOT / 'counts_direct_20261101'), str(ROOT / 'integration_direct_20261101'), str(ROOT / 'grouping')]
from identity_revision_fixture import refresh_projection
from combined_pair_fixture import fixture_unit, replace_unit
from decision_revision_hook import refresh_for_decision, require_current


def check():
    first, source1 = fixture_unit(1, [0, 1, 2], ['Q1', 'Q1', 'Q2'])
    second, source2 = fixture_unit(2, [3, 4], ['Q1', 'Q3'])
    state, history, calls = {}, [], []
    replace_unit(state, second, source2)
    def recompute(current, previous, pair_history):
        calls.append(True)
        return refresh_projection(current, previous, pair_history)
    before = refresh_for_decision(state, first, source1, None, history, recompute)
    require_current(before, state)
    original_state, original_history = deepcopy(state), deepcopy(history)
    assert refresh_for_decision(state, first, source1, before, history, recompute) is before
    assert len(calls) == 1 and state == original_state and history == original_history
    revised = deepcopy(first)
    revised.update(version='page-1-simulated-v2', prior_version=first['version'])
    for decision in revised['decisions'][:2]:
        decision['qid'] = 'Q4'
    after = refresh_for_decision(state, revised, source1, before, history, recompute)
    assert len(calls) == 2 and after['stale_previous_projection_rejected']
    require_current(after, state)
    try:
        require_current(before, state)
    except ValueError:
        pass
    else:
        raise AssertionError('Old projection accepted after QID revision')
    assert 'fallback:Q1:Q2' not in after['projection']['active_views']
    assert 'fallback:Q2:Q4' in after['projection']['active_views']
    assert after['projection']['pair_counts']['Q1|Q3']['source_strength'] == 1.0
    assert before['projection']['pair_counts']['Q1|Q3']['source_strength'] == 0.5
    assert len(history) == 2 and sum(map(len, state.values())) == 3
    assert all(state[key][:len(versions)] == versions for key, versions in original_state.items())
    assert all(v['occurrences'] == versions[0]['occurrences'] for versions in state.values() for v in versions)
    assert refresh_for_decision(state, revised, source1, after, history, recompute) is after and len(calls) == 2
    # Same-version content conflict must fail before recomputation or state mutation.
    frozen_state, frozen_history = deepcopy(state), deepcopy(history)
    conflict = deepcopy(revised)
    conflict['decisions'][0]['qid'] = 'Q5'
    try:
        refresh_for_decision(state, conflict, source1, after, history, recompute)
    except ValueError:
        pass
    else:
        raise AssertionError('Conflicting content reused an existing decision version')
    assert state == frozen_state and history == frozen_history and len(calls) == 2
    # A new version, even with equal QIDs, still has a new decision dependency.
    third = deepcopy(revised)
    third.update(version='page-1-simulated-v3', prior_version=revised['version'])
    def fail_refresh(*args):
        raise RuntimeError('Synthetic recomputation failure')
    try:
        refresh_for_decision(state, third, source1, after, history, fail_refresh)
    except RuntimeError:
        pass
    else:
        raise AssertionError('Synthetic refresh failure was ignored')
    assert state == frozen_state and history == frozen_history and len(calls) == 2
    latest = refresh_for_decision(state, third, source1, after, history, recompute)
    assert len(calls) == 3 and latest['decision_binding'] != after['decision_binding']
    assert latest['projection'] == after['projection'] or latest['projection']['active_views'] == after['projection']['active_views']
    return dict(status='PASS_SYNCHRONOUS_FIXTURE_REFRESH', recomputations=len(calls),
                before=before, after=after, latest=latest, pair_history=history,
                units=[dict(scope=list(key), versions=versions) for key, versions in state.items()],
                source_texts=[source1.decode(), source2.decode()], real_decisions_changed=False,
                targeted_recompute=False, background_trigger=False)


if __name__ == '__main__':
    from check_one_unit import digest
    protected = [ROOT / 'integration_direct_20261101/real_handoff_0001/sealed_v1/unit.private.json',
                 ROOT / 'pair_relations_direct_20261101/identity_revision_fixture.py',
                 ROOT / 'integration_direct_20261101/occurrence_decisions.py',
                 ROOT / 'counts_direct_20261101/pair_counts.py',
                 ROOT / 'pair_relations_direct_20261101/pair_relations.py']
    hashes = {str(path): digest(path) for path in protected}
    result = check()
    assert all(digest(Path(path)) == expected for path, expected in hashes.items())
    output = HERE / 'revision_hook_0001'
    output.mkdir()
    (output / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    receipt = dict(status=result['status'], output_sha256=digest(output / 'result.json'),
                   code_sha256=digest(HERE / 'decision_revision_hook.py'),
                   test_sha256=digest(Path(__file__)), protected_sha256=hashes,
                   checks=['changed_QID_refresh', 'same_version_replay_skips_refresh', 'stale_projection_rejected',
                           'source_and_prior_history_preserved', 'denominator_recomputed',
                           'same_version_different_content_rejected', 'new_version_equal_QID_refresh',
                           'failed_refresh_no_state_commit'])
    (output / 'verification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(dict(status=result['status'], checks=len(receipt['checks']), recomputations=result['recomputations'], output=str(output))))
