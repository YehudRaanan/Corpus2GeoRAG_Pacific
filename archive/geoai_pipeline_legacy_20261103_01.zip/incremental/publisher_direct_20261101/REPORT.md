# E7 / Task 7 / R9 first real-unit consumer increment

Completed one offline local partial snapshot from the sealed E2/E4 handoff for page 48975579 / processing revision 1375061414 / first-unit-exact-v1. Only publisher_direct_20261101 was created or modified. Plans, source artifacts, existing adapters and consumer code remain read-only.

136 original occurrences reconcile to 30 accepted occurrences / ten typed QID identities and 106 pending. The adapter consumes only accepted assignments. Pending rows remain in the hash-pinned handoff; no SYN identity was assigned. No relations, co-occurrence weights, Event roles or geometry were invented.

| Existing typed node | Original source name | Accepted occurrences |
|---|---|---:|
| Q11751::LOC | Nagoya | 2 |
| Q131347::LOC | Oahu | 1 |
| Q1490::LOC | Tokyo | 8 |
| Q153732::LOC | Mariana Islands | 3 |
| Q2505636::ORG | Twentieth Air Force | 1 |
| Q51679::LOC | Saipan | 5 |
| Q5687462::PER | Haywood S. Hansell | 1 |
| Q741723::ORG | United States Army Air Forces | 1 |
| Q8042593::ORG | XXI Bomber Command | 6 |
| Q8042652::ORG | XX Bomber Command | 2 |

consumer_adapter.py maps these to the existing minimum Entity export inputs entity_id/type/name/aliases, then calls unchanged build_graph and GraphStore.from_json(model_dir=...). Graph names use the cached native English label, then Japanese; aliases remain unchanged cached strings. The cache SHA256 is pinned to the existing exact-stage receipt. Original mention forms, chosen language and native item revision stay in private/missingness.json. No required graph-node field is missing. This is not a full six-table population adapter: complete native claims/ranks/qualifiers/references are unavailable in the compact metadata input, and relation acquisition/population was not attempted.

snapshot_0001/graph.json contains ten existing-contract nodes, zero edges and an empty relation catalog. Existing development metadata vocabulary (test / TEST / relation-map-v2.1.2) is reused; no relationship mapping is asserted. Snapshot/model holds Entity inputs plus empty Events/Relations, Geography with five explicit null references, and a separate empty EPSG:4326 geometries.parquet with place_id/geometry columns. No missing geometry is represented by a fabricated point. All five LOCs lack accepted geometry; coverage remains zero for this unit. This missingness does not prevent loading the coherent partial snapshot.

TDD: test_adapter.py first failed because the adapter module did not exist. After the minimal adapter was added, it passed accepted/pending reconciliation, ten typed IDs, native name priority, no SYN creation, and corruption rejection for a changed accepted contribution count. Existing bridge virtualenv was reused without installation.

Independent readback: verify_readback.py ran in a separate Python process without importing the adapter. It checked all receipt input/output hashes, upstream source/consumer immutability, all 30 accepted occurrences and 106 pending directly from aggregate, ten typed QIDs, native names/aliases, QID resolution in the unchanged consumer, empty edges/geometries, five null Geography references, empty GeoParquet CRS/schema and exact graph vocabulary. PASS_FRESH_PROCESS_READBACK is recorded in snapshot_0001/private/independent_verification.json.

Receipt SHA256: 3f60c48f3f26f978bab92fabde901bb71f2a63d3ae725c50cc05b32a9a84b2c3.
Adapter SHA256: 596c2c221a07fea5df08624dd73fb55ca8661e9bfddcb9badae975fd8307b531.

Re-run readback with contract_fixtures/.venv-bridge/Scripts/python.exe -B publisher_direct_20261101/verify_readback.py. The adapter intentionally refuses to overwrite snapshot_0001. This increment is not the general R9 freeze/publisher implementation: no cadence counters, atomic current-pointer/release, crash recovery, real relations/count serialization, enrichment, publication, paid work, Git or nested agents. No denied, pending or uncertain action remains. Further source-backed relations/geometry are future integration work, not a blocker to this local partial result. Backup: Unprotected.
