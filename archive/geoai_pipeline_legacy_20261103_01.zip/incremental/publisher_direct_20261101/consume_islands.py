"""Append the two already-verified island rows, preserving Tokyo and the graph."""
import gzip
import hashlib
import json
import shutil
import sys
from pathlib import Path
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
import geopandas as gpd
import pandas as pd
from geo_agent.graph_store import GraphStore
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'geometry_direct_20261101/islands_handoff_0001'
PREVIOUS = HERE / 'snapshot_0002'
OUT = HERE / 'snapshot_0003'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def read_gzip(path):
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        return json.load(stream)

def run():
    verification_pin = '99092abb618019d44ae802aa6a3e5a47cb8fa7cc8c034e0d50401903215b455f'
    if sha(SOURCE / 'verification.json') != verification_pin:
        raise ValueError('Islands verification hash differs')
    verification = read(SOURCE / 'verification.json')
    inputs = dict(verification['inputs'])
    inputs[str(SOURCE / 'verification.json')] = verification_pin
    inputs.update({str(SOURCE / name):expected for name,expected in verification['files'].items()})
    inputs.update(read(PREVIOUS / 'private/receipt.json')['inputs_sha256'])
    for previous in [HERE / 'snapshot_0001', PREVIOUS]:
        inputs.update({str(p):sha(p) for p in previous.rglob('*') if p.is_file()})
    if not all(sha(path) == expected for path,expected in inputs.items()):
        raise ValueError('Pinned upstream bytes changed')
    handoff = read(SOURCE / 'handoff.json')
    if handoff['new_selection'] or {(i['qid'],i['accepted_occurrences']) for i in handoff['identities']} != {('Q153732',3),('Q51679',5)}:
        raise ValueError('Unexpected identity frontier')
    previous = gpd.read_parquet(PREVIOUS / 'model/geometries.parquet')
    added = gpd.read_parquet(SOURCE / 'model/geometries.parquet')
    if previous['place_id'].tolist() != ['Q1490'] or set(added['place_id']) != {'Q153732','Q51679'}:
        raise ValueError('Unexpected geometry population')
    if list(previous.columns) != list(added.columns) or previous.crs != added.crs:
        raise ValueError('Geometry columns or CRS differ')
    combined = gpd.GeoDataFrame(pd.concat([previous, added], ignore_index=True), geometry='geometry', crs=previous.crs)
    OUT.mkdir()  # Never modify a previous snapshot or overwrite this generation.
    (OUT / 'model').mkdir()
    private = OUT / 'private'
    private.mkdir()
    shutil.copyfile(PREVIOUS / 'graph.json', OUT / 'graph.json')
    for name in ['entities.json.gz','events.json.gz','relations.json.gz']:
        shutil.copyfile(PREVIOUS / 'model' / name, OUT / 'model' / name)
    combined.to_parquet(OUT / 'model/geometries.parquet',index=False)
    fragment = {r['place_id']:r for r in handoff['geography_fragment']}
    geography = [dict(fragment.get(row['place_id'],row)) for row in read_gzip(PREVIOUS / 'model/geography.json.gz')]
    for row in geography:
        if row['geometry_ref'] is not None:
            row['geometry_ref'] = dict(file='geometries.parquet',place_id=row['place_id'],sha256=sha(OUT / 'model/geometries.parquet'))
    (OUT / 'model/geography.json.gz').write_bytes(gzip.compress(json.dumps(geography).encode(),mtime=0))
    shutil.copytree(PREVIOUS / 'private', private / 'previous_snapshot_0002')
    shutil.copytree(SOURCE / 'private', private / 'islands')
    shutil.copyfile(SOURCE / 'handoff.json', private / 'islands/handoff.json')
    shutil.copyfile(SOURCE / 'verification.json', private / 'islands/verification.json')
    gaps = read(PREVIOUS / 'private/missingness.json')
    for identity in gaps['identity_mapping']:
        if identity['entity_id'] in fragment:
            identity['unavailable_source_fields'].remove('selected source-backed geometry')
    gaps.update(missingness='Native relation population not supplied. Three verified geometries retained; Nagoya Q11751 and Oahu Q131347 have no geometry in this snapshot.',
        locations_with_geometry=3,locations_without_geometry=2,geometry_bound_accepted_occurrences=16,
        geometry_caveat=handoff['caveat'],remaining_geometry_gaps=handoff['unresolved'])
    (private / 'missingness.json').write_text(json.dumps(gaps,indent=2),encoding='utf-8')
    store = GraphStore.from_json(OUT / 'graph.json',model_dir=OUT / 'model')
    assert len(store.nodes) == 10 and not store.edges and set(store.geoms) == {'Q1490::LOC','Q153732::LOC','Q51679::LOC'}
    assert all(sha(path) == expected for path,expected in inputs.items())
    receipt = dict(status='PASS_LOCAL_SNAPSHOT_0003_ISLANDS',nodes=10,edges=0,geometry_rows=3,
        accepted_occurrences=30,pending_occurrences=106,geometry_bound_accepted_occurrences=16,
        locations_without_geometry=2,graph_byte_identical=True,new_selection=False,publication=False,
        inputs_sha256=inputs,artifact_sha256={p.relative_to(OUT).as_posix():sha(p) for p in OUT.rglob('*') if p.is_file()},
        stage_sha256=sha(Path(__file__)),backup_status='Unprotected')
    (private / 'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print('PASS snapshot_0003: 10 nodes, 0 edges, 3 geometry rows / 16 accepted occurrences; 2 LOC gaps')

if __name__ == '__main__':
    run()
