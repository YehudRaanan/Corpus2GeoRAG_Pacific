"""Owner-approved isolated exception handling and actual source-only completion checks."""
import json,sys,os
from copy import deepcopy
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path.insert(0,str(PUBLISHER/'component_materializer_0001'));import materialize_components as m

def write(p,value):p.write_text(json.dumps(value,indent=2),encoding='utf-8');return dict(path=str(p),sha256=m.sha(p))
def check_outputs(output):
 receipt=m.read(output/'private/receipt.json')
 for name,digest in receipt['artifact_sha256'].items():assert m.sha(output/name)==digest,name
 for path,digest in receipt['inputs_sha256'].items():assert m.sha(path)==digest,path
 graph=m.read(output/'graph.json');ids={r['id'] for r in graph['nodes']};qids={r['wikidata_id'] for r in graph['nodes']}
 assert all((e['source'] in ids or e['source'] in qids) and (e['target'] in ids or e['target'] in qids) for e in graph['edges'])
 return receipt,m.read(output/'private/data_exceptions.json')

def main():
 out=HERE/'exception_regression_0001';out.mkdir();fixture=HERE/'regression_0003'
 context=m.read(ROOT/'orchestration_direct_20261101/count_relation_chain_0001/result.json')['before']
 state={tuple(row['scope']):versions for row,versions in zip(context['count_receipt']['decision_binding'],context['units'])}
 base=PUBLISHER/'proposed_strength_0001/snapshot_0007_retry_0001';native=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
 counts=context['count_receipt'];relation=context['relation_receipt'];locs={r['qid'] for r in counts['projection']['typed_counts'] if r['entity_group']=='LOC'}
 paths=[base/'model/geography.json.gz',base/'model/geometries.parquet']
 projection=dict(scope_kind='FULL_LOC_POPULATION',scope_qids=sorted(locs),geography_path=str(paths[0]),geoparquet_path=str(paths[1]),artifact_sha256={str(p):m.sha(p) for p in paths},source_binding=dict(count_receipt_sha256=m.content_hash(counts),relation_receipt_sha256=m.content_hash(relation)))
 source=dict(path=str(fixture/'fixture_GEO_source.json'),sha256=m.sha(fixture/'fixture_GEO_source.json'))
 geometry=dict(decision_binding=m.decision_binding(state),projection=projection,projection_sha256=m.content_hash(projection),active_LOC_projection_required=True,source_receipt=source)
 parameters=dict(identity_state=state,count_receipt=counts,relation_receipt=relation,geometry_receipt=geometry,native_registry=dict(path=str(native),sha256=m.sha(native)),source_receipts=[source],consumer_root=PUBLISHER/'proposed_strength_0001/consumer')
 checks={}
 for label,registry_name,expected_items in [('inactive_missing','fixture_identity_registry.json',0),('active_missing_source','fixture_active_missing_registry.json',1),('active_missing_name','fixture_active_nameless_registry.json',1)]:
  item=fixture/registry_name;parameters['native_registry']['identity_registry']=dict(path=str(item),sha256=m.sha(item))
  result=m.materialize_components(out/label,**parameters);receipt,exceptions=check_outputs(out/label)
  assert receipt['test_only'] is True and exceptions['quarantined_typed_items']==expected_items
  assert m.read(out/label/'private/count_receipt.json')==counts
  assert m.read(out/label/'private/identity_frontier.json')['units']==list(state.values())
  if expected_items:assert exceptions['items'][0]['resolved'] is False and exceptions['items'][0]['needed_remedy']
  checks[label]=receipt['consumer_checks']
 # Registry hash and same-ID whole-record integrity errors are systemic, never quarantined.
 bad=deepcopy(parameters);bad['native_registry']['identity_registry']['sha256']='0'*64
 try:m.materialize_components(out/'bad_hash',**bad)
 except ValueError as e:assert 'registry hash differs'in str(e)
 else:raise AssertionError('Hash failure quarantined')
 corrupt=m.read(fixture/'fixture_identity_registry.json');qid=next(q for q in corrupt['selected_references'] if q!='Q1490');corrupt['selected_references'][qid]['envelope']['entity']['id']='Q1'
 bad=deepcopy(parameters);bad['native_registry']['identity_registry']=write(out/'wrong_identity_registry.json',corrupt)
 try:m.materialize_components(out/'wrong_QID',**bad)
 except ValueError as e:assert 'not the accepted QID'in str(e)
 else:raise AssertionError('Whole-record integrity failure quarantined')
 assert not (out/'bad_hash').exists() and not (out/'wrong_QID').exists()
 b=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001/three_unit_v3_0001/native_projection_0001';manifest=m.read(b/'ordinary_contract_probe_manifest.json')
 actual=dict(compact_frontier=manifest['compact_frontier'],count_receipt=m.read(manifest['count_receipt']['path']),relation_receipt=m.read(manifest['relation_receipt']['path']),geometry_receipt=m.read(manifest['geometry_receipt']['path']),native_registry=deepcopy(manifest['native_registry']),source_receipts=manifest['source_receipts'],consumer_root=parameters['consumer_root'])
 result=m.materialize_components(out/'actual_quarantined',**actual);receipt,exceptions=check_outputs(out/'actual_quarantined')
 assert receipt['consumer_checks']==dict(nodes=48,edges=844,geometries=19,support_identities=424)
 assert exceptions['quarantined_typed_items']==1 and exceptions['quarantined_mentions']==2
 assert exceptions['items'][0]['qid']=='Q700727' and len(exceptions['items'][0]['occurrences']['occurrence_ids'])==2
 checks['actual_quarantined']=receipt['consumer_checks']
 # Merge only the newly verified source record into current generation_014 for entity support.
 handoff_path=ROOT/'pair_relations_direct_20261101/local_Q700727_ready_0001/HANDOFF.json';handoff=m.read(handoff_path);record=handoff['verified_record']
 assert m.sha(record['path'])==record['sha256'];verified=m.read(record['path']);assert verified['envelope']['requested_qid']=='Q700727' and verified['envelope']['entity']['id']=='Q700727'
 registry=m.read(actual['native_registry']['path']);prior=deepcopy(registry);registry['selected_references']['Q700727']=verified
 assert all(registry['selected_references'][q]==r for q,r in prior['selected_references'].items())
 actual['native_registry']['identity_registry']=write(out/'current_identity_registry_plus_Q700727.json',registry)
 actual['source_receipts']=actual['source_receipts']+[dict(path=str(handoff_path),sha256=m.sha(handoff_path)),record]
 result=m.materialize_components(out/'actual_source_completed',**actual);receipt,exceptions=check_outputs(out/'actual_source_completed')
 assert receipt['consumer_checks']==dict(nodes=49,edges=844,geometries=19,support_identities=424)
 assert exceptions['quarantined_typed_items']==0 and m.read(out/'actual_source_completed/private/count_receipt.json')==actual['count_receipt']
 checks['actual_source_completed']=receipt['consumer_checks']
 report=dict(status='PASS_ISOLATED_DATA_EXCEPTIONS_AND_ACTUAL_THREE_UNIT_SOURCE_COMPLETION',pid=os.getpid(),checks=checks,systemic_hash_and_identity_failure_blocked=True,raw_counts_history_preserved=True,quarantined_occurrence_ids_verified=2,actual_final_exceptions=0,actual_source_completed_refresh_inputs=str(out/'actual_source_completed/private/refresh_inputs.json'),actual_final_receipt=dict(path=result['receipt_path'],sha256=result['receipt_sha256']),no_CPU_or_relation_recomputation=True,all_required_unit_stages_complete=False,publication=False)
 write(HERE/'EXCEPTION_VERIFICATION.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':main()
