"""Resolve exception IDs only through caller-pinned current CPU unit/patch links."""
def attach_occurrences(items, sources, binding, pinned, read, sha):
    if not items:return
    versions={r['decision_version']:r for r in binding};found={(r['qid'],r['entity_group']):[] for r in items}
    def pin(descriptor):
        if sha(descriptor['path'])!=descriptor['sha256']:raise ValueError('Exception occurrence source hash differs')
        pinned[descriptor['path']]=descriptor['sha256'];return read(descriptor['path'])
    def add(decision,version,reference,group=None):
        for key in found:
            if key[0]==decision.get('qid') and (group is None or key[1]==group):
                found[key].append(dict(occurrence_id=decision['occurrence_id'],decision_version=version,source=reference))
    for descriptor in sources:
        document=pin(descriptor)
        if not isinstance(document,dict):continue
        units=document.get('units',[])
        if not isinstance(units,list):continue  # HANDOFF.units is a count, not a unit inventory.
        for entry in units:
            if not isinstance(entry,dict):continue
            if 'unit' in entry and 'outcomes' in entry:
                unit=pin(entry['unit']);version=unit['version'];expected=versions.get(version)
                if expected is None:raise ValueError('Exception occurrence unit version differs')
                from decision_revision_hook import content_hash
                fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
                if [unit['manifest'][k] for k in fields]!=expected['scope'] or content_hash(unit)!=expected['decision_content_sha256']:raise ValueError('Exception occurrence unit frontier differs')
                members={r['occurrence_id']:r for r in unit['occurrences']}
                for decision in unit['decisions']:
                    if decision.get('qid') not in {k[0] for k in found}:continue
                    occurrence=members[decision['occurrence_id']]
                    add(decision,version,dict(unit=entry['unit']),occurrence['entity_group'])
            elif 'policy_receipt' in entry:
                policy=entry['policy_receipt'];receipt=pin(policy);patch=receipt['decision_patch'];decisions=pin(patch);version=decisions['decision_version']
                if version not in versions:raise ValueError('Exception occurrence decision version differs')
                for decision in decisions['decisions']:add(decision,version,dict(decision_patch=patch,policy_receipt=policy))
    for item in items:
        rows={r['occurrence_id']:r for r in found[(item['qid'],item['entity_group'])]}
        if len(rows)==item['occurrences']['mention_count']:
            item['occurrences'].update(occurrence_ids=sorted(rows),verified_references=[rows[k] for k in sorted(rows)])
