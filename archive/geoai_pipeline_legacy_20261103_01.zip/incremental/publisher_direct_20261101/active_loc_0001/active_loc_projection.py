"""Pinned GEO admission before name lookup; raw count/frontier evidence is never changed."""
import gzip,json,hashlib
from pathlib import Path


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def admit_population(counts, geometry_receipt):
    rows=counts['typed_counts']
    if not geometry_receipt.get('active_LOC_projection_required',False):return rows,None,{}
    descriptor=geometry_receipt['source_receipt'];pins={}
    def pinned(item):
        if sha(item['path'])!=item['sha256']:raise ValueError('Active LOC source pin differs')
        pins[item['path']]=item['sha256']
        return json.loads(Path(item['path']).read_text(encoding='utf-8-sig'))
    source=pinned(descriptor)
    snapshot=pinned(source['counts_snapshot'])
    if snapshot['typed_counts']!=rows:raise ValueError('Active LOC source uses a different typed frontier')
    for key in ['GEO_code','GEO_handoff','native_registry']:
        item=source[key]
        if sha(item['path'])!=item['sha256']:raise ValueError('Active LOC provenance pin differs')
        pins[item['path']]=item['sha256']
    decisions=source['decisions'];locs={r['qid'] for r in rows if r['entity_group']=='LOC'}
    if len(decisions)!=len(locs) or {d['qid'] for d in decisions}!=locs:raise ValueError('Active LOC decisions do not cover full LOC population')
    positioned_gate=source.get('active_endpoint_gate') is not None
    for d in decisions:
        expected=d['mask_result']=='INCLUDE'
        if positioned_gate:expected=expected and d.get('position_selected') is True and d.get('position_selection_pending') is False
        if d['entity_type']!='LOC' or d['mask_result'] not in {'INCLUDE','EXCLUDE','UNKNOWN'} or type(d['allow_active_LOC']) is not bool or d['allow_active_LOC']!=expected:
            raise ValueError('Invalid verified LOC admission decision')
    active={d['qid'] for d in decisions if d['allow_active_LOC']}
    admitted=[r for r in rows if r['entity_group']!='LOC' or r['qid'] in active]
    if positioned_gate:
        gate=pinned(source['active_endpoint_gate'])
        expected_ids={r['qid']+'::'+r['entity_group'] for r in admitted}
        if len(gate['active_node_ids'])!=len(expected_ids) or set(gate['active_node_ids'])!=expected_ids:raise ValueError('Verified GEO typed endpoint gate differs')
    if len(admitted)!=source['active_typed_nodes'] or len(active)!=source['active_LOC']:raise ValueError('Active LOC admission totals differ')
    geometry=geometry_receipt['projection']
    if set(geometry['scope_qids'])!=locs:raise ValueError('GEO source scope differs from raw LOC frontier')
    for role,key in [('geography','geography_path'),('geoparquet','geoparquet_path')]:
        item=source['artifacts'][role]
        if item['path']!=geometry[key] or item['sha256']!=geometry['artifact_sha256'][item['path']] or sha(item['path'])!=item['sha256']:
            raise ValueError('Active LOC artifacts differ from verified source')
        pins[item['path']]=item['sha256']
    audit=dict(test_only=source.get('test_only',False),source_receipt=descriptor,active_LOC=sorted(active),inactive_LOC=[d for d in decisions if not d['allow_active_LOC']],
               raw_typed_count=len(rows),active_typed_count=len(admitted),non_LOC_unchanged=True)
    return admitted,audit,pins


def active_views(rows, population):
    qids={r['qid'] for r in population}
    return [r for r in rows if r['source'].split('::')[0] in qids and r['target'].split('::')[0] in qids
            and ('::' not in r['source'] or any(r['source']==p['qid']+'::'+p['entity_group'] for p in population))
            and ('::' not in r['target'] or any(r['target']==p['qid']+'::'+p['entity_group'] for p in population))]


def write_active_geometry(geometry, active, model):
    """Copy selected rows with exact WKB; update only required file-checksum pointers."""
    import geopandas as gpd
    with gzip.open(geometry['geography_path'],'rt',encoding='utf-8') as stream:rows=json.load(stream)
    frame=gpd.read_parquet(geometry['geoparquet_path'])
    selected=frame.loc[frame['place_id'].isin(active)].copy()
    selected.to_parquet(model/'geometries.parquet',index=False)
    digest=sha(model/'geometries.parquet')
    rows=[r for r in rows if r['place_id'] in active]
    for r in rows:
        if r.get('geometry_ref') is not None:r['geometry_ref']=dict(file='geometries.parquet',place_id=r['place_id'],sha256=digest)
    (model/'geography.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0))
    reread=gpd.read_parquet(model/'geometries.parquet')
    if dict(zip(selected.place_id,selected.geometry.to_wkb()))!=dict(zip(reread.place_id,reread.geometry.to_wkb())):raise ValueError('Active geometry WKB changed')
    return dict(geography=str(model/'geography.json.gz'),geoparquet=str(model/'geometries.parquet'))
