"""Regression checks. Fixture GEO decisions are synthetic; actual admission is separately probed."""
import json,sys,gzip
from pathlib import Path
from copy import deepcopy
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path.insert(0,str(PUBLISHER/'component_materializer_0001'));import materialize_components as m
from active_loc_projection import admit_population,active_views,write_active_geometry

def write(p,d):p.write_text(json.dumps(d,indent=2),encoding='utf-8');return dict(path=str(p),sha256=m.sha(p))

def run():
 out=HERE/(sys.argv[1] if len(sys.argv)>1 else 'regression_0001');out.mkdir()
 context_path=ROOT/'orchestration_direct_20261101/count_relation_chain_0001/result.json';context=m.read(context_path)['before']
 state={tuple(row['scope']):versions for row,versions in zip(context['count_receipt']['decision_binding'],context['units'])}
 base=PUBLISHER/'proposed_strength_0001/snapshot_0007_retry_0001'
 counts=context['count_receipt'];relation=context['relation_receipt'];native=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
 locs={r['qid'] for r in counts['projection']['typed_counts'] if r['entity_group']=='LOC'}
 excluded='Q1490';snapshot=write(out/'fixture_counts.json',dict(typed_counts=counts['projection']['typed_counts']))
 paths={role:dict(path=str(base/'model'/name),sha256=m.sha(base/'model'/name)) for role,name in [('geography','geography.json.gz'),('geoparquet','geometries.parquet')]}
 src=dict(test_only=True,counts_snapshot=snapshot,GEO_code=dict(path=str(HERE/'active_loc_projection.py'),sha256=m.sha(HERE/'active_loc_projection.py')),GEO_handoff=snapshot,native_registry=dict(path=str(native),sha256=m.sha(native)),artifacts=paths,active_LOC=len(locs)-1,active_typed_nodes=len(counts['projection']['typed_counts'])-1,decisions=[dict(qid=q,entity_type='LOC',mask_result='EXCLUDE' if q==excluded else 'INCLUDE',allow_active_LOC=q!=excluded) for q in sorted(locs)])
 source=write(out/'fixture_GEO_source.json',src)
 geometry=dict(scope_kind='FULL_LOC_POPULATION',scope_qids=sorted(locs),geography_path=paths['geography']['path'],geoparquet_path=paths['geoparquet']['path'],artifact_sha256={v['path']:v['sha256'] for v in paths.values()},source_binding=dict(count_receipt_sha256=m.content_hash(counts),relation_receipt_sha256=m.content_hash(relation)))
 receipt=dict(decision_binding=m.decision_binding(state),projection=geometry,projection_sha256=m.content_hash(geometry),active_LOC_projection_required=True,source_receipt=source)
 registry=m.read(native);del registry['selected_references'][excluded]
 fixture_registry=write(out/'fixture_identity_registry.json',registry)
 parameters=dict(identity_state=state,count_receipt=counts,relation_receipt=relation,geometry_receipt=receipt,native_registry=dict(path=str(native),sha256=m.sha(native),identity_registry=fixture_registry),source_receipts=[source,snapshot],consumer_root=PUBLISHER/'proposed_strength_0001/consumer')
 # Inactive LOC has no native reference: must never reach the name lookup.
 result=m.materialize_components(out/'inactive_missing_source',**parameters)
 proof=m.read(result['receipt_path']);assert proof['test_only'] is True and result['test_only'] is True
 assert proof['consumer_checks']==dict(nodes=9,edges=72,geometries=4,support_identities=36),proof['consumer_checks']
 assert m.read(out/'inactive_missing_source/private/count_receipt.json')==counts
 assert m.read(out/'inactive_missing_source/private/identity_frontier.json')['units']==list(state.values())
 graph=m.read(out/'inactive_missing_source/graph.json');ids={r['id'] for r in graph['nodes']};qids={r['wikidata_id'] for r in graph['nodes']}
 assert excluded not in qids and all((e['source'] in ids or e['source'] in qids) and (e['target'] in ids or e['target'] in qids) for e in graph['edges'])
 # An active missing source must still fail before creating an output.
 bad=deepcopy(registry);missing=next(q for q in bad['selected_references'] if q in qids);del bad['selected_references'][missing]
 parameters['native_registry']['identity_registry']=write(out/'fixture_active_missing_registry.json',bad)
 try:m.materialize_components(out/'active_missing_source',**parameters)
 except ValueError as e:assert str(e)=='Unsupported missing whole native name/source for accepted identity: '+missing
 else:raise AssertionError('Active missing source accepted')
 assert not (out/'active_missing_source').exists()
 nameless=deepcopy(registry);entity=nameless['selected_references'][missing]['envelope']['entity'];entity['labels']={};entity['aliases']={};entity['sitelinks']={}
 parameters['native_registry']['identity_registry']=write(out/'fixture_active_nameless_registry.json',nameless)
 try:m.materialize_components(out/'active_missing_name',**parameters)
 except ValueError:pass
 else:raise AssertionError('Active missing name accepted')
 assert not (out/'active_missing_name').exists()
 # Non-LOC role sharing an inactive LOC QID is retained.
 extra=deepcopy(counts['projection']);extra['typed_counts'].append(dict(qid=excluded,entity_group='MISC',mention_count=1,page_count=1))
 src['active_typed_nodes']+=1;src['counts_snapshot']=write(out/'fixture_dual_counts.json',dict(typed_counts=extra['typed_counts']));receipt['source_receipt']=write(out/'fixture_dual_GEO.json',src)
 population,_,_=admit_population(extra,receipt);assert any(r['qid']==excluded and r['entity_group']=='MISC' for r in population)
 # Actual 3-unit projection must exactly match independently emitted 844 views.
 b=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001/three_unit_v3_0001/native_projection_0001';manifest=m.read(b/'ordinary_contract_probe_manifest.json')
 actual_counts=m.read(manifest['count_receipt']['path']);actual_relation=m.read(manifest['relation_receipt']['path']);actual_geo=m.read(manifest['geometry_receipt']['path'])
 population,audit,pins=admit_population(actual_counts['projection'],actual_geo);views=active_views(actual_relation['projection']['active_views'],population)
 assert len(population)==49 and len(audit['active_LOC'])==19 and len(views)==844 and views==m.read(b/'active_relation_views.json')
 assert [r['entity_group'] for r in population if r['qid']=='Q700727']==['MISC']
 try:m.materialize_components(out/'actual_three_unit',compact_frontier=manifest['compact_frontier'],count_receipt=actual_counts,relation_receipt=actual_relation,geometry_receipt=actual_geo,native_registry=manifest['native_registry'],source_receipts=manifest['source_receipts'],consumer_root=parameters['consumer_root'])
 except ValueError as e:assert str(e)=='Unsupported missing whole native name/source for accepted identity: Q700727';blocker=str(e)
 else:raise AssertionError('Actual active MISC missing source bypassed')
 assert not (out/'actual_three_unit').exists()
 report=dict(status='PASS_BOUNDED_ACTIVE_LOC_REGRESSION_ACTUAL_CONSUMER_BLOCKED',fixture_consumer=proof['consumer_checks'],inactive_missing_source_off_graph=True,active_missing_source_rejected=True,active_missing_name_rejected=True,non_LOC_retained=True,no_dangling_edges=True,raw_counts_and_history_preserved=True,actual_typed_nodes=49,actual_active_LOC=19,actual_relation_views=844,actual_views_match_verified_projection=True,actual_blocker=blocker,actual_consumer_complete=False,publication=False)
 write(HERE/'verification.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':run()
