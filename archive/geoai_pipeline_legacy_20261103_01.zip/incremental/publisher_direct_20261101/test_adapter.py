"""One small real-frontier acceptance check; run with python -B test_adapter.py."""
import gzip
import json
from pathlib import Path
from consumer_adapter import adapt

ROOT = Path(__file__).resolve().parent.parent
aggregate = json.loads((ROOT / 'integration_direct_20261101/real_handoff_0001/aggregate.json').read_text())
with gzip.open(r'C:\Users\User\.cache\geoai_bigquery_20261018\entity_metadata.json.gz', 'rt', encoding='utf-8') as f:
    metadata = json.load(f)
entities, report = adapt(aggregate, metadata)
assert len(entities) == 10
assert report['accepted_occurrences'] == 30 and report['pending_occurrences'] == 106
assert {e['entity_id'] + '::' + e['type'] for e in entities} == {r['qid'] + '::' + r['entity_group'] for r in aggregate['typed_counts']}
assert next(e for e in entities if e['entity_id'] == 'Q1490')['name'] == metadata['Q1490']['labels']['en']
assert all(not e['entity_id'].startswith('SYN_') for e in entities)
broken = json.loads(json.dumps(aggregate))
broken['typed_counts'][0]['mention_count'] += 1
try:
    adapt(broken, metadata)
except ValueError:
    pass
else:
    raise AssertionError('Mismatched accepted contribution count was not rejected')
print('PASS: 10 typed identities, 30 accepted, 106 pending, native name priority, no SYN, corrupt count rejected')
