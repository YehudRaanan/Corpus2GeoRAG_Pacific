"""Existing synthetic Event-date fixture wired into actual baseline components. No live policy."""
import gzip,json,sys,subprocess
from copy import deepcopy
from pathlib import Path
HERE=Path(__file__).resolve().parent
PUBLISHER=HERE.parent
ROOT=PUBLISHER.parent
sys.path.insert(0,str(PUBLISHER/'component_materializer_0001'))
import materialize_components as m
from decision_revision_hook import decision_binding,content_hash
from GG_Data.pipeline.event_model import event_rows
from event_input import load_event_route,PROCESSOR

def write(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf-8')
def desc(path):return dict(path=str(path),sha256=m.sha(path))
context_path=ROOT/'orchestration_direct_20261101/count_relation_chain_0001/result.json'
context=m.read(context_path)['before']
state={tuple(row['scope']):versions for row,versions in zip(context['count_receipt']['decision_binding'],context['units'])}
base=PUBLISHER/'proposed_strength_0001/snapshot_0007_retry_0001'
geo_paths={str(base/'model'/name):m.sha(base/'model'/name) for name in ['geography.json.gz','geometries.parquet']}
gprojection=dict(scope_kind='FULL_LOC_POPULATION',scope_qids=sorted(r['qid'] for r in context['count_receipt']['projection']['typed_counts'] if r['entity_group']=='LOC'),
 geography_path=str(base/'model/geography.json.gz'),geoparquet_path=str(base/'model/geometries.parquet'),artifact_sha256=geo_paths,
 source_binding=dict(count_receipt_sha256=content_hash(context['count_receipt']),relation_receipt_sha256=content_hash(context['relation_receipt'])),baseline_only=True)
geometry=dict(decision_binding=decision_binding(state),projection=gprojection,projection_sha256=content_hash(gprojection))
native=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
parameters=dict(identity_state=state,count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'],geometry_receipt=geometry,
 native_registry=desc(native),source_receipts=[desc(context_path),desc(native),desc(base/'private/receipt.json')],consumer_root=PUBLISHER/'proposed_strength_0001/consumer')
fixture=HERE/'synthetic_route_0001'
if not fixture.exists():
 fixture.mkdir()
 # The Q1/two P585 values are the existing test_event_model.py synthetic fixture.
 def statement(date):return dict(mainsnak=dict(datatype='time',datavalue=dict(value=dict(time=date,precision=11,calendarmodel='Gregorian'))))
 raw=dict(id='Q1',lastrevid=1,modified='2026-01-01T00:00:00Z',labels={'en':{'value':'Example'}},claims={'P585':[statement('+1945-08-09T00:00:00Z'),statement('+1945-08-06T00:00:00Z')]})
 native_path=fixture/'native.json';write(native_path,dict(Q1=dict(raw_record=raw,revision=1,modified=raw['modified'],source=dict(path='GENERATED_TEST',sha256='0'*64,line=1))))
 projection_path=fixture/'projection.json';write(projection_path,dict(count_receipt=context['count_receipt']))
 inputs=dict(native_evidence=desc(native_path),identity_projection=desc(projection_path),native_registry=desc(native));binding={k:v['sha256'] for k,v in inputs.items()}
 decision=dict(qid='Q1',keep_event=True)
 selection=fixture/'selection_input.json';write(selection,dict(version='synthetic-event-v1',purpose='DEVELOPMENT_PARAMETERIZATION_ONLY_NOT_RUNTIME_APPROVAL',input_binding=binding,decisions=[decision]))
 config=fixture/'scope_input.json';write(config,dict(version='synthetic-scope-v1',purpose='DEVELOPMENT_PARAMETERIZATION_ONLY_NOT_RUNTIME_APPROVAL',input_binding=binding,anchors=[],predicates=[]))
 source=dict(provider='GENERATED_TEST',file='GENERATED_TEST',sha256='0'*64,line=1,record_id='Q1',revision=1,modified=raw['modified'])
 entity,event=event_rows(raw,source,decision);entity['reference_source']='GENERATED_TEST'
 values=dict(entities=[entity],events=[event],scope=dict(candidates=[],opened_records=[],source_pending=[]),selection=dict(decisions=[decision],source_pending=[]))
 artifacts={}
 for name,value in values.items():
  path=fixture/(name+'.json');write(path,value);artifacts[name]=desc(path)
 request=dict(inputs=inputs,event_selection=desc(selection),scope_config=desc(config),previous=None,code_sha256=m.sha(PROCESSOR),
  dependencies={str(ROOT/'event_scope_direct_20261101/event_scope.py'):m.sha(ROOT/'event_scope_direct_20261101/event_scope.py'),str(Path(sys.modules[event_rows.__module__].__file__)):m.sha(Path(sys.modules[event_rows.__module__].__file__))})
 result=dict(artifacts=artifacts,input_binding=binding,input_pins=inputs,identity_decisions_changed=False,event_selection_version='synthetic-event-v1',scope_config_version='synthetic-scope-v1',
  scope_status='EXECUTED_CONFIGURED_SCOPE',event_population_status='MATERIALIZED_SUPPLIED_SELECTION',pending_inputs=[],fixture=True)
 write(fixture/'receipt.json',dict(request=request,result=result))
route=desc(fixture/'receipt.json')
result=m.materialize_components(HERE/'synthetic_consumer_0002',**parameters,event_route=route,event_route_test_only=True)
assert result['status']=='PASS_EVENT_CONSUMER_FIXTURE' and result['test_only'] is True
output=Path(result['receipt_path']).parent.parent
original=m.read(fixture/'events.json')
assert json.loads(gzip.decompress((output/'model/events.json.gz').read_bytes()))==original
assert json.loads(gzip.decompress((output/'model/entities.json.gz').read_bytes()))[-1]==m.read(fixture/'entities.json')[0]
graph=m.read(output/'graph.json');node=next(n for n in graph['nodes'] if n['id']=='Q1::event')
assert node['attributes']==dict(start_date='+1945-08-06T00:00:00Z',end_date='+1945-08-09T00:00:00Z')
assert 'kind' not in node and len(graph['nodes'])==11 and len(graph['edges'])==90
receipt=m.read(result['receipt_path'])
assert receipt['consumer_checks']==dict(nodes=11,edges=90,geometries=5,support_identities=45)
assert receipt['event_route_complete'] is False and receipt['event_selection_version']=='synthetic-event-v1'
assert m.read(output/'private/count_receipt.json')==context['count_receipt']
print('PASS synthetic Event consumer: 11 nodes/90 edges/5 geometries, exact model/provenance/time retained')
