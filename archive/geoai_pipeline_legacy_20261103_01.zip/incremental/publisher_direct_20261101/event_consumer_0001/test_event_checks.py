"""Negative Event gates + fresh readback; no source selection or external calls."""
import gzip,json,sys,subprocess
from copy import deepcopy
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path.insert(0,str(PUBLISHER/'component_materializer_0001'))
import materialize_components as m
from event_input import load_event_route

def desc(path):return dict(path=str(path),sha256=m.sha(path))
fixture=HERE/'synthetic_route_0001';route=desc(fixture/'receipt.json');supplied=m.read(route['path'])
count=m.read(supplied['request']['inputs']['identity_projection']['path'])['count_receipt']
native=supplied['request']['inputs']['native_registry']
args=dict(count_receipt=count,native_registry=native)
valid=load_event_route(route,**args,test_only=True)
assert valid['status']=='VERIFIED_EVENT_CONSUMER_INPUTS' and len(valid['events'])==1
blocked=load_event_route(route,**args)
assert 'MISSING_APPROVED_EVENT_SELECTION_EVIDENCE' in blocked['pending_inputs'] and blocked['consumer_materialized'] is False
blocked=load_event_route(route,**args,approved_event_selection=supplied['request']['event_selection'])
assert 'DEVELOPMENT_SELECTION_NOT_RUNTIME_APPROVAL' in blocked['pending_inputs']
invalid=deepcopy(route);invalid['sha256']='0'*64
try:load_event_route(invalid,**args,test_only=True)
except ValueError:pass
else:raise AssertionError('Wrong Event receipt hash accepted')
invalid_count=deepcopy(count);invalid_count['projection']['decision_version']='STALE'
try:load_event_route(route,count_receipt=invalid_count,native_registry=native,test_only=True)
except ValueError as error:assert 'frontier' in str(error)
else:raise AssertionError('Mixed Event/count frontier accepted')
# Actual source-backed receipt has NO approved selection. It must stay blocked, not complete empty Events.
handoff=m.read(ROOT/'pair_relations_direct_20261101/event_runtime_0001/HANDOFF.json')
actual_route=handoff['actual_receipt'];actual=m.read(actual_route['path'])
actual_projection=m.read(actual['request']['inputs']['identity_projection']['path'])
blocked_actual=load_event_route(actual_route,count_receipt=actual_projection['count_receipt'],native_registry=actual['request']['inputs']['native_registry'])
assert blocked_actual['status']=='BLOCKED_EVENT_CONSUMER_INPUTS'
assert blocked_actual['scope_status']=='PENDING_CONFIGURATION' and blocked_actual['event_population_status']=='PENDING_SELECTION'
assert blocked_actual['event_route_complete'] is False and blocked_actual['consumer_materialized'] is False
# A caller may pass the real blocked receipt into the normal materializer: no successful generation is created.
from occurrence_decisions import SCOPE_FIELDS
state={tuple(v[-1]['manifest'][k] for k in SCOPE_FIELDS):v for v in actual_projection['count_state']}
output=HERE/'actual_blocked_no_generation'
parameters=dict(identity_state=state,count_receipt=actual_projection['count_receipt'],relation_receipt=actual_projection['relation_receipt'],
 geometry_receipt=actual_projection['full_geometry']['receipt'],native_registry=actual['request']['inputs']['native_registry'],
 source_receipts=[actual_route],consumer_root=PUBLISHER/'proposed_strength_0001/consumer',event_route=actual_route)
result=m.materialize_components(output,**parameters)
assert result['status']=='BLOCKED_EVENT_CONSUMER_INPUTS' and not output.exists()
reader='''import gzip,json,sys
from pathlib import Path
root=Path(sys.argv[1]);consumer=Path(sys.argv[2]);sys.path[:0]=[str(consumer),r'D:\\Projects\\GeoAI']
from geo_agent.graph_store import GraphStore
store=GraphStore.from_json(root/'graph.json',model_dir=root/'model')
rows=json.loads(gzip.decompress((root/'model/events.json.gz').read_bytes()))
original=json.loads(Path(sys.argv[3]).read_text())
assert rows==original
assert store.nodes['Q1::event'].attributes==dict(start_date='+1945-08-06T00:00:00Z',end_date='+1945-08-09T00:00:00Z')
assert rows[0]['temporal_evidence']['claims']['P585'][0]['mainsnak']['datavalue']['value']['calendarmodel']=='Gregorian'
assert rows[0]['start_date'][0]['precision']==11 and rows[0]['temporal_evidence']['derived_range']['from']['derived'] is True
print('PASS fresh Event consumer native dates, original precision/calendar, derived marker and raw evidence')
'''
readback=subprocess.run([sys.executable,'-B','-c',reader,str(HERE/'synthetic_consumer_0002'),str(PUBLISHER/'proposed_strength_0001/consumer'),str(fixture/'events.json')],capture_output=True,text=True,check=True)
print(readback.stdout.strip())
report=dict(status='PASS_EVENT_CONSUMER_FIXTURE_AND_ACTUAL_PENDING',synthetic_only=True,event_node='Q1::event',consumer_nodes=11,consumer_edges=90,geometries=5,
 native_time_precision_calendar_provenance_lossless=True,derived_markers_preserved=True,counts_unchanged=True,
 real_receipt_status=blocked_actual['status'],real_pending=blocked_actual['pending_inputs'],real_consumer_materialized=False,
 missing_authority_blocked=True,development_selection_not_runtime_approval=True,stale_version_and_wrong_hash_rejected=True,
 actual_blocked_creates_no_generation=True,publication=False,completed_live_units=0,
 materializer_sha256=m.sha(Path(m.__file__)),event_input_sha256=m.sha(HERE/'event_input.py'))
(HERE/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
