# Event consumer wiring: callable, verified fixture, real inputs still blocked

## Interface

The existing materialize_components(...) keeps all previous keyword arguments and adds three optional keywords:

    event_route={"path": "<RELATIONS Event receipt.json>", "sha256": "<pinned hash>"}
    approved_event_selection={"path": "<existing upstream-approved selection.json>", "sha256": "<pinned hash>"}
    event_route_test_only=False

The read-only admission function is event_consumer_0001/event_input.py::load_event_route(event_route, *, count_receipt, native_registry, approved_event_selection=None, test_only=False). INTEGRATION should pass the route receipt explicitly; omission preserves the old no-Event baseline behavior and does not attest global Event-route completion.

For a real selected route, approved_event_selection must be the EXACT existing selection descriptor consumed by RELATIONS. Supplying this argument conveys caller/upstream authority already established for that artifact; a checksum alone is not semantic approval. PUBLISHER does not choose or score Events or infer WWII relevance, and does not create an approval receipt. No new Event policy or approval question is introduced. The producer selection must retain its actual version and source binding. A DEVELOPMENT-labelled selection cannot be promoted to a real runtime selection by passing the same descriptor.

Real missing configuration, missing approved selection, incomplete selection/source records, PENDING_TYPE or PENDING_GEO returns BLOCKED_EVENT_CONSUMER_INPUTS with exact pending reasons, original route descriptor and false consumer_materialized/event_route_complete/publication. It returns before creating a consumer generation. Existing upstream G6/G7 and Event-selection requirements remain explicit; neither an empty Events file nor a zero selected population is invented as completion.

## What is connected

Verified producer artifacts.entities are appended as their existing event-typed Entity rows, and artifacts.events replaces the formerly unconditional empty Events list. Existing build_graph(entities,events,...) and GraphStore/model_dates perform the existing typed-node/date serialization and model join. Event QIDs can coexist with an existing separate typed node. No occurrence is added to count_receipt, no mention ID is fabricated, no source-only Event gains pair counts, no path becomes a new graph edge, and no LOC geometry is invented. Existing selected native/inverse/default edges and full LOC geometry are unchanged.

Every Entity/Event row is retained losslessly in model/entities.json.gz and model/events.json.gz. Whole native record, exact source provider/file/hash/line/revision/modified, Event selection evidence/version, native classes, all raw time statements, precision/calendar and existing derived-range markers remain. The graph uses the existing scalar date projection; native class QID lists are not reinterpreted as Agent kind labels. The private materialization receipt copies the original Event route receipt, records selection/scope versions and binds all Event inputs/artifacts, fixed processor, serializer/scope dependencies, previous receipt history and the owned admission code hashes. Source records/provenance are compared to their pinned native evidence and the existing event_rows serializer is reproduced; no new date or period-type logic is added.

## Development-only proof

Start command (each materialized generation is immutable; preserve existing outputs):

    contract_fixtures/.venv-bridge/Scripts/python.exe -B publisher_direct_20261101/event_consumer_0001/test_event_consumer.py

The retained current-code generation is synthetic_consumer_0002, with refresh inputs at synthetic_consumer_0002/private/refresh_inputs.json. It reuses Q1 and the two P585 dates from the existing GG_Data.pipeline.test_event_model synthetic fixture. All Event provenance is explicitly GENERATED_TEST; no real record is activated by fixture mode. Its selection is DEVELOPMENT_PARAMETERIZATION_ONLY_NOT_RUNTIME_APPROVAL. No new real anchor, predicate, geographic boundary, period/type rule or acceptance decision is supplied by these tests.

Result: 11 nodes = previous10 plus Q1::event; 90 existing relation views, five existing geometries, 45 support identities. The Event table and added Entity row compare exactly with input values. Graph dates are +1945-08-06T00:00:00Z through +1945-08-09T00:00:00Z; both original P585 values, precision11, original 'Gregorian' calendar string and the existing derived_range marker remain in the model. This is preservation, not a calendar conversion. A separate Python process loads the actual consumer/model and checks these values again.

Fixture materializations have status PASS_EVENT_CONSUMER_FIXTURE, test_only=true and event_route_complete=false. They cannot qualify as completed runtime units. publisher_refresh now explicitly rejects test-only or incomplete Event source receipts before output creation, preventing an intermediate refresh from relabelling a fixture as checkpoint success. Existing prepare_package also rejects the fixture status. No live cadence or publication operation is invoked.

## Actual source result and remaining inputs

The actual descriptor comes from pair_relations_direct_20261101/event_runtime_0001/HANDOFF.json, actual_firstnine_v2_0001/receipt.json, SHA c7b0b1c86c0278f0db16a4ba9fbbc9539b5a036c48a94b3d28caafb653a568d9. Its current pinned identity/count frontier and native registry are verified exactly. It remains PENDING_CONFIGURATION / PENDING_SELECTION, with missing G6 anchors/predicates and Event selection/WWII scope evidence. Passing it through the NORMAL materialize_components entrypoint returned BLOCKED_EVENT_CONSUMER_INPUTS and created no consumer output directory. No approved real Event selection artifact exists in this handoff, so no real Event rows were activated and no full Event completion is claimed. G7 remains an upstream concrete-input gap when LOC inclusion is needed.

Evidence: verification.json; boundary_verification.json; synthetic_consumer_0002/private/{receipt.json,readback.json,event_route_receipt.json}; baseline_compatibility/verification.json. Tests cover wrong Event hash and mixed count frontier rejection; missing authority and development selection blocking; altered native source/precision rejection; exact time/provenance readback; immutable replay; fixture refresh/package rejection before output; and the real pending handoff. Previous complete no-Event baseline still passes with ten nodes,90 views,five geometries and stale-receipt/unsupported raw Event-identity rejection. The raw count branch still does not classify arbitrary accepted entity_group=event rows; source-bound Event additions use the explicit separate route.

Previous implementations are preserved as materialize_before_event.py and refresh_before_event_guard.py. Existing consumer/source generations remain unchanged. Only owned PUBLISHER files were modified. No RELATIONS adapter, INTEGRATION state, plan, DATA, source selection or official consumer changed. No publication/PR/merge, paid work, GPU, external call, dependency installation or nested agent occurred. Live completed-unit count remains zero for this task. No tool denial or uncertain executed action remains. The real consumer action is BLOCKED pending the specific upstream policy/source inputs above; the synthetic wiring work is complete. Backup: Unprotected.
