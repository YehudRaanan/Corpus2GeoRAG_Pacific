"""Test fixtures cannot become completed checkpoints; reject tampered native rows."""
import gzip,json,sys
from copy import deepcopy
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path.insert(0,str(PUBLISHER/'component_materializer_0001'))
import materialize_components as m
from event_input import load_event_route
from publisher_refresh import refresh_snapshot
sys.path.insert(0,str(PUBLISHER/'delivery_0001'))
from delivery_package import prepare_package

def desc(path):return dict(path=str(path),sha256=m.sha(path))
fixture=HERE/'synthetic_route_0001';saved=m.read(fixture/'receipt.json')
count=m.read(saved['request']['inputs']['identity_projection']['path'])['count_receipt'];native=saved['request']['inputs']['native_registry']
for label,role in [('changed_native_source','entities'),('changed_time_precision','events')]:
 folder=HERE/label;folder.mkdir()
 value=m.read(saved['result']['artifacts'][role]['path'])
 if role=='entities':value[0]['raw_reference']['full']['entity']['labels']['en']['value']='Invented name'
 else:value[0]['start_date'][0]['precision']=9
 path=folder/(role+'.json');path.write_text(json.dumps(value),encoding='utf-8')
 receipt=deepcopy(saved);receipt['result']['artifacts'][role]=desc(path)
 path=folder/'receipt.json';path.write_text(json.dumps(receipt),encoding='utf-8')
 try:load_event_route(desc(path),count_receipt=count,native_registry=native,test_only=True)
 except ValueError as error:
  assert 'native' in str(error).lower() or 'source' in str(error).lower()
 else:raise AssertionError('Changed Event raw data/precision accepted')
source=HERE/'synthetic_consumer_0002';inputs=m.read(source/'private/refresh_inputs.json')
baseline=m.read(PUBLISHER/'publisher_refresh_0001/simulation_0002/baseline_inputs.json')
parameters={k:inputs[k] for k in ['frontier','identities','relations','geometries','source_receipts','consumer_root']}
parameters['frontier']=dict(parameters['frontier'],previous_receipt_sha256=baseline['frontier']['previous_receipt_sha256'])
parameters.update({k:baseline[k] for k in ['previous_snapshot','cadence_attempt','completed_at']})
try:refresh_snapshot(HERE/'fixture_refresh_forbidden',**parameters)
except ValueError as error:assert 'Fixture or incomplete Event' in str(error)
else:raise AssertionError('Fixture promoted to successful checkpoint')
assert not (HERE/'fixture_refresh_forbidden').exists()
try:prepare_package(source,HERE/'fixture_package_forbidden',checkpoint_id='not-for-delivery',source_receipt=inputs['receipt_path'],source_receipt_sha256=inputs['receipt_sha256'],consumer_root=inputs['consumer_root'],test_only=False)
except ValueError as error:assert 'No verified materialization receipt' in str(error)
else:raise AssertionError('Fixture prepared as live package')
assert not (HERE/'fixture_package_forbidden').exists()
before={p.relative_to(source).as_posix():(m.sha(p),p.stat().st_mtime_ns) for p in source.rglob('*') if p.is_file()}
# Existing materializer immutability guard precedes any supplied projection read.
try:m.materialize_components(source,identity_state={},count_receipt={},relation_receipt={},geometry_receipt={},native_registry={},source_receipts=[],consumer_root=inputs['consumer_root'])
except ValueError as error:assert 'new owned output' in str(error)
else:raise AssertionError('Existing fixture generation overwritten')
assert before=={p.relative_to(source).as_posix():(m.sha(p),p.stat().st_mtime_ns) for p in source.rglob('*') if p.is_file()}
report=dict(status='PASS_EVENT_LOSSLESS_AND_CHECKPOINT_BOUNDARIES',tampered_raw_source_rejected=True,tampered_precision_rejected=True,
 fixture_refresh_rejected_before_output=True,fixture_package_rejected_before_output=True,immutable_replay_unchanged=True,publication=False)
(HERE/'boundary_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
