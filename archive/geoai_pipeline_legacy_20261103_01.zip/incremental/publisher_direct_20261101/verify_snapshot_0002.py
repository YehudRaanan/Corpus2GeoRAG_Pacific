"""Independent acceptance/readback of the second snapshot; no adapter import."""
import gzip
import hashlib
import json
import sys
from pathlib import Path
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
import geopandas as gpd
from shapely import from_wkb
from geo_agent.graph_store import GraphStore

HERE = Path(__file__).resolve().parent
OUT = HERE / 'snapshot_0002'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

receipt = read(OUT / 'private/receipt.json')
for path, expected in receipt['inputs_sha256'].items():
    assert sha(path) == expected, path
for path, expected in receipt['artifact_sha256'].items():
    assert sha(OUT / path) == expected, path
assert sha(HERE / 'consume_tokyo.py') == receipt['stage_sha256']
assert (OUT / 'graph.json').read_bytes() == (HERE / 'snapshot_0001/graph.json').read_bytes()
for name in ['entities', 'events', 'relations']:
    assert (OUT / ('model/'+name+'.json.gz')).read_bytes() == (HERE / ('snapshot_0001/model/'+name+'.json.gz')).read_bytes()
handoff = read(OUT / 'private/tokyo_handoff.json')
assert (handoff['qid'], handoff['node_id'], handoff['accepted_occurrences']) == ('Q1490', 'Q1490::LOC', 8)
assert handoff['page_id'] == 48975579 and handoff['processing_revision_id'] == 1375061414
assert handoff['decision_version'] == 'first-unit-exact-v1' and handoff['new_selection'] is False
assert handoff['source_object_id'] == 'relation:1543125' and str(handoff['osm_version']) == '239'
raw = read(OUT / 'private/source_osm_row.json')
with gzip.open(handoff['source_file'], 'rt', encoding='utf-8') as stream:
    source = json.load(stream)
rows = [r for r in source['rows'] if str(r['osm_id']) == '1543125']
assert len(rows) == 1 and rows[0] == raw
assert {r['key']:r['value'] for r in raw['all_tags']}['wikidata'] == 'Q1490'
original = from_wkb(bytes.fromhex(raw['geometry_wkb']))
frame = gpd.read_parquet(OUT / 'model/geometries.parquet')
assert len(frame) == 1 and frame.iloc[0]['place_id'] == 'Q1490' and frame.crs.to_epsg() == 4326
actual = frame.geometry.iloc[0]
assert actual.wkb == original.wkb and actual.is_valid and not actual.is_empty and actual.geom_type == 'MultiPolygon'
with gzip.open(OUT / 'model/geography.json.gz', 'rt', encoding='utf-8') as stream:
    geography = json.load(stream)
assert len(geography) == 5
assert [r['place_id'] for r in geography if r['geometry_ref'] is not None] == ['Q1490']
assert next(r for r in geography if r['place_id'] == 'Q1490')['geometry_ref'] == handoff['geometry_ref']
store = GraphStore.from_json(OUT / 'graph.json', model_dir=OUT / 'model')
assert len(store.nodes) == 10 and not store.edges and set(store.geoms) == {'Q1490::LOC'}
assert store.geoms['Q1490::LOC'].wkb == original.wkb
aggregate = read(HERE.parent / 'integration_direct_20261101/real_handoff_0001/aggregate.json')
assert next(r['mention_count'] for r in aggregate['typed_counts'] if (r['qid'],r['entity_group']) == ('Q1490','LOC')) == 8
assert sum(bool(o['decision_values']) for o in aggregate['occurrences']) == 30 and len(aggregate['occurrences']) == 136
result = dict(status='PASS_INDEPENDENT_SNAPSHOT_0002_READBACK', nodes=10, edges=0,
    geometry_rows=1, geometry_nodes=['Q1490::LOC'], locations_without_geometry=4,
    geometry_bound_accepted_occurrences=8, accepted_occurrences=30, pending_occurrences=106,
    native_wkb_exact=True, source_object_id='relation:1543125', osm_version=239,
    graph_byte_identical=True, snapshot_0001_preserved=True, receipt_sha256=sha(OUT / 'private/receipt.json'),
    verification_code_sha256=sha(Path(__file__)), publication=False)
(OUT / 'private/independent_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
