"""First sealed real-unit consumer adapter. Offline development only.
Example: .venv-bridge/Scripts/python.exe -B consumer_adapter.py
"""
import gzip
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
HANDOFF = ROOT / 'integration_direct_20261101/real_handoff_0001'
METADATA = Path(r'C:\Users\User\.cache\geoai_bigquery_20261018\entity_metadata.json.gz')
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def adapt(aggregate, metadata):
    """Use accepted source decisions only; no pending-to-SYN conversion."""
    names, counts = {}, Counter()
    accepted = 0
    for occurrence in aggregate['occurrences']:
        if occurrence['identity_conflict']:
            raise ValueError('Conflicting identity frontier')
        if not occurrence['decision_values']:
            continue
        if len(occurrence['decision_values']) != 1:
            raise ValueError('Multiple accepted identities')
        qid = occurrence['decision_values'][0]
        supports = [s for s in occurrence['supports'] if s['decision'] and s['decision']['qid'] == qid]
        kinds = {s['member']['entity_group'] for s in supports}
        if len(kinds) != 1 or next(iter(kinds)) not in {'LOC', 'ORG', 'PER'}:
            raise ValueError('Unsupported real-unit type')
        key = qid, next(iter(kinds))
        # Original names remain private evidence; cached native labels supply name priority.
        names.setdefault(key, set()).update(s['member']['word'] for s in supports)
        counts[key] += 1
        accepted += 1
    expected = {(r['qid'], r['entity_group']): r['mention_count'] for r in aggregate['typed_counts']}
    if dict(counts) != expected:
        raise ValueError('Accepted contribution counts differ')
    entities, mapping = [], []
    for (qid, kind), originals in sorted(names.items()):
        record = metadata.get(qid) or {}
        labels = record.get('labels') or {}
        name = labels.get('en') or labels.get('ja')
        if not isinstance(name, str) or not name.strip():
            raise ValueError('Required native label unavailable; fallback availability unverified: ' + qid)
        aliases = record.get('aliases') or []
        if not isinstance(aliases, list) or any(not isinstance(a, str) for a in aliases):
            raise ValueError('Unsupported aliases: ' + qid)
        entities.append(dict(entity_id=qid, type=kind, name=name, aliases=aliases))
        mapping.append(dict(entity_id=qid, type=kind, node_id=qid+'::'+kind,
            name_source='cached Wikidata en' if labels.get('en') else 'cached Wikidata ja',
            source_revision=record.get('revision'), original_names=sorted(originals),
            mention_count=counts[qid, kind], missing_required_graph_fields=[],
            unavailable_source_fields=['full native claims/ranks/qualifiers/references'] +
                (['selected source-backed geometry'] if kind == 'LOC' else [])))
    return entities, dict(accepted_occurrences=accepted,
        pending_occurrences=len(aggregate['occurrences'])-accepted, identity_mapping=mapping,
        missingness='Native relation population and LOC geometry not supplied; empty output is partial coverage, not a negative source assertion.',
        canonical_full_entity_model=False)


def main():
    from GG_Data.pipeline.graph_export import build_graph
    from geo_agent.graph_store import GraphStore
    import geopandas as gpd
    import pandas as pd
    receipt = json.loads((HANDOFF / 'receipt.json').read_text())
    pinned_receipt = digest(HANDOFF / 'receipt.json')
    inputs = {str(HANDOFF / 'receipt.json'): pinned_receipt}
    for relative, expected in receipt['output_sha256'].items():
        path = HANDOFF / relative
        if digest(path) != expected:
            raise ValueError('Handoff artifact changed: ' + relative)
        inputs[str(path)] = expected
    metadata_pin = '0032e97cf9af90f56dae231071dbdd2bed8d9c379708a029c4a53b407a9378f8'
    if digest(METADATA) != metadata_pin:
        raise ValueError('Metadata source hash changed')
    inputs[str(METADATA)] = metadata_pin
    protected = [Path(r'D:\Projects\GeoAI\GG_Data\pipeline\graph_export.py'),
        Path(r'D:\Projects\GeoAI\GG_Data\pipeline\graph_contract.py'),
        Path(r'D:\Projects\GeoAI\Agent\geo_agent\graph_store.py'),
        Path(r'D:\Projects\GeoAI\Agent\geo_agent\model_dates.py')]
    inputs.update({str(p): digest(p) for p in protected})
    aggregate = json.loads((HANDOFF / 'aggregate.json').read_text())
    with gzip.open(METADATA, 'rt', encoding='utf-8') as stream:
        entities, gaps = adapt(aggregate, json.load(stream))
    if (len(entities), gaps['accepted_occurrences'], gaps['pending_occurrences']) != (10, 30, 106):
        raise ValueError('Unexpected first-unit frontier')
    graph, export_report = build_graph(entities, [], [], [], [], dict(
        schema_version='test', relation_map_version='relation-map-v2.1.2',
        release_status='TEST', scope='one sealed real unit; accepted identities only'))
    output = HERE / 'snapshot_0001'
    output.mkdir()  # Never overwrite a previous generation.
    model = output / 'model'
    model.mkdir()
    for name, rows in [('entities', entities), ('events', []), ('relations', []),
        ('geography', [dict(place_id=e['entity_id'], geometry_ref=None) for e in entities if e['type'] == 'LOC'])]:
        (model / (name+'.json.gz')).write_bytes(gzip.compress(json.dumps(rows).encode(), mtime=0))
    # No accepted geometry was supplied. A typed empty GeoParquet creates no geometry facts.
    gpd.GeoDataFrame({'place_id': pd.Series(dtype='str')}, geometry=gpd.GeoSeries([], crs='EPSG:4326')).to_parquet(model / 'geometries.parquet', index=False)
    (output / 'graph.json').write_text(json.dumps(graph, indent=2), encoding='utf-8')
    store = GraphStore.from_json(output / 'graph.json', model_dir=model)
    assert len(store.nodes) == 10 and not store.edges and not store.geoms
    assert all(not ({'geometry', 'geometry_ref', 'status'} & n.keys()) for n in graph['nodes'])
    assert all(digest(path) == sha for path, sha in inputs.items())
    files = {p.relative_to(output).as_posix(): digest(p) for p in output.rglob('*') if p.is_file()}
    private = output / 'private'
    private.mkdir()
    (private / 'missingness.json').write_text(json.dumps(gaps, indent=2), encoding='utf-8')
    result = dict(status='PASS_LOCAL_PARTIAL_CONSUMER_LOAD', nodes=10, edges=0,
        geometry_rows=0, locations_without_geometry=sum(e['type']=='LOC' for e in entities),
        accepted_occurrences=30, pending_occurrences=106, publication=False,
        inputs_sha256=inputs, artifact_sha256=files,
        missingness_sha256=digest(private / 'missingness.json'),
        adapter_sha256=digest(Path(__file__)), backup_status='Unprotected')
    (private / 'receipt.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in {'inputs_sha256','artifact_sha256'}}, indent=2))


if __name__ == '__main__':
    main()
