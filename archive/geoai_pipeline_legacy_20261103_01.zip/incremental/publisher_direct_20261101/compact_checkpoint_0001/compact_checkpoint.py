"""Checkpoint-only assembly from pinned compact C3 summaries; no per-unit history input."""
import hashlib,json,math,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent
sys.path.insert(0,str(PUBLISHER/'component_materializer_0001'))
from materialize_components import content_hash

def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def pinned(descriptor):
 if sha(descriptor['path'])!=descriptor['sha256']:raise ValueError('Compact checkpoint input hash differs')
 return read(descriptor['path'])

def _translate_c3(counts):
 if counts['frontier_sha256']!=content_hash(counts['frontier']):raise ValueError('C3 exported frontier hash differs')
 fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
 binding=[dict(scope=[head['scope'][k] for k in fields],decision_version=head['decision_version'],decision_content_sha256=head['contribution_sha256']) for head in counts['frontier']]
 binding.sort(key=lambda row:tuple(row['scope']))
 projection={k:counts[k] for k in ['identity_counts','typed_counts','physical_pages','pending_occurrences','explicit_unmatched_occurrences','conflicted_occurrences']}
 if 'pairs' in counts:projection['pairs']=counts['pairs']
 projection.update(decision_version='sha256:'+counts['frontier_sha256'],retained_occurrences=counts['unique_occurrences'],accepted_occurrences=sum(row['mention_count'] for row in counts['identity_counts']))
 return binding,projection

def verify_compact_frontier(descriptor,count_receipt,relation_receipt,geometry_receipt):
 frontier=pinned(descriptor)
 if frontier.get('schema')!='geoai-compact-frontier-v1' or type(frontier.get('test_only')) is not bool:raise ValueError('Explicit compact frontier schema/test flag required')
 if any(k in frontier for k in ['units','identity_state','history','occurrences']):raise ValueError('Compact frontier must contain heads/references only')
 binding=frontier['decision_binding'];scopes=[tuple(row['scope']) for row in binding]
 if not binding or len(set(scopes))!=len(scopes) or scopes!=sorted(scopes):raise ValueError('Unique sorted active frontier heads required')
 if any(len(row['scope'])!=6 or not row['decision_version'] or len(row['decision_content_sha256'])!=64 for row in binding):raise ValueError('Malformed current decision binding')
 for receipt in [count_receipt,relation_receipt,geometry_receipt]:
  if receipt['decision_binding']!=binding or receipt['projection_sha256']!=content_hash(receipt['projection']):raise ValueError('Compact projection frontier/content differs')
 counts=count_receipt['projection']
 if counts['decision_version']!=frontier['version']:raise ValueError('Compact frontier version differs')
 if 'upstream_counts' in count_receipt:
  expected_binding,expected_projection=_translate_c3(pinned(count_receipt['upstream_counts']))
  if binding!=expected_binding or counts!=expected_projection:raise ValueError('Compact projection differs from pinned C3 export')
 elif not frontier['test_only']:raise ValueError('Real compact checkpoint requires a pinned C3 counts snapshot')
 if any(k in counts for k in ['occurrence_ids','pending_evidence','identity_state','units','history']):raise ValueError('Compact count export cannot carry raw occurrence/history bodies')
 typed=counts['typed_counts'];identities=counts['identity_counts'];byqid={row['qid']:row for row in identities}
 if len(byqid)!=len(identities) or len({(r['qid'],r['entity_group']) for r in typed})!=len(typed):raise ValueError('Repeated compact identity count')
 for row in typed+identities:
  if any(type(row[k]) is not int or row[k]<=0 for k in ['mention_count','page_count']) or row['page_count']>row['mention_count']:raise ValueError('Invalid compact mention/page count')
 if {r['qid'] for r in typed}!=set(byqid):raise ValueError('Typed/identity count populations differ')
 grouped={qid:[] for qid in byqid}
 for row in typed:grouped[row['qid']].append(row)
 for qid,row in byqid.items():
  selected=grouped[qid]
  if sum(r['mention_count'] for r in selected)!=row['mention_count'] or not max(r['page_count'] for r in selected)<=row['page_count']<=sum(r['page_count'] for r in selected):raise ValueError('Compact typed identity totals differ')
 if counts['accepted_occurrences']!=sum(r['mention_count'] for r in identities):raise ValueError('Compact accepted count differs')
 for pair in counts.get('pairs',[]):
  n=pair['shared_page_count'];a=byqid[pair['source_qid']]['page_count'];b=byqid[pair['target_qid']]['page_count']
  if type(n) is not int or not 0<=n<=min(a,b) or (pair['source_page_count'],pair['target_page_count'])!=(a,b) or not math.isclose(pair['source_strength'],n/a) or not math.isclose(pair['target_strength'],n/b):raise ValueError('Compact physical-page denominator differs')
 for view in relation_receipt['projection'].get('active_views',[]):
  if view.get('kind')!='CO_MENTIONED':continue
  n=view['shared_page_count'];a=byqid[view['source']]['page_count'];b=byqid[view['target']]['page_count']
  if type(n) is not int or not 0<n<=min(a,b) or (view['source_page_count'],view['target_page_count'])!=(a,b) or not math.isclose(view['directional_strength'],n/a):raise ValueError('Compact co-occurrence support denominator differs')
 refs=frontier['source_receipts']
 if not refs:raise ValueError('Verified C3 export/source receipt references required')
 pins={str(Path(descriptor['path']).resolve()):descriptor['sha256']}
 for source in refs:
  if sha(source['path'])!=source['sha256']:raise ValueError('C3 source/export receipt changed')
  pins[str(Path(source['path']).resolve())]=source['sha256']
 return frontier,pins

def materialize_compact_checkpoint(output_dir,*,manifest,consumer_root):
 """Caller invokes only at checkpoint/smoke; this function never checks or bypasses cadence."""
 spec=pinned(manifest)
 if spec.get('schema')!='geoai-compact-checkpoint-v1':raise ValueError('Unsupported compact checkpoint manifest')
 required=['compact_frontier','count_receipt','relation_receipt','geometry_receipt','native_registry']
 loaded={name:pinned(spec[name]) for name in required[:-1]}
 if sha(spec['native_registry']['path'])!=spec['native_registry']['sha256']:raise ValueError('Compact native source registry differs')
 sources=list(spec['source_receipts'])+[manifest]+[spec[name] for name in required[:-1]]
 if not spec['source_receipts']:raise ValueError('Checkpoint source receipts required')
 from materialize_components import materialize_components
 optional={name:spec[name] for name in ['event_route','approved_event_selection','approved_mask_result'] if name in spec}
 return materialize_components(output_dir,identity_state=None,compact_frontier=spec['compact_frontier'],
  count_receipt=loaded['count_receipt'],relation_receipt=loaded['relation_receipt'],geometry_receipt=loaded['geometry_receipt'],
  native_registry=spec['native_registry'],source_receipts=sources,consumer_root=consumer_root,**optional)

def export_c3_checkpoint_counts(output_dir,*,counts_snapshot,source_receipts,test_only=False):
 """Translate the actual C3 counts export; pairs remain optional and no histories are read."""
 output=Path(output_dir).resolve()
 if output.exists() or not output.is_relative_to(PUBLISHER.resolve()):raise ValueError('Use a new owned compact count export directory')
 counts=pinned(counts_snapshot)
 binding,projection=_translate_c3(counts)
 version=projection['decision_version']
 frontier=dict(schema='geoai-compact-frontier-v1',version=version,decision_binding=binding,test_only=test_only,source_receipts=list(source_receipts)+[counts_snapshot])
 receipt=dict(decision_binding=binding,projection=projection,projection_sha256=content_hash(projection),upstream_counts=counts_snapshot)
 output.mkdir();frontier_path=output/'compact_frontier.json';counts_path=output/'count_receipt.json'
 for path,value in [(frontier_path,frontier),(counts_path,receipt)]:path.write_text(json.dumps(value,indent=2),encoding='utf-8')
 return dict(compact_frontier=dict(path=str(frontier_path),sha256=sha(frontier_path)),count_receipt=dict(path=str(counts_path),sha256=sha(counts_path)),decision_version=version)
