"""Same compact count translation, new versioned allowance for the approved C counts root."""
import json
from pathlib import Path
from compact_checkpoint import sha,pinned,_translate_c3,content_hash
PUBLISHER=Path(__file__).resolve().parents[1]
C_COUNT_ROOT=Path('C:/Users/User/Documents/Codex/2026-11-01/task-4/downstream_stage_outputs/counts').resolve()
COMPACT_BASE=Path(sha.__code__.co_filename).resolve()

def export_c3_checkpoint_counts(output_dir,*,counts_snapshot,source_receipts,test_only=False):
 output=Path(output_dir).resolve()
 if output.exists() or not any(output.is_relative_to(r) for r in [PUBLISHER,C_COUNT_ROOT]):raise ValueError('Use a new owned compact count export directory')
 counts=pinned(counts_snapshot);binding,projection=_translate_c3(counts);version=projection['decision_version']
 frontier=dict(schema='geoai-compact-frontier-v1',version=version,decision_binding=binding,test_only=test_only,source_receipts=list(source_receipts)+[counts_snapshot])
 receipt=dict(decision_binding=binding,projection=projection,projection_sha256=content_hash(projection),upstream_counts=counts_snapshot)
 output.mkdir();frontier_path=output/'compact_frontier.json';counts_path=output/'count_receipt.json'
 for path,value in [(frontier_path,frontier),(counts_path,receipt)]:path.write_text(json.dumps(value,indent=2),encoding='utf-8')
 return dict(compact_frontier=dict(path=str(frontier_path),sha256=sha(frontier_path)),count_receipt=dict(path=str(counts_path),sha256=sha(counts_path)),decision_version=version)
