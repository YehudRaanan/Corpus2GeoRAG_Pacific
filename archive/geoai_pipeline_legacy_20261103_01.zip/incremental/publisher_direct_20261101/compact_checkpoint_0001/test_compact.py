"""Compact C3 interface + consumer fixture; no bulk/policy/publication execution."""
import json,sys
from copy import deepcopy
from pathlib import Path
from compact_checkpoint import materialize_compact_checkpoint,export_c3_checkpoint_counts,verify_compact_frontier,pinned,sha
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path.insert(0,str(PUBLISHER/'component_materializer_0001'))
from materialize_components import read,content_hash,decision_binding

def write(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf-8')
def desc(path):return dict(path=str(path),sha256=sha(path))
c3=ROOT/'pair_relations_direct_20261101/compact_unit_store_0001'
export=export_c3_checkpoint_counts(HERE/'actual_C3_fixture_export_0002',counts_snapshot=desc(c3/'fixture_counts.json'),source_receipts=[desc(c3/'verification.json')],test_only=True)
c3_counts=pinned(export['count_receipt']);assert c3_counts['projection']['physical_pages']==2 and c3_counts['projection']['retained_occurrences']==4
assert len(pinned(export['compact_frontier'])['decision_binding'])==2
no_pairs=deepcopy(read(c3/'fixture_counts.json'));no_pairs.pop('pairs',None)
no_pair_path=HERE/'C3_no_pairs_fixture.json';write(no_pair_path,no_pairs)
no_pair_export=export_c3_checkpoint_counts(HERE/'C3_optional_pairs_0001',counts_snapshot=desc(no_pair_path),source_receipts=[desc(c3/'verification.json')],test_only=True)
assert 'pairs' not in pinned(no_pair_export['count_receipt'])['projection']
# Existing real-source consumer baseline becomes a labelled compact fixture, never a live lexical result.
context_path=ROOT/'orchestration_direct_20261101/count_relation_chain_0001/result.json';context=read(context_path)['before']
base=PUBLISHER/'proposed_strength_0001/snapshot_0007_retry_0001';native=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
case=HERE/'consumer_inputs_0002';case.mkdir()
counts=deepcopy(context['count_receipt'])
for key in ['occurrence_ids','pending_evidence','history_versions']:counts['projection'].pop(key,None)
counts['projection_sha256']=content_hash(counts['projection'])
relations=deepcopy(context['relation_receipt']);relations['projection']['counts']=counts['projection'];relations['projection']['input_binding']['count_receipt_sha256']=content_hash(counts);relations['projection_sha256']=content_hash(relations['projection'])
geometry_projection=dict(scope_kind='FULL_LOC_POPULATION',scope_qids=sorted(r['qid'] for r in counts['projection']['typed_counts'] if r['entity_group']=='LOC'),
 geography_path=str(base/'model/geography.json.gz'),geoparquet_path=str(base/'model/geometries.parquet'),artifact_sha256={str(base/'model'/name):sha(base/'model'/name) for name in ['geography.json.gz','geometries.parquet']},
 source_binding=dict(count_receipt_sha256=content_hash(counts),relation_receipt_sha256=content_hash(relations)),baseline_only=True)
geometry=dict(decision_binding=counts['decision_binding'],projection=geometry_projection,projection_sha256=content_hash(geometry_projection))
source=case/'fixture_source_receipt.json';write(source,dict(status='FIXTURE_ONLY_NOT_CPU_TRIGRAM_RUN',source_context=desc(context_path)))
frontier=dict(schema='geoai-compact-frontier-v1',version=counts['projection']['decision_version'],decision_binding=counts['decision_binding'],test_only=True,source_receipts=[desc(source)])
for name,value in [('compact_frontier',frontier),('count_receipt',counts),('relation_receipt',relations),('geometry_receipt',geometry)]:write(case/(name+'.json'),value)
manifest=dict(schema='geoai-compact-checkpoint-v1',**{name:desc(case/(name+'.json')) for name in ['compact_frontier','count_receipt','relation_receipt','geometry_receipt']},native_registry=desc(native),source_receipts=[desc(source)])
path=case/'checkpoint_manifest.json';write(path,manifest)
result=materialize_compact_checkpoint(HERE/'consumer_fixture_0002',manifest=desc(path),consumer_root=PUBLISHER/'proposed_strength_0001/consumer')
assert result['status']=='PASS_COMPACT_CHECKPOINT_FIXTURE' and result['test_only'] is True
output=Path(result['receipt_path']).parent.parent;receipt=read(result['receipt_path'])
assert receipt['consumer_checks']==dict(nodes=10,edges=90,geometries=5,support_identities=45)
identity=read(output/'private/identity_frontier.json')
assert 'units' not in identity and 'history' not in identity and len((output/'private/identity_frontier.json').read_bytes())<2048
assert read(output/'graph.json')==read(PUBLISHER/'component_materializer_0001/baseline_0003/graph.json')
assert sha(output/'model/geometries.parquet')==sha(base/'model/geometries.parquet')
# Adversarial compact data cannot acquire a success receipt by keeping stale content hashes.
wrong=deepcopy(relations);wrong['decision_binding'][0]['decision_version']='STALE'
try:verify_compact_frontier(desc(case/'compact_frontier.json'),counts,wrong,geometry)
except ValueError:pass
else:raise AssertionError('Mixed compact frontier accepted')
bad=deepcopy(counts);bad['projection']['pairs'][0]['source_page_count']+=1;bad['projection_sha256']=content_hash(bad['projection'])
try:verify_compact_frontier(desc(case/'compact_frontier.json'),bad,relations,geometry)
except ValueError:pass
else:raise AssertionError('Wrong page denominator accepted')
report=dict(status='PASS_C4_COMPACT_CHECKPOINT_FIXTURE',actual_C3_snapshot_translated=True,C3_physical_pages=2,C3_active_heads=2,
 no_identity_state_or_history_required=True,identity_frontier_bytes=(output/'private/identity_frontier.json').stat().st_size,
 consumer_checks=receipt['consumer_checks'],graph_and_geometry_unchanged=True,stale_frontier_and_denominator_rejected=True,
 checkpoint_assembly_only=True,test_only=True,publication=False,receipt=desc(Path(result['receipt_path'])),refresh_inputs=str(output/'private/refresh_inputs.json'))
write(HERE/'verification.json',report);print(json.dumps(report,indent=2))
