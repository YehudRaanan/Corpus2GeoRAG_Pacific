"""Minimal local proposed-snapshot refresh interface; python -B publisher_refresh.py runs the isolated baseline check."""
import hashlib,json,sys
from datetime import datetime,timedelta,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
PUBLISHER=HERE.parent
ROOT=PUBLISHER.parent

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def refresh_snapshot(output_dir, *, frontier, identities, relations, geometries, source_receipts,
                     previous_snapshot, cadence_attempt, completed_at, consumer_root):
    """Refresh only caller-pinned versions from existing verified proposed snapshot receipts.

    Each component is {version, decision_version, artifacts:{role:absolute_path}}.
    Each named source receipt is {path, sha256, artifact_root}; artifacts must be
    covered by its existing artifact_sha256 map. frontier pins the three accepted
    versions and previous_receipt_sha256. This function never selects latest versions.
    """
    import shutil,subprocess
    output=Path(output_dir).resolve()
    previous=Path(previous_snapshot).resolve()
    consumer=Path(consumer_root).resolve()
    if not output.is_relative_to(PUBLISHER.resolve()) or output==previous or output.exists():
        raise ValueError('Use a new owned publisher output directory')
    if sha(previous/'private/receipt.json')!=frontier['previous_receipt_sha256']:
        raise ValueError('Stale previous-snapshot receipt')
    expected=dict(identities=frontier['identity_version'],relations=frontier['relation_version'],geometries=frontier['geometry_version'])
    components=dict(identities=identities,relations=relations,geometries=geometries)
    for name,component in components.items():
        if component['version']!=expected[name] or component['decision_version']!=frontier['identity_version']:
            raise ValueError('Mixed/stale component version: '+name)
    attempt_path=Path(cadence_attempt['path'])
    if sha(attempt_path)!=cadence_attempt['sha256']:raise ValueError('Cadence attempt hash differs')
    attempt=read(attempt_path)
    if not attempt.get('simulation') or not attempt['decision']['due']:raise ValueError('Due simulation attempt required')
    completed=datetime.fromisoformat(completed_at) if isinstance(completed_at,str) else completed_at
    if completed.utcoffset() is None or completed<datetime.fromisoformat(attempt['decision_time']):
        raise ValueError('Use an aware success time after the attempt')
    pinned={str(attempt_path):cadence_attempt['sha256']}
    proofs={}
    cached={}
    for name,source in source_receipts.items():
        path=Path(source['path']).resolve()
        key=(str(path),source['sha256'])
        if key not in cached:
            if sha(path)!=source['sha256']:raise ValueError('Source receipt hash differs: '+name)
            receipt=read(path)
            if not receipt.get('proposed_contract') or receipt.get('decision_version')!=frontier['identity_version']:
                raise ValueError('Source receipt identity/contract version differs')
            artifact_root=Path(source['artifact_root']).resolve()
            if not receipt.get('artifact_sha256'):raise ValueError('Source receipt has no persisted artifact hashes')
            for relative,digest in receipt['artifact_sha256'].items():
                artifact=(artifact_root/relative).resolve()
                if not artifact.is_relative_to(artifact_root) or sha(artifact)!=digest:
                    raise ValueError('Source artifact differs: '+relative)
                pinned[str(artifact)]=digest
            for artifact,digest in receipt.get('inputs_sha256',{}).items():
                if sha(artifact)!=digest:raise ValueError('Source provenance differs: '+artifact)
                pinned[artifact]=digest
            pinned[str(path)]=source['sha256']
            cached[key]=(receipt,artifact_root)
        proofs[name]=cached[key]
    for name,component in components.items():
        receipt,artifact_root=proofs[name]
        for role,path in component['artifacts'].items():
            path=Path(path).resolve()
            if not path.is_relative_to(artifact_root):raise ValueError('Component leaves its receipt root')
            expected_hash=receipt['artifact_sha256'].get(path.relative_to(artifact_root).as_posix())
            if expected_hash is None or sha(path)!=expected_hash:raise ValueError('Unbound component artifact: '+role)
        if name=='relations' and receipt.get('pair_projection_version')!=expected[name]:
            raise ValueError('Stale source relation projection')
        if name=='geometries' and 'sha256:'+sha(component['artifacts']['geoparquet'])!=expected[name]:
            raise ValueError('Stale source geometry projection')
    consumer_pins=proofs['relations'][0].get('consumer_copy_sha256',{})
    if not consumer_pins:raise ValueError('Verified proposed consumer copy required')
    for original,digest in consumer_pins.items():
        local=consumer/'geo_agent'/Path(original).name
        if sha(local)!=digest:raise ValueError('Consumer copy differs from verified source')
        pinned[str(local)]=digest
    previous_pins={str(path):sha(path) for path in previous.rglob('*') if path.is_file()}
    pinned.update(previous_pins)
    source_graph=read(identities['artifacts']['graph'])
    relation_graph=read(relations['artifacts']['graph'])
    graph=dict(metadata=relation_graph['metadata'],relation_catalog=relation_graph['relation_catalog'],
               nodes=source_graph['nodes'],edges=relation_graph['edges'])
    # Preserve exact existing field vocabulary; geometry remains in its separate model.
    output.mkdir()
    model=output/'model';model.mkdir()
    private=output/'private';private.mkdir()
    def write(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf-8')
    write(output/'graph.json',graph)
    for role,filename in [('entities','entities.json.gz'),('events','events.json.gz')]:
        shutil.copyfile(identities['artifacts'][role],model/filename)
    for role,filename in [('relations','relations.json.gz'),('cooccurrence_support','cooccurrence_support.json.gz')]:
        shutil.copyfile(relations['artifacts'][role],model/filename)
    for role,filename in [('geography','geography.json.gz'),('geoparquet','geometries.parquet')]:
        shutil.copyfile(geometries['artifacts'][role],model/filename)
    shutil.copyfile(relations['artifacts']['pair_views'],private/'pair_views.json')
    for name,source in source_receipts.items():shutil.copyfile(source['path'],private/(name+'_source_receipt.json'))
    write(private/'frontier.json',dict(frontier=frontier,components=components,source_receipts=source_receipts,
        previous_snapshot=str(previous),previous_snapshot_sha256=previous_pins,proposed_contract=True,daniel_approval='not recorded'))
    files={path.relative_to(output).as_posix():sha(path) for path in output.rglob('*') if path.is_file()}
    reader = """import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);consumer=Path(sys.argv[2]);project=Path(sys.argv[3])
sys.path[:0]=[str(consumer),str(project)]
from geo_agent.graph_store import GraphStore
import geo_agent.graph_store as module
assert Path(module.__file__).resolve()==(consumer/'geo_agent/graph_store.py').resolve()
for name,expected in json.loads(sys.stdin.read()).items():
 with (root/name).open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
store=GraphStore.from_json(root/'graph.json',model_dir=root/'model')
print(json.dumps(dict(nodes=len(store.nodes),edges=len(store.edges),geometries=len(store.geoms),support_identities=store.schema()['assertion_count'],strength_query_views=sum('strength' in store.summarize_edge(e) for e in store.edges))))
"""
    process=subprocess.run([sys.executable,'-B','-c',reader,str(output),str(consumer),r'D:\Projects\GeoAI'],
        input=json.dumps(files),capture_output=True,text=True,check=True,timeout=60)
    checks=json.loads(process.stdout)
    if checks['nodes']!=len(graph['nodes']) or checks['edges']!=len(graph['edges']):raise ValueError('Consumer population differs')
    if not all(sha(path)==digest for path,digest in pinned.items()):raise ValueError('Source changed during refresh')
    write(private/'readback.json',dict(status='PASS_FRESH_CONSUMER_AND_ARTIFACT_READBACK',checks=checks,verified_sha256=files))
    # This final receipt is written only after all source, consumer and fresh readback checks.
    receipt=dict(status='SUCCESS_LOCAL_CHECKPOINT_SIMULATION',simulation=True,proposed_contract=True,
        daniel_approval='not recorded',attempt_sha256=cadence_attempt['sha256'],completed_at=completed.isoformat(),
        decision_version=frontier['identity_version'],frontier=frontier,consumer_checks=checks,
        source_receipts=source_receipts,source_sha256=pinned,refresh_code_sha256=sha(Path(__file__)),
        artifact_sha256={str(path):sha(path) for path in output.rglob('*') if path.is_file()},publication=False)
    receipt_path=private/'success_receipt.json'
    write(receipt_path,receipt)
    return dict(status=receipt['status'],receipt_path=str(receipt_path),receipt_sha256=sha(receipt_path),consumer_checks=checks)



def self_check():
    from copy import deepcopy
    sys.path.insert(0,str(PUBLISHER/'cadence_caller_0001'))
    from cadence_caller import initialize,evaluate,confirm,save
    base=PUBLISHER/'proposed_strength_0001/snapshot_0007_retry_0001'
    receipt=read(base/'private/receipt.json')
    frontier=dict(identity_version=receipt['decision_version'],relation_version=receipt['pair_projection_version'],
        geometry_version='sha256:'+sha(base/'model/geometries.parquet'),previous_receipt_sha256=sha(base/'private/receipt.json'))
    def component(version,artifacts):return dict(version=version,decision_version=frontier['identity_version'],artifacts={k:str(base/v) for k,v in artifacts.items()})
    identities=component(frontier['identity_version'],dict(graph='graph.json',entities='model/entities.json.gz',events='model/events.json.gz'))
    relations=component(frontier['relation_version'],dict(graph='graph.json',relations='model/relations.json.gz',cooccurrence_support='model/cooccurrence_support.json.gz',pair_views='private/pair_views_v2.json'))
    geometries=component(frontier['geometry_version'],dict(geography='model/geography.json.gz',geoparquet='model/geometries.parquet'))
    source_receipts={k:dict(path=str(base/'private/receipt.json'),sha256=sha(base/'private/receipt.json'),artifact_root=str(base)) for k in ['identities','relations','geometries']}
    case=HERE/'simulation_0001'
    case.mkdir(exist_ok=True)
    reference=read(PUBLISHER/'cadence_caller_0001/simulation_0001'/next((PUBLISHER/'cadence_caller_0001/simulation_0001').glob('attempt-*.json')).name)['verified_references'][0]
    required=['input','grouping','exact','handoff','counts','consumer_snapshot']
    start=datetime(2026,11,1,12,tzinfo=timezone.utc)
    state=case/'cadence_state.json'
    initialize(state,start,required)
    attempt_result=evaluate(state,start,[reference],final_flush=True)
    attempt=Path(attempt_result['attempt'])
    parameters=dict(frontier=frontier,identities=identities,relations=relations,geometries=geometries,
        source_receipts=source_receipts,previous_snapshot=base,
        cadence_attempt=dict(path=str(attempt),sha256=sha(attempt)),completed_at=start+timedelta(minutes=1),
        consumer_root=PUBLISHER/'proposed_strength_0001/consumer')
    manifest={k:(str(v) if isinstance(v,(Path,datetime)) else v) for k,v in parameters.items()}
    save(case/'baseline_inputs.json',manifest)
    before=sha(state)
    result=refresh_snapshot(case/'snapshot_0001',**parameters)
    assert result and result['status']=='SUCCESS_LOCAL_CHECKPOINT_SIMULATION','Refresh did not return a consumer-verified success receipt'
    assert sha(state)==before,'Publisher advanced cadence before its caller confirmed success'
    assert confirm(state,attempt,Path(result['receipt_path']),result['receipt_sha256']) is True
    assert read(state)['last_successful_checkpoint']==(start+timedelta(minutes=1)).isoformat()
    for label,change in [('mixed_identity',dict(identity_version='unrun-new-model-version')),('stale_relations',dict(relation_version='old-source-v1')),('stale_previous',dict(previous_receipt_sha256='0'*64))]:
        invalid=dict(parameters,frontier=dict(frontier,**change))
        destination=case/label
        try:refresh_snapshot(destination,**invalid)
        except ValueError:pass
        else:raise AssertionError('Mixed/stale version accepted: '+label)
        assert not destination.exists()
    report=dict(status='PASS_PUBLISHER_REFRESH_BASELINE_SIMULATION',signature='refresh_snapshot(output_dir, *, frontier, identities, relations, geometries, source_receipts, previous_snapshot, cadence_attempt, completed_at, consumer_root)',
        baseline_inputs_only=True,new_real_model_decisions=False,nodes=10,edge_views=90,geometries=5,
        mixed_and_stale_versions_rejected=True,success_receipt_advanced_cadence_only_after_checks=True,
        publisher_did_not_write_cadence_state=True,proposed_contract=True,daniel_approval='not recorded',
        refresh_code_sha256=sha(Path(__file__)),success_receipt_sha256=result['receipt_sha256'],publication=False)
    save(case/'verification.json',report)
    print(json.dumps(report,indent=2))

if __name__=='__main__':self_check()
