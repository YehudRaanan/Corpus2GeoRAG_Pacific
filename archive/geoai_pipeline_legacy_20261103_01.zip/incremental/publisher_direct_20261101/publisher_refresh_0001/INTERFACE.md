# Minimal callable publisher refresh for INTEGRATION

Completed and tested: publisher_refresh.py. One implementation file with its bounded baseline self-check; no shared consumer/cadence/orchestration source changed.

```python
refresh_snapshot(
    output_dir, *, frontier, identities, relations, geometries,
    source_receipts, previous_snapshot, cadence_attempt,
    completed_at, consumer_root,
)
```

The current callable returns {status, receipt_path, receipt_sha256, consumer_checks}. status is SUCCESS_LOCAL_CHECKPOINT_SIMULATION, compatible with cadence_caller_0001.confirm. The caller still owns cadence state: refresh never advances its clock or acknowledgments. No live publication is performed.

## Exact input shape

frontier contains identity_version, relation_version, geometry_version and previous_receipt_sha256. For the verified existing baseline these are first-unit-exact-v1, real-pair-source-v2, sha256:<full combined GeoParquet hash>, and the exact previous private receipt hash. The caller pins the accepted target frontier; the refresh does not discover or choose newest versions. Mixed/stale means disagreement with those explicit pins, not a claimed general authenticated history registry.

Each component contains version, decision_version and artifacts with absolute path strings:
- identities.artifacts: graph, entities, events.
- relations.artifacts: graph, relations, cooccurrence_support, pair_views.
- geometries.artifacts: geography, geoparquet. It additionally REQUIRES scope={kind: FULL_LOC_POPULATION, place_ids: [...]}, listing the complete current LOC identity set.

All component decision_version values must match frontier.identity_version. Identity and relation/geometry projection versions must match their expected frontier entries. Relation source receipt pair_projection_version and the exact geometry artifact hash are independently checked. Each named source_receipts entry (identities/relations/geometries) contains path, sha256 and artifact_root. The current adapter consumes the existing verified proposed-snapshot receipt schema: proposed_contract, decision_version, artifact_sha256, source inputs_sha256 and, for relations, pair_projection_version plus consumer_copy_sha256. Every selected component artifact must be covered by that receipt's existing hash map. The example reuses the same verified full baseline receipt for all three components; different verified component receipts are permitted when they bind the same accepted identity frontier.

previous_snapshot is preserved and pinned by its receipt plus all actual file hashes before/after refresh. output_dir must be new and remain under publisher_direct_20261101. cadence_attempt is {path, sha256}, must be a due local-simulation attempt, and is bound into the returned success receipt. completed_at is explicit/timezone-aware and cannot precede the attempt. consumer_root points to the exact already-verified isolated proposed consumer; its copied code hashes must match the source receipt.

## Full geometry, never a replacement fragment

INTEGRATION must merge Tokyo or other per-identity changes into a complete current geometry projection before calling refresh. Declaring a fragment is rejected. Even when declared full, Geography must have exactly one row for EVERY current LOC identity, with explicit null or a source-backed pointer. GeoParquet must have exactly the selected non-null place rows, valid nonempty EPSG:4326 objects and matching file/place/checksum pointers. A full view can retain explicit nulls where no shape exists; unmentioned identities cannot disappear because a fragment was passed. This module makes no geometry choice or new identity decision.

The full source-consistent graph is built from identity nodes and relation metadata/catalog/edges. Existing model files are copied without changing fields; geometry remains separate. Complete pair evidence and copied source receipts remain private. Private frontier bindings preserve source/previous-version paths and hashes; retaining pinned earlier local generations is required for that local provenance chain.

## Output artifacts

- graph.json.
- model/entities.json.gz, events.json.gz, relations.json.gz, cooccurrence_support.json.gz, geography.json.gz and geometries.parquet.
- private/pair_views.json, identities_source_receipt.json, relations_source_receipt.json, geometries_source_receipt.json and frontier.json.
- private/readback.json: actual file hash checks plus a fresh subprocess loading the exact isolated consumer (module-path checked), including model assertion/pair evidence and geometry joins.
- private/success_receipt.json: written LAST, only after source consistency, prior preservation and consumer/readback checks pass. It binds the attempt, success time, frontier, source hashes and every output artifact hash. It is explicitly simulation=true, proposed_contract=true, daniel_approval='not recorded', publication=false.

If a later check fails, the output may remain as an incomplete diagnostic directory but no success receipt is returned; a new output slot is required. The function does not change caller cadence state. Only cadence_caller.confirm verifies the returned existing receipt/artifacts and advances successful time.

## Measured verification and example

simulation_0002/baseline_inputs.json is the concrete full input manifest for INTEGRATION. It uses only the existing proposed snapshot_0007_retry_0001 baseline, not new real model decisions. Its output is simulation_0002/snapshot_0001. Tests passed for ten nodes, 90 edge views, five geometries, rejection of mismatched identity/stale relation/stale previous receipt versions before output creation, explicit fragment rejection, full LOC/selected geometry consistency, preserved old snapshots and no publisher writes to cadence state. Only after refresh returned a verified receipt did the existing cadence caller advance its fresh simulation state. Consumer/readback ran in a new Python process.

TDD first failed because refresh returned no receipt. The implemented baseline passed in simulation_0001. The first full-scope guard then failed its Tokyo-fragment assertion; after implementing the strict full-view check, simulation_0002 passed. The earlier code is preserved byte-for-byte in publisher_refresh_before_full_scope.py so its earlier receipt/code hash remains reviewable. Current refresh SHA256: 8206fb316b0d54380ef33a60005d8ba4715717feefcbc49c57f089b9ce594ba5. Latest success receipt SHA256: f9f2aba53a415cb424318ede180f16d6d34396b31173cb221ac13aa8f02c9fa7.

Evidence: simulation_0002/verification.json and snapshot_0001/private/readback.json plus success_receipt.json. The self-check preserves its existing output slot; a subsequent simulation needs a new slot. The interface and existing snapshot sources are read-only until the caller explicitly invokes it with a new owned output path.

No new real model decisions, consumer-contract rewrite, source overwrite, live scheduler, external call/publication, paid work, Git, installation or nested agent. No denied/pending/uncertain action remains. Single local writer only; no distributed/power-loss or publication guarantee. Backup: Unprotected.
