# E7/R9-R10 cadence caller connection: local simulation

PASS. cadence_caller.py connects the unchanged approved checkpoint_decision function to the existing read-only receipt caller and E2 recover interface. Only publisher_direct_20261101/cadence_caller_0001 was created/modified. No live scheduler or publication exists in this increment.

initialize persists an explicit timezone-aware run_start, explicit unique required_stages and the pure cadence code hash. Restart with the same configuration leaves state bytes unchanged; a different configuration is rejected. evaluate verifies the persisted inspect_chain output hash, its existing caller-code binding, every receipt/artifact hash and the existing sealed unit through recover. Required-stage admission and all time/count rules are delegated to checkpoint_decision unchanged. Exact duplicate receipt references are read once; logical units remain wiki_site/page_id/processing revision, not attempts or decision versions.

evaluate persists an attempt only when cadence is due; it does not alter successful time or acknowledged units. confirm requires an existing hash-pinned SUCCESS_LOCAL_CHECKPOINT_SIMULATION receipt bound to that exact attempt and actual persisted checkpoint artifact hashes. Failed receipts do not alter state. Successful completion time must follow the attempt; stale attempts are rejected through the before-state hash. Only verified success advances last_successful_checkpoint and acknowledgments. Replaying the same successful receipt is idempotent. These are simulation receipt statuses, not production publication success claims.

The simulation invokes existing orchestration_direct_20261101/check_one_unit.py::inspect_chain() read-only, persists its verified result locally, and reuses the real first-unit E2 seal. Producer stages are not rerun. Its explicitly declared simulation-required stages are input, grouping, exact, handoff, counts and consumer_snapshot. This is the existing completed partial receipt chain; it does not silently claim a model stage ran or define every future run's required stages.

Measured checks:
- Persisted run start 2026-11-01T10:00:00+00:00 remains the initial baseline. 59 minutes and one qualifying unit waits.
- One real page/revision supplied 100 times counts once, not 100.
- The finished exact stage may retain 106 documented unresolved identity decisions and still qualify for this declared simulation scope.
- Requiring an additional model_not_run stage excludes that same unit. Its separate state keeps no successful checkpoint and no acknowledgments.
- The explicit approved-geography/correction test flag permits an attempt after 60 minutes with one unit, using the existing rule; no actual geographic publication is performed.
- Attempt preparation and an actual persisted FAILED_LOCAL_CHECKPOINT_SIMULATION receipt leave the initial state bytes unchanged.
- A real locally persisted simulation artifact and matching success receipt advance the clock to the receipt's 11:10 completion time, not the attempt's 11:00 time. Replaying the receipt leaves bytes unchanged.
- At 11:20 the elapsed interval is 600 seconds from successful completion, and the already acknowledged unit contributes zero new completions.
- A hash-invalid success receipt is rejected without advancing the separate state.

TDD RED failed on the missing caller module. After implementation the full simulation passed. A separate fresh Python process, without importing the caller, then checked source/receipt/artifact hashes, exact initial state reconstruction, deduplicated acknowledgment key, run-start/required-stage persistence, successful receipt time/artifact binding, failed-receipt binding, documented partial completion and the untouched missing-model state. The initial independent reconstruction assumed LF; source-byte inspection proved state uses Windows CRLF. Only that checker was corrected, and fresh readback passed with the caller/state unchanged.

Evidence: simulation_0001/verification.json and independent_verification.json; verified_chain.json; state.json and required_model_state.json; attempt-*.json; failed_receipt.json, success_receipt.json and checkpoint.private.json. Caller SHA256 4b5cabded151fdbd4b1eb5ac02462b661cb9db50115b9b7cc2192bcb972ac775. Pure cadence SHA256 remains 52694edec3dbe1e39a44fd8039633ad4a61e11f397d8ee4f8ea54b8591a0e7b6. Successful simulation state SHA256 893235153f0f41fd803d86b5c0b6c316ac5412b5500657f98de8ebf494e217fc; success receipt SHA256 19c98a0b010b67ea78e7b2672d5d550eb1bb3d5ccc4ed1d3defe541e6dea203a.

Repeat independent readback: contract_fixtures/.venv-bridge/Scripts/python.exe -B publisher_direct_20261101/cadence_caller_0001/verify_readback.py. test_simulation.py preserves simulation_0001 and refuses to recreate it; another simulation needs a new owned output slot.

Scope: one local writer, atomic file replacement; no distributed authentication, production release, crash/power-loss guarantee, live timer or scheduler. Cadence eligibility does not execute delivery. No policy or consumer contract changed, no real publication counters/state were updated, and no external calls, paid work, source/plan edits, Git, dependency installation or nested agents occurred. No denied, pending or uncertain action remains. Backup: Unprotected.
