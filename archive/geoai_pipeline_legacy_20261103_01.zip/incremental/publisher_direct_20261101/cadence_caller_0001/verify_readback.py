"""Independent fresh-process readback; does not import the cadence caller."""
import hashlib,json
from datetime import datetime
from pathlib import Path
HERE=Path(__file__).resolve().parent
OUT=HERE/'simulation_0001'
ROOT=HERE.parent.parent

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
report=read(OUT/'verification.json')
assert report['status']=='PASS_CADENCE_CALLER_SIMULATION' and report['simulation'] and not report['publication'] and not report['scheduler']
assert sha(HERE/'cadence_caller.py')==report['caller_code_sha256']
assert sha(ROOT/'cadence_direct_20261101/checkpoint_cadence.py')==report['pure_cadence_code_sha256']
chain=read(OUT/'verified_chain.json')
assert sha(OUT/'verified_chain.json')==report['chain_sha256']
for field in ['receipt_sha256','verified_artifact_sha256']:
    for path,expected in chain[field].items():assert sha(path)==expected,path
assert chain['stages']['exact']['pending_occurrences']==106 and chain['stages']['exact']['status']=='COMPLETED_PARTIAL'
state=read(OUT/'state.json')
assert sha(OUT/'state.json')==report['successful_state_sha256']
assert state['run_start']=='2026-11-01T10:00:00+00:00'
assert state['last_successful_checkpoint']=='2026-11-01T11:10:00+00:00'
assert state['acknowledged_units']==[['enwiki',48975579,1375061414]]
receipt=read(OUT/'success_receipt.json')
assert sha(OUT/'success_receipt.json')==state['last_success_receipt_sha256']
attempts=list(OUT.glob('attempt-*.json'))
assert len(attempts)==1
attempt=read(attempts[0])
assert receipt['attempt_sha256']==sha(attempts[0]) and receipt['status']=='SUCCESS_LOCAL_CHECKPOINT_SIMULATION'
assert attempt['decision']==dict(due=True,elapsed_seconds=3600.0,new_completed_units=1,reason='approved_geometry_or_correction')
assert attempt['eligible_units']==state['acknowledged_units'] and len(attempt['verified_references'])==1
assert datetime.fromisoformat(receipt['completed_at'])>=datetime.fromisoformat(attempt['decision_time'])
for path,expected in receipt['artifact_sha256'].items():assert sha(path)==expected,path
initial=dict(state,last_successful_checkpoint=None,acknowledged_units=[],last_success_receipt_sha256=None)
newline='\r\n' if b'\r\n' in (OUT/'state.json').read_bytes() else '\n'
initial_bytes=(json.dumps(initial,indent=2,sort_keys=True)+'\n').replace('\n',newline).encode()
initial_sha=hashlib.sha256(initial_bytes).hexdigest()
assert attempt['before_state_sha256']==initial_sha
failed=read(OUT/'failed_receipt.json')
assert failed['status']=='FAILED_LOCAL_CHECKPOINT_SIMULATION' and failed['attempt_sha256']==sha(attempts[0])
model=read(OUT/'required_model_state.json')
assert model['required_stages']==state['required_stages']+['model_not_run']
assert model['last_successful_checkpoint'] is None and model['acknowledged_units']==[]
result=dict(status='PASS_INDEPENDENT_CADENCE_CALLER_READBACK',simulation=True,
    verified_real_receipt_chain=True,persisted_run_start=True,required_stages_explicit=True,
    documented_unresolved_allowed=True,unrun_required_model_excluded=True,deduplicated_unit=['enwiki',48975579,1375061414],
    clock_matches_actual_local_success_receipt=True,attempt_did_not_acknowledge_early=True,
    published=False,live_scheduler=False,limits='Single local writer; local simulation receipt only, no production publication or power-loss guarantee',
    source_sha256={'cadence_caller.py':sha(HERE/'cadence_caller.py'),'test_simulation.py':sha(HERE/'test_simulation.py'),'verify_readback.py':sha(Path(__file__))},
    successful_state_sha256=sha(OUT/'state.json'),success_receipt_sha256=sha(OUT/'success_receipt.json'))
(OUT/'independent_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
