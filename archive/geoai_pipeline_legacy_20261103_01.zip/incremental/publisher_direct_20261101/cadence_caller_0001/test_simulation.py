"""One isolated cadence-caller simulation; never a publication or live scheduler."""
import hashlib,json,sys
from datetime import datetime,timedelta,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sys.path[:0]=[str(HERE),str(ROOT/'orchestration_direct_20261101')]
from cadence_caller import initialize,evaluate,confirm,save,sha
from check_one_unit import inspect_chain

OUT=HERE/'simulation_0001'
OUT.mkdir()
chain=inspect_chain()  # Existing read-only caller; producer stages are not rerun.
chain['code_sha256']=sha(ROOT/'orchestration_direct_20261101/check_one_unit.py')
chain_path=OUT/'verified_chain.json'
save(chain_path,chain)
unit_dir=ROOT/'integration_direct_20261101/real_handoff_0001/sealed_v1'
reference=dict(chain_path=str(chain_path),chain_sha256=sha(chain_path),unit_directory=str(unit_dir),unit_sha256='35d0edd3f0eb17aa0e468f25a25dbfd1daf257bec938f05bb510e848ec5ae0f6')
required=['input','grouping','exact','handoff','counts','consumer_snapshot']
start=datetime(2026,11,1,10,tzinfo=timezone.utc)
state=OUT/'state.json'
initialize(state,start,required)
initial=state.read_bytes()
initialize(state,start,required)
assert state.read_bytes()==initial
result=evaluate(state,start+timedelta(minutes=59),[reference]*100)
assert result['new_completed_units']==1 and result['due'] is False and result['elapsed_seconds']==3540
assert state.read_bytes()==initial
result=evaluate(state,start+timedelta(hours=1),[reference],approved_geometry_or_correction=True)
assert result['due'] and result['new_completed_units']==1
attempt=Path(result['attempt'])
assert state.read_bytes()==initial
failed=OUT/'failed_receipt.json'
save(failed,dict(status='FAILED_LOCAL_CHECKPOINT_SIMULATION',simulation=True,attempt_sha256=sha(attempt)))
assert confirm(state,attempt,failed,sha(failed)) is False and state.read_bytes()==initial
artifact=OUT/'checkpoint.private.json'
save(artifact,dict(simulation=True,source_chain_sha256=sha(chain_path),unit_count=1))
success=OUT/'success_receipt.json'
save(success,dict(status='SUCCESS_LOCAL_CHECKPOINT_SIMULATION',simulation=True,attempt_sha256=sha(attempt),completed_at=(start+timedelta(minutes=70)).isoformat(),artifact_sha256={str(artifact):sha(artifact)}))
assert confirm(state,attempt,success,sha(success)) is True
successful=state.read_bytes()
assert confirm(state,attempt,success,sha(success)) is True and state.read_bytes()==successful
later=evaluate(state,start+timedelta(minutes=80),[reference]*100)
assert later['new_completed_units']==0 and later['elapsed_seconds']==600
model_state=OUT/'required_model_state.json'
initialize(model_state,start,required+['model_not_run'])
assert evaluate(model_state,start+timedelta(hours=1),[reference])['new_completed_units']==0
assert json.loads(state.read_text())['last_successful_checkpoint']==(start+timedelta(minutes=70)).isoformat()
# A hash-invalid success receipt must never advance the separate state.
try:confirm(model_state,attempt,success,'0'*64)
except ValueError:pass
else:raise AssertionError('Corrupt success receipt accepted')
assert json.loads(model_state.read_text())['last_successful_checkpoint'] is None
report=dict(status='PASS_CADENCE_CALLER_SIMULATION',simulation=True,run_start_persisted=True,required_stages=required,
    real_unit_candidate_in_simulation=1,documented_pending_identities=106,duplicate_replays=100,deduplicated_units=1,
    unrun_required_model_excluded=True,failure_does_not_advance=True,actual_local_success_receipt_advances=True,
    repeated_success_idempotent=True,clock_after_success='2026-11-01T11:10:00+00:00',
    successful_state_sha256=sha(state),chain_sha256=sha(chain_path),caller_code_sha256=sha(HERE/'cadence_caller.py'),
    pure_cadence_code_sha256=sha(ROOT/'cadence_direct_20261101/checkpoint_cadence.py'),publication=False,scheduler=False)
save(OUT/'verification.json',report)
print(json.dumps(report,indent=2))
