"""Single-writer local cadence simulation; no publication, scheduler or clock reads.
Example: initialize(state, aware_run_start, explicit_required_stages), then evaluate/confirm.
"""
import hashlib,json,os,sys
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent.parent
sys.path[:0]=[str(ROOT/'cadence_direct_20261101'),str(ROOT/'durable_units_direct_20261101'),str(ROOT/'source_custody')]
from checkpoint_cadence import checkpoint_decision
from durable_unit import recover
CADENCE=ROOT/'cadence_direct_20261101/checkpoint_cadence.py'


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def instant(value):
    value=datetime.fromisoformat(value) if isinstance(value,str) else value
    if value.utcoffset() is None:raise ValueError('Use timezone-aware timestamps')
    return value

def save(path,value):
    """Close and replace one local state file; one writer, no distributed/power-loss claim."""
    path=Path(path)
    temporary=path.with_name(path.name+'.tmp')
    with temporary.open('w',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2,sort_keys=True)
        stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)

def initialize(state_path,run_start,required_stages):
    required=list(required_stages)
    if not required or len(set(required))!=len(required) or any(not isinstance(s,str) or not s for s in required):
        raise ValueError('Supply unique explicit required stages')
    config=dict(simulation=True,run_start=instant(run_start).isoformat(),required_stages=required,cadence_code_sha256=sha(CADENCE))
    state_path=Path(state_path)
    if state_path.exists():
        current=read(state_path)
        if any(current.get(k)!=v for k,v in config.items()):raise ValueError('Persisted run configuration differs')
        return current
    state=dict(config,last_successful_checkpoint=None,acknowledged_units=[],last_success_receipt_sha256=None)
    save(state_path,state)
    return state

_CPU_VERIFIER=None

def verified_unit(reference):
    """Recheck the existing receipt caller's persisted chain and reuse E2 recovery."""
    if reference.get('kind')=='cpu_frontier_unit':
        import importlib.util
        global _CPU_VERIFIER
        verifier=ROOT/'orchestration_direct_20261101/cpu_unit_admission.py'
        expected=reference['cpu_verifier_sha256']
        if sha(verifier)!=expected:raise ValueError('Fixed CPU admission verifier changed')
        if _CPU_VERIFIER is None or _CPU_VERIFIER[0]!=expected:
            spec=importlib.util.spec_from_file_location('_publisher_cpu_admission',verifier)
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            _CPU_VERIFIER=(expected,module)
        record=_CPU_VERIFIER[1].verified_cpu_unit(reference)
        if sha(verifier)!=expected:raise ValueError('CPU admission verifier changed during validation')
        return record
    if reference.get('kind')=='runtime_unit':
        # Only the fixed project verifier is executable; caller paths are data, never code.
        import importlib.util
        verifier=ROOT/'orchestration_direct_20261101/runtime_unit_admission.py'
        expected=reference['runtime_verifier_sha256']
        if sha(verifier)!=expected:raise ValueError('Runtime admission verifier changed')
        sys.path.insert(0,str(verifier.parent))
        spec=importlib.util.spec_from_file_location('_publisher_runtime_admission',verifier)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        record=module.verified_runtime_unit(reference)
        if sha(verifier)!=expected:raise ValueError('Runtime admission verifier changed during validation')
        return record
    path=Path(reference['chain_path'])
    if sha(path)!=reference['chain_sha256']:raise ValueError('Receipt-chain hash differs')
    chain=read(path)
    if chain.get('code_sha256')!=sha(ROOT/'orchestration_direct_20261101/check_one_unit.py'):
        raise ValueError('Existing receipt caller code differs')
    for field in ['receipt_sha256','verified_artifact_sha256']:
        if not chain.get(field):raise ValueError('Verified persistence receipts are missing')
        for artifact,expected in chain[field].items():
            if sha(artifact)!=expected:raise ValueError('Persisted stage receipt/artifact differs: '+artifact)
    history=reference.get('prior_history',[])
    if not isinstance(history,list):raise ValueError('prior_history must be an ordered list of pinned seals')
    prior=[]
    for entry in history:
        earlier=recover(entry['unit_directory'],entry['unit_sha256'],prior_history=prior)
        if earlier['status']!='sealed':raise ValueError('Prior history entry is not sealed')
        prior.append(earlier['handoff'])
    recovered=recover(reference['unit_directory'],reference['unit_sha256'],prior_history=prior)
    if recovered['status']=='sealed':
        scope=recovered['receipt']['scope']
        if (chain['page_id'],chain['processing_revision_id'])!=(scope['page_id'],scope['support_revision_id']):
            raise ValueError('Stage chain belongs to another page/revision')
        recovered['stage_chain']=chain
    return recovered

def evaluate(state_path,now,references,*,approved_geometry_or_correction=False,final_flush=False):
    state=read(state_path)
    if not state['simulation'] or state['cadence_code_sha256']!=sha(CADENCE):raise ValueError('Run/cadence binding differs')
    now=instant(now)
    # Identical receipt references are read once; pure cadence still deduplicates different versions of one unit.
    unique={json.dumps(ref,sort_keys=True):ref for ref in references}
    records=[verified_unit(ref) for ref in unique.values()]
    options=dict(run_start=instant(state['run_start']),required_stages=state['required_stages'])
    reference=instant(state['last_successful_checkpoint']) if state['last_successful_checkpoint'] else None
    result=checkpoint_decision(now,reference,records,state['acknowledged_units'],approved_geometry_or_correction,final_flush,**options)
    result['attempt']=None
    if not result['due']:return result
    eligible=[]
    for record in records:
        if checkpoint_decision(now,reference,[record],state['acknowledged_units'],final_flush=True,**options)['new_completed_units']:
            scope=record['receipt']['scope']
            eligible.append([scope['wiki_site'],scope['page_id'],scope['support_revision_id']])
    attempt=dict(simulation=True,before_state_sha256=sha(state_path),decision_time=now.isoformat(),
        decision={k:v for k,v in result.items() if k!='attempt'},eligible_units=sorted(set(map(tuple,eligible))),
        verified_references=list(unique.values()),cadence_code_sha256=state['cadence_code_sha256'])
    identity=hashlib.sha256(json.dumps(attempt,sort_keys=True).encode()).hexdigest()[:16]
    path=Path(state_path).parent/('attempt-'+identity+'.json')
    if path.exists():
        if read(path)!=json.loads(json.dumps(attempt)):raise ValueError('Attempt slot differs')
    else:save(path,attempt)
    result['attempt']=str(path)
    return result

def confirm(state_path,attempt_path,receipt_path,expected_receipt_sha256):
    """Only an existing hash-verified successful LOCAL SIMULATION receipt advances state."""
    if sha(receipt_path)!=expected_receipt_sha256:raise ValueError('Success receipt hash differs')
    receipt=read(receipt_path)
    attempt=read(attempt_path)
    if not receipt.get('simulation') or receipt.get('attempt_sha256')!=sha(attempt_path):raise ValueError('Receipt/attempt binding differs')
    if receipt['status']=='FAILED_LOCAL_CHECKPOINT_SIMULATION':return False
    if receipt['status']!='SUCCESS_LOCAL_CHECKPOINT_SIMULATION' or not receipt.get('artifact_sha256'):
        raise ValueError('Persisted successful checkpoint artifact receipt required')
    for artifact,expected in receipt['artifact_sha256'].items():
        if sha(artifact)!=expected:raise ValueError('Successful checkpoint artifact differs')
    state=read(state_path)
    if state['last_success_receipt_sha256']==expected_receipt_sha256:return True
    if sha(state_path)!=attempt['before_state_sha256']:raise ValueError('Stale checkpoint attempt')
    if not attempt['simulation'] or not attempt['decision']['due']:raise ValueError('Checkpoint was not due')
    completed=instant(receipt['completed_at'])
    if completed<instant(attempt['decision_time']):raise ValueError('Success precedes checkpoint attempt')
    state['last_successful_checkpoint']=completed.isoformat()
    state['acknowledged_units']=[list(key) for key in sorted(set(map(tuple,state['acknowledged_units']+attempt['eligible_units'])))]
    state['last_success_receipt_sha256']=expected_receipt_sha256
    save(state_path,state)
    return True

