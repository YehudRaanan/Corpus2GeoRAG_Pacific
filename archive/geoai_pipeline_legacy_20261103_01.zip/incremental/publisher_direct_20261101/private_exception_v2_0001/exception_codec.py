"""Versioned private exception dedup; legacy values via streaming dual reader. No activation side effects."""
import hashlib,ijson,json,sys
from pathlib import Path
from ijson.common import ObjectBuilder
PUBLISHER=Path(__file__).resolve().parent.parent
SCHEMA='geoai-private-exceptions-v2';REF='decision_binding_ref'

def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def descriptor(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('utf8')
def key(v):return hashlib.sha256(encoded(v)).hexdigest()
def dump(path,value):
 with Path(path).open('w',encoding='utf8',newline='\n') as f:json.dump(value,f,ensure_ascii=True,separators=(',',':'),allow_nan=False)
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def signature(path):
 s=Path(path).stat();return s.st_size,s.st_mtime_ns

def _value(first,events):
 builder=ObjectBuilder();depth=0
 while True:
  prefix,event,value=first;builder.event(event,value)
  if event in ('start_map','start_array'):depth+=1
  elif event in ('end_map','end_array'):depth-=1
  if depth==0:return builder.value
  first=next(events)

def _metadata_full(path):
 result={}
 with Path(path).open('rb') as f:
  events=iter(ijson.parse(f,use_float=True))
  if next(events)[1]!='start_map':raise ValueError('Exception root object required')
  for prefix,event,value in events:
   if prefix=='' and event=='end_map':break
   if prefix!='' or event!='map_key':raise ValueError('Malformed exception metadata')
   first=next(events)
   if value=='items':
    if first[1]!='start_array':raise ValueError('Exception items array required')
    depth=1
    for p,e,v in events:
     if e in ('start_map','start_array'):depth+=1
     elif e in ('end_map','end_array'):depth-=1
     if depth==0:break
   else:result[value]=_value(first,events)
 return result

def legacy_metadata(path):
 # Fast bounded footer for the existing indent=2 producer (LF or Windows CRLF).
 # Arbitrary other legacy JSON layouts use the standard streaming parser fallback.
 with Path(path).open('rb') as f:
  parser=iter(ijson.parse(f,use_float=True));first=next(parser)
  if first[1]!='start_map':raise ValueError('Exception root object required')
  prefix=next(parser);value=_value(next(parser),parser)
  next_key=next(parser);start=next(parser)
  fast=(prefix==('', 'map_key','schema') and value=='geoai-data-exceptions-v1' and next_key==('', 'map_key','items') and start[1]=='start_array')
 if fast:
  with Path(path).open('rb') as f:f.seek(max(0,Path(path).stat().st_size-262144));tail=f.read()
  for marker in [b'\r\n  ],\r\n',b'\n  ],\n']:
   pos=tail.rfind(marker)
   if pos<0:continue
   try:footer=json.loads(b'{'+tail[pos+len(marker):])
   except ValueError:continue
   if footer and next(iter(footer))=='quarantined_typed_items' and not any(isinstance(v,(dict,list)) for v in footer.values()):return dict(schema=value,**footer)
 return _metadata_full(path)

class _DigestReader:
 def __init__(self,file):self.file=file;self.digest=hashlib.sha256()
 def read(self,n=-1):
  value=self.file.read(n);self.digest.update(value);return value
 def readinto(self,buffer):
  n=self.file.readinto(buffer)
  if n:self.digest.update(memoryview(buffer)[:n])
  return n

def _write(items,metadata,output_dir,source_finish=None,progress=None):
 out=Path(output_dir).resolve()
 if not out.is_relative_to(PUBLISHER) or out.exists():raise ValueError('Use a new versioned publisher exception directory')
 if 'items' in metadata:raise ValueError('Metadata cannot contain item bodies')
 out.mkdir();bindings={};last_value=object();last_key=None;count=0;mentions=0
 with (out/'items.jsonl').open('w',encoding='utf8',newline='\n') as f:
  for original in items:
   row=original;lookup=original.get('occurrences',{}).get('lookup',{})
   if REF in lookup:raise ValueError('Legacy binding reference collision')
   if 'decision_binding' in lookup:
    binding=lookup['decision_binding']
    if last_key is not None and binding==last_value:identity=last_key
    else:identity=key(binding);bindings.setdefault(identity,binding);last_value=bindings[identity];last_key=identity
    row=dict(original);row['occurrences']=dict(original['occurrences']);row['occurrences']['lookup']=dict(lookup)
    del row['occurrences']['lookup']['decision_binding'];row['occurrences']['lookup'][REF]=identity
   json.dump(row,f,ensure_ascii=True,separators=(',',':'),allow_nan=False);f.write('\n');count+=1;mentions+=original.get('occurrences',{}).get('mention_count',0)
   if progress and count%256==0:progress(count)
 if metadata.get('quarantined_typed_items',count)!=count or metadata.get('quarantined_mentions',mentions)!=mentions:raise ValueError('Exception footer count differs')
 source=source_finish() if source_finish else None
 dump(out/'metadata.json',metadata);dump(out/'bindings.json',bindings)
 manifest=dict(schema=SCHEMA,codec_sha256=sha(__file__),source=source,item_count=count,mention_count=mentions,binding_count=len(bindings),files={name:sha(out/name) for name in ['metadata.json','bindings.json','items.jsonl']})
 dump(out/'manifest.json',manifest);return descriptor(out/'manifest.json')

def write_summary(summary,output_dir,*,progress=None):
 """New producer API: pass the unmodified in-memory v1 summary BEFORE json.dumps."""
 metadata={k:v for k,v in summary.items() if k!='items'}
 if metadata.get('schema')!='geoai-data-exceptions-v1':raise ValueError('Unsupported legacy exception schema')
 out=Path(output_dir).resolve()
 if out.exists():
  import itertools
  ref=descriptor(out/'manifest.json');manifest=read(ref['path'])
  if manifest['codec_sha256']!=sha(__file__) or read(out/'metadata.json')!=metadata:raise ValueError('Changed exception summary cannot overwrite generation')
  missing=object()
  for original,restored in itertools.zip_longest(summary['items'],iter_items(ref),fillvalue=missing):
   if original!=restored:raise ValueError('Changed exception summary cannot overwrite generation')
  return ref
 return _write(iter(summary['items']),metadata,out,progress=progress)

def convert_legacy(source_path,output_dir,*,expected_source_sha256=None,progress=None):
 source=Path(source_path).resolve();out=Path(output_dir).resolve();before=signature(source)
 if out.exists():
  ref=descriptor(out/'manifest.json');manifest=read(ref['path'])
  if manifest['schema']!=SCHEMA or manifest['codec_sha256']!=sha(__file__) or manifest['source']['path']!=str(source):raise ValueError('Changed exception conversion cannot overwrite generation')
  actual=sha(source)
  if actual!=manifest['source']['sha256'] or (expected_source_sha256 and actual!=expected_source_sha256):raise ValueError('Legacy exception source changed')
  sum(1 for _ in iter_items(ref));return ref
 metadata=legacy_metadata(source)
 if metadata.get('schema')!='geoai-data-exceptions-v1':raise ValueError('Unsupported legacy exception schema')
 with source.open('rb') as f:
  stream=_DigestReader(f)
  def finish():
   digest=stream.digest.hexdigest()
   if signature(source)!=before or (expected_source_sha256 and digest!=expected_source_sha256):raise ValueError('Legacy exception source changed during conversion')
   return dict(path=str(source),sha256=digest,bytes=before[0])
  return _write(ijson.items(stream,'items.item',use_float=True),metadata,out,finish,progress)

def _open(reference):
 path=Path(reference['path']).resolve()
 if sha(path)!=reference['sha256']:raise ValueError('Exception manifest/source hash differs')
 # Peek only at the schema; never json.load a multi-GB v1 file.
 with path.open('rb') as f:schema=next(ijson.items(f,'schema'),None)
 if schema=='geoai-data-exceptions-v1':return path,None,None
 if schema!=SCHEMA:raise ValueError('Unsupported private exception schema')
 manifest=read(path);root=path.parent;expected={'metadata.json','bindings.json','items.jsonl'}
 if set(manifest['files'])!=expected:raise ValueError('Unexpected compact exception files')
 for name,digest in manifest['files'].items():
  p=root/name
  if p.is_symlink() or not p.resolve().is_relative_to(root) or sha(p)!=digest:raise ValueError('Compact exception file hash differs: '+name)
 bindings=read(root/'bindings.json')
 if len(bindings)!=manifest['binding_count'] or any(key(value)!=identity for identity,value in bindings.items()):raise ValueError('Corrupt decision binding identity')
 metadata=read(root/'metadata.json')
 if metadata.get('schema')!='geoai-data-exceptions-v1' or 'items' in metadata:raise ValueError('Invalid preserved exception metadata')
 return path,manifest,bindings

def iter_items(reference,*,share_binding=True):
 """Dual v1/v2 reader; v2 shared bindings are read-only by contract. Set False for mutable independent values."""
 path,manifest,bindings=_open(reference)
 if manifest is None:
  with path.open('rb') as f:yield from ijson.items(f,'items.item',use_float=True)
  return
 import copy
 count=0;mentions=0
 with (path.parent/'items.jsonl').open(encoding='utf8') as f:
  for line in f:
   row=json.loads(line);lookup=row.get('occurrences',{}).get('lookup',{})
   if REF in lookup:
    identity=lookup.pop(REF)
    if identity not in bindings:raise ValueError('Missing decision binding reference')
    if 'decision_binding' in lookup:raise ValueError('Conflicting inline and shared decision binding')
    lookup['decision_binding']=bindings[identity] if share_binding else copy.deepcopy(bindings[identity])
   count+=1;mentions+=row.get('occurrences',{}).get('mention_count',0);yield row
 if (count,mentions)!=(manifest['item_count'],manifest['mention_count']):raise ValueError('Compact exception counts differ')

def read_summary(reference,*,share_binding=True):
 """Reconstruct all original root/record values; shared=True avoids repeating frontier objects in RAM."""
 path,manifest,bindings=_open(reference)
 metadata=legacy_metadata(path) if manifest is None else read(path.parent/'metadata.json')
 return dict(metadata,items=list(iter_items(reference,share_binding=share_binding)))
