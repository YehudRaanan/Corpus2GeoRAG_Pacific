"""Finite generic union/consumer callable. Reads immutable stage receipts; never schedules work."""
import gzip,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path[:0]=[str(HERE),str(PUBLISHER/'component_materializer_0001'),str(PUBLISHER/'active_loc_0001'),str(PUBLISHER/'frozen_catchup_0001')]
import materialize_components_v2 as m
from active_loc_projection import admit_population

def desc(p):return dict(path=str(Path(p).resolve()),sha256=m.sha(p))
def write(p,v):p.write_text(json.dumps(v,indent=2),encoding='utf-8');return desc(p)

def verify_components(root,receipt,count,geo):
 for name,d in receipt['artifact_sha256'].items():
  if m.sha(root/name)!=d:raise ValueError('Consumer output hash differs: '+name)
 for p,d in receipt['inputs_sha256'].items():
  if m.sha(p)!=d:raise ValueError('Consumer source changed: '+p)
 if m.read(root/'private/count_receipt.json')!=count:raise ValueError('Raw counts changed')
 graph=m.read(root/'graph.json');ids={n['id'] for n in graph['nodes']};qids={n['wikidata_id'] for n in graph['nodes']}
 if len({e['id'] for e in graph['edges']})!=len(graph['edges']) or any((e['source'] not in ids and e['source'] not in qids) or (e['target'] not in ids and e['target'] not in qids) for e in graph['edges']):raise ValueError('Duplicate or dangling consumer edge')
 exceptions=m.read(root/'private/data_exceptions.json')
 if any(r['resolved'] is not False for r in exceptions['items']):raise ValueError('Quarantine incorrectly resolved')
 removed={r['qid'] for r in exceptions['items'] if r['entity_group']=='LOC'}
 expected=set(geo['active_scope_qids'])-removed
 if {n['wikidata_id'] for n in graph['nodes'] if n['type']=='location'}!=expected:raise ValueError('Consumer LOC population differs from verified gate')
 with gzip.open(root/'model/relations.json.gz','rt',encoding='utf-8') as f:relations=json.load(f)
 if len({r['observation_id'] for r in relations})!=len(relations):raise ValueError('Native support duplicate')
 return dict(status='PASS_INDEPENDENT_FROZEN_CONSUMER_READBACK',consumer_checks=receipt['consumer_checks'],native_assertions_after_active_filters=len(relations),quarantined_typed_items=len(exceptions['items']),quarantined_QIDs=len({r['qid'] for r in exceptions['items']}),all_quarantined_occurrence_IDs_verified=all(r['occurrences']['occurrence_ids'] is not None and len(r['occurrences']['occurrence_ids'])==r['occurrences']['mention_count'] for r in exceptions['items']),input_output_hashes_passed=True,no_dangling_edges=True,raw_counts_preserved=True)

def materialize_frozen_consumer(output_dir,*,event_handoff,ordinary_handoff,geo_handoff,count_preparation,consumer_root=None):
 """All handoffs are {path,sha256}; count_preparation is prepare_consumer_inputs' receipt descriptor.

 Caller owns serial dispatch and assigns a unique PUBLISHER directory. Replays only verify/read.
 Missing stage receipts remain a caller dependency; isolated data gaps use existing quarantine.
 """
 work=Path(output_dir).resolve();consumer=Path(consumer_root or PUBLISHER/'proposed_strength_0001/consumer').resolve()
 if not work.is_relative_to(PUBLISHER.resolve()):raise ValueError('Consumer output leaves publisher ownership')
 request=dict(event_handoff=event_handoff,ordinary_handoff=ordinary_handoff,geo_handoff=geo_handoff,count_preparation=count_preparation,consumer_root=str(consumer))
 pins={}
 def pin(d,load=True):
  p=str(Path(d['path']).resolve())
  if m.sha(p)!=d['sha256']:raise ValueError('Publisher input hash differs: '+p)
  pins[p]=d['sha256'];return m.read(p) if load else p
 event=pin(event_handoff);ordinary=pin(ordinary_handoff);geo=pin(geo_handoff);prepared=pin(count_preparation)
 if work.exists():
  marker=work/'VERIFIED_HANDOFF.json'
  if not marker.exists():raise ValueError('Incomplete consumer generation; use a new output directory')
  previous=m.read(marker)
  if previous['request']!=request or previous['wrapper_code_sha256']!=m.sha(__file__):raise ValueError('Changed consumer request cannot overwrite generation')
  for p,d in previous['input_sha256'].items():
   if m.sha(p)!=d:raise ValueError('Consumer replay input changed')
  for name,d in previous['artifact_sha256'].items():
   if m.sha(work/name)!=d:raise ValueError('Consumer replay output changed')
  return previous
 if ordinary['count_receipt']!=event['count_receipt'] or ordinary['native_registry']!=event['native_registry'] or ordinary['frozen_frontier']!=event['frozen_frontier'] or geo['frontier_receipt']!=event['frozen_frontier'] or prepared['frontier_receipt']!=event['frozen_frontier']:raise ValueError('Consumer stage frontier differs')
 frozen=pin(event['frozen_frontier']);count=pin(event['count_receipt']);relation=pin(ordinary['relation_receipt'])
 if frozen.get('schema')!='geoai-immutable-cpu-frontier-v1' or frozen.get('status')!='READY_CPU_ONLY' or frozen.get('canonical_store_write_allowed') is not False:raise ValueError('Committed immutable CPU frontier required')
 if geo['decision_binding']!=count['decision_binding'] or pin(geo['count_receipt'])['projection']!=count['projection'] or pin(prepared['consumer_inputs']['count_receipt'])['projection']!=count['projection']:raise ValueError('Consumer count frontier differs')
 if len(count['decision_binding'])!=frozen['active_units'] or prepared['CPU_units']!=frozen['active_units']:raise ValueError('Consumer unit frontier differs')
 for hand in [event,ordinary,geo]:
  for value in hand.values():
   if isinstance(value,dict) and {'path','sha256'}<=set(value):pin(value,False)
 for p,d in geo['source_sha256'].items():pin(dict(path=p,sha256=d),False)
 for d in geo['artifacts'].values():pin(d,False)
 source=pin(geo['source_GEO_receipt'])
 producer=geo.get('processor') or geo.get('producer') or dict(path=str(Path(geo_handoff['path']).with_name('prepare_frozen90.py')),sha256=geo['code_sha256'])
 if not Path(producer['path']).resolve().is_relative_to(ROOT/'geometry_direct_20261101'):raise ValueError('Unexpected GEO producer ownership')
 pin(producer,False)
 source.update(status=geo['status'],decisions=geo['decisions'],active_LOC=geo['active_LOC'],active_typed_nodes=geo['active_typed_nodes'],GEO_handoff=geo_handoff,GEO_code=producer,active_endpoint_gate=geo['artifacts']['active_endpoint_gate'])
 work.mkdir();normalized=write(work/'verified_active_GEO_source.json',source)
 projection=dict(scope_kind='FULL_LOC_POPULATION',scope_qids=geo['source_scope_qids'],geography_path=geo['artifacts']['full_source_geography']['path'],geoparquet_path=geo['artifacts']['full_source_geoparquet']['path'],artifact_sha256={geo['artifacts'][k]['path']:geo['artifacts'][k]['sha256'] for k in ['full_source_geography','full_source_geoparquet']},source_binding=dict(count_receipt_sha256=m.content_hash(count),relation_receipt_sha256=m.content_hash(relation)))
 geometry=dict(decision_binding=count['decision_binding'],projection=projection,projection_sha256=m.content_hash(projection),active_LOC_projection_required=True,source_receipt=normalized)
 geometry_descriptor=write(work/'geometry_receipt.json',geometry);population,audit,unused=admit_population(count['projection'],geometry)
 if len(population)!=geo['active_typed_nodes'] or set(audit['active_LOC'])!=set(geo['active_scope_qids']):raise ValueError('GEO active population differs')
 registry=pin(event['native_registry']);prior=dict(registry['selected_references']);geo_registry=pin(geo['geometry_source_registry'])
 for q,reference in geo_registry['selected_references'].items():
  raw=reference['envelope']['entity']
  if raw.get('id')!=q or reference['envelope']['requested_qid']!=q or 'claims' not in raw:raise ValueError('GEO identity source integrity differs')
  registry['selected_references'].setdefault(q,reference)
 if any(registry['selected_references'][q]!=r for q,r in prior.items()):raise ValueError('Existing source registry changed')
 identity=write(work/'current_identity_registry_plus_verified_LOC_sources.json',registry);native=dict(event['native_registry'],identity_registry=identity)
 sources=[event_handoff,ordinary_handoff,geo_handoff,count_preparation,event['frozen_frontier'],event['count_receipt'],ordinary['relation_receipt'],ordinary['join_compatibility'],ordinary['pending_pair_scope'],geo['geometry_source_registry'],geo['source_GEO_receipt'],geo['artifacts']['exceptions'],geo['artifacts']['active_endpoint_gate'],normalized,geometry_descriptor]
 manifest=dict(schema='geoai-compact-checkpoint-v1',compact_frontier=prepared['consumer_inputs']['compact_frontier'],count_receipt=event['count_receipt'],relation_receipt=ordinary['relation_receipt'],geometry_receipt=geometry_descriptor,native_registry=native,event_route=event['route'],source_receipts=sources)
 manifest_descriptor=write(work/'manifest.json',manifest)
 print('VERIFIED frozen stage inputs; materializing '+str(frozen['active_units'])+' units',flush=True)
 result=m.materialize_components(work/'components',compact_frontier=manifest['compact_frontier'],count_receipt=count,relation_receipt=relation,geometry_receipt=geometry,native_registry=native,event_route=event['route'],source_receipts=sources+[manifest_descriptor],consumer_root=consumer)
 receipt=m.read(result['receipt_path']);exceptions=m.read(work/'components/private/data_exceptions.json');verification=verify_components(work/'components',receipt,count,geo);proof=write(work/'independent_verification.json',verification)
 if any(m.sha(p)!=d for p,d in pins.items()):raise ValueError('Stage input changed during consumer materialization')
 after=receipt.get('native_event_assertions',0);ordinary_native=len(relation['projection']['relations']);counts=count['projection']
 report=dict(status='PASS_FROZEN_FULL_ORDINARY_EVENT_ACTIVE_GEO_CONSUMER',consumer_checks=receipt['consumer_checks'],CPU_units=frozen['active_units'],raw_occurrences=counts['retained_occurrences'],raw_assigned=counts['accepted_occurrences'],raw_pending=counts['pending_occurrences'],raw_NONE=counts['explicit_unmatched_occurrences'],raw_typed_nodes=len(counts['typed_counts']),GEO_active_before_source_name_quarantine=geo['active_LOC'],GEO_source_gaps=geo['native_source_gaps'],GEO_unknown=geo['unknown_LOC'],GEO_position_pending_inside=sum(d['mask_result']=='INCLUDE' and d['position_selection_pending'] for d in geo['decisions']),ordinary_native_before_active_filters=ordinary_native,Event_native_after_dedup=after,ordinary_Event_unique_native_before_active_filters=ordinary_native+after,ordinary_source_gaps=ordinary.get('missing_QIDs'),Event_source_gaps=event.get('source_gaps'),Event_quarantined=event.get('quarantine'),consumer_quarantined_typed_items=exceptions['quarantined_typed_items'],consumer_quarantined_mentions=exceptions['quarantined_mentions'],excluded_GEO_relation_views=exceptions['excluded_GEO_relation_views'],excluded_quarantine_relation_views=exceptions['excluded_quarantine_relation_views'],receipt=dict(path=result['receipt_path'],sha256=result['receipt_sha256']),refresh_inputs=desc(work/'components/private/refresh_inputs.json'),manifest=manifest_descriptor,independent_verification=proof,graph=desc(work/'components/graph.json'),model_native_assertions_after_active_filters=verification['native_assertions_after_active_filters'],all_quarantined_occurrence_IDs_verified=verification['all_quarantined_occurrence_IDs_verified'],full_unit_completion_claim=False,DATE_context_completion_claim=False,canonical_CPU_store_opened=False,publication=False,request=request,wrapper_code_sha256=m.sha(__file__),input_sha256=dict(receipt['inputs_sha256'],**pins),artifact_sha256={p.relative_to(work).as_posix():m.sha(p) for p in work.rglob('*') if p.is_file()})
 write(work/'VERIFIED_HANDOFF.json',report);return report
