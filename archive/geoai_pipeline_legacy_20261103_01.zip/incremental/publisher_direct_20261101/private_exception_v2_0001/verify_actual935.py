"""Actual935 full semantic equivalence, byte-preserving replay and bounded-memory serialization benchmark."""
import gc,ijson,json,sys,time,tracemalloc,psutil
from pathlib import Path
from itertools import zip_longest
HERE=Path(__file__).resolve().parent
import exception_codec as c

def measure(fn):
 gc.collect();tracemalloc.start();fn();peak=tracemalloc.get_traced_memory()[1];tracemalloc.stop();return peak

def main():
 diagnostic=json.loads(Path('C:/Users/User/Documents/Codex/2026-11-01/task-4/exception_duplication_935.json').read_text());source=Path(diagnostic['source']);before=c.signature(source)
 assert before==(diagnostic['source_bytes'],diagnostic['source_mtime_ns'])
 metadata=c.legacy_metadata(source);sample=[]
 with source.open('rb') as f:
  for row in ijson.items(f,'items.item',use_float=True):
   sample.append(row)
   if len(sample)==64:break
 shared=sample[0]['occurrences']['lookup']['decision_binding']
 for row in sample:assert row['occurrences']['lookup']['decision_binding']==shared;row['occurrences']['lookup']['decision_binding']=shared
 test_meta=dict(metadata,quarantined_typed_items=len(sample),quarantined_mentions=sum(r['occurrences']['mention_count'] for r in sample));summary=dict(test_meta,items=sample)
 old_peak=measure(lambda:json.dumps(summary,indent=2))
 new_peak=measure(lambda:c.write_summary(summary,HERE/'sample64_compact_0001'))
 assert c.read_summary(c.descriptor(HERE/'sample64_compact_0001/manifest.json'))==summary
 assert new_peak<old_peak/4,(old_peak,new_peak)
 print(json.dumps(dict(stage='SAMPLE64_MEMORY_PASS',legacy_json_dumps_peak_python_bytes=old_peak,v2_streaming_writer_peak_python_bytes=new_peak)),flush=True)
 del summary,sample,shared;gc.collect();process=psutil.Process();peak_rss=process.memory_info().rss;started=time.perf_counter()
 def progress(n):
  nonlocal peak_rss
  peak_rss=max(peak_rss,process.memory_info().rss)
  if n%512==0:print(json.dumps(dict(stage='CONVERTING935',items=n,elapsed_seconds=round(time.perf_counter()-started,1),rss_bytes=process.memory_info().rss)),flush=True)
 ref=c.convert_legacy(source,HERE/'converted935_0001',progress=progress);manifest=c.read(ref['path']);assert manifest['item_count']==6422 and manifest['mention_count']==34189 and manifest['binding_count']==1
 print(json.dumps(dict(stage='CONVERSION_PASS',items=manifest['item_count'],bindings=manifest['binding_count'],seconds=round(time.perf_counter()-started,1))),flush=True)
 # Compare EVERY source record/value, including all935 binding heads, against reconstructed v1 records.
 count=0;missing=object();comparison=time.perf_counter()
 with source.open('rb') as f:
  for old,new in zip_longest(ijson.items(f,'items.item',use_float=True),c.iter_items(ref),fillvalue=missing):
   assert old==new,('Semantic mismatch',count);count+=1
   peak_rss=max(peak_rss,process.memory_info().rss)
   if count%1024==0:print(json.dumps(dict(stage='EQUIVALENCE935',items=count,elapsed_seconds=round(time.perf_counter()-comparison,1))),flush=True)
 assert count==6422 and c.signature(source)==before
 compact_meta=c.read(Path(ref['path']).parent/'metadata.json');assert compact_meta==metadata
 files=[p for p in Path(ref['path']).parent.iterdir() if p.is_file()];snap={p:(c.sha(p),p.stat().st_mtime_ns) for p in files}
 assert c.convert_legacy(source,HERE/'converted935_0001')==ref
 assert all((c.sha(p),p.stat().st_mtime_ns)==v for p,v in snap.items())
 loaded=c.read_summary(ref);assert len(loaded['items'])==6422;bindings=[r['occurrences']['lookup']['decision_binding'] for r in loaded['items']];assert all(b is bindings[0] for b in bindings)
 peak_rss=max(peak_rss,process.memory_info().rss);compact_bytes=sum(p.stat().st_size for p in files)
 report=dict(status='PASS_ACTUAL935_PRIVATE_EXCEPTION_DEDUP_EXACT_EQUIVALENCE',source=dict(path=str(source),sha256=manifest['source']['sha256'],bytes=before[0]),compact_manifest=ref,compact_bytes=compact_bytes,reduction_percent=round((1-compact_bytes/before[0])*100,4),original_records=6422,reconstructed_records=count,quarantined_mentions=34189,unique_bindings=1,binding_heads=len(bindings[0]),all_original_values_equal=True,metadata_equal=True,all_occurrence_QID_reason_count_provenance_values_preserved=True,source_signature_unchanged=c.signature(source)==before,replay_preserved_bytes_and_mtimes=True,legacy_json_dumps_sample64_peak_python_bytes=old_peak,v2_streaming_sample64_peak_python_bytes=new_peak,sample_memory_reduction_percent=round((1-new_peak/old_peak)*100,4),measured_process_peak_rss_bytes=peak_rss,whole935_legacy_load_not_attempted='Avoided unsafe multi-GB allocation; full source was compared record-by-record. Controlled64-record benchmark measures the actual legacy serialization versus streaming v2.',elapsed_seconds=round(time.perf_counter()-started,2),active_writer_outputs_modified=False,public_graph_or_Parquet_schema_changed=False,production_activated=False,publication=False)
 c.dump(HERE/'verification935.json',report);print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
