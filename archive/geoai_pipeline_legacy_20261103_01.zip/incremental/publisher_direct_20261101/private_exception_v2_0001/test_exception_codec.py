"""Replay, exact nested values, metadata fallback, corruption and missing references."""
import json,sys,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
import exception_codec as c

def main():
 work=HERE/(sys.argv[1] if len(sys.argv)>1 else 'unit_0001');work.mkdir()
 binding=[dict(scope=['input','enwiki',71,123,'source','policy'],decision_version='v1',decision_content_sha256='f'*64)]
 rows=[dict(qid='Q1',reason='MISSING_SOURCE',occurrences=dict(mention_count=2,occurrence_ids=['a','b'],lookup=dict(decision_binding=binding,count_projection_sha256='d'*64)),source=dict(raw=dict(score=0.125,name='日本')),resolved=False),dict(qid='Q2',reason='PENDING_NAME',occurrences=dict(mention_count=1,occurrence_ids=['c'],lookup=dict(decision_binding=binding,count_projection_sha256='d'*64)),source=None,resolved=False)]
 summary=dict(schema='geoai-data-exceptions-v1',items=rows,quarantined_typed_items=2,quarantined_mentions=3,extra=dict(nested=[True,None,1.25]),resolved=False)
 legacy=work/'legacy.json';legacy.write_text(json.dumps(summary,ensure_ascii=True),encoding='utf8');assert c.read_summary(c.descriptor(legacy))==summary
 ref=c.write_summary(summary,work/'compact');assert c.read_summary(ref)==summary
 before={p:c.sha(p) for p in (work/'compact').iterdir()};assert c.write_summary(summary,work/'compact')==ref;assert all(c.sha(p)==d for p,d in before.items())
 # Manifest-pinned byte corruption must reject before any record escapes.
 damaged=work/'corrupt';shutil.copytree(work/'compact',damaged);(damaged/'bindings.json').write_text('{}',encoding='utf8')
 try:list(c.iter_items(c.descriptor(damaged/'manifest.json')))
 except ValueError:pass
 else:raise AssertionError('Corrupt binding file accepted')
 # Re-sign the test container to isolate semantic missing-reference validation.
 missing=work/'missing_reference';shutil.copytree(work/'compact',missing);lines=(missing/'items.jsonl').read_text().splitlines();row=json.loads(lines[0]);row['occurrences']['lookup'][c.REF]='0'*64;lines[0]=json.dumps(row);(missing/'items.jsonl').write_text('\n'.join(lines)+'\n',encoding='utf8');manifest=c.read(missing/'manifest.json');manifest['files']['items.jsonl']=c.sha(missing/'items.jsonl');c.dump(missing/'manifest.json',manifest)
 try:list(c.iter_items(c.descriptor(missing/'manifest.json')))
 except ValueError as e:assert 'Missing decision binding reference' in str(e)
 else:raise AssertionError('Missing reference accepted')
 converted=c.convert_legacy(legacy,work/'converted');assert c.read_summary(converted)==summary;assert c.convert_legacy(legacy,work/'converted')==converted
 print('PASS exact nested values, dual-reader metadata, writer/converter replay, corrupt bytes and missing-reference rejection')
if __name__=='__main__':main()
