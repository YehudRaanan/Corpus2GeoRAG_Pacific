"""Private v2 file boundary for a versioned producer; historical v1 is never rewritten."""
import json
from pathlib import Path
import ijson
import exception_codec as codec
LINK_SCHEMA='geoai-private-exceptions-link-v2'

def read_json(path):
 path=Path(path)
 if path.name=='data_exceptions.json':
  with path.open('rb') as f:schema=next(ijson.items(f,'schema'),None)
  if schema==LINK_SCHEMA:
   link=codec.read(path);relative=Path(link['manifest']['path'])
   if relative.is_absolute():raise ValueError('Exception store reference must be relative')
   target=(path.parent/relative).resolve()
   if not target.is_relative_to(path.parent.resolve()) or target.is_symlink():raise ValueError('Exception store reference leaves private directory')
   return codec.read_summary(dict(path=str(target),sha256=link['manifest']['sha256']))
 return json.loads(path.read_text(encoding='utf-8-sig'))

def write_private_summary(path,summary):
 path=Path(path).resolve()
 if not path.is_relative_to(codec.PUBLISHER):raise ValueError('Exception output leaves publisher ownership')
 ref=codec.write_summary(summary,path.parent/(path.stem+'_v2'))
 link=dict(schema=LINK_SCHEMA,manifest=dict(path=Path(ref['path']).relative_to(path.parent).as_posix(),sha256=ref['sha256']))
 if path.exists():
  if codec.read(path)!=link:raise ValueError('Changed private exception pointer cannot overwrite generation')
 else:codec.dump(path,link)
 return codec.descriptor(path)
