# Actual-frontier component materializer: ready interface and baseline evidence

Function ready in materialize_components.py:

    materialize_components(output_dir, *, identity_state, count_receipt,
        relation_receipt, geometry_receipt, native_registry,
        source_receipts, consumer_root)

Inputs are the actual in-memory identity state and existing INTEGRATION count/relation projection receipts. require_current validates every decision_binding/projection hash against that state. The materializer independently reproduces the bounded one-unit count projection, requires relation counts/count-receipt binding and native-registry/catalog hashes to match, and requires full geometry to bind both current count/relation receipts. It does not accept an old consumer receipt as proof of a new identity frontier.

GEO_INPUT_INTERFACE.txt gives the exact pending full-geometry handoff: the standard decision_binding/projection/projection_sha256 wrapper; projection.scope_kind=FULL_LOC_POPULATION, scope_qids, geography_path, geoparquet_path, artifact_sha256 and source_binding containing content_hash(count_receipt) and content_hash(relation_receipt). Full LOC membership/null/pointer/GeoParquet validity is checked through the already-tested full-scope validator. Tokyo-only fragments are not a full projection.

The fresh output builds source-native Entity rows from the actual current typed counts and pinned whole source records using existing choose_name/build_graph/catalog machinery, takes native/default views from the current relation projection, preserves source assertions/dates/counts, maps only the already-proposed strength field and existing source_edge_id, and copies the supplied full geometry. Accepted LOC/ORG/PER only. MISC/Event/DATE or a missing full source/name is an explicit unsupported branch; no retyping, SYN, relation or geometry is invented.

Fresh generated artifacts are graph.json; model/entities/events/relations/cooccurrence_support/geography JSON gzip plus geometries.parquet; private actual identity/count/relation/full-geometry receipts, native registry, source references, readback and a NEW receipt.json. private/refresh_inputs.json supplies identities/relations/geometries/source_receipts/frontier/consumer_root in the refresh_snapshot input shape. INTEGRATION still supplies previous_snapshot, frontier.previous_receipt_sha256, cadence_attempt, completed_at and a new output_dir. This stage emits no cadence-success receipt and never advances a checkpoint.

Verified existing baseline: count_relation_chain_0001/result.json BEFORE context, unchanged real-pair-source-v2 registry, and the previously verified full five-LOC baseline geometry explicitly wrapped at the SAME first-unit-exact-v1 frontier. That geometry wrapper is baseline_only=true; it is not evidence for a later decision frontier. No real model decisions were changed or invoked.

TDD first failed because no new component receipt existed. Completed baseline_0002 passes fresh-process consumer/hash readback: ten nodes, 90 views, five geometries, 45 support identities. Stale relation and geometry bindings are rejected before output creation; MISC is explicitly rejected. Each output gets a newly generated receipt bound to actual input projection hashes. An initial Python reader-literal warning was removed without changing logic; baseline_0001 and its exact source/report remain preserved.

Latest receipt SHA256: a85ab2a64eddc716b72403042f4d028fbcd7b9ef91549086ce83749abbc3c210. Current code SHA256: d434aa512830aadca64f08ca0aa510c658e6e77e49e8dfbc620b011274e43780. Evidence: verification.json, baseline_0002/private/readback.json, receipt.json and refresh_inputs.json.

Ready for INTEGRATION/GEO wiring. The fresh-materializer -> refresh_snapshot end-to-end call has NOT run yet; this report returns the requested small-step result without waiting for it. GEO's forthcoming full_projection_0001 schema needs reconciliation against the explicit input contract; no claim it has already been consumed. All output remains proposed_contract=true with Daniel approval not recorded. Official consumer and prior snapshots are unchanged. No external call, GPU, publication, paid work, nested agent or source/plan overwrite. No denied or uncertain action. Backup: Unprotected.
