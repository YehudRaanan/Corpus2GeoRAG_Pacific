"""Actual one-unit count/relation/identity frontier -> fresh proposed component receipt.
Run python -B materialize_components.py for the existing verified baseline check.
"""
import hashlib,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
PUBLISHER=HERE.parent
ROOT=PUBLISHER.parent
sys.path[:0]=[str(ROOT/'orchestration_direct_20261101'),str(ROOT/'source_custody'),str(PUBLISHER/'publisher_refresh_0001'),r'D:\Projects\GeoAI']
from decision_revision_hook import decision_binding,require_current,content_hash
from publisher_refresh import validate_geometry_scope

def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def materialize_components(output_dir, *, identity_state, count_receipt, relation_receipt,
                           geometry_receipt, native_registry, source_receipts, consumer_root):
    """Consume current actual projections, never an old consumer receipt as frontier proof.

    geometry_receipt uses the same decision_binding/projection/projection_sha256
    wrapper as count/relation receipts; see GEO_INPUT_INTERFACE.txt.
    """
    import csv,gzip,shutil,subprocess
    from real_counts_revision import recompute_counts
    from GG_Data.pipeline.entities import choose_name
    from GG_Data.pipeline.graph_export import build_graph
    output=Path(output_dir).resolve()
    if not output.is_relative_to(PUBLISHER.resolve()) or output.exists():raise ValueError('Use a new owned output directory')
    if len(identity_state)!=1:raise ValueError('Current bounded adapter supports one source unit')
    require_current(count_receipt,identity_state)
    counts=count_receipt['projection']
    for row in counts['typed_counts']:
        if row['entity_group'] not in {'LOC','ORG','PER'}:
            raise ValueError('Unsupported accepted type: '+row['entity_group']+'; no MISC/Event/DATE mapping')
    expected_counts=recompute_counts(identity_state,None,[])
    if counts!=expected_counts:raise ValueError('Counts do not reproduce the actual supplied identity frontier')
    require_current(relation_receipt,identity_state)
    require_current(geometry_receipt,identity_state)
    relation=relation_receipt['projection']
    if relation['counts']!=counts or relation['input_binding']['count_receipt_sha256']!=content_hash(count_receipt):
        raise ValueError('Relation projection uses different counts')
    geometry=geometry_receipt['projection']
    expected_source=dict(count_receipt_sha256=content_hash(count_receipt),relation_receipt_sha256=content_hash(relation_receipt))
    if geometry['source_binding']!=expected_source:raise ValueError('Full geometry projection uses different counts/relations')
    if geometry['scope_kind']!='FULL_LOC_POPULATION':raise ValueError('Full geometry projection required, not a fragment')
    pinned={}
    for source in source_receipts:
        if sha(source['path'])!=source['sha256']:raise ValueError('Source receipt/artifact hash differs')
        pinned[source['path']]=source['sha256']
    if not pinned:raise ValueError('Pinned source receipts required')
    registry_path=Path(native_registry['path'])
    if sha(registry_path)!=native_registry['sha256'] or relation['input_binding']['native_registry_sha256']!=native_registry['sha256']:
        raise ValueError('Native source registry differs from relation projection')
    pinned[str(registry_path)]=native_registry['sha256']
    registry=read(registry_path)
    entities=[]
    for row in counts['typed_counts']:
        qid=row['qid']
        if qid not in registry['selected_references']:
            raise ValueError('Unsupported missing whole native name/source for accepted identity: '+qid)
        reference=registry['selected_references'][qid]
        envelope=reference['envelope']
        raw=envelope['entity']
        if envelope['requested_qid']!=qid or raw.get('id')!=qid or 'claims' not in raw:
            raise ValueError('Whole source record is not the accepted QID')
        name=choose_name(qid,raw,{},[])
        entities.append(dict(entity_id=qid,type=row['entity_group'],name=name['value'],aliases=[],
            name_selection=name,raw_reference=dict(full=envelope),sources=[reference['provenance']]))
    mapping_path=Path(r'D:\Projects\GeoAI/GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv')
    directions_path=mapping_path.with_name('RELATION_DIRECTION_LOOKUP_v2.1.1.csv')
    for path,key in [(mapping_path,'mapping_sha256'),(directions_path,'direction_sha256')]:
        if sha(path)!=relation['input_binding'][key]:raise ValueError('Relation catalog differs')
        pinned[str(path)]=sha(path)
    def csv_rows(path):
        with path.open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream))
    graph,_=build_graph(entities,[],relation['relations'],csv_rows(mapping_path),csv_rows(directions_path),dict(registry['native_producer_graph']['metadata']))
    defaults=[row for row in relation['active_views'] if row.get('kind')=='CO_MENTIONED']
    graph['edges']=[row for row in relation['active_views'] if row.get('kind')!='CO_MENTIONED']
    for row in defaults:
        edge=dict(id=row['id'],source=row['source'],target=row['target'],type='CO_MENTIONED',count=row['shared_page_count'],strength=row['directional_strength'])
        if row['source']>row['target']:
            reverse=[r for r in defaults if (r['source'],r['target'])==(row['target'],row['source'])]
            if len(reverse)!=1:raise ValueError('Missing unique reverse default support')
            edge['source_edge_id']=reverse[0]['id']
        graph['edges'].append(edge)
    geometry_version='sha256:'+sha(geometry['geoparquet_path'])
    geometry_component=dict(version=geometry_version,decision_version=counts['decision_version'],
        scope=dict(kind='FULL_LOC_POPULATION',place_ids=geometry['scope_qids']),
        artifacts=dict(geography=geometry['geography_path'],geoparquet=geometry['geoparquet_path']))
    for path in geometry_component['artifacts'].values():
        if geometry['artifact_sha256'].get(path)!=sha(path):raise ValueError('Full geometry artifact is not bound to its projection')
        pinned[path]=sha(path)
    validate_geometry_scope(geometry_component,graph)
    consumer=Path(consumer_root).resolve()
    consumer_pins={str(consumer/'geo_agent'/name):sha(consumer/'geo_agent'/name) for name in ['__init__.py','graph_store.py','model_dates.py']}
    pinned.update(consumer_pins)
    output.mkdir()
    model=output/'model';model.mkdir()
    private=output/'private';private.mkdir()
    def write(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf-8')
    def compressed(path,value):path.write_bytes(gzip.compress(json.dumps(value).encode(),mtime=0))
    write(output/'graph.json',graph)
    compressed(model/'entities.json.gz',entities)
    compressed(model/'events.json.gz',[])
    compressed(model/'relations.json.gz',relation['relations'])
    compressed(model/'cooccurrence_support.json.gz',defaults)
    shutil.copyfile(geometry['geography_path'],model/'geography.json.gz')
    shutil.copyfile(geometry['geoparquet_path'],model/'geometries.parquet')
    write(private/'identity_frontier.json',dict(decision_binding=decision_binding(identity_state),units=list(identity_state.values())))
    write(private/'count_receipt.json',count_receipt)
    write(private/'relation_frontier.json',relation_receipt)
    write(private/'full_geometry_receipt.json',geometry_receipt)
    shutil.copyfile(registry_path,private/'native_registry.json')
    write(private/'source_receipts.json',source_receipts)
    reader="""import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);consumer=Path(sys.argv[2]);sys.path[:0]=[str(consumer),r'D:\Projects\GeoAI']
from geo_agent.graph_store import GraphStore
import geo_agent.graph_store as module
assert Path(module.__file__).resolve()==(consumer/'geo_agent/graph_store.py').resolve()
for name,digest in json.loads(sys.stdin.read()).items():
 with (root/name).open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==digest,name
store=GraphStore.from_json(root/'graph.json',model_dir=root/'model')
print(json.dumps(dict(nodes=len(store.nodes),edges=len(store.edges),geometries=len(store.geoms),support_identities=store.schema()['assertion_count'])))
"""
    artifacts={path.relative_to(output).as_posix():sha(path) for path in output.rglob('*') if path.is_file()}
    process=subprocess.run([sys.executable,'-B','-c',reader,str(output),str(consumer)],input=json.dumps(artifacts),text=True,capture_output=True,check=True,timeout=60)
    checks=json.loads(process.stdout)
    if checks['nodes']!=len(entities) or checks['edges']!=len(graph['edges']):raise ValueError('Consumer projection differs')
    if not all(sha(path)==digest for path,digest in pinned.items()):raise ValueError('Source changed during materialization')
    write(private/'readback.json',dict(status='PASS_FRESH_COMPONENT_CONSUMER_READBACK',checks=checks,artifact_sha256=artifacts))
    relation_version='sha256:'+relation_receipt['projection_sha256']
    receipt=dict(status='PASS_NEW_FRONTIER_COMPONENT_MATERIALIZATION',new_materialization=True,proposed_contract=True,daniel_approval='not recorded',
        decision_version=counts['decision_version'],decision_binding=decision_binding(identity_state),pair_projection_version=relation_version,
        count_projection_sha256=count_receipt['projection_sha256'],relation_projection_sha256=relation_receipt['projection_sha256'],geometry_projection_sha256=geometry_receipt['projection_sha256'],
        consumer_checks=checks,source_receipts=source_receipts,inputs_sha256=pinned,consumer_copy_sha256=consumer_pins,
        materializer_code_sha256=sha(Path(__file__)),artifact_sha256={path.relative_to(output).as_posix():sha(path) for path in output.rglob('*') if path.is_file()},publication=False)
    receipt_path=private/'receipt.json';write(receipt_path,receipt)
    def component(version,roles):return dict(version=version,decision_version=counts['decision_version'],artifacts={k:str(output/v) for k,v in roles.items()})
    identity_component=component(counts['decision_version'],dict(graph='graph.json',entities='model/entities.json.gz',events='model/events.json.gz'))
    relation_component=component(relation_version,dict(graph='graph.json',relations='model/relations.json.gz',cooccurrence_support='model/cooccurrence_support.json.gz',pair_views='private/relation_frontier.json'))
    geometry_component=component(geometry_version,dict(geography='model/geography.json.gz',geoparquet='model/geometries.parquet'))
    geometry_component['scope']=dict(kind='FULL_LOC_POPULATION',place_ids=geometry['scope_qids'])
    proof=dict(path=str(receipt_path),sha256=sha(receipt_path),artifact_root=str(output))
    result=dict(status=receipt['status'],receipt_path=str(receipt_path),receipt_sha256=proof['sha256'],
        frontier=dict(identity_version=counts['decision_version'],relation_version=relation_version,geometry_version=geometry_version),
        identities=identity_component,relations=relation_component,geometries=geometry_component,
        source_receipts={name:proof for name in ['identities','relations','geometries']},consumer_root=str(consumer))
    write(private/'refresh_inputs.json',result)
    return result



def self_check():
    from copy import deepcopy
    context_path=ROOT/'orchestration_direct_20261101/count_relation_chain_0001/result.json'
    proof=read(context_path.parent/'verification.json')
    assert sha(context_path)==proof['result_sha256']
    context=read(context_path)['before']
    state={tuple(row['scope']):versions for row,versions in zip(context['count_receipt']['decision_binding'],context['units'])}
    base=PUBLISHER/'proposed_strength_0001/snapshot_0007_retry_0001'
    geometry_paths={str(base/'model/geography.json.gz'):sha(base/'model/geography.json.gz'),str(base/'model/geometries.parquet'):sha(base/'model/geometries.parquet')}
    projection=dict(scope_kind='FULL_LOC_POPULATION',scope_qids=sorted(row['qid'] for row in context['count_receipt']['projection']['typed_counts'] if row['entity_group']=='LOC'),
        geography_path=str(base/'model/geography.json.gz'),geoparquet_path=str(base/'model/geometries.parquet'),artifact_sha256=geometry_paths,
        source_binding=dict(count_receipt_sha256=content_hash(context['count_receipt']),relation_receipt_sha256=content_hash(context['relation_receipt'])),baseline_only=True)
    geometry=dict(decision_binding=decision_binding(state),projection=projection,projection_sha256=content_hash(projection))
    native=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    sources=[dict(path=str(path),sha256=sha(path)) for path in [context_path,context_path.parent/'verification.json',native,base/'private/receipt.json']]
    parameters=dict(identity_state=state,count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'],geometry_receipt=geometry,
        native_registry=dict(path=str(native),sha256='1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4'),
        source_receipts=sources,consumer_root=PUBLISHER/'proposed_strength_0001/consumer')
    result=materialize_components(HERE/'baseline_0001',**parameters)
    assert result and result['status']=='PASS_NEW_FRONTIER_COMPONENT_MATERIALIZATION','No fresh component materialization receipt'
    receipt=read(Path(result['receipt_path']))
    assert receipt['decision_version']=='first-unit-exact-v1' and receipt['new_materialization'] is True
    assert receipt['consumer_checks']==dict(nodes=10,edges=90,geometries=5,support_identities=45)
    for label,name in [('stale_relations','relation_receipt'),('stale_geometry','geometry_receipt')]:
        invalid=deepcopy(parameters)
        invalid[name]['decision_binding'][0]['decision_version']='STALE'
        try:materialize_components(HERE/label,**invalid)
        except ValueError:pass
        else:raise AssertionError('Stale component receipt accepted')
        assert not (HERE/label).exists()
    invalid=deepcopy(parameters)
    invalid['count_receipt']['projection']['typed_counts'][0]['entity_group']='MISC'
    invalid['count_receipt']['projection_sha256']=content_hash(invalid['count_receipt']['projection'])
    try:materialize_components(HERE/'unsupported_MISC',**invalid)
    except ValueError as error:assert 'Unsupported accepted type' in str(error)
    else:raise AssertionError('MISC was silently mapped')
    assert not (HERE/'unsupported_MISC').exists()
    report=dict(status='PASS_ACTUAL_BASELINE_COMPONENT_MATERIALIZER',baseline_only=True,real_model_decisions_changed=False,
        decision_version=receipt['decision_version'],nodes=10,edges=90,geometries=5,new_receipt=True,
        stale_relation_and_geometry_rejected=True,unsupported_MISC_rejected=True,proposed_contract=True,
        daniel_approval='not recorded',receipt_sha256=result['receipt_sha256'],code_sha256=sha(Path(__file__)),publication=False)
    (HERE/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':self_check()
