# Ready GEO interface consumed

PASS_ACTUAL_FULL_GEO_RECEIPT_MATERIALIZATION. The existing materialize_components signature is unchanged. The actual GEO receipt is consumed through the owned field-only adapter:

    bind_full_geometry(receipt_path, expected_sha256, *, identity_state,
                       count_receipt, relation_receipt)

Import it from consume_full_geometry.py, then pass its return value as geometry_receipt to materialize_components. The adapter requires the original file/hash, checks require_current on counts, relations and the original GEO receipt, verifies all source/output hashes and the original full-scope/version/artifact bindings, and retains original_geometry_receipt unchanged. It maps actual GEO scope/artifacts fields into the already-defined materializer input shape. Its new source_binding is explicitly an adapter context binding to already-current count/relation inputs; it does not claim that those extra fields existed in GEO's receipt. Original GEO version, request hash, projection hash and file hash remain separately preserved. No old receipt can be relabelled to another decision frontier.

The actual tested source is geometry_direct_20261101/full_projection_0001/version_1/receipt.json, independently compared with its verified output_receipts entry. Its Geography/GeoParquet are copied byte-for-byte into a new component generation. The producer's source receipt and all source/output files remained unchanged. Geometry was not reconstructed or selected.

Result: full_geometry_baseline_0001 contains a NEW materialization receipt, graph/model/private provenance and refresh inputs; ten nodes, 90 views, five geometries, 45 support identities. Fresh-process consumer/hash readback passed. A different decision frontier was rejected. Tests used the actual baseline only, not new real model decisions. The GEO version_2/version_3 synthetic branches are not claimed consumed; the current materializer still explicitly rejects missing whole native entity/name sources and unsupported accepted types.

Latest receipt SHA256 c1987f5de6e06fe1bc6d486a0a4983d1d0938a67c6bbe554470435fd72fad9e0. Field-adapter SHA256 85a05c405f7e5c379b91f9bd72c9d8fb3bee7f4a084691c6978a8ddb12b73875. Ready manifest: full_geometry_baseline_0001/private/refresh_inputs.json. Evidence: full_geometry_verification.json and full_geometry_baseline_0001/private/readback.json. INTEGRATION supplies previous snapshot/hash, cadence attempt/time and a new refresh output slot. The final fresh-components -> refresh/cadence end-to-end invocation has not been performed here.

All prior versions, official consumer and source modules remain unchanged. Proposed contract only; no recorded Daniel approval, external call, publication, GPU, paid work or nested agent. No denied/uncertain tool action or remaining GEO-format blocker. Backup: Unprotected.
