"""Bind the ready GEO receipt to current count/relation inputs without rewriting it."""
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sys.path.insert(0,str(HERE))
from materialize_components import materialize_components,decision_binding,require_current,content_hash,sha,read

def bind_full_geometry(receipt_path,expected_sha256,*,identity_state,count_receipt,relation_receipt):
    """Map receipt fields only; retain the exact original GEO receipt and version."""
    receipt_path=Path(receipt_path).resolve()
    if sha(receipt_path)!=expected_sha256:raise ValueError('Full GEO receipt hash differs')
    original=read(receipt_path)
    for receipt in [count_receipt,relation_receipt,original]:require_current(receipt,identity_state)
    if relation_receipt['projection']['input_binding']['count_receipt_sha256']!=content_hash(count_receipt):
        raise ValueError('Current relation/count dependency differs')
    projection=original['projection']
    if original['scope']!=projection['scope'] or original['scope']['kind']!='FULL_LOC_POPULATION':
        raise ValueError('Actual GEO receipt is not a full projection')
    if original['artifacts']!=projection['artifacts']:raise ValueError('GEO artifact views differ')
    for path,digest in original['source_sha256'].items():
        if sha(path)!=digest:raise ValueError('Full GEO source changed')
    for path,digest in original['artifact_sha256'].items():
        if sha(path)!=digest:raise ValueError('Full GEO output changed')
    artifacts=original['artifacts']
    if original['version']!='sha256:'+sha(artifacts['geoparquet']):raise ValueError('GEO source version differs')
    mapped=dict(scope_kind=original['scope']['kind'],scope_qids=original['scope']['place_ids'],
        geography_path=artifacts['geography'],geoparquet_path=artifacts['geoparquet'],
        artifact_sha256=original['artifact_sha256'],
        source_binding=dict(count_receipt_sha256=content_hash(count_receipt),relation_receipt_sha256=content_hash(relation_receipt)),
        adapter_context_binding=True,source_geometry_version=original['version'],
        source_geometry_receipt=dict(path=str(receipt_path),sha256=expected_sha256,
            projection_sha256=original['projection_sha256'],request_sha256=original['request_sha256']))
    return dict(decision_binding=decision_binding(identity_state),projection=mapped,projection_sha256=content_hash(mapped),
        adapter_only=True,original_geometry_receipt=original)



def self_check():
    from copy import deepcopy
    context_path=ROOT/'orchestration_direct_20261101/count_relation_chain_0001/result.json'
    proof=read(context_path.parent/'verification.json')
    assert sha(context_path)==proof['result_sha256']
    context=read(context_path)['before']
    state={tuple(row['scope']):versions for row,versions in zip(context['count_receipt']['decision_binding'],context['units'])}
    geo=ROOT/'geometry_direct_20261101/full_projection_0001'
    source=geo/'version_1/receipt.json'
    geo_proof=read(geo/'verification.json')
    assert read(source)==geo_proof['output_receipts'][0]
    before={str(p):sha(p) for p in (geo/'version_1').iterdir() if p.is_file()}
    adapted=bind_full_geometry(source,sha(source),identity_state=state,count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'])
    assert adapted,'Actual full GEO receipt was not adapted'
    native=ROOT/'pair_relations_direct_20261101/real_pair_views_v2_20261101T205143791359Z/pair_views.json'
    result=materialize_components(HERE/'full_geometry_baseline_0001',identity_state=state,
        count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'],geometry_receipt=adapted,
        native_registry=dict(path=str(native),sha256='1770c78950a542f336047dda8033d0231c6b0e2d4f86ed45ed1fe26fdb2029e4'),
        source_receipts=[dict(path=str(p),sha256=sha(p)) for p in [context_path,context_path.parent/'verification.json',source,geo/'verification.json',native]],
        consumer_root=HERE.parent/'proposed_strength_0001/consumer')
    materialized=read(Path(result['receipt_path']))
    assert materialized['consumer_checks']==dict(nodes=10,edges=90,geometries=5,support_identities=45)
    assert adapted['original_geometry_receipt']==read(source)
    assert before=={str(p):sha(p) for p in (geo/'version_1').iterdir() if p.is_file()}
    stale=deepcopy(state)
    next(iter(stale.values()))[-1]['version']='STALE'
    try:bind_full_geometry(source,sha(source),identity_state=stale,count_receipt=context['count_receipt'],relation_receipt=context['relation_receipt'])
    except ValueError:pass
    else:raise AssertionError('Old GEO receipt relabelled to another frontier')
    report=dict(status='PASS_ACTUAL_FULL_GEO_RECEIPT_MATERIALIZATION',source_receipt_unchanged=True,
        source_GEO_interface_consumed=True,geometry_reconstructed=False,old_receipt_not_relabelled=True,
        decision_version=materialized['decision_version'],nodes=10,edges=90,geometries=5,
        receipt_sha256=result['receipt_sha256'],adapter_code_sha256=sha(Path(__file__)),
        refresh_inputs=str(Path(result['receipt_path']).parent/'refresh_inputs.json'),publication=False)
    (HERE/'full_geometry_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':self_check()
