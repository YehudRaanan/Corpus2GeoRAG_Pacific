"""Fresh-process readback; deliberately does not import the adapter."""
import gzip
import hashlib
import json
import sys
from pathlib import Path
from collections import Counter
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
import geopandas as gpd
from geo_agent.graph_store import GraphStore

root = Path(__file__).resolve().parent
snapshot = root / 'snapshot_0001'
private = snapshot / 'private'
receipt = json.loads((private / 'receipt.json').read_text())
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for path, expected in receipt['inputs_sha256'].items():
    assert sha(path) == expected, path
for path, expected in receipt['artifact_sha256'].items():
    assert sha(snapshot / path) == expected, path
assert sha(private / 'missingness.json') == receipt['missingness_sha256']
assert sha(root / 'consumer_adapter.py') == receipt['adapter_sha256']
aggregate = json.loads((root.parent / 'integration_direct_20261101/real_handoff_0001/aggregate.json').read_text())
accepted = [o for o in aggregate['occurrences'] if len(o['decision_values']) == 1 and not o['identity_conflict']]
assert len(aggregate['occurrences']) == 136 and len(accepted) == 30
assert len(aggregate['occurrences']) - len(accepted) == 106
expected = Counter()
for occurrence in accepted:
    qid = occurrence['decision_values'][0]
    support = next(s for s in occurrence['supports'] if s['decision'] and s['decision']['qid'] == qid)
    expected[qid + '::' + support['member']['entity_group']] += 1
store = GraphStore.from_json(snapshot / 'graph.json', model_dir=snapshot / 'model')
assert set(store.nodes) == set(expected) and len(store.nodes) == 10
assert not store.edges and not store.geoms
with gzip.open(r'C:\Users\User\.cache\geoai_bigquery_20261018\entity_metadata.json.gz', 'rt', encoding='utf-8') as f:
    metadata = json.load(f)
for node in store.nodes.values():
    source = metadata[node.wikidata_id]
    assert node.name == (source['labels'].get('en') or source['labels']['ja'])
    assert node.aliases == source['aliases']
    assert store.resolve_ids(node.wikidata_id) == [node.id]
frame = gpd.read_parquet(snapshot / 'model/geometries.parquet')
assert len(frame) == 0 and frame.crs.to_epsg() == 4326
assert set(frame.columns) == {'place_id', 'geometry'}
with gzip.open(snapshot / 'model/geography.json.gz', 'rt') as f:
    geography = json.load(f)
assert {r['place_id'] for r in geography} == {n.wikidata_id for n in store.nodes.values() if n.type == 'location'}
assert len(geography) == 5 and all(r['geometry_ref'] is None for r in geography)
graph = json.loads((snapshot / 'graph.json').read_text())
assert set(graph) == {'metadata', 'nodes', 'edges', 'relation_catalog'}
assert all(set(n) == {'id', 'wikidata_id', 'name', 'type', 'aliases'} for n in graph['nodes'])
result = dict(status='PASS_FRESH_PROCESS_READBACK', checks=[
    'upstream pinned bytes unchanged', 'snapshot hashes intact', '30 accepted occurrences independently reconciled',
    '106 pending omitted without SYN', '10 typed QIDs and native labels/aliases preserved',
    'existing consumer load and QID resolution', 'no invented edges or geometry',
    'five null Geography references', 'empty EPSG:4326 GeoParquet', 'unchanged graph vocabulary'],
    snapshot_receipt_sha256=sha(private / 'receipt.json'), verification_code_sha256=sha(Path(__file__)))
(private / 'independent_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
