# Historical co-occurrence contract reconciliation

Read-only inspection completed. The formula and both directions are already approved. No further semantic approval is needed for them. This report supersedes the earlier suggestion that every default-export issue requires a new semantic gate: kind/type and assertion support are adapter work; the remaining mismatch is the existing consumer interface.

## Exact supported historical representation

SIMPLE Agent/geo_agent/compact_format.py defines format simplified-cooccurrence-v1 and five pair columns:

    [source_index, target_index, shared_page_count,
     strength_source_target, strength_target_source]

GG_Data/pipeline/simplified_relations.py:172-185 writes n/pages(source) and n/pages(target). It also writes relations.json.gz using these arrays plus relations_schema.json with the exact columns and relation_type CO_OCCURS_ON_PAGE. simplified_parquet.py:23-33 has integer shared_page_count and float64 strength_source_target/strength_target_source; this is whole-graph transport, not Geography GeoParquet.

The matching compact_store.py:303-333 query response already names count, shared_page_count, source_page_count, target_page_count, strength, reverse_strength, denominator_unit, shared_page_indices, source_pages/page_scope_id and shared assertion_id. _query reads both orientations from the same unordered pair; _relation returns n/source_count and n/target_count. Existing asymmetric fixture uses denominators four/five with shared count two (0.5 versus 0.4). This is concrete historical directional support. Tests were read, not rerun or accepted here.

## What reuses unchanged, and what does not

| Requirement | Existing evidence and result |
|---|---|
| Two directions/formula | Reuse unchanged from compact pair columns/query logic. No new formula/direction decision. |
| Ordinary relation type | MAIN Agent README:117 explicitly supports CO_MENTIONED. Private kind -> ordinary type is a direct field mapping, not a policy gap. Compact uses a different literal CO_OCCURS_ON_PAGE. Do not silently equate the two format identifiers. |
| Integer supporting count | Compact count=n is shared-page support; ordinary Edge.count is integer. Preserve the approved actual shared-page count and its support unit; never substitute a fraction. |
| Default assertion identity | Compact uses pair:min:max as assertion_id and one id per direction. Ordinary model-backed load_model_dates requires Relations observation_id through edge.id or source_edge_id for EVERY edge. Compact pair arrays are not native Relations records. A mixed adapter must retain complete pair evidence and supply an appropriate existing-model projection; no historical native record should be fabricated. |
| Catalog mapping | Pinned v2.1.1 mapping table and direction lookup contain no CO_MENTIONED, CO_OCCURS_ON_PAGE or co-occurrence row. Ordinary CO_MENTIONED is legacy open vocabulary, not a Wikidata catalog mapping. No source predicate or inverse catalog row can be invented. |
| Strength in ordinary queries | MAIN GraphStore Edge declares no strength field; summarize_edge returns endpoints/relation/count and known identity/date/source fields. Adding tolerated extra fields would not establish their query behavior. |
| Compact as the whole current graph | Cannot reuse unchanged. CompactStore accepts only its pair-array format, reports PAGE_CO_OCCURRENCE_ONLY, requires all positive page pairs via raw-count conservation, and explicitly rejects model_dir with 'Compact Geography must be embedded in the versioned graph'. Our current result has native edges, fallback suppression, nine source-pending pairs and separate model GeoParquet. Switching wholesale would change the output/interface and native/default population. |

There is therefore an exact supported historical strength representation, but no inspected unchanged adapter combining it with the present native/catalog/model-backed graph. The smallest remaining implementation choice is how the target mixed consumer reuses that EXISTING compact strength protocol alongside native assertions and separate Geography. Formula, denominator and bidirectionality are not reopened. Under the present no-new-consumer-field restriction, appending strength to ordinary edges is not an equivalent reuse. This inspection does not select a replacement consumer/interface or add a new semantic gate.

## Concrete bounded next step

NEXT_NATIVE_SNAPSHOT_STEP.json prepares snapshot_0005 from snapshot_0004, without executing it. Keep ten nodes/four geometries; add the four native assertions and four catalog inverse views plus all four full Relations source rows; preserve source_edge_id and selected dates/precision/calendar. The prior compatibility probe already loaded these eight native/inverse views with ten nodes and three then-available geometries; the current fourth geometry is independently verified, but this proposed combined fifth snapshot has not run.

All 64 active internal default directions over 32 pairs must remain in the complete private payload with counts, both strengths, denominators, source scope and history. The partial native consumer projection must explicitly record that they await mixed-consumer integration; do not call them absent or resolved. The nine Q131347 pair gaps remain separate from the 106 pending identities. Every output receipt binds first-unit-exact-v1; future identity revisions regenerate affected projections while retaining old versions.

Current completed snapshot remains snapshot_0004: ten nodes, zero edges, four geometry rows covering 18 accepted occurrences, only Oahu geometry missing; 30 accepted and 106 pending overall. Nothing was added to it. Exact source hashes/line evidence are in COOCCURRENCE_RECONCILIATION_EVIDENCE.json. Only new owned report/preparation files were written. No source/code/plan/snapshot changes, acceptance run, external call, publication, paid work or nested agent. No tool action denied or uncertain. Backup: Unprotected.
