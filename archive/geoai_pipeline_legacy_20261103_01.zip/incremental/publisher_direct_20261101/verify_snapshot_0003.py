"""Fresh independent snapshot_0003 readback; run after consume_islands.py."""
import gzip
import hashlib
import json
import sys
from pathlib import Path
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
import geopandas as gpd
from shapely import from_wkb
from geo_agent.graph_store import GraphStore
HERE = Path(__file__).resolve().parent
OUT = HERE / 'snapshot_0003'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
receipt = read(OUT / 'private/receipt.json')
for path, expected in receipt['inputs_sha256'].items():
    assert sha(path) == expected, path
for path, expected in receipt['artifact_sha256'].items():
    assert sha(OUT / path) == expected, path
assert sha(HERE / 'consume_islands.py') == receipt['stage_sha256']
assert (OUT / 'graph.json').read_bytes() == (HERE / 'snapshot_0002/graph.json').read_bytes() == (HERE / 'snapshot_0001/graph.json').read_bytes()
frame = gpd.read_parquet(OUT / 'model/geometries.parquet')
assert len(frame) == 3 and frame.crs.to_epsg() == 4326
assert frame['place_id'].tolist() == ['Q1490', 'Q153732', 'Q51679']
previous = gpd.read_parquet(HERE / 'snapshot_0002/model/geometries.parquet')
assert frame.geometry.iloc[0].wkb == previous.geometry.iloc[0].wkb
handoff = read(OUT / 'private/islands/handoff.json')
assert handoff['new_selection'] is False and handoff['processing_revision_id'] == 1375061414
assert handoff['page_id'] == 48975579 and handoff['decision_version'] == 'first-unit-exact-v1'
expected = {'Q153732': ('relation:7811079', '9', 'MultiPolygon', 3), 'Q51679': ('relation:3218318', '10', 'Polygon', 5)}
with gzip.open(handoff['source_file'], 'rt', encoding='utf-8') as stream:
    original_source = json.load(stream)
for item in handoff['identities']:
    qid = item['qid']
    source_id, version, kind, count = expected[qid]
    assert (item['source_object_id'], item['osm_version'], item['geometry_type'], item['accepted_occurrences']) == (source_id, version, kind, count)
    raw = read(OUT / ('private/islands/'+qid+'_source_row.json'))
    rows = [r for r in original_source['rows'] if str(r['osm_id']) == source_id.split(':')[1]]
    assert len(rows) == 1 and rows[0] == raw and str(raw['osm_version']) == version
    assert {r['key']:r['value'] for r in raw['all_tags']}['wikidata'] == qid
    geometry = frame.loc[frame['place_id'] == qid].geometry.iloc[0]
    assert geometry.wkb == from_wkb(bytes.fromhex(raw['geometry_wkb'])).wkb
    assert geometry.is_valid and not geometry.is_empty and geometry.geom_type == kind
with gzip.open(OUT / 'model/geography.json.gz', 'rt', encoding='utf-8') as stream:
    geography = json.load(stream)
assert len(geography) == 5
assert {r['place_id'] for r in geography if r['geometry_ref'] is None} == {'Q11751', 'Q131347'}
for row in geography:
    if row['geometry_ref'] is not None:
        assert row['geometry_ref'] == dict(file='geometries.parquet', place_id=row['place_id'], sha256=sha(OUT / 'model/geometries.parquet'))
store = GraphStore.from_json(OUT / 'graph.json', model_dir=OUT / 'model')
assert len(store.nodes) == 10 and not store.edges
assert set(store.geoms) == {'Q1490::LOC', 'Q153732::LOC', 'Q51679::LOC'}
for row in frame.itertuples():
    assert store.geoms[row.place_id+'::LOC'].wkb == row.geometry.wkb
aggregate = read(HERE.parent / 'integration_direct_20261101/real_handoff_0001/aggregate.json')
counts = {r['qid']:r['mention_count'] for r in aggregate['typed_counts'] if r['entity_group']=='LOC'}
assert sum(counts[qid] for qid in frame['place_id']) == 16
assert len(aggregate['occurrences']) == 136 and sum(bool(o['decision_values']) for o in aggregate['occurrences']) == 30
result = dict(status='PASS_INDEPENDENT_SNAPSHOT_0003_READBACK', nodes=10, edges=0, geometry_rows=3,
    geometry_bound_accepted_occurrences=16, accepted_occurrences=30, pending_occurrences=106,
    remaining_LOC_gaps=['Q11751::LOC','Q131347::LOC'], native_WKB_exact=True,
    Tokyo_preserved=True, graph_byte_identical=True, previous_snapshots_preserved=True,
    receipt_sha256=sha(OUT / 'private/receipt.json'), verification_code_sha256=sha(Path(__file__)), publication=False)
(OUT / 'private/independent_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
