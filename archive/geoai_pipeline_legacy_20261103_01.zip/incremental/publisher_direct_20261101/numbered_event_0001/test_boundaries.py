"""Numbered admission boundaries + previous fixture compatibility. Local only."""
import json,sys
from copy import deepcopy
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path[:0]=[str(PUBLISHER/'event_consumer_0001'),str(PUBLISHER/'component_materializer_0001')]
from event_input import load_event_route,sha,read
proof=read(ROOT/'orchestration_direct_20261101/approved_event_integration_0001/admission_interface_check.json')
route=proof['source_handoff'];hand=read(route['path']);producer=read(read(hand['full_independent_readback']['path'])['handoff']['path']);context=read(producer['inputs']['identity_projection']['path'])
args=dict(count_receipt=context['count_receipt'],native_registry=producer['inputs']['native_registry'],approved_event_selection=proof['selection'])
wrong=dict(route,sha256='0'*64)
try:load_event_route(wrong,**args)
except ValueError:pass
else:raise AssertionError('Bad numbered handoff hash accepted')
stale=deepcopy(context['count_receipt']);stale['projection']['decision_version']='STALE'
try:load_event_route(route,**dict(args,count_receipt=stale))
except ValueError as error:assert 'frontier' in str(error)
else:raise AssertionError('Mixed numbered Event/count version accepted')
mask=read(hand['newer_GEO_receipt']['path']);mask['mask_version']='STALE'
path=HERE/'wrong_mask_version.json';path.write_text(json.dumps(mask),encoding='utf-8')
try:load_event_route(route,**args,approved_mask_result=dict(path=str(path),sha256=sha(path)))
except ValueError as error:assert 'mask version' in str(error)
else:raise AssertionError('Wrong approved mask version accepted')
# Existing synthetic wrapper stays on the old fixed-processor branch.
fixture=PUBLISHER/'event_consumer_0001/synthetic_route_0001/receipt.json';old=read(fixture);old_context=read(old['request']['inputs']['identity_projection']['path'])
result=load_event_route(dict(path=str(fixture),sha256=sha(fixture)),count_receipt=old_context['count_receipt'],native_registry=old['request']['inputs']['native_registry'],test_only=True)
assert result['status']=='VERIFIED_EVENT_CONSUMER_INPUTS' and len(result['events'])==1
report=dict(status='PASS_NUMBERED_EVENT_BOUNDARIES_AND_OLD_FIXTURE',wrong_handoff_hash_rejected=True,stale_current_frontier_rejected=True,
 stale_mask_version_rejected=True,old_fixture_compatible=True,publication=False)
(HERE/'boundary_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
