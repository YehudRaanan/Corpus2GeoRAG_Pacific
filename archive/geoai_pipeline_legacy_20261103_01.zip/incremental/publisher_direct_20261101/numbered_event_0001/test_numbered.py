"""Actual numbered handoff regression; does not run inference, source acquisition or publication."""
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path[:0]=[str(PUBLISHER/'event_consumer_0001'),str(PUBLISHER/'component_materializer_0001')]
from event_input import load_event_route,sha,read
from materialize_components import materialize_components
route=ROOT/'pair_relations_direct_20261101/event_wwii_rule_0001/RELATIONS_HANDOFF_0001.json'
proof=read(ROOT/'orchestration_direct_20261101/approved_event_integration_0001/admission_interface_check.json')
assert sha(route)==proof['source_handoff']['sha256']
policy=read(read(route)['policy_handoff']['path'])
producer=read(read(read(route)['full_independent_readback']['path'])['handoff']['path'])
projection=read(producer['inputs']['identity_projection']['path'])
parameters=dict(count_receipt=projection['count_receipt'],native_registry=producer['inputs']['native_registry'],approved_event_selection=proof['selection'])
result=load_event_route(proof['source_handoff'],**parameters)
assert result['status']=='VERIFIED_EVENT_CONSUMER_INPUTS'
assert {r['event_id'] for r in result['events']}=={'Q1645012','Q52418','Q713516'}
assert result['resolved_occurrences']==4 and result['unresolved_occurrences']==21 and len(result['relations'])==4
print('PASS numbered Event admission: 3 Events/4 accepted occurrences/4 native rows;21 unresolved kept')
from occurrence_decisions import SCOPE_FIELDS
from copy import deepcopy
import gzip,subprocess
state={tuple(v[-1]['manifest'][k] for k in SCOPE_FIELDS):v for v in projection['count_state']}
output=HERE/'actual_three_events_0003'
source_hashes={str(Path(d['path'])):d['sha256'] for d in [proof['source_handoff'],proof['selection'],producer['inputs']['identity_projection']]}
materialized=materialize_components(output,identity_state=state,count_receipt=projection['count_receipt'],relation_receipt=projection['relation_receipt'],
 geometry_receipt=projection['full_geometry']['receipt'],native_registry=producer['inputs']['native_registry'],
 source_receipts=[proof['source_handoff'],producer['inputs']['identity_projection']],consumer_root=PUBLISHER/'proposed_strength_0001/consumer',
 event_route=proof['source_handoff'],approved_event_selection=proof['selection'])
receipt=read(materialized['receipt_path']);graph=read(output/'graph.json')
assert receipt['pair_projection_version']!='sha256:'+projection['relation_receipt']['projection_sha256']
assert receipt['event_count']==3 and receipt['native_event_assertions']==4 and receipt['event_directional_views']==8
assert receipt['event_resolved_occurrences']==4 and receipt['event_unresolved_occurrences']==21
assert len([n for n in graph['nodes'] if n['type']=='event'])==3 and not any(n['id']=='Q362::event' for n in graph['nodes'])
assert json.loads(gzip.decompress((output/'model/events.json.gz').read_bytes()))==read(read(route)['events']['path'])
assert read(output/'private/count_receipt.json')==projection['count_receipt']
base=ROOT/'publisher_direct_20261101/orchestration_refresh_0001/policy_v2_all17_registry340/components'
base_graph=read(base/'graph.json')
assert [n for n in graph['nodes'] if n['type']!='event']==base_graph['nodes']
assert graph['edges'][:len(base_graph['edges'])]==base_graph['edges']
assert sha(output/'model/geometries.parquet')==sha(base/'model/geometries.parquet')
unresolved=read(output/'private/event_unresolved.json');assert len(unresolved['outcomes'])==21 and [r['qid'] for r in unresolved['decisions']]==['Q362']
audit=read(output/'private/event_scope_admission.json');assert audit['counts']['UNKNOWN']==414 and audit['counts']['PENDING_TYPE']==61091
assert all(r['inclusion']!='INCLUDE' for r in audit['decisions'] if r['inclusion'] in ['UNKNOWN','PENDING_TYPE'])
assert source_hashes=={p:sha(p) for p in source_hashes}
reader='''import json,gzip,sys
from pathlib import Path
root=Path(sys.argv[1]);consumer=Path(sys.argv[2]);sys.path[:0]=[str(consumer),r'D:\\Projects\\GeoAI']
from geo_agent.graph_store import GraphStore
store=GraphStore.from_json(root/'graph.json',model_dir=root/'model')
assert {n.wikidata_id for n in store.nodes.values() if n.type=='event'}=={'Q1645012','Q52418','Q713516'}
rows=json.loads(gzip.decompress((root/'model/relations.json.gz').read_bytes()))
model={r['observation_id']:r for r in rows};events=json.loads(gzip.decompress((root/'model/events.json.gz').read_bytes()))
for edge in store.edges[-8:]:
 row=model[edge.source_edge_id or edge.id]
 assert edge.start_date==(row['time_from'] or None) and edge.end_date==(row['time_to'] or None) and edge.point_date==(row['time_point'] or None)
 assert id(edge) in store.model_edge_dates
for event in events:
 assert store.model_node_dates[event['event_id']+'::event']
print('PASS fresh actual Event nodes, four native assertions/eight views and native model-time joins')
'''
check=subprocess.run([sys.executable,'-B','-c',reader,str(output),str(PUBLISHER/'proposed_strength_0001/consumer')],text=True,capture_output=True,check=True)
print(check.stdout.strip())
report=dict(status='PASS_ACTUAL_NUMBERED_EVENTS_MASK_NATIVE_EDGES',accepted_event_qids=sorted(r['event_id'] for r in result['events']),resolved_occurrences=4,unresolved_occurrences=21,
 consumer_checks=receipt['consumer_checks'],native_event_assertions=4,event_directional_views=8,scope_counts=audit['counts'],scope_unknown_outside_included=True,
 ordinary_nodes_edges_counts_unchanged=True,geometry_bytes_unchanged=True,structured_time_lossless=True,admission_format=receipt['event_admission_format'],
 actual_receipt=dict(path=materialized['receipt_path'],sha256=materialized['receipt_sha256']),refresh_inputs=str(output/'private/refresh_inputs.json'),publication=False)
(HERE/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))

