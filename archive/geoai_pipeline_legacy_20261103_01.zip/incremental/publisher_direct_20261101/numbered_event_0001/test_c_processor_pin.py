import unittest
from pathlib import Path
from unittest.mock import patch
import numbered_input_c_v1 as m
class ProcessorPins(unittest.TestCase):
 def test_approved_C_exact(self):self.assertEqual(m.resolve_current_processor(m.APPROVED_C_PROCESSOR),Path(m.APPROVED_C_PROCESSOR['path']).resolve())
 def test_C_hash_cannot_be_replaced(self):
  with self.assertRaises(ValueError):m.resolve_current_processor(dict(m.APPROVED_C_PROCESSOR,sha256='0'*64))
 def test_other_path_rejected(self):
  with self.assertRaises(ValueError):m.resolve_current_processor(dict(m.APPROVED_C_PROCESSOR,path='C:/unapproved/current_event_refresh_c_v1.py'))
 def test_C_guard_hash_required(self):
  with patch.dict(m.APPROVED_C_GUARD,sha256='0'*64):
   with self.assertRaises(ValueError):m.resolve_current_processor(m.APPROVED_C_PROCESSOR)
 def test_legacy_D_still_supported(self):
  d=dict(path=str(m.LEGACY_CURRENT_PROCESSOR),sha256=m._processor_sha(m.LEGACY_CURRENT_PROCESSOR));self.assertEqual(m.resolve_current_processor(d),m.LEGACY_CURRENT_PROCESSOR.resolve())
 def test_legacy_wrong_hash_rejected(self):
  with self.assertRaises(ValueError):m.resolve_current_processor(dict(path=str(m.LEGACY_CURRENT_PROCESSOR),sha256='0'*64))
if __name__=='__main__':unittest.main()
