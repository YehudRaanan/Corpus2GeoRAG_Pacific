"""Read only supplied Event route records; never choose anchors, Event membership or dates."""
import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
PROCESSOR=ROOT/'pair_relations_direct_20261101/event_runtime_0001/event_runtime.py'

def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def load_event_route(event_route,*,count_receipt,native_registry,approved_event_selection=None,test_only=False):
 """Validate an explicitly supplied existing selection; approved descriptor is caller authority.

 Test-only mode accepts GENERATED_TEST sources only. Real policy authority is
 supplied upstream, never inferred from a hash, a page title or Event ancestry.
 """
 if type(test_only) is not bool:raise ValueError('Explicit Event test_only boolean required')
 pins={}
 def pinned(descriptor):
  path=str(Path(descriptor['path']).resolve())
  if sha(path)!=descriptor['sha256']:raise ValueError('Event source/artifact hash differs: '+path)
  pins[path]=descriptor['sha256'];return read(path)
 receipt=pinned(event_route);request=receipt['request'];result=receipt['result']
 if request['code_sha256']!=sha(PROCESSOR):raise ValueError('Fixed Event processor changed')
 pins[str(PROCESSOR)]=sha(PROCESSOR)
 for path,digest in request['dependencies'].items():
  if sha(path)!=digest:raise ValueError('Event serializer dependency changed')
  pins[path]=digest
 previous=request.get('previous');seen=set()
 while previous is not None:
  if previous['sha256'] in seen:raise ValueError('Cyclic Event receipt history')
  seen.add(previous['sha256']);earlier=pinned(previous)
  for desc in earlier['result']['input_pins'].values():pinned(desc)
  for desc in earlier['result']['artifacts'].values():pinned(desc)
  for key in ['event_selection','scope_config']:
   if earlier['request'].get(key) is not None:pinned(earlier['request'][key])
  previous=earlier['request'].get('previous')
 inputs={name:pinned(desc) for name,desc in request['inputs'].items()}
 binding={name:desc['sha256'] for name,desc in request['inputs'].items()}
 if binding!=result['input_binding'] or result['input_pins']!=request['inputs']:raise ValueError('Event source binding differs')
 projection=inputs['identity_projection']
 if projection['count_receipt']!=count_receipt:raise ValueError('Event identity/count frontier differs')
 if request['inputs']['native_registry']['sha256']!=native_registry['sha256']:raise ValueError('Event native registry differs')
 artifacts={name:pinned(desc) for name,desc in result['artifacts'].items()}
 pending=list(result['pending_inputs'])
 if result['identity_decisions_changed'] is not False:raise ValueError('Event route changed identity decisions')
 selection=request.get('event_selection')
 if selection is None:pending.append('MISSING_SUPPLIED_EVENT_SELECTION')
 elif not test_only:
  if approved_event_selection is None:pending.append('MISSING_APPROVED_EVENT_SELECTION_EVIDENCE')
  elif approved_event_selection!=selection:raise ValueError('Approved Event selection differs from producer selection')
 if selection is not None:
  selected=pinned(selection)
  if not selected.get('version') or selected['input_binding']!=binding or selected['version']!=result['event_selection_version']:raise ValueError('Event selection version/frontier differs')
  if 'DEVELOPMENT' in str(selected.get('purpose','')).upper() and not test_only:pending.append('DEVELOPMENT_SELECTION_NOT_RUNTIME_APPROVAL')
  if selected['decisions']!=artifacts['selection']['decisions']:raise ValueError('Event decisions changed in serializer')
 config=request.get('scope_config')
 if config is not None:
  configured=pinned(config)
  if configured['input_binding']!=binding or configured['version']!=result['scope_config_version']:raise ValueError('Event scope version/frontier differs')
 if result['scope_status']!='EXECUTED_CONFIGURED_SCOPE':pending.append('SCOPE_CONFIGURATION_NOT_COMPLETE')
 if result['event_population_status']!='MATERIALIZED_SUPPLIED_SELECTION':pending.append('EVENT_POPULATION_NOT_COMPLETE')
 if artifacts['selection']['source_pending'] or artifacts['scope'].get('source_pending'):pending.append('EVENT_SOURCE_PENDING')
 if any(row.get('inclusion','').startswith('PENDING') for row in artifacts['scope'].get('candidates',[])):pending.append('EVENT_SCOPE_PENDING')
 if pending:return dict(status='BLOCKED_EVENT_CONSUMER_INPUTS',event_route=event_route,scope_status=result['scope_status'],event_population_status=result['event_population_status'],event_selection_version=result['event_selection_version'],pending_inputs=sorted(set(pending)),event_route_complete=False,consumer_materialized=False,publication=False,input_sha256=pins)
 entities=artifacts['entities'];events=artifacts['events'];decisions=artifacts['selection']['decisions']
 kept={row['qid'] for row in decisions if row['keep_event'] is True}
 if len({row['qid'] for row in decisions})!=len(decisions) or any(type(row.get('keep_event')) is not bool for row in decisions):raise ValueError('Event selection decisions invalid')
 if {row['entity_id'] for row in entities}!=kept or {row['event_id'] for row in events}!=kept or len(entities)!=len(kept) or len(events)!=len(kept):raise ValueError('Selected Event/Entity populations differ')
 for entity in entities:
  qid=entity['entity_id'];raw=entity['raw_reference']['full']['entity']
  if qid in inputs['native_evidence']:
   native=inputs['native_evidence'][qid]
   expected_raw=native['raw_record']
   provider='GENERATED_TEST' if test_only and result.get('fixture') is True and native['source']['path']=='GENERATED_TEST' else 'WIKIDATA'
   expected_source=dict(provider=provider,file=native['source']['path'],sha256=native['source']['sha256'],line=native['source']['line'],record_id=qid,revision=native['revision'],modified=native['modified'])
   if expected_raw.get('lastrevid')!=native['revision'] or expected_raw.get('modified')!=native['modified']:raise ValueError('Native Event source version differs')
  elif qid in inputs['native_registry']['selected_references']:
   selected=inputs['native_registry']['selected_references'][qid]
   expected_raw=selected['envelope']['entity'];expected_source=selected['provenance']
  else:raise ValueError('Selected Event missing from pinned native sources')
  if raw!=expected_raw or entity['sources']!=[expected_source]:raise ValueError('Event source/provenance differs from pinned native evidence')
  if entity['type']!='event' or raw['id']!=qid or entity['raw_reference']['full']['requested_qid']!=qid or entity['revision']!=raw.get('lastrevid'):raise ValueError('Event entity/source identity or revision differs')
  if entity['attributes']['mention_ids']!=[]:raise ValueError('Source-only Event has invented mentions')
  if test_only and any(row.get('provider')!='GENERATED_TEST' for row in entity['sources']):raise ValueError('Synthetic Event wiring accepts GENERATED_TEST sources only')
  event=next(row for row in events if row['event_id']==qid)
  for prop in ['P580','P582','P585']:
   if event['temporal_evidence']['claims'][prop]!=raw['claims'].get(prop,[]):raise ValueError('Native Event time evidence changed')
 # Reproduction uses the already approved serializer; no new date/period/type selection is added.
 from GG_Data.pipeline.event_model import event_rows
 for entity in entities:
  event=next(row for row in events if row['event_id']==entity['entity_id'])
  decision=next(row for row in decisions if row['qid']==entity['entity_id'])
  expected_entity,expected_event=event_rows(entity['raw_reference']['full']['entity'],entity['sources'][0],decision)
  expected_entity['reference_source']=entity['sources'][0]['provider']
  if entity!=expected_entity or event!=expected_event:raise ValueError('Event model differs from supplied native serializer')
 return dict(status='VERIFIED_EVENT_CONSUMER_INPUTS',entities=entities,events=events,input_sha256=pins,
  selection_version=result['event_selection_version'],scope_version=result['scope_config_version'],
  event_route_complete=not test_only,test_only=test_only,pending_inputs=[],publication=False)
