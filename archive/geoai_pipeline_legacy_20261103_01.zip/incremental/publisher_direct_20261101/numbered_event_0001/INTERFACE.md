# Numbered real Event admission: current callable handoff

The exact mismatch is fixed. event_consumer_0001/event_input.py::load_event_route now recognizes RELATIONS_HANDOFF_0001_READY before looking for the historical request/result wrapper. It delegates to numbered_input.py::admit_numbered_event. The old request/result fixture branch is retained. The numbered route records its real run_actual.py/event_rule.py/config lineage; it is NOT stamped as an execution of the old fixed event_runtime processor.

## Call

Existing call works unchanged for the numbered descriptor:

    event_data = load_event_route(
        event_route={path, sha256},
        count_receipt=current_count_receipt,
        native_registry={path, sha256},
        approved_event_selection=numbered_handoff.selection,
        approved_mask_result=None,
        test_only=False)

approved_mask_result is optional. None uses the exact hash-pinned newer_GEO_receipt supplied IN the numbered handoff, not filesystem latest discovery. An explicit override must pass the same mask/code/version/source verification. materialize_components(...) forwards the same new optional approved_mask_result keyword alongside its existing event_route/approved_event_selection arguments. No new approval is requested or inferred. This consumes the owner's already approved P361 rule, all-explicit first hop/place-only second hop and supplied GEO mask.

Numbered route: pair_relations_direct_20261101/event_wwii_rule_0001/RELATIONS_HANDOFF_0001.json, SHA4a68a73a46a5247bac89cd033c71b473e5363304a299cc317f68ad1add229912. Selection SHA b091563aa49332802fdbd2c7fbf9a2ac93a6e977e7042c72a64157540198a7eb. The loader verifies numbered policy/full audit/producer linkage, every artifact and source hash, exact current count/registry binding, fixed actual producer/rule code, selection/config versions, the native P361 acceptance chains, whole Event source records/revisions and exact event_rows reproduction. Per-unit source scopes, original occurrence records, input-occurrence hashes and outcome identities are checked against the actual ordinary frontier. Wrong hash, frontier or mask version is an error.

The separately approved mask's versioned GeoJSON/code and input geometry hashes are verified. Existing five shapes are read back and their decisions reproduced by classify_loc without alteration. The supplied mask is applied ONLY to scope rows typed LOC; absent source geometry remains UNKNOWN. Non-LOC scope types are unaffected. Scope decisions are retained with original source-record indexes and a checksum pointer to the complete original scope artifact, preserving every original path/source statement without duplicating its227MB raw file. UNKNOWN/PENDING_TYPE records never become included scope rows. A QID may independently have an included non-LOC type and an UNKNOWN LOC type; both decisions remain distinct. Existing ordinary typed nodes and QID-level edge semantics remain unchanged; no type winner is invented.

## Real accepted population and native edges

Accepted Events are exactly Q1645012, Q52418 and Q713516, supported by four resolved source occurrences. The21 Q362 occurrences remain unresolved; there is no Q362::event node and no invented zero-hop/root exception. Full per-occurrence outcomes and the unaccepted Q362 decision remain in private/event_unresolved.json. Scope UNKNOWN and PENDING_TYPE decisions remain in private/event_scope_admission.json alongside their original evidence descriptor.

Four explicit native statements have both endpoints in the supplied included scope and at least one accepted Event endpoint. They are verified against their whole source records and passed through existing scan/populate and relation/date/direction catalogs. No two-hop path is collapsed into an Event-to-place assertion. Existing native source direction, predicates, revisions, qualifiers and reference evidence are retained. materialize_components now preserves these supplied Event relations/views when it installs the ordinary pair views; it appends the four complete Relations records and their eight native/reverse views. All ordinary nodes, edges, counts and geometry bytes remain unchanged. Event rows create no raw occurrence/page/cooccurrence support.

The combined relation version now hashes the ordinary relation projection, exact Event handoff hash, selection/scope/mask versions and native Event rows. It cannot silently reuse the ordinary-only relation version for the enriched graph. The existing ordinary relation_frontier remains separate evidence; the Event route receipt, complete Event rows and scope/outcome files provide the additional binding. All consumer fields remain within the existing contract.

The admission is complete for the explicitly supplied bounded policy generation, with documented unresolved outcomes retained. This is the existing G12 distinction between executed unresolved cases and unrun stages. It does not certify complete Event discovery for all17 pages/current Wikidata: the receipt records event_bounded_scope from the producer and event_global_source_completeness=false. No runtime unit-completion, upload-cadence or publication state is changed by this task.

## Deliverables and tests

Current actual generation: actual_three_events_0003; caller can read private/refresh_inputs.json and use the existing explicit refresh interface. It contains the new combined relation version and fresh source receipt, rather than reusing an old ordinary-only receipt. No refresh/publication was invoked in this task.

Actual readback:366 nodes,11941 directional edges,5 geometries,6070 shared assertion identities. This is previous363 ordinary nodes/11933 views plus3 Event nodes/8 views. Exactly four native Event assertions are added. All three Event native dates/precision/calendar and every added relation date are independently joined by GraphStore/model_dates in a fresh process. Events rows exactly equal the supplied native Event table. Ordinary count_receipt and geometry bytes compare exactly with the previous verified consumer.

Scope audit:62258 records =32 included path/type records,721 excluded,414 UNKNOWN LOC records and61091 PENDING_TYPE records. These are record counts, not distinct active entities. The21 unresolved Event occurrences are a separate population and are preserved, not mixed with geographic/type uncertainty.

verification.json and test_numbered.py prove the actual3/4/21 population, native4/eight-view integration, ordinary model preservation, source hashes and structured-time readback. boundary_verification.json/test_boundaries.py prove wrong handoff hash, wrong current frontier and wrong mask version rejection, plus old synthetic fixture compatibility. baseline_compatibility/verification.json proves previous no-Event10-node/90-view/five-geometry behavior and stale/unsupported raw-type rejection still pass. Earlier successful generations are preserved; current-code pin verification should use actual_three_events_0003.

Only PUBLISHER-owned files were modified. Prior event_input and materializer implementations are preserved as event_input_before_numbered.py and materialize_before_numbered.py. No INTEGRATION state/plans, RELATIONS artifacts, source records, acceptance policy, mask coordinates, geometry selection, raw identity decisions, account/permissions or official consumer were changed. No external call, inference, GPU, paid work, dependency install, PR, merge, publication or nested agent. No denied/pending/uncertain executed operation remains. Backup: Unprotected.
