"""Numbered approved P361 handoff admission; no old event_runtime execution claim."""
import csv,gzip,hashlib,importlib.util,json,sys
from collections import Counter
from copy import deepcopy
from pathlib import Path
import ijson
ROOT=Path(__file__).resolve().parent.parent.parent
sys.path[:0]=[str(ROOT/'orchestration_direct_20261101'),r'D:\Projects\GeoAI']

SOURCE_SCHEMA='event-source-handoff-v1'
RESULT_SCHEMA='event-consumer-input-v1'

def normalize_event_handoff(document):
 """One structural boundary for all supported source formats; no policy decisions."""
 if document.get('schema')=='geoai-current-frontier-event-route-v1':
  if document.get('status')!='CURRENT_FRONTIER_EVENT_ROUTE_V1_READY':raise ValueError('Current Event handoff is not ready')
  return dict(schema=SOURCE_SCHEMA,kind='current_frontier',sources=document.get('config'),execution=document.get('processor'))
 if {'request','result'}<=set(document):
  request=document['request'];result=document['result']
  return dict(schema=SOURCE_SCHEMA,kind='legacy',identity=None,selection=request.get('event_selection'),
   scope=result['artifacts'].get('scope'),sources=request['inputs'],geo=None,execution=None,verification=None)
 kinds={'RELATIONS_HANDOFF_0001_READY':'numbered_event','RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001_READY':'root_identity','ROOT_EXPANSION_HANDOFF_0001_READY':'root_expansion'}
 kind=kinds.get(document.get('status'))
 if kind is None:raise ValueError('Unsupported Event handoff status: '+str(document.get('status')))
 return dict(schema=SOURCE_SCHEMA,kind=kind,identity=document.get('root_identity_successor',document.get('previous_policy_handoff',document.get('policy_handoff'))),
  selection=document.get('selection'),scope=document.get('scope',document.get('scope_output')),sources=document.get('sources',document.get('source_graph')),
  geo=document.get('geo',document.get('newer_GEO_receipt')),execution=document.get('execution_handoff'),
  verification=document.get('full_independent_readback',document.get('verification')))

def verify_membership(q,decision,native,*,allow_root_identity=False):
 root='Q362'
 if allow_root_identity and q==root:
  evidence=decision.get('identity_evidence',{});node=native.get(root)
  if (node is None or node['record'].get('id')!=root or decision.get('qid')!=root or decision.get('keep_event') is not True
      or decision.get('reason')!='ROOT_EVENT_IDENTITY' or decision.get('acceptance_reason')!='ROOT_EVENT_IDENTITY'
      or decision.get('p361_chain')!=[] or evidence.get('qid')!=root or evidence.get('path_length')!=0
      or evidence.get('statement_fabricated') is not False or evidence.get('source')!=node['source']
      or evidence.get('native_record_revision')!=node['record'].get('lastrevid')):
   raise ValueError('Invalid source-bound ROOT_EVENT_IDENTITY')
  return
 current=q
 for edge in decision['p361_chain']:
  if edge['subject_qid']!=current or edge['source_predicate']!='wd:P361' or edge['raw_statement'] not in native[current]['record']['claims'].get('P361',[]) or edge['source']!=native[current]['source']:raise ValueError('Native P361 acceptance evidence differs')
  current=edge['object_qid']
 if not decision['p361_chain'] or current!=root:raise ValueError('Missing approved native P361 membership chain')

def admit_numbered_event(route,*,count_receipt,native_registry,approved_event_selection=None,approved_mask_result=None,relation_receipt=None):
 pins={};cache={}
 def sha(path):
  with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
 def pin(desc,load=True):
  path=str(Path(desc['path']).resolve())
  if path not in pins:
   if sha(path)!=desc['sha256']:raise ValueError('Numbered Event input hash differs: '+path)
   pins[path]=desc['sha256']
  elif pins[path]!=desc['sha256']:raise ValueError('Conflicting Event input pins')
  if not load:return path
  if path not in cache:cache[path]=json.loads(Path(path).read_text(encoding='utf-8-sig'))
  return cache[path]
 hand=pin(route);normalized=normalize_event_handoff(hand)
 if normalized['kind']=='current_frontier':
  processor=ROOT/'pair_relations_direct_20261101/event_current_frontier_0001/current_event_refresh.py'
  if Path(hand['processor']['path']).resolve()!=processor.resolve():raise ValueError('Unexpected current Event processor path')
  pin(hand['processor'],False)
  spec=importlib.util.spec_from_file_location('_publisher_current_event_refresh',processor)
  module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
  result=module.admit_current_event_route(route,count_receipt=count_receipt,native_registry=native_registry,relation_receipt=relation_receipt)
  if result.get('normalized_schema')!=RESULT_SCHEMA or result.get('status')!='VERIFIED_EVENT_CONSUMER_INPUTS':raise ValueError('Current Event normalization contract differs')
  for descriptor in hand['artifacts'].values():pin(descriptor,False)
  config=pin(hand['config'])
  for key in ['counts_snapshot','active_units','native_registry','source_policy','geometry_source']:
   if config.get(key) is not None:pin(config[key],False)
  policy=pin(config['source_policy'])
  for value in policy.values():
   if isinstance(value,dict) and {'path','sha256'}<=set(value):pin(value,False)
  for descriptor in policy.get('processors',{}).values():pin(descriptor,False)
  inventory=pin(config['active_units'])
  for unit in inventory['units']:
   for key in ['unit','outcomes']:pin(unit[key],False)
  # Full source-only endpoints may be absent from the ordinary registry; reuse only approved pinned records.
  records=pin(policy['scope_sources']);membership=pin(policy['membership_sources'])
  records=dict(records)
  for q,node in membership.items():records.setdefault(q,node)
  registry=pin(config['native_registry']);endpoints={r[k] for r in result['relations'] for k in ['subject_entity_id','object_entity_id'] if r.get(k)}
  support={}
  for q in sorted(endpoints-set(registry['selected_references'])):
   node=records.get(q)
   if node is None or node.get('coverage','FULL')!='FULL':continue
   if node['record'].get('id')!=q or 'claims' not in node['record']:raise ValueError('Event supporting whole source identity differs')
   support[q]=dict(envelope=dict(requested_qid=q,entity=node['record']),provenance=node['source'])
  result['supporting_references']=support
  result['exception_occurrence_sources']=[config['active_units']]
  pins[str(Path(__file__).resolve())]=sha(__file__)
  result['input_sha256'].update(pins)
  return result
 if normalized['kind']=='root_expansion':
  return _admit_scope_expansion(normalized,hand,route,pin,pins,count_receipt,native_registry,approved_event_selection,approved_mask_result)
 if normalized['kind']=='root_identity':
  return _admit_root_successor(hand,route,pin,pins,count_receipt,native_registry,approved_event_selection,approved_mask_result)
 if normalized['kind']!='numbered_event':raise ValueError('Use legacy Event input through load_event_route')
 policy=pin(hand['policy_handoff']);audit=pin(hand['full_independent_readback']);producer=pin(audit['handoff'])
 if policy['status']!='VERIFIED_EVENT_POLICY_HANDOFF_0001' or audit['status']!='PASS_INDEPENDENT_APPROVED_EVENT_RULE_AND_HOPS':raise ValueError('Numbered Event verification is incomplete')
 for key,name in [('selection','event_selection.json'),('entities','event_entities.json'),('events','events.json'),('scope_output','scope_discovery.json')]:
  if hand[key]!=policy[key] or hand[key]!=producer['artifacts'][name]:raise ValueError('Numbered Event policy/audited model descriptors differ')
 for key in ['processor','rule','rule_config','verification']:pin(policy[key],False)
 if Path(policy['processor']['path']).resolve()!=ROOT/'pair_relations_direct_20261101/event_wwii_rule_0001/run_actual.py' or Path(policy['rule']['path']).resolve()!=ROOT/'pair_relations_direct_20261101/event_wwii_rule_0001/event_rule.py':raise ValueError('Unexpected numbered Event producer')
 inputs=producer['inputs'];binding={key:desc['sha256'] for key,desc in inputs.items()}
 if binding!=policy['input_binding']:raise ValueError('Numbered Event source binding differs')
 projection=pin(inputs['identity_projection'])
 if projection['count_receipt']!=count_receipt or inputs['native_registry']['sha256']!=native_registry['sha256']:raise ValueError('Numbered Event current count/registry frontier differs')
 registry=pin(inputs['native_registry']);pin(inputs['native_evidence']);pin(producer['archive'],False)
 for descriptor in producer['artifacts'].values():pin(descriptor,False)
 selection=pin(hand['selection']);config=pin(policy['rule_config']);entities=pin(hand['entities']);events=pin(hand['events'])
 if approved_event_selection is not None and approved_event_selection!=hand['selection']:raise ValueError('Approved numbered selection descriptor differs')
 if selection['input_binding']!=binding or selection['version']!=policy['version'] or config['version']!=policy['version'] or producer['rule_version']!=policy['version']:raise ValueError('Numbered Event selection version differs')
 decisions={row['qid']:row for row in selection['decisions']}
 if len(decisions)!=len(selection['decisions']) or any(type(row['keep_event']) is not bool for row in decisions.values()):raise ValueError('Invalid numbered Event decisions')
 accepted=sorted(q for q,row in decisions.items() if row['keep_event'])
 if accepted!=hand['accepted_event_qids'] or accepted!=policy['accepted_event_qids'] or {row['event_id'] for row in events}!=set(accepted) or {row['entity_id'] for row in entities}!=set(accepted):raise ValueError('Numbered Event populations differ')
 native=pin(producer['artifacts']['p361_source_evidence.json'])
 from GG_Data.pipeline.event_model import event_rows
 for entity in entities:
  q=entity['entity_id'];node=native[q];raw=node['record'];decision=decisions[q]
  if raw['id']!=q or entity['revision']!=raw['lastrevid'] or entity['raw_reference']['full']['entity']!=raw or entity['sources']!=[node['source']]:raise ValueError('Numbered Event source/revision differs')
  expected_entity,expected_event=event_rows(raw,node['source'],decision);expected_entity['reference_source']=node['source']['provider']
  if entity!=expected_entity or next(row for row in events if row['event_id']==q)!=expected_event:raise ValueError('Numbered Event native model/time differs')
  verify_membership(q,decision,native)
 if decisions.get('Q362',{}).get('keep_event') is not False:raise ValueError('Unapproved Q362 zero-hop exception')
 # Per-unit outcomes remain separate from ordinary occurrence-to-QID decisions.
 units={v[-1]['manifest']['page_id']:v[-1] for v in projection['count_state']};outcomes=[];seen=set()
 candidate_rows=pin(producer['artifacts']['candidate_inputs.json'])
 for candidate in candidate_rows:
  occurrence=candidate['occurrence'];current=next((row for row in units[occurrence['page_id']]['occurrences'] if row['occurrence_id']==occurrence['occurrence_id']),None)
  if current!=occurrence:raise ValueError('Event original occurrence evidence differs')
 from decision_revision_hook import content_hash
 fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
 for entry in policy['per_unit_receipts']:
  receipt=pin(entry['event_route']);unit=units[entry['page']]
  if receipt['execution']!='EXECUTED' or receipt['source_scope']!={k:unit['manifest'][k] for k in fields}:raise ValueError('Event occurrence source scope differs')
  raw=sorted([row['occurrence'] for row in candidate_rows if row['occurrence']['page_id']==entry['page']],key=lambda row:row['occurrence_id'])
  if receipt['input_occurrences_sha256']!=content_hash(raw):raise ValueError('Event per-unit occurrence evidence hash differs')
  members={row['occurrence_id'] for row in raw}
  for descriptor in receipt['artifacts']:pin(descriptor,False)
  for row in receipt['outcomes']:
   if row['occurrence_id'] not in members or row['occurrence_id'] in seen:raise ValueError('Missing/duplicate Event occurrence')
   if row['status']=='RESOLVED' and (len(row['accepted_event_qids'])!=1 or row['accepted_event_qids'][0] not in accepted):raise ValueError('Event occurrence selection differs')
   seen.add(row['occurrence_id']);outcomes.append(row)
 resolved=sum(row['status']=='RESOLVED' for row in outcomes)
 if (resolved,len(outcomes)-resolved)!=(hand['resolved_occurrences'],hand['unresolved_occurrences']):raise ValueError('Numbered Event occurrence counts differ')
 # Apply only the separately supplied, already approved LOC mask results.
 mask_desc=approved_mask_result or hand['newer_GEO_receipt'];mask=pin(mask_desc)
 mask_path=ROOT/'geometry_direct_20261101/pacific_loc_mask_v1/pacific_loc_mask.py';mask_json=mask_path.with_name('pacific_loc_mask_v1.geojson')
 if sha(mask_path)!=mask['mask_code_sha256'] or sha(mask_json)!=mask['mask_sha256']:raise ValueError('Approved mask code/artifact differs')
 pins[str(mask_path)]=mask['mask_code_sha256'];pins[str(mask_json)]=mask['mask_sha256']
 spec=importlib.util.spec_from_file_location('_publisher_approved_mask',mask_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 if module.MASK_VERSION!=mask['mask_version']:raise ValueError('Approved mask version differs')
 for key in ['GEO_verification','GEO_independent_readback']:pin(mask[key])
 import geopandas as gpd
 frames={}
 for decision in mask['decisions']:
  path=pin(decision['source'],False)
  if path not in frames:frames[path]=gpd.read_parquet(path)
  frame=frames[path];selected=frame.loc[frame['place_id']==decision['qid']]
  geometry=selected.geometry.iloc[0] if len(selected)==1 else None
  result=module.classify_loc(geometry,entity_type=decision['entity_type'],crs=frame.crs)
  if result!=decision['mask_result']:raise ValueError('Approved mask result/source geometry differs')
  if decision['entity_type']=='LOC' and mask['geo'].get(decision['qid'])!={'INCLUDE':True,'EXCLUDE':False,'UNKNOWN':None}[result]:raise ValueError('Mask map differs')
 scope_desc=hand['scope_output'];scope_path=pin(scope_desc,False);scope_audit=[];active=set(accepted);edge_cases={};counts=Counter()
 with Path(scope_path).open('rb') as stream:
  for index,row in enumerate(ijson.items(stream,'candidates.item',use_float=True)):
   inclusion=row['inclusion']
   if row['type']=='LOC' and inclusion!='EXCLUDE':inclusion={True:'INCLUDE',False:'EXCLUDE',None:'UNKNOWN'}[mask['geo'].get(row['qid'])]
   scope_audit.append(dict(source_record_index=index,qid=row['qid'],type=row['type'],hop=row['hop'],inclusion=inclusion))
   counts[inclusion]+=1
   if inclusion=='INCLUDE':active.add(row['qid'])
   for edge in row['path']:
    if not ({edge['subject_qid'],edge['object_qid']}&set(accepted)):continue
    value={k:edge[k] for k in ['subject_qid','object_qid','source_predicate','source_record_id','raw_statement','source']}
    sid=value['source_record_id']
    if sid in edge_cases and edge_cases[sid]!=value:raise ValueError('Conflicting repeated native scope statement')
    edge_cases[sid]=value
 # Preserve original native endpoints, never collapse two-hop paths into Event edges.
 chosen=[edge for edge in edge_cases.values() if {edge['subject_qid'],edge['object_qid']}<=active]
 mapping_path=Path(r'D:\Projects\GeoAI/GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv');direction_path=mapping_path.with_name('RELATION_DIRECTION_LOOKUP_v2.1.1.csv')
 with mapping_path.open(encoding='utf-8-sig',newline='') as stream:mapping=list(csv.DictReader(stream))
 rules={(row['source'],row['source_predicate']):row for row in mapping}
 endpoints={q for edge in chosen for q in [edge['subject_qid'],edge['object_qid']]};replay=[]
 sys.path.insert(0,str(ROOT/'pair_relations_direct_20261101/registry_completion_0001'))
 from registry_completion import choose_name
 for q in sorted(endpoints):
  if q in accepted:entity=deepcopy(next(row for row in entities if row['entity_id']==q))
  else:
   ref=registry['selected_references'][q];raw=ref['envelope']['entity']
   entity=dict(entity_id=q,name=choose_name(q,raw,{},[])['value'],sources=[ref['provenance']],raw_reference=dict(full=deepcopy(ref['envelope'])))
  raw=entity['raw_reference']['full']['entity'];original=raw['claims'];raw['claims']={}
  for edge in chosen:
   if edge['subject_qid']!=q:continue
   prop=edge['source_predicate'].removeprefix('wd:')
   if edge['raw_statement'] not in original.get(prop,[]) or entity['sources']!=[edge['source']]:raise ValueError('Approved scope edge not in pinned source/version')
   raw['claims'].setdefault(prop,[]).append(edge['raw_statement'])
  replay.append(entity)
 from GG_Data.pipeline.relations import scan,populate
 retained,excluded,_=scan(replay,endpoints,rules)
 if excluded or len(retained)!=len(chosen):raise ValueError('Existing native exclusion/edge semantics differ')
 relations=populate(retained,rules)
 for path in [mapping_path,direction_path,Path(sys.modules[event_rows.__module__].__file__),Path(sys.modules[scan.__module__].__file__),Path(__file__)]:pins[str(path.resolve())]=sha(path)
 return dict(normalized_schema=RESULT_SCHEMA,status='VERIFIED_EVENT_CONSUMER_INPUTS',entities=entities,events=events,relations=relations,input_sha256=pins,
  selection_version=selection['version'],scope_version=producer['hop_version']+'+'+mask['mask_version'],event_route_complete=True,test_only=False,pending_inputs=[],publication=False,
  admission_format='RELATIONS_HANDOFF_0001',resolved_occurrences=resolved,unresolved_occurrences=len(outcomes)-resolved,
  retained_unresolved=[row for row in outcomes if row['status']!='RESOLVED'],retained_unresolved_decisions=[row for row in decisions.values() if not row['keep_event']],
  scope_audit=dict(source=scope_desc,mask_receipt=mask_desc,decisions=scope_audit,counts=dict(counts),active_qids=sorted(active),global_source_completeness=False),
  bounded_scope=selection['scope'])




def _admit_root_successor(hand,route,pin,pins,count_receipt,native_registry,approved_selection,approved_mask):
 audit=pin(hand['verification']);produced=pin(audit['handoff'])
 if audit['status']!='PASS_INDEPENDENT_ROOT_EVENT_IDENTITY_SUCCESSOR':raise ValueError('Root successor readback is incomplete')
 for key in ['selection','entities','events','per_unit_receipts','input_binding','source_graph','previous_policy_handoff','previous_new_unit_handoff','processor','rule','version']:
  if hand[key]!=produced[key]:raise ValueError('Root successor/audited artifact binding differs')
 if hand['root_hop_expansion']!='NOT_REEXECUTED_IN_THIS_BOUNDED_ACCEPTANCE_FIX':raise ValueError('Unsupported root expansion successor')
 for key,name in [('processor','apply_successor.py'),('rule','event_rule_v2.py')]:
  if Path(hand[key]['path']).resolve()!=ROOT/'pair_relations_direct_20261101/event_root_fix_0001'/name:raise ValueError('Unexpected root identity producer')
  pin(hand[key],False)
 old_policy=pin(hand['previous_policy_handoff']);pin(hand['previous_new_unit_handoff'])
 prior_path=Path(hand['previous_policy_handoff']['path']).with_name('RELATIONS_HANDOFF_0001.json')
 with prior_path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
 prior_desc=dict(path=str(prior_path),sha256=digest);prior_hand=pin(prior_desc)
 if prior_hand['policy_handoff']!=hand['previous_policy_handoff']:raise ValueError('Root prior policy linkage differs')
 prior=admit_numbered_event(prior_desc,count_receipt=count_receipt,native_registry=native_registry,
  approved_event_selection=old_policy['selection'],approved_mask_result=approved_mask)
 pins.update(prior['input_sha256'])
 if prior['input_sha256'].get(str(Path(hand['source_graph']['path']).resolve()))!=hand['source_graph']['sha256']:raise ValueError('Root source graph differs from verified prior source')
 native=pin(hand['source_graph']);selection=pin(hand['selection']);old_selection=pin(old_policy['selection'])
 if approved_selection is not None and approved_selection!=hand['selection']:raise ValueError('Approved root selection differs')
 if selection['version']!=hand['version'] or selection['input_binding']!=hand['input_binding'] or hand['input_binding']!=old_selection['input_binding'] or selection['previous_selection']!=old_policy['selection']:raise ValueError('Root selection/source version differs')
 decisions={row['qid']:row for row in selection['decisions']};previous={row['qid']:row for row in old_selection['decisions']}
 if set(decisions)!=set(previous) or len(decisions)!=len(selection['decisions']) or any(row.get('keep_event') is not True for row in decisions.values()):raise ValueError('Root successor selected population differs')
 for q,decision in decisions.items():
  verify_membership(q,decision,native,allow_root_identity=True)
  if q!='Q362' and decision!=previous[q]:raise ValueError('Non-root P361 decision changed')
 entities=pin(hand['entities']);events=pin(hand['events'])
 if {r['entity_id'] for r in entities}!=set(decisions) or {r['event_id'] for r in events}!=set(decisions) or len(entities)!=len(decisions) or len(events)!=len(decisions):raise ValueError('Root Entity/Events population differs')
 from GG_Data.pipeline.event_model import event_rows
 for entity in entities:
  q=entity['entity_id']
  if q!='Q362':
   if entity!=next(row for row in prior['entities'] if row['entity_id']==q) or next(row for row in events if row['event_id']==q)!=next(row for row in prior['events'] if row['event_id']==q):raise ValueError('Prior Event/native dates changed')
  else:
   expected,event=event_rows(native[q]['record'],native[q]['source'],decisions[q]);expected['reference_source']=native[q]['source']['provider']
   if entity!=expected or next(row for row in events if row['event_id']==q)!=event:raise ValueError('Root native record/time/provenance differs')
 old_audit=pin(prior_hand['full_independent_readback']);old_producer=pin(old_audit['handoff']);projection=pin(old_producer['inputs']['identity_projection'])
 units={v[-1]['manifest']['page_id']:v[-1] for v in projection['count_state']}
 first=pin(hand['per_unit_receipts'][0]['event_route'])
 evidence_desc=next(d for d in first['artifacts'] if Path(d['path']).name=='candidate_evidence.json');candidates=pin(evidence_desc)
 byid={row['occurrence']['occurrence_id']:row for row in candidates}
 if len(byid)!=len(candidates):raise ValueError('Duplicate root candidate occurrence')
 from decision_revision_hook import content_hash
 fields=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version');outcomes=[];seen=set();pages=set();root_count=0
 for entry in hand['per_unit_receipts']:
  receipt=pin(entry['event_route']);page=entry['page_id'];unit=units[page]
  if page in pages or receipt['execution']!='EXECUTED' or receipt['source_scope']!={k:unit['manifest'][k] for k in fields}:raise ValueError('Root per-unit source scope differs')
  pages.add(page)
  for desc in receipt['artifacts']:pin(desc,False)
  previous_receipt=pin(receipt['previous_receipt']);old_outcomes={row['occurrence_id']:row for row in previous_receipt['outcomes']}
  ids={row['occurrence_id'] for row in receipt['outcomes']}
  raw=sorted([row for row in unit['occurrences'] if row['occurrence_id'] in ids],key=lambda row:row['occurrence_id'])
  if content_hash(raw)!=receipt['input_occurrences_sha256'] or len(raw)!=len(ids):raise ValueError('Root original occurrence evidence differs')
  for row in receipt['outcomes']:
   oid=row['occurrence_id']
   if oid in seen or oid not in byid or byid[oid]['occurrence']!=next(r for r in raw if r['occurrence_id']==oid):raise ValueError('Root duplicate/stale occurrence')
   seen.add(oid)
   if byid[oid]['candidate_qids']==['Q362']:
    if row['status']!='RESOLVED' or row['accepted_event_qids']!=['Q362'] or row['reason']!='ROOT_EVENT_IDENTITY' or row.get('p361_chain')!=[] or row.get('identity_evidence')!=decisions['Q362']['identity_evidence']:raise ValueError('Root occurrence identity evidence differs')
    root_count+=1
   elif row!=old_outcomes[oid]:raise ValueError('Prior non-root occurrence outcome changed')
   outcomes.append(row)
 if seen!=set(byid) or len(outcomes)!=hand['resolved_Event_occurrences'] or root_count!=hand['corrected_root_occurrences'] or any(row['status']!='RESOLVED' for row in outcomes) or hand['unresolved_Event_occurrences']!=0:raise ValueError('Root forty-occurrence totals differ')
 prior.update(entities=entities,events=events,selection_version=selection['version'],scope_version=prior['scope_version']+'+ROOT_HOPS_PENDING',
  event_route_complete=False,pending_inputs=['ROOT_NATIVE_HOP_EXPANSION_NOT_EXECUTED'],admission_format='RELATIONS_ROOT_SUCCESSOR_HANDOFF_0001',
  resolved_occurrences=len(outcomes),unresolved_occurrences=0,retained_unresolved=[],retained_unresolved_decisions=[],
  input_sha256=pins,root_hop_expansion=hand['root_hop_expansion'],root_identity_occurrences=root_count,
  stage_status=dict(root_identity='COMPLETED_VERIFIED',prior_event_hops='VERIFIED_PRIOR_GENERATION',root_hop_expansion='PENDING_NOT_EXECUTED'),
  bounded_scope='ROOT_IDENTITY_SUCCESSOR_OF_VERIFIED_PRIOR_SCOPE; root native expansion NOT_EXECUTED')
 prior['scope_audit']=deepcopy(prior['scope_audit']);prior['scope_audit'].update(root_hop_expansion='PENDING_NOT_EXECUTED',accepted_event_qids=sorted(decisions),successor_selection=hand['selection'])
 return prior


def _admit_scope_expansion(normalized,hand,route,pin,pins,count_receipt,native_registry,approved_selection,approved_mask):
 execution=pin(normalized['execution']);audit=pin(normalized['verification'])
 if execution['status']!='ROOT_RELATION_SCOPE_EXECUTED' or audit['status']!='PASS_BOUNDED_ROOT_EXPANSION':raise ValueError('Root expansion verification is incomplete')
 if execution['inputs']['root_successor']!=normalized['identity']:raise ValueError('Root expansion identity linkage differs')
 for key,name in [('scope','scope.json'),('geo','geo_decisions.json')]:
  if normalized[key]!=execution['artifacts'][name]:raise ValueError('Root expansion audited artifact differs')
 for key in ['processor','traversal']:pin(execution[key],False)
 if Path(execution['processor']['path']).resolve()!=ROOT/'pair_relations_direct_20261101/root_relation_expansion_0001/execute_root_scope.py':raise ValueError('Unexpected expansion processor')
 for desc in execution['inputs'].values():pin(desc,False)
 for desc in execution['artifacts'].values():pin(desc,False)
 if execution.get('previous') is not None:pin(execution['previous'])
 if pin(execution['inputs']['projection'])['count_receipt']!=count_receipt or execution['inputs']['registry']['sha256']!=native_registry['sha256']:raise ValueError('Expansion current count/registry binding differs')
 root=admit_numbered_event(normalized['identity'],count_receipt=count_receipt,native_registry=native_registry,
  approved_event_selection=approved_selection,approved_mask_result=approved_mask)
 pins.update(root['input_sha256'])
 records=pin(normalized['sources']);used=pin(execution['artifacts']['sources.json']);geo=pin(normalized['geo'])
 for q,node in used.items():
  if records.get(q)!=node:raise ValueError('Expansion source custody differs from pinned frontier')
 if hand['first_hop_source_gaps']!=execution['full_first_hop_source_gaps'] or audit['source_gaps']!=hand['first_hop_source_gaps'] or audit['source_gap_count']!=len(hand['first_hop_source_gaps']):raise ValueError('Expansion source-gap records differ')
 mask_path=ROOT/'geometry_direct_20261101/pacific_loc_mask_v1/pacific_loc_mask.py';mask_json=mask_path.with_name('pacific_loc_mask_v1.geojson')
 def sha(path):
  with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
 if geo['mask_version']!=hand['mask_version'] or geo['mask_sha256']!=hand['mask_sha256'] or sha(mask_path)!=geo['mask_code_sha256'] or sha(mask_json)!=geo['mask_sha256']:raise ValueError('Expansion approved mask binding differs')
 pins[str(mask_path)]=geo['mask_code_sha256'];pins[str(mask_json)]=geo['mask_sha256']
 spec=importlib.util.spec_from_file_location('_publisher_scope_geo',mask_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 import geopandas as gpd
 frames={}
 for row in geo['decisions']:
  path=pin(row['source'],False);geometry=None
  if Path(path).suffix=='.parquet':
   if path not in frames:frames[path]=gpd.read_parquet(path)
   frame=frames[path];subset=frame.loc[frame['place_id']==row['qid']]
   if len(subset)>1:raise ValueError('Ambiguous source geometry')
   geometry=subset.geometry.iloc[0] if len(subset)==1 else None
  actual=module.classify_loc(geometry,entity_type=row['entity_type'],crs=frames[path].crs if path in frames else 'EPSG:4326')
  if actual!=row['mask_result'] or geo['geo'].get(row['qid'])!={'INCLUDE':True,'EXCLUDE':False,'UNKNOWN':None}[actual]:raise ValueError('Expansion geometry decision differs')
 projection=pin(execution['inputs']['projection']);typed={(r['qid'],r['entity_group']) for r in count_receipt['projection']['typed_counts']}
 events_by_qid={row['entity_id']:row for row in root['entities']};active=set(events_by_qid);decisions=[];path_edges={};counts=Counter();paths=Counter()
 scope_path=pin(normalized['scope'],False)
 with Path(scope_path).open('rb') as stream:
  for index,row in enumerate(ijson.items(stream,'candidates.item',use_float=True)):
   hop=row['hop'];kind=row['type'];inclusion=row['inclusion'];paths[hop]+=1;counts[(hop,inclusion)]+=1
   if row['anchor']!='Q362' or hop not in [1,2] or len(row['path'])!=hop:raise ValueError('Expansion traversal boundary differs')
   if inclusion=='INCLUDE':
    if kind=='LOC':
     if geo['geo'].get(row['qid']) is not True:raise ValueError('Included LOC lacks approved mask inclusion')
    elif hop==2:raise ValueError('Non-LOC second hop cannot be active')
    if (row['qid'],kind) not in typed and not (kind=='Event' and row['qid'] in events_by_qid):raise ValueError('Included endpoint has no supplied type')
    active.add(row['qid'])
   elif kind=='LOC' and inclusion=='PENDING_GEO' and geo['geo'].get(row['qid']) is not None:raise ValueError('LOC unknown decision differs')
   decisions.append(dict(source_record_index=index,qid=row['qid'],type=kind,hop=hop,inclusion=inclusion))
   if inclusion!='INCLUDE':continue
   for edge in row['path']:
    value={k:edge[k] for k in ['subject_qid','object_qid','source_predicate','source_record_id','raw_statement','source']};sid=value['source_record_id']
    if sid in path_edges and path_edges[sid]!=value:raise ValueError('Conflicting native expansion statement')
    path_edges[sid]=value
 if not (paths[1]==hand['first_hop_paths']==execution['first_hop_paths']==audit['first_hop_paths'] and paths[2]==hand['second_hop_paths']==execution['second_hop_paths']==audit['second_hop_paths'] and sum(paths.values())==audit['total_paths_verified']) or dict((str(k),v) for k,v in counts.items())!=audit['counts']:raise ValueError('Expansion path/inclusion counts differ')
 chosen=[edge for edge in path_edges.values() if {edge['subject_qid'],edge['object_qid']}<=active]
 mapping_path=Path(r'D:\Projects\GeoAI/GG_Data/mapping/RELATION_MAPPING_TABLE_v2.1.1.csv');direction_path=mapping_path.with_name('RELATION_DIRECTION_LOOKUP_v2.1.1.csv')
 with mapping_path.open(encoding='utf-8-sig',newline='') as stream:catalog=list(csv.DictReader(stream))
 rules={(r['source'],r['source_predicate']):r for r in catalog};endpoints={q for e in chosen for q in [e['subject_qid'],e['object_qid']]};replay=[]
 sys.path.insert(0,str(ROOT/'pair_relations_direct_20261101/registry_completion_0001'))
 from registry_completion import choose_name
 for q in sorted(endpoints):
  if q not in records:raise ValueError('Included native edge lacks source custody')
  node=records[q];raw=deepcopy(node['record']);original=raw['claims'];raw['claims']={}
  for edge in chosen:
   if edge['subject_qid']!=q:continue
   prop=edge['source_predicate'].removeprefix('wd:')
   if edge['source']!=node['source'] or edge['raw_statement'] not in original.get(prop,[]):raise ValueError('Expansion native direction/source/version differs')
   raw['claims'].setdefault(prop,[]).append(edge['raw_statement'])
  name=events_by_qid[q]['name'] if q in events_by_qid else choose_name(q,node['record'],{},[])['value']
  replay.append(dict(entity_id=q,name=name,sources=[node['source']],raw_reference=dict(full=dict(requested_qid=q,entity=raw))))
 from GG_Data.pipeline.relations import scan,populate
 retained,excluded,_=scan(replay,endpoints,rules)
 if excluded or len(retained)!=len(chosen):raise ValueError('Native expansion exclusions/normalization differ')
 rows=populate(retained,rules);ordinary={r['observation_id']:r for r in projection['relation_receipt']['projection']['relations']};added={r['observation_id']:r for r in root['relations']}
 for row in rows:
  oid=row['observation_id']
  if oid in ordinary:
   if row!=ordinary[oid]:raise ValueError('Existing ordinary native assertion changed')
  elif oid in added:
   if row!=added[oid]:raise ValueError('Repeated Event assertion version differs')
  else:added[oid]=row
 prior_scope=root['scope_audit']
 for path in [Path(__file__),mapping_path,direction_path,Path(sys.modules[scan.__module__].__file__)]:pins[str(path.resolve())]=sha(path)
 root.update(normalized_schema=RESULT_SCHEMA,source_format=normalized['kind'],relations=list(added.values()),input_sha256=pins,
  scope_version=execution['hop_version']+'+'+geo['mask_version']+':'+normalized['scope']['sha256'],
  event_route_complete=True,pending_inputs=[],admission_format='ROOT_EXPANSION_HANDOFF_0001',root_hop_expansion='EXECUTED_BOUNDED_WITH_DOCUMENTED_GAPS',
  stage_status=dict(root_identity='COMPLETED_VERIFIED',prior_event_hops='VERIFIED_PRIOR_GENERATION',root_hop_expansion='EXECUTED_BOUNDED_WITH_DOCUMENTED_GAPS'),
  root_expansion_paths=sum(paths.values()),root_expansion_included=sum(v for (hop,inc),v in counts.items() if inc=='INCLUDE'),source_gaps=hand['first_hop_source_gaps'],
  scope_audit=dict(source=normalized['scope'],geo=normalized['geo'],source_frontier=normalized['sources'],decisions=decisions,
   counts={str(k):v for k,v in counts.items()},active_qids=sorted(active),source_gaps=hand['first_hop_source_gaps'],prior_scope_audit=prior_scope,
   root_hop_expansion='EXECUTED_BOUNDED_WITH_DOCUMENTED_GAPS',global_source_completeness=False),
  bounded_scope=hand['source_coverage'])
 return root
