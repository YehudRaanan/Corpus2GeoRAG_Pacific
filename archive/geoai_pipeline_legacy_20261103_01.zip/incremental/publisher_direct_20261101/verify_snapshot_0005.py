"""Independent snapshot_0005 acceptance/readback. No stage import."""
import gzip
import hashlib
import json
import sys
from pathlib import Path
sys.path[:0] = [r'D:\Projects\GeoAI',r'D:\Projects\GeoAI\Agent']
import geopandas as gpd
from geo_agent.graph_store import GraphStore
HERE=Path(__file__).resolve().parent
OUT=HERE/'snapshot_0005'
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def compressed(path):
    with gzip.open(path,'rt',encoding='utf-8') as stream:return json.load(stream)
receipt=read(OUT/'private/receipt.json')
assert receipt['decision_version']=='first-unit-exact-v1' and receipt['page_id']==48975579 and receipt['processing_revision_id']==1375061414
for path,expected in receipt['inputs_sha256'].items():assert sha(path)==expected,path
for path,expected in receipt['artifact_sha256'].items():assert sha(OUT/path)==expected,path
assert sha(HERE/'consume_native_relations.py')==receipt['stage_sha256']
previous=read(HERE/'snapshot_0004/graph.json')
graph=read(OUT/'graph.json')
payload=read(OUT/'private/pair_views.json')
assert graph['nodes']==previous['nodes'] and len(graph['nodes'])==10
assert set(graph)==set(previous)=={'nodes','edges','metadata','relation_catalog'}
assert set(graph['metadata'])==set(previous['metadata'])
assert graph['edges']==payload['native_producer_graph']['edges'] and len(graph['edges'])==8
assert graph['relation_catalog']==payload['native_producer_graph']['relation_catalog']
assert graph['metadata']['relation_map_version']=='relation-map-v2.1.1'
assert compressed(OUT/'model/relations.json.gz')==payload['relations'] and len(payload['relations'])==4
assert read(OUT/'private/pair_views.json')==read(HERE.parent/'pair_relations_direct_20261101/real_pair_views_20261101T203117785273Z/pair_views.json')
for name in ['entities.json.gz','events.json.gz','geography.json.gz','geometries.parquet']:
    assert (OUT/'model'/name).read_bytes()==(HERE/'snapshot_0004/model'/name).read_bytes()
store=GraphStore.from_json(OUT/'graph.json',model_dir=OUT/'model')
assert len(store.nodes)==10 and len(store.edges)==8 and len(store.geoms)==4
assert store.schema()['assertion_count']==4 and len(store.model_edge_dates)==8
assert {e.source_edge_id for e in store.edges if e.source_edge_id}=={e.id for e in store.edges if not e.source_edge_id}
assert all(e.count==1 for e in store.edges)
for edge in store.edges:
    if edge.source_edge_id:
        base=next(e for e in store.edges if e.id==edge.source_edge_id)
        assert (edge.source,edge.target)==(base.target,base.source)
        assert (edge.start_date,edge.end_date,edge.point_date)==(base.start_date,base.end_date,base.point_date)
        assert store.model_edge_dates[id(edge)]==store.model_edge_dates[id(base)]
timed=next(e for e in store.edges if e.type=='wd:P361')
assert timed.start_date=='+1944-03-28T00:00:00Z' and timed.end_date=='+1945-06-17T00:00:00Z'
assert store.model_edge_dates[id(timed)]['start_date']['precision']==11
frame=gpd.read_parquet(OUT/'model/geometries.parquet')
assert len(frame)==4 and frame.crs.to_epsg()==4326
assert set(store.geoms)=={r.place_id+'::LOC' for r in frame.itertuples()}
for row in frame.itertuples():assert store.geoms[row.place_id+'::LOC'].wkb==row.geometry.wkb
gap=read(OUT/'private/default_export_gap.json')
assert gap['default_views']==[e for e in payload['active_pair_views'] if e.get('kind')=='CO_MENTIONED'] and len(gap['default_views'])==64
assert gap['pending_pairs']==payload['pending_pairs'] and len(gap['pending_pairs'])==9
assert gap['decision_version']==receipt['decision_version'] and gap['formula_or_direction_approval_required'] is False
assert len({tuple(sorted((r['source'],r['target']))) for r in gap['default_views']})==32
assert not {e['id'] for e in graph['edges']} & {e['id'] for e in gap['default_views']}
assert all('directional_strength' not in e and 'strength' not in e for e in graph['edges'])
result=dict(status='PASS_INDEPENDENT_SNAPSHOT_0005_READBACK',decision_version=receipt['decision_version'],nodes=10,
    native_views=4,inverse_views=4,base_assertions=4,model_date_joins=8,geometry_rows=4,
    geometry_bound_accepted_occurrences=18,accepted_occurrences=30,pending_occurrences=106,
    private_default_views=64,private_default_pairs=32,private_pending_Q131347_pairs=9,
    no_extra_consumer_fields=True,all_previous_snapshots_preserved=True,complete_private_provenance_preserved=True,
    receipt_sha256=sha(OUT/'private/receipt.json'),verification_code_sha256=sha(Path(__file__)),publication=False)
(OUT/'private/independent_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
