"""Fresh independent snapshot_0004 readback, without importing its stage."""
import gzip
import hashlib
import json
import sys
from pathlib import Path
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
import geopandas as gpd
from shapely import from_wkb
from shapely.geometry import Point
from pyproj import Geod
from geo_agent.graph_store import GraphStore
HERE = Path(__file__).resolve().parent
OUT = HERE / 'snapshot_0004'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
receipt = read(OUT / 'private/receipt.json')
assert receipt['decision_version'] == 'first-unit-exact-v1' and receipt['processing_revision_id'] == 1375061414
for path, expected in receipt['inputs_sha256'].items():
    assert sha(path) == expected, path
for path, expected in receipt['artifact_sha256'].items():
    assert sha(OUT / path) == expected, path
assert sha(HERE / 'consume_nagoya.py') == receipt['stage_sha256']
assert (OUT / 'graph.json').read_bytes() == (HERE / 'snapshot_0003/graph.json').read_bytes()
frame = gpd.read_parquet(OUT / 'model/geometries.parquet')
previous = gpd.read_parquet(HERE / 'snapshot_0003/model/geometries.parquet')
assert frame.place_id.tolist() == previous.place_id.tolist()+['Q11751'] and frame.crs.to_epsg() == 4326
for row in previous.itertuples():
    assert frame.loc[frame.place_id == row.place_id].geometry.iloc[0].wkb == row.geometry.wkb
handoff = read(OUT / 'private/nagoya/handoff.json')
assert handoff['new_selection'] is False and handoff['decision_version'] == receipt['decision_version']
item = handoff['identities'][0]
assert (item['qid'], item['accepted_occurrences'], item['source_object_id'], item['osm_version']) == ('Q11751',2,'relation:4576938','13')
raw = read(OUT / 'private/nagoya/Q11751_source_row.json')
with gzip.open(handoff['source_file'],'rt',encoding='utf-8') as stream:
    source = json.load(stream)
assert [r for r in source['rows'] if str(r['osm_id'])=='4576938'] == [raw]
assert {r['key']:r['value'] for r in raw['all_tags']}['wikidata'] == 'Q11751'
actual = frame.loc[frame.place_id == 'Q11751'].geometry.iloc[0]
assert actual.wkb == from_wkb(bytes.fromhex(raw['geometry_wkb'])).wkb
assert actual.geom_type == 'Polygon' and actual.is_valid and not actual.is_empty
coordinate_evidence = handoff['retained_coordinate_evidence']
statements = coordinate_evidence['statements']
assert len(statements) == 2 and coordinate_evidence['selected_coordinate'] is None
coords = [s['mainsnak']['datavalue']['value'] for s in statements]
assert all(actual.covers(Point(v['longitude'],v['latitude'])) for v in coords)
distance = Geod(ellps='WGS84').inv(coords[0]['longitude'],coords[0]['latitude'],coords[1]['longitude'],coords[1]['latitude'])[2]
assert abs(distance-coordinate_evidence['distance_metres']) < 1e-9
assert all(s['references'] for s in statements)
with gzip.open(OUT / 'model/geography.json.gz','rt',encoding='utf-8') as stream:
    geography = json.load(stream)
assert len(geography)==5 and [r['place_id'] for r in geography if r['geometry_ref'] is None]==['Q131347']
for row in geography:
    if row['geometry_ref'] is not None:
        assert row['geometry_ref'] == dict(file='geometries.parquet',place_id=row['place_id'],sha256=sha(OUT / 'model/geometries.parquet'))
store = GraphStore.from_json(OUT / 'graph.json',model_dir=OUT / 'model')
assert len(store.nodes)==10 and not store.edges and set(store.geoms)=={qid+'::LOC' for qid in frame.place_id}
for row in frame.itertuples():
    assert store.geoms[row.place_id+'::LOC'].wkb==row.geometry.wkb
aggregate = read(HERE.parent / 'integration_direct_20261101/real_handoff_0001/aggregate.json')
counts = {r['qid']:r['mention_count'] for r in aggregate['typed_counts'] if r['entity_group']=='LOC'}
assert sum(counts[qid] for qid in frame.place_id)==18
assert len(aggregate['occurrences'])==136 and sum(bool(o['decision_values']) for o in aggregate['occurrences'])==30
result = dict(status='PASS_INDEPENDENT_SNAPSHOT_0004_READBACK',decision_version=receipt['decision_version'],nodes=10,edges=0,
    geometry_rows=4,geometry_bound_accepted_occurrences=18,accepted_occurrences=30,pending_occurrences=106,
    remaining_LOC_gaps=['Q131347::LOC'],native_WKB_exact=True,all_previous_geometries_preserved=True,
    coordinate_statements_retained=2,coordinate_distance_metres=distance,selected_coordinate=None,
    graph_byte_identical=True,previous_snapshots_preserved=True,receipt_sha256=sha(OUT / 'private/receipt.json'),
    verification_code_sha256=sha(Path(__file__)),publication=False)
(OUT / 'private/independent_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
