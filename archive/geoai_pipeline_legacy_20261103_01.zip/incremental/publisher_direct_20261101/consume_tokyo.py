"""Consume one pinned Tokyo handoff into a new local immutable snapshot; no selection."""
import hashlib
import json
import shutil
import sys
from pathlib import Path
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
from geo_agent.graph_store import GraphStore

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'geometry_direct_20261101/tokyo_handoff_0001'
PREVIOUS = HERE / 'snapshot_0001'
OUT = HERE / 'snapshot_0002'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def run():
    verification_pin = '6abd5bf262bb7972acad0336d2370d3b817b7811c9a4f9f7eec6021bcde90bcd'
    if sha(SOURCE / 'verification.json') != verification_pin:
        raise ValueError('Tokyo verification hash differs')
    verification = read(SOURCE / 'verification.json')
    inputs = dict(verification['inputs'])
    inputs[str(SOURCE / 'verification.json')] = verification_pin
    inputs.update({str(SOURCE / path): expected for path, expected in verification['files'].items()})
    # Pin every file in snapshot_0001, including private receipts, before any output.
    inputs.update({str(p):sha(p) for p in PREVIOUS.rglob('*') if p.is_file()})
    previous_receipt = read(PREVIOUS / 'private/receipt.json')
    inputs.update(previous_receipt['inputs_sha256'])
    if not all(sha(path) == expected for path, expected in inputs.items()):
        raise ValueError('Upstream input differs')
    handoff = read(SOURCE / 'handoff.json')
    if (handoff['qid'], handoff['node_id'], handoff['accepted_occurrences'], handoff['new_selection']) != ('Q1490','Q1490::LOC',8,False):
        raise ValueError('Unexpected identity/selection handoff')
    if sha(SOURCE / 'graph.json') != sha(PREVIOUS / 'graph.json'):
        raise ValueError('Graph frontier differs')
    OUT.mkdir()  # Never overwrite snapshot_0001 or an existing snapshot_0002.
    (OUT / 'model').mkdir()
    private = OUT / 'private'
    private.mkdir()
    shutil.copyfile(PREVIOUS / 'graph.json', OUT / 'graph.json')
    for name in ['entities.json.gz','events.json.gz','relations.json.gz']:
        if sha(SOURCE / 'model' / name) != sha(PREVIOUS / 'model' / name):
            raise ValueError('Non-geography model changed: '+name)
        shutil.copyfile(PREVIOUS / 'model' / name, OUT / 'model' / name)
    for name in ['geography.json.gz','geometries.parquet']:
        shutil.copyfile(SOURCE / 'model' / name, OUT / 'model' / name)
    for name in ['source_osm_row.json','original_selection_and_native_claims.json']:
        shutil.copyfile(SOURCE / 'private' / name, private / name)
    shutil.copyfile(SOURCE / 'handoff.json', private / 'tokyo_handoff.json')
    shutil.copyfile(SOURCE / 'verification.json', private / 'tokyo_verification.json')
    gaps = read(PREVIOUS / 'private/missingness.json')
    for identity in gaps['identity_mapping']:
        if identity['node_id'] == 'Q1490::LOC':
            identity['unavailable_source_fields'].remove('selected source-backed geometry')
    gaps.update(missingness='Native relation population not supplied. One existing Tokyo administrative geometry is retained; four LOC geometries remain unavailable in this snapshot.',
        locations_with_geometry=1, locations_without_geometry=4, geometry_bound_accepted_occurrences=8,
        geometry_caveat=handoff['caveat'], geometry_enrichment_status=handoff['enrichment_status'])
    (private / 'missingness.json').write_text(json.dumps(gaps,indent=2),encoding='utf-8')
    store = GraphStore.from_json(OUT / 'graph.json', model_dir=OUT / 'model')
    assert len(store.nodes) == 10 and not store.edges and set(store.geoms) == {'Q1490::LOC'}
    assert all(sha(path) == expected for path,expected in inputs.items())
    receipt = dict(status='PASS_LOCAL_SNAPSHOT_0002_TOKYO', nodes=10, edges=0, geometry_rows=1,
        accepted_occurrences=30, pending_occurrences=106, geometry_bound_accepted_occurrences=8,
        locations_without_geometry=4, graph_byte_identical=True, new_selection=False, publication=False,
        inputs_sha256=inputs, artifact_sha256={p.relative_to(OUT).as_posix():sha(p) for p in OUT.rglob('*') if p.is_file()},
        stage_sha256=sha(Path(__file__)), backup_status='Unprotected')
    (private / 'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print('PASS snapshot_0002: 10 nodes, 0 edges, 1 Tokyo geometry; 30 accepted / 106 pending; snapshot_0001 preserved')

if __name__ == '__main__':
    run()
