"""Read-only-source relation compatibility probe; this is not a published snapshot."""
import gzip
import hashlib
import json
import shutil
import sys
from pathlib import Path
sys.path[:0] = [r'D:\Projects\GeoAI', r'D:\Projects\GeoAI\Agent']
from geo_agent.graph_store import GraphStore, Edge
from pydantic import ValidationError
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'pair_relations_direct_20261101/real_pair_views_20261101T203117785273Z'
BASE = HERE / 'snapshot_0003'
OUT = HERE / 'relations_compatibility_0001'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
payload_pin = '60638fb16df6e2814896a1ca0e94e7b56dbb5b8ec85f6f8c226af5df3ecde83f'
assert sha(SOURCE / 'pair_views.json') == payload_pin
payload = read(SOURCE / 'pair_views.json')
assert read(SOURCE / 'independent_readback.json')['output_sha256'] == payload_pin
prior = {str(p):sha(p) for directory in ['snapshot_0001','snapshot_0002','snapshot_0003'] for p in (HERE / directory).rglob('*') if p.is_file()}
native = payload['native_producer_graph']
active_native = [e for e in payload['active_pair_views'] if e.get('kind') != 'CO_MENTIONED']
assert active_native == native['edges'] and len(active_native) == 8
assert len(payload['relations']) == 4
OUT.mkdir()
(OUT / 'model').mkdir()
for name in ['geography.json.gz','geometries.parquet','events.json.gz']:
    shutil.copyfile(BASE / 'model' / name, OUT / 'model' / name)
(OUT / 'model/relations.json.gz').write_bytes(gzip.compress(json.dumps(payload['relations']).encode(),mtime=0))
probe = read(BASE / 'graph.json')
probe['edges'] = active_native
probe['relation_catalog'] = native['relation_catalog']
probe['metadata']['relation_map_version'] = native['metadata']['relation_map_version']
(OUT / 'graph.json').write_text(json.dumps(probe,indent=2),encoding='utf-8')
shutil.copyfile(SOURCE / 'pair_views.json', OUT / 'complete_private_pair_evidence.json')
store = GraphStore.from_json(OUT / 'graph.json', model_dir=OUT / 'model')
assert len(store.nodes) == 10 and len(store.edges) == 8 and store.schema()['assertion_count'] == 4
assert len(store.model_edge_dates) == 8 and len(store.geoms) == 3
fallback = next(e for e in payload['active_pair_views'] if e.get('kind') == 'CO_MENTIONED')
try:
    Edge.model_validate(fallback)
except ValidationError as error:
    missing_fields = [e['loc'][0] for e in error.errors() if e['type']=='missing']
    assert missing_fields == ['type']
else:
    raise AssertionError('Unadapted private fallback unexpectedly accepted')
# A temporary candidate tests only an existing field translation, not strength serialization.
count_candidate = dict(fallback, type=fallback['kind'], count=fallback['shared_page_count'])
probe['edges'] = active_native + [count_candidate]
(OUT / 'fallback_diagnostic.json').write_text(json.dumps(probe),encoding='utf-8')
try:
    GraphStore.from_json(OUT / 'fallback_diagnostic.json',model_dir=OUT / 'model')
except ValueError as error:
    assert str(error) == 'Missing model assertion: '+fallback['id']
    model_error = str(error)
else:
    raise AssertionError('Missing fallback model assertion was not rejected')
assert all(sha(p)==expected for p,expected in prior.items())
result = dict(status='PASS_COMPATIBILITY_PROBE_NATIVE_READY_DEFAULT_PENDING',
    native_views=4,inverse_views=4,base_assertions=4,consumer_nodes=10,consumer_geometries=3,
    native_model_dates_pass=True,private_default_views=64,pending_Q131347_pairs=9,
    default_missing_edge_field='type (private input uses kind)',
    count_mapping_condition='count must retain integer shared_page_count; never directional_strength',
    default_missing_model_support=model_error,
    open_decision='G11: no agreed consumer field for directional_strength; keep strength and denominators private until representation is resolved',
    source_payload_sha256=payload_pin,code_sha256=sha(Path(__file__)),
    prior_snapshots_preserved=True,new_snapshot_created=False,publication=False)
(OUT / 'verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
