"""Materialize eight existing native/inverse views; retain all default evidence privately."""
import gzip
import hashlib
import json
import shutil
import sys
from pathlib import Path
sys.path[:0]=[r'D:\Projects\GeoAI',r'D:\Projects\GeoAI\Agent']
from geo_agent.graph_store import GraphStore
HERE=Path(__file__).resolve().parent
PREVIOUS=HERE/'snapshot_0004'
SOURCE=HERE.parent/'pair_relations_direct_20261101/real_pair_views_20261101T203117785273Z'
OUT=HERE/'snapshot_0005'
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def run():
    payload_pin='60638fb16df6e2814896a1ca0e94e7b56dbb5b8ec85f6f8c226af5df3ecde83f'
    if sha(SOURCE/'pair_views.json')!=payload_pin:raise ValueError('Native source payload changed')
    pair=read(SOURCE/'pair_views.json')
    verification=read(SOURCE/'verification.json')
    if verification['output_sha256']!=payload_pin or read(SOURCE/'independent_readback.json')['output_sha256']!=payload_pin:
        raise ValueError('Relation verification frontier differs')
    previous=read(PREVIOUS/'private/receipt.json')
    if previous['decision_version']!='first-unit-exact-v1' or sha(PREVIOUS/'private/receipt.json')!='97cb15b872b877c115bb66c7408cc7d4c8880afa612af5d2dac3a2c20616613c':
        raise ValueError('Prior accepted frontier differs')
    inputs=dict(previous['inputs_sha256'])
    inputs.update(verification['protected_sha256'])
    for name in ['pair_views.json','verification.json','independent_readback.json']:
        inputs[str(SOURCE/name)]=sha(SOURCE/name)
    inputs[str(SOURCE.parent/'run_real_pair_views.py')]=verification['code_sha256']
    for number in range(1,5):
        inputs.update({str(p):sha(p) for p in (HERE/f'snapshot_{number:04d}').rglob('*') if p.is_file()})
    if not all(sha(path)==expected for path,expected in inputs.items()):raise ValueError('Pinned upstream bytes changed')
    defaults=[e for e in pair['active_pair_views'] if e.get('kind')=='CO_MENTIONED']
    edges=[e for e in pair['active_pair_views'] if e.get('kind')!='CO_MENTIONED']
    if edges!=pair['native_producer_graph']['edges'] or (len(edges),len(defaults),len(pair['pending_pairs']),len(pair['relations']))!=(8,64,9,4):
        raise ValueError('Unexpected native/default frontier')
    graph=read(PREVIOUS/'graph.json')
    graph['edges']=edges
    graph['relation_catalog']=pair['native_producer_graph']['relation_catalog']
    graph['metadata']['relation_map_version']=pair['native_producer_graph']['metadata']['relation_map_version']
    OUT.mkdir()  # All earlier versions remain immutable; no overwrite.
    (OUT/'model').mkdir()
    private=OUT/'private'
    private.mkdir()
    for name in ['entities.json.gz','events.json.gz','geography.json.gz','geometries.parquet']:
        shutil.copyfile(PREVIOUS/'model'/name,OUT/'model'/name)
    (OUT/'model/relations.json.gz').write_bytes(gzip.compress(json.dumps(pair['relations']).encode(),mtime=0))
    (OUT/'graph.json').write_text(json.dumps(graph,indent=2),encoding='utf-8')
    shutil.copytree(PREVIOUS/'private',private/'previous_snapshot_0004')
    for name in ['pair_views.json','verification.json','independent_readback.json']:
        shutil.copyfile(SOURCE/name,private/name)
    gap=dict(status='NOT_EXPORTED_PENDING_MIXED_CONSUMER_ADAPTER',decision_version=previous['decision_version'],
        page_id=previous['page_id'],processing_revision_id=previous['processing_revision_id'],
        default_views=defaults,pending_pairs=pair['pending_pairs'],source_scope=pair['source_scope'],
        default_directions=64,default_pairs=32,formula_or_direction_approval_required=False,
        development_work='Reuse existing compact directional-strength protocol with the ordinary native/model-backed consumer. Map kind to type and integer shared-page support, retain pair assertion identity/provenance, join model dates without fabricating native assertions, and expose existing strength semantics through the mixed adapter. This is adapter development, not a request for new formula or bidirectionality approval.',
        coverage='Nine Q131347 native-source pairs remain separately pending; 106 identity decisions remain pending. No absent-native claim is made outside the selected nine-record cache frontier.')
    (private/'default_export_gap.json').write_text(json.dumps(gap,indent=2),encoding='utf-8')
    missing=read(PREVIOUS/'private/missingness.json')
    missing.update(missingness='Eight verified native/inverse views exported from four source assertions. All 64 default views and nine source-pending pairs retained in private/default_export_gap.json and complete pair payload; defaults await mixed-consumer adapter. Four geometries retained; only Oahu geometry missing.',
        exported_native_assertions=4,exported_native_inverse_views=8,private_default_directions=64,private_pending_pairs=9)
    (private/'missingness.json').write_text(json.dumps(missing,indent=2),encoding='utf-8')
    store=GraphStore.from_json(OUT/'graph.json',model_dir=OUT/'model')
    assert len(store.nodes)==10 and len(store.edges)==8 and len(store.geoms)==4
    assert store.schema()['assertion_count']==4 and len(store.model_edge_dates)==8
    assert all(sha(path)==expected for path,expected in inputs.items())
    receipt=dict(status='PASS_LOCAL_SNAPSHOT_0005_NATIVE_PARTIAL',decision_version=previous['decision_version'],
        page_id=previous['page_id'],processing_revision_id=previous['processing_revision_id'],maturity='interim partial frozen projection',
        nodes=10,native_views=4,inverse_views=4,base_assertions=4,geometry_rows=4,
        geometry_bound_accepted_occurrences=18,accepted_occurrences=30,pending_occurrences=106,
        private_default_views=64,private_default_pairs=32,private_pending_pairs=9,
        consumer_fields_added=[],publication=False,inputs_sha256=inputs,
        artifact_sha256={p.relative_to(OUT).as_posix():sha(p) for p in OUT.rglob('*') if p.is_file()},
        stage_sha256=sha(Path(__file__)),backup_status='Unprotected')
    (private/'receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print('PASS snapshot_0005: 10 nodes, 4 native + 4 inverse views, 4 geometries; all 64 defaults / 9 pending pairs retained privately')

if __name__=='__main__':run()
