"""Prepare C4 consumer count inputs from one committed immutable CPU snapshot; no live DB access."""
import hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
READER=ROOT/'orchestration_direct_20261101/cpu_trigram_full_5747_0001/capture_cpu_frontier.py'
sys.path[:0]=[str(PUBLISHER/'compact_checkpoint_0001'),str(ROOT/'pair_relations_direct_20261101/compact_unit_store_0001')]
from compact_checkpoint_counts_v2 import export_c3_checkpoint_counts,COMPACT_BASE
from contribution_store import ContributionStore,digest,encoded

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,value):p.write_text(json.dumps(value,indent=2),encoding='utf-8')
def desc(p):return dict(path=str(Path(p).resolve()),sha256=sha(p))

C_COUNT_ROOT=Path('C:/Users/User/Documents/Codex/2026-11-01/task-4/downstream_stage_outputs/counts').resolve()

def prepare_consumer_inputs(frontier_receipt,output_dir):
 output=Path(output_dir).resolve();pins={}
 def pin(d):
  if sha(d['path'])!=d['sha256']:raise ValueError('Frozen consumer input hash differs: '+d['path'])
  pins[d['path']]=d['sha256'];return read(d['path'])
 receipt=pin(frontier_receipt)
 if receipt.get('schema')!='geoai-immutable-cpu-frontier-v1' or receipt.get('status')!='READY_CPU_ONLY' or receipt.get('canonical_store_write_allowed') is not False:raise ValueError('Immutable committed CPU receipt required')
 if not any(output.is_relative_to(r) for r in [PUBLISHER.resolve(),C_COUNT_ROOT]):raise ValueError('Consumer preparation leaves publisher ownership')
 if output.exists():
  previous=read(output/'receipt.json')
  if previous['frontier_receipt']!=frontier_receipt or previous['code_sha256']!=sha(__file__):raise ValueError('Changed consumer preparation cannot overwrite generation')
  for p,d in previous['input_sha256'].items():
   if sha(p)!=d:raise ValueError('Frozen consumer replay source changed')
  for name,d in previous['artifact_sha256'].items():
   if sha(output/name)!=d:raise ValueError('Frozen consumer replay artifact changed')
  return previous
 if receipt['reader']['path']!=str(READER) or sha(READER)!=receipt['reader']['sha256']:raise ValueError('Unexpected frozen CPU reader')
 pins[str(READER)]=sha(READER)
 database=receipt['database']
 if Path(database['path']).resolve()==Path(receipt['canonical_source_store']).resolve() or sha(database['path'])!=database['sha256']:raise ValueError('Advancing live CPU store is not a frozen snapshot')
 pins[database['path']]=database['sha256']
 if hashlib.sha256(encoded(receipt['frontier'])).hexdigest()!=receipt['frontier_sha256']:raise ValueError('Frozen CPU frontier hash differs')
 spec=importlib.util.spec_from_file_location('_publisher_frozen_cpu_reader',READER);reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
 state=reader.read_active_units(frontier_receipt['path'])
 expected={tuple(r['scope']):r['active_head'] for r in receipt['frontier']}
 actual={key:dict(version=versions[-1]['version'],sha256=digest(versions[-1])) for key,versions in state.items()}
 if actual!=expected or len(state)!=receipt['active_units']:raise ValueError('Frozen CPU active heads differ')
 for entry in receipt['frontier']:
  evidence=pin(entry['evidence'])
  if evidence.get('schema')=='geoai-cpu-unit-commit-v1':
   if evidence['status']!='CPU_COMMITTED_PENDING_DOWNSTREAM' or evidence['active_head']!=entry['active_head']:raise ValueError('Uncommitted CPU head')
 # Reuse C3's existing pure count reducer; never instantiate its database-writing constructor.
 counts=ContributionStore._counts(None,state,False)
 reducer=ROOT/'pair_relations_direct_20261101/compact_unit_store_0001/contribution_store.py';pins[str(reducer)]=sha(reducer)
 exporter=Path(export_c3_checkpoint_counts.__code__.co_filename).resolve();pins[str(exporter)]=sha(exporter);pins[str(COMPACT_BASE)]=sha(COMPACT_BASE)
 output.mkdir(parents=True);write(output/'counts_snapshot.json',counts)
 refs=[frontier_receipt,receipt['reader'],dict(path=str(reducer),sha256=sha(reducer)),desc(exporter),desc(COMPACT_BASE)]
 exported=export_c3_checkpoint_counts(output/'compact_counts',counts_snapshot=desc(output/'counts_snapshot.json'),source_receipts=refs)
 result=dict(status='FROZEN_CPU_CONSUMER_COUNT_INPUTS_VERIFIED_PENDING_STAGES',frontier_receipt=frontier_receipt,CPU_units=len(state),history_contributions=receipt['history_contributions'],occurrences=counts['unique_occurrences'],accepted_mentions=sum(r['mention_count'] for r in counts['identity_counts']),pending_occurrences=counts['pending_occurrences'],explicit_NONE=counts['explicit_unmatched_occurrences'],typed_nodes=len(counts['typed_counts']),C3_counts_frontier_sha256=counts['frontier_sha256'],snapshot_receipt_frontier_sha256=receipt['frontier_sha256'],consumer_inputs=exported,counts_snapshot=desc(output/'counts_snapshot.json'),source_receipts=refs,required_stage_receipts=['ordinary relation receipt with same count receipt and decision_binding','FULL LOC geometry receipt bound to those count/relation receipts','RELATIONS current-frontier Event handoff with same count/registry','required DATE/context outcomes'],native_registry='Caller must pin the exact registry used by matching relation/Event receipts; do not silently reuse registry341',full_consumer_complete=False,full_units_complete_claimed=0,live_CPU_store_opened=False,Event_output_computed=False,code_sha256=sha(__file__),input_sha256=pins,artifact_sha256={p.relative_to(output).as_posix():sha(p) for p in output.rglob('*') if p.is_file()},publication=False)
 if not all(sha(p)==d for p,d in pins.items()):raise ValueError('Frozen source changed during consumer preparation')
 write(output/'receipt.json',result);return result
