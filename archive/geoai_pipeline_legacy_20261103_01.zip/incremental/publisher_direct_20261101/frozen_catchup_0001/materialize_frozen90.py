"""Bind verified frozen90 GEO to the exact ordinary/Event count receipt, then materialize once."""
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent;ROOT=PUBLISHER.parent
sys.path[:0]=[str(PUBLISHER/'component_materializer_0001'),str(PUBLISHER/'active_loc_0001')]
import materialize_components as m
from active_loc_projection import admit_population

def write(p,value):p.write_text(json.dumps(value,indent=2),encoding='utf-8');return desc(p)
def desc(p):return dict(path=str(Path(p).resolve()),sha256=m.sha(p))
def main():
 work=HERE/'full90_0001';work.mkdir()
 ep=ROOT/'pair_relations_direct_20261101/event_current_frontier_0001/frozen90_0001/HANDOFF.json';rp=ROOT/'pair_relations_direct_20261101/ordinary_frozen90_0001/HANDOFF.json';gp=ROOT/'geometry_direct_20261101/frozen90_geometry_0001/PUBLISHER_HANDOFF.json'
 event=m.read(ep);ordinary=m.read(rp);geo=m.read(gp);count=m.read(event['count_receipt']['path']);relation=m.read(ordinary['relation_receipt']['path'])
 assert ordinary['count_receipt']==event['count_receipt'] and ordinary['native_registry']==event['native_registry'] and ordinary['frozen_frontier']==event['frozen_frontier']==geo['frontier_receipt']
 assert geo['decision_binding']==count['decision_binding'] and m.read(geo['count_receipt']['path'])['projection']==count['projection']
 for h in [event,ordinary,geo]:
  for d in h.values():
   if isinstance(d,dict) and {'path','sha256'}<=set(d):assert m.sha(d['path'])==d['sha256'],d['path']
 for path,digest in geo['source_sha256'].items():assert m.sha(path)==digest,path
 for d in geo['artifacts'].values():assert m.sha(d['path'])==d['sha256'],d['path']
 print('PASS all frozen90 source, count, ordinary, Event and GEO pins',flush=True)
 source=m.read(geo['source_GEO_receipt']['path']);code=gp.with_name('prepare_frozen90.py');assert m.sha(code)==geo['code_sha256']
 source.update(status=geo['status'],decisions=geo['decisions'],active_LOC=geo['active_LOC'],active_typed_nodes=geo['active_typed_nodes'],GEO_handoff=desc(gp),GEO_code=desc(code),active_endpoint_gate=geo['artifacts']['active_endpoint_gate'])
 normalized_source=write(work/'verified_active_GEO_source.json',source)
 projection=dict(scope_kind='FULL_LOC_POPULATION',scope_qids=geo['source_scope_qids'],geography_path=geo['artifacts']['full_source_geography']['path'],geoparquet_path=geo['artifacts']['full_source_geoparquet']['path'],artifact_sha256={geo['artifacts'][k]['path']:geo['artifacts'][k]['sha256'] for k in ['full_source_geography','full_source_geoparquet']},source_binding=dict(count_receipt_sha256=m.content_hash(count),relation_receipt_sha256=m.content_hash(relation)))
 geometry=dict(decision_binding=count['decision_binding'],projection=projection,projection_sha256=m.content_hash(projection),active_LOC_projection_required=True,source_receipt=normalized_source)
 geometry_descriptor=write(work/'geometry_receipt.json',geometry)
 population,audit,pins=admit_population(count['projection'],geometry);assert len(population)==1144 and len(audit['active_LOC'])==213
 registry=m.read(event['native_registry']['path']);prior=dict(registry['selected_references']);geo_registry=m.read(geo['geometry_source_registry']['path'])
 for q,reference in geo_registry['selected_references'].items():
  raw=reference['envelope']['entity'];assert raw['id']==q and reference['envelope']['requested_qid']==q and 'claims' in raw
  registry['selected_references'].setdefault(q,reference)
 assert all(registry['selected_references'][q]==r for q,r in prior.items())
 identity_registry=write(work/'current_identity_registry_plus_verified_LOC_sources.json',registry)
 native=dict(event['native_registry'],identity_registry=identity_registry)
 sources=[desc(p) for p in [ep,rp,gp]]+[event['frozen_frontier'],event['count_receipt'],ordinary['relation_receipt'],ordinary['join_compatibility'],ordinary['pending_pair_scope'],geo['geometry_source_registry'],geo['source_GEO_receipt'],geo['artifacts']['exceptions'],geo['artifacts']['active_endpoint_gate'],normalized_source,geometry_descriptor]
 prepared=m.read(HERE/'frontier90_0001/receipt.json')
 manifest=dict(schema='geoai-compact-checkpoint-v1',compact_frontier=prepared['consumer_inputs']['compact_frontier'],count_receipt=event['count_receipt'],relation_receipt=ordinary['relation_receipt'],geometry_receipt=geometry_descriptor,native_registry=native,event_route=event['route'],source_receipts=sources)
 manifest_descriptor=write(work/'manifest.json',manifest)
 print('PASS exact213 LOC gate; starting full materializer and independent consumer readback',flush=True)
 parameters=dict(compact_frontier=manifest['compact_frontier'],count_receipt=count,relation_receipt=relation,geometry_receipt=geometry,native_registry=native,event_route=event['route'],source_receipts=sources+[manifest_descriptor],consumer_root=PUBLISHER/'proposed_strength_0001/consumer')
 result=m.materialize_components(work/'components',**parameters)
 receipt=m.read(result['receipt_path']);exceptions=m.read(work/'components/private/data_exceptions.json')
 report=dict(status='PASS_FROZEN90_FULL_ORDINARY_EVENT_ACTIVE_GEO_CONSUMER',consumer_checks=receipt['consumer_checks'],CPU_units=90,raw_occurrences=21225,raw_assigned=7832,raw_pending=11644,raw_NONE=1749,raw_typed_nodes=1593,GEO_active_before_source_name_quarantine=213,GEO_source_gaps=275,GEO_unknown=335,GEO_position_pending_inside=11,ordinary_native_before_active_filters=575,Event_native_after_dedup=84,ordinary_Event_unique_native_before_active_filters=659,ordinary_source_gaps=1057,Event_source_gaps=88,Event_quarantined=event['quarantine'],consumer_quarantined_typed_items=exceptions['quarantined_typed_items'],consumer_quarantined_mentions=exceptions['quarantined_mentions'],excluded_GEO_relation_views=exceptions['excluded_GEO_relation_views'],excluded_quarantine_relation_views=exceptions['excluded_quarantine_relation_views'],receipt=dict(path=result['receipt_path'],sha256=result['receipt_sha256']),refresh_inputs=desc(work/'components/private/refresh_inputs.json'),manifest=manifest_descriptor,full_unit_completion_claim=False,DATE_context_completion_claim=False,canonical_CPU_store_opened=False,publication=False)
 write(work/'HANDOFF.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':main()
