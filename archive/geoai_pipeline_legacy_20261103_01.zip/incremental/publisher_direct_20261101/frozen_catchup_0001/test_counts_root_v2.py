import json,sys,unittest,uuid
from pathlib import Path
HERE=Path(__file__).resolve().parent;PUBLISHER=HERE.parent
sys.path[:0]=[str(HERE),str(PUBLISHER/'compact_checkpoint_0001')]
import compact_checkpoint as old
import compact_checkpoint_counts_v2 as new
import prepare_consumer_inputs_v2 as prep

class CountRootTests(unittest.TestCase):
 def setUp(self):
  self.tag=uuid.uuid4().hex;self.inputs=Path('C:/Users/User/Documents/Codex/2026-11-01/task-9/publisher_counts_tests_v2')/self.tag;self.inputs.mkdir(parents=True)
  self.croot=Path('C:/Users/User/Documents/Codex/2026-11-01/task-4/downstream_stage_outputs/counts');self.croot.mkdir(parents=True,exist_ok=True)
  scope=dict(zip(('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version'),('a'*64,'enwiki',1,1,'b'*64,'fixture-v1')))
  heads=[dict(scope=scope,decision_version='fixture-v1',contribution_sha256='c'*64)]
  self.data=dict(frontier=heads,frontier_sha256=old.content_hash(heads),identity_counts=[dict(qid='Q1',mention_count=1,page_count=1)],typed_counts=[dict(qid='Q1',entity_group='LOC',mention_count=1,page_count=1)],physical_pages=1,pending_occurrences=0,explicit_unmatched_occurrences=0,conflicted_occurrences=0,unique_occurrences=1)
  p=self.inputs/'counts.json';p.write_text(json.dumps(self.data));self.ref=dict(path=str(p),sha256=old.sha(p))
 def test_C_output_is_byte_equal_to_legacy_D(self):
  dparent=HERE/'counts_root_tests_v2';dparent.mkdir(exist_ok=True);a=old.export_c3_checkpoint_counts(dparent/self.tag,counts_snapshot=self.ref,source_receipts=[self.ref],test_only=True);b=new.export_c3_checkpoint_counts(self.croot/('fixture_'+self.tag),counts_snapshot=self.ref,source_receipts=[self.ref],test_only=True)
  for key in ['compact_frontier','count_receipt']:self.assertEqual(Path(a[key]['path']).read_bytes(),Path(b[key]['path']).read_bytes())
 def test_existing_generation_is_preserved(self):
  out=self.croot/('fixture_'+self.tag);new.export_c3_checkpoint_counts(out,counts_snapshot=self.ref,source_receipts=[self.ref],test_only=True)
  with self.assertRaises(ValueError):new.export_c3_checkpoint_counts(out,counts_snapshot=self.ref,source_receipts=[self.ref],test_only=True)
 def test_other_owner_root_rejected(self):
  out=self.croot.parent/'ordinary'/('forbidden_'+self.tag)
  with self.assertRaises(ValueError):new.export_c3_checkpoint_counts(out,counts_snapshot=self.ref,source_receipts=[self.ref],test_only=True)
  p=self.inputs/'frontier.json';p.write_text(json.dumps(dict(schema='geoai-immutable-cpu-frontier-v1',status='READY_CPU_ONLY',canonical_store_write_allowed=False)))
  with self.assertRaisesRegex(ValueError,'ownership'):prep.prepare_consumer_inputs(dict(path=str(p),sha256=old.sha(p)),out)
  self.assertFalse(out.exists())
 def test_bad_source_hash_rejected(self):
  with self.assertRaises(ValueError):new.export_c3_checkpoint_counts(self.croot/('fixture_'+self.tag),counts_snapshot=dict(self.ref,sha256='0'*64),source_receipts=[self.ref],test_only=True)
if __name__=='__main__':unittest.main()
