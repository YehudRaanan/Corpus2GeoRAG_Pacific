"""Synthetic membership contract; no production source/data imports."""
import unittest
from local_unit_contract import membership_status


class MembershipTests(unittest.TestCase):
    def setUp(self):
        self.scope = {
            "input_sha256": "a" * 64,
            "wiki_site": "enwiki",
            "page_id": 41,
            "support_revision_id": 73,
            "source_sha256": "b" * 64,
            "policy_version": "fixture-v1",
        }
        self.manifest = {**self.scope, "expected_row_indices": [2, 8]}

    def test_split_page_stays_pending_until_all_declared_occurrences_arrive(self):
        # Closing at a shard boundary would wrongly enable early grouping.
        first = {**self.scope, "row_indices": [2]}
        second = {**self.scope, "row_indices": [8]}
        pending = membership_status(self.manifest, [first])
        self.assertFalse(pending["membership_complete"])
        self.assertEqual(pending["missing_row_indices"], [8])
        complete = membership_status(self.manifest, [first, second])
        self.assertTrue(complete["membership_complete"])
        self.assertEqual(complete["missing_row_indices"], [])
        self.assertEqual(complete["received_occurrences"], 2)


    def test_changed_input_or_support_binding_cannot_complete_unit(self):
        for field, value in {
            "input_sha256": "c" * 64,
            "wiki_site": "jawiki",
            "page_id": 99,
            "support_revision_id": 99,
            "source_sha256": "d" * 64,
            "policy_version": "fixture-v2",
        }.items():
            with self.subTest(field=field):
                stale = {**self.scope, "row_indices": [2, 8], field: value}
                with self.assertRaises(ValueError):
                    membership_status(self.manifest, [stale])

    def test_unknown_support_revision_stays_pending(self):
        manifest = {**self.manifest, "support_revision_id": None}
        shard = {**self.scope, "support_revision_id": None, "row_indices": [2, 8]}
        result = membership_status(manifest, [shard])
        self.assertFalse(result["membership_complete"])
        self.assertEqual(result["missing_row_indices"], [])

    def test_replay_counts_original_occurrences_once(self):
        shard = {**self.scope, "row_indices": [2, 8]}
        self.assertEqual(
            membership_status(self.manifest, [shard, shard]),
            {"membership_complete": True, "missing_row_indices": [], "received_occurrences": 2},
        )

    def test_undeclared_or_invalid_row_identity_is_rejected(self):
        for row_indices in ([2, 8, 9], [2, True], [2, -1], [2, "8"]):
            with self.subTest(row_indices=row_indices):
                with self.assertRaises(ValueError):
                    membership_status(self.manifest, [{**self.scope, "row_indices": row_indices}])
        for expected in ([2, 2], [True], [-1], ["2"]):
            with self.subTest(expected=expected):
                with self.assertRaises(ValueError):
                    membership_status({**self.manifest, "expected_row_indices": expected}, [])

    def test_source_bytes_match_manifest_and_changed_byte_is_rejected(self):
        from local_unit_contract import validate_source_bytes

        original = b"abc"
        # Published SHA-256 test vector, independently specified literal.
        manifest = {**self.manifest, "source_sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"}
        validate_source_bytes(original, manifest["source_sha256"])
        with self.assertRaises(ValueError):
            validate_source_bytes(b"abd", manifest["source_sha256"])
        self.assertEqual(original, b"abc")

    def test_source_membership_readiness_requires_valid_bytes_and_all_rows(self):
        from local_unit_contract import source_membership_ready

        manifest = {**self.manifest, "source_sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"}
        shard = {**self.scope, "source_sha256": manifest["source_sha256"], "row_indices": [2, 8]}
        self.assertTrue(source_membership_ready(manifest, [shard], b"abc"))
        with self.assertRaises(ValueError):
            source_membership_ready(manifest, [shard], b"abd")
        incomplete = {**shard, "row_indices": [2]}
        self.assertFalse(source_membership_ready(manifest, [incomplete], b"abc"))

    def test_partial_checkpoint_reloads_and_replay_counts_occurrences_once(self):
        from pathlib import Path
        from uuid import uuid4
        from local_unit_contract import write_checkpoint, load_checkpoint, source_membership_ready

        checkpoint = Path(__file__).resolve().parent / f"checkpoint-fixture-{uuid4().hex}.json"
        self.addCleanup(checkpoint.unlink, missing_ok=True)
        source = b"abc"
        manifest = {**self.manifest, "source_sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"}
        first = {**self.scope, "source_sha256": manifest["source_sha256"], "row_indices": [2]}
        write_checkpoint(checkpoint, manifest, [first], source)
        restored = load_checkpoint(checkpoint, manifest, source)
        self.assertEqual(restored, [first])
        self.assertFalse(source_membership_ready(manifest, restored, source))
        second = {**first, "row_indices": [8]}
        resumed = restored + [second]
        self.assertTrue(source_membership_ready(manifest, resumed, source))
        self.assertEqual(membership_status(manifest, resumed + [first])["received_occurrences"], 2)
        with self.assertRaises(FileExistsError):
            write_checkpoint(checkpoint, manifest, resumed, source)
        self.assertEqual(load_checkpoint(checkpoint, manifest, source), [first])
        self.assertEqual(source, b"abc")

    def test_checkpoint_reuse_rejects_changed_bindings_source_and_truncation(self):
        from pathlib import Path
        from uuid import uuid4
        from local_unit_contract import write_checkpoint, load_checkpoint

        checkpoint = Path(__file__).resolve().parent / f"checkpoint-fixture-{uuid4().hex}.json"
        self.addCleanup(checkpoint.unlink, missing_ok=True)
        manifest = {**self.manifest, "source_sha256": "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"}
        first = {**self.scope, "source_sha256": manifest["source_sha256"], "row_indices": [2]}
        with self.assertRaises(ValueError):
            write_checkpoint(checkpoint, manifest, [first], b"abd")
        self.assertFalse(checkpoint.exists())
        write_checkpoint(checkpoint, manifest, [first], b"abc")
        with self.assertRaises(ValueError):
            load_checkpoint(checkpoint, manifest, b"abd")
        for field, value in {
            "input_sha256": "c" * 64,
            "policy_version": "fixture-v2",
            "expected_row_indices": [2, 8, 9],
        }.items():
            with self.subTest(field=field):
                with self.assertRaises(ValueError):
                    load_checkpoint(checkpoint, {**manifest, field: value}, b"abc")
        checkpoint.write_text('{"manifest":', encoding="utf-8")
        with self.assertRaises(ValueError):
            load_checkpoint(checkpoint, manifest, b"abc")

if __name__ == "__main__":
    unittest.main()





