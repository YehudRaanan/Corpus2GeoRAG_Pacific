"""Offline source-byte and membership checks for one declared support unit.

Trust boundary: callers supply a declared inventory and source/input digest
labels. Membership checks bindings and rows; the separate byte check does not prove
completeness of that declaration, eligible entities, or durable completion.
A support revision is a containing revision; no extraction revision is inferred.
"""


import hashlib
import json


def membership_status(manifest, shards):
    scope_fields = (
        "input_sha256", "wiki_site", "page_id", "support_revision_id",
        "source_sha256", "policy_version",
    )
    scope = tuple(manifest[field] for field in scope_fields)
    rows = manifest["expected_row_indices"]
    if any(type(index) is not int or index < 0 for index in rows):
        raise ValueError("Expected row indices must be nonnegative integers")
    expected = set(rows)
    if len(expected) != len(rows):
        raise ValueError("Declared occurrence IDs must be unique")
    received = set()
    for shard in shards:
        if tuple(shard[field] for field in scope_fields) != scope:
            raise ValueError("Shard input/source/page/revision/policy binding differs")
        indices = shard["row_indices"]
        if any(type(index) is not int or index < 0 for index in indices):
            raise ValueError("Received row indices must be nonnegative integers")
        if not set(indices) <= expected:
            raise ValueError("Shard contains an undeclared occurrence")
        received.update(indices)
    missing = sorted(expected - received)
    revision = manifest["support_revision_id"]
    return {
        "membership_complete": not missing and type(revision) is int and revision > 0,
        "missing_row_indices": missing,
        "received_occurrences": len(received),
    }


def validate_source_bytes(source_bytes, expected_sha256):
    """Reject bytes that differ from the pinned digest without changing them."""
    if hashlib.sha256(source_bytes).hexdigest() != expected_sha256:
        raise ValueError("Source bytes do not match declared SHA-256")



def source_membership_ready(manifest, shards, source_bytes):
    """Check declared source/membership only, not grouping or matching eligibility."""
    validate_source_bytes(source_bytes, manifest["source_sha256"])
    return membership_status(manifest, shards)["membership_complete"]





def write_checkpoint(path, manifest, shards, source_bytes):
    """Exclusive-create a fixture checkpoint; interrupted writes may leave invalid JSON."""
    source_membership_ready(manifest, shards, source_bytes)
    with path.open("x", encoding="utf-8") as stream:
        json.dump({"manifest": manifest, "shards": shards}, stream)


def load_checkpoint(path, manifest, source_bytes):
    """Validate before returning replay input; malformed/truncated JSON is rejected."""
    with path.open(encoding="utf-8") as stream:
        checkpoint = json.load(stream)
    if checkpoint["manifest"] != manifest:
        raise ValueError("Checkpoint manifest differs from expected bindings")
    source_membership_ready(manifest, checkpoint["shards"], source_bytes)
    return checkpoint["shards"]


