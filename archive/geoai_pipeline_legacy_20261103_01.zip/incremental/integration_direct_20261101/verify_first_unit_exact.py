"""One-unit approved unique literal exact route; MISC/type uncertainty stays pending."""
import gzip
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
PILOT = Path(r"D:\Projects\GeoAI-luke-pilot-20261028")
sys.path.insert(0, str(PILOT))
from GG_Data.entity_resolution.hundred_page_pilot.filter_qid_inventory import _types
from GG_Data.entity_resolution.hundred_page_pilot.match_exact import exact_pairs


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run():
    cache = HERE / "candidate_cache_0002"
    prior = json.loads((cache / "receipt.json").read_text())
    for name, expected in prior["output_sha256"].items():
        assert digest(cache / name) == expected
    ledger = json.loads((cache / "ledger.json").read_text(encoding="utf-8"))
    grouped = json.loads((HERE / "real_unit_0001/groups.json").read_text(encoding="utf-8"))
    original = deepcopy(grouped)
    positive = json.loads((cache / "literal_positive_evidence.json").read_text(encoding="utf-8"))
    assert sum(bool(g["candidate_qids"]) for g in positive) == 15
    metadata_path = Path(r"C:\Users\User\.cache\geoai_bigquery_20261018\entity_metadata.json.gz")
    with gzip.open(metadata_path, "rt", encoding="utf-8") as stream:
        metadata = json.load(stream)
    paths = [cache / "ledger.json", cache / "receipt.json", cache / "literal_positive_evidence.json",
             HERE / "real_unit_0001/groups.json", HERE / "real_unit_0001/run_receipt.json", metadata_path,
             PILOT / "GG_Data/entity_resolution/hundred_page_pilot/match_exact.py",
             PILOT / "GG_Data/entity_resolution/hundred_page_pilot/filter_qid_inventory.py"]
    protected = {str(path): digest(path) for path in paths}
    page, revision = 48975579, 1375061414
    source_qids = {qid for t in ledger["all_raw_targets_with_inclusion_evidence"] if t["included_from_relevant_component"] for qid in t["candidate_qids"]}
    entities, type_evidence = [], []
    for candidate in ledger["active_cached_candidates"]:
        qid = candidate["qid"]
        assert qid in source_qids and not candidate["accepted_identity"]
        labels = {m["assertion"]["label"] for m in candidate["cached_metadata"] if m["assertion"].get("label")}
        native = sorted({kind for m in candidate["cached_metadata"] for kind in m["assertion"].get("native_types", [])})
        typed = _types(native, metadata)
        type_evidence.append(dict(qid=qid, native_types=native, **typed))
        for label in sorted(labels):
            entities.append(dict(page_id=page, revision_id=revision, qid=qid, label=label,
                                 qid_source_status="KEEP", **typed))
    flat = []
    for group in grouped["groups"]:
        key = group["key"]
        assert (key["page_id"], key["revision_id"]) == (page, revision)
        changed = [m["source_row_index"] for m in group["members"] if m["word_original"] != m["word"]]
        flat.append(dict(id=group["group_id"], page_id=page, revision_id=revision, name=key["word"], type=key["entity_group"],
                         repaired_source_row_indices=changed,
                         source_review_statuses=["MISC_POLICY_PENDING"] if key["entity_group"] == "MISC" else []))
    before = deepcopy((flat, entities))
    pairs = exact_pairs(flat, entities)
    assert (flat, entities) == before and grouped == original
    assert len(pairs) == len({p["group_id"] for p in pairs}) == 10
    assert {p["entity_group"] for p in pairs} <= {"LOC", "ORG", "PER"}
    evidence_by_qid = {r["qid"]: r for r in type_evidence}
    for pair in pairs:
        assert pair["entity_group"] in evidence_by_qid[pair["qid"]]["type_categories"]
        assert not evidence_by_qid[pair["qid"]]["type_unknown"]
    # Sensitivity: a second QID with the same literal must suppress that exact result.
    conflict = dict(next(e for e in entities if e["qid"] == "Q1490" and e["label"] == "Tokyo"), qid="Q999999999")
    assert not any(p["name"] == "Tokyo" for p in exact_pairs(flat, entities + [conflict]))
    # Foreign processing revisions cannot supply a match for this unit.
    assert exact_pairs(flat, [dict(e, revision_id=revision + 1) for e in entities]) == []
    selected = {p["group_id"]: p for p in pairs}
    decisions, accepted_groups = [], []
    for group in grouped["groups"]:
        pair = selected.get(group["group_id"])
        if pair:
            accepted_groups.append(dict(group_id=group["group_id"], qid=pair["qid"], entity_group=pair["entity_group"],
                                        occurrence_ids=[m["occurrence_id"] for m in group["members"]]))
        for member in group["members"]:
            decisions.append(dict(occurrence_id=member["occurrence_id"], source_row_index=member["source_row_index"],
                                  group_id=group["group_id"], raw_type=member["entity_group"],
                                  status="ACCEPTED_UNIQUE_LITERAL_EXACT" if pair else "PENDING_MISC_POLICY" if member["entity_group"] == "MISC" else "PENDING_NO_APPROVED_EXACT_DECISION",
                                  accepted_qid=pair["qid"] if pair else None,
                                  none_decision=False, evidence=pair))
    assert len(decisions) == len({d["occurrence_id"] for d in decisions}) == 136
    assert sum(d["accepted_qid"] is not None for d in decisions) == 30
    assert {d["occurrence_id"] for d in decisions} == {m["occurrence_id"] for g in grouped["groups"] for m in g["members"]}
    assert not any(d["none_decision"] for d in decisions)
    assert protected == {path: digest(Path(path)) for path in protected}
    output = HERE / "exact_unit_0001"
    output.mkdir()
    payload = dict(page_id=page, processing_revision_id=revision, accepted_groups=accepted_groups,
                   occurrence_decisions=decisions, type_evidence=type_evidence,
                   candidate_frontier_sha256=protected[str(cache / "ledger.json")],
                   unresolved_relevant_targets=ledger["unresolved_relevant_targets"],
                   template_uncertainty_unchanged=True, acceptance_basis="Approved unique literal exact in same unit; retained source evidence and supported original type; MISC policy remains pending")
    (output / "decisions.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    assert json.loads((output / "decisions.json").read_text(encoding="utf-8")) == payload
    receipt = dict(status="PASS_FIRST_UNIT_SUPPORTED_UNIQUE_EXACT", checked_utc=datetime.now(timezone.utc).isoformat(),
                   page_id=page, processing_revision_id=revision, original_occurrences=136,
                   literal_positive_groups=15, accepted_groups=10, accepted_occurrences=30, pending_occurrences=106,
                   pending_positive_MISC_groups=5, pending_positive_MISC_occurrences=7,
                   missing_targets_are_none=False, unresolved_target_count=6,
                   unique_cardinality_and_revision_sensitivity_checks="PASS", no_global_coverage_veto=True,
                   protected_sha256=protected, code_sha256=digest(Path(__file__)), decisions_sha256=digest(output / "decisions.json"),
                   consumer_export=False, model_inference=False, publication=False, backup_status="Unprotected")
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in receipt.items() if not k.endswith("sha256")}, ensure_ascii=False))


if __name__ == "__main__":
    run()
