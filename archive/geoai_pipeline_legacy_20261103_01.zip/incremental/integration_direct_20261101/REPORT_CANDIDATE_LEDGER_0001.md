# Relevant-component candidate evidence — one real unit

**PASS**, 2026-11-01 19:56:36 UTC. Page 48975579 / processing revision 1375061414 only. This report applies the owner's clarification: collect candidates only from relevant page components under the approved cleaning policy, independently of extracted NER spans.

| Measure | Before component filter | Relevant components only |
|---|---:|---:|
| Literal link occurrences | 52 | 34 |
| Distinct target titles | 47 | 30 |
| Targets resolved by inspected caches | 22 | 19 |
| Unresolved targets | 25 | 11 |

Eighteen link occurrences were OUT. Seventeen target titles occur exclusively in excluded components and supply **no active QID candidate or mapping assertion**. A target with both retained and excluded occurrences is supported only through its retained component; every source occurrence retains its own decision/reason/offsets. The old 47/22/25 figures in EXACT_PREREQUISITES_FIRST_UNIT.md are preserved as **pre-filter diagnostics**, not the active inventory.

The 19 relevant cached titles lead to 18 distinct QIDs, without conflicting QID assertions in the inspected caches. All 18 have cached labels; 17 have nonempty native-type evidence, while one remains missing type evidence. These are source-bound cached candidates, not accepted identities or historically authoritative type/label values. DATE/MISC and all original mention types remain unchanged.

## Source relevance and provenance

Reused approved narrow_source_policy.py build_view/classify. The rebuilt full-page cleaned text and origin segments exactly match INPUT's saved cleaned-page projection, whose artifact hash is pinned by the sealed writer receipt. Filtering uses actual link display/source-component spans, not NER mention intersections. A small test verifies body Tokyo stays IN while ref/Notes links stay OUT even without any NER input.

The ledger retains all 47 raw targets and all 52 literal source-link records for inclusion/exclusion audit. It also retains 66 template records: 59 OUT, five IN components and two PENDING components. Existing template_targets reports every one as unsupported with no target_title, so no template-derived QID is invented. The IN/PENDING template evidence and full source offsets remain explicit coverage gaps.

Verified processing source SHA256: 40d9dd751d0731f5f46b5a7c5b38ae4eab8d4965d7fffb9de4602d8521146665. No exact extraction revision was required or inferred. Current/cached title-to-QID assertions and native label/type metadata retain their separate cache files, retrieval times and temporal basis; they are not relabeled as historical statements from this revision.

Caches reused: hundred_page_pilot_20261028/collection_titles_final and template_name_pilot_20261029/recovery_100_v2, each title_qid_mapping.parquet and native_metadata.parquet. Source/cache/policy/grouping receipt hashes were checked before/after; no external request or shared write occurred. The first bridge environment lacked mwparserfromhell, so the existing .venv-template-pilot environment was reused without installing anything.

## Verification and remaining work

build_unit_candidate_ledger.py exited 0, producing candidate_ledger_0001/ledger.json and receipt.json. JSON readback passed. A fresh process verified code/ledger/protected hashes, 47/30 target counts, 52 source records, 19 mapped relevant targets/18 distinct candidates, and zero candidate leakage from exclusively excluded targets.

Inventory completeness is **NOT_ESTABLISHED**. Eleven relevant targets need additional supported cached mapping evidence or separately scoped retrieval; unsupported/relevance-pending template components and missing native type evidence remain explicit. Existing G3/G5 eligibility/acceptance semantics must be applied before exact promotion. No normalization/alias default, repaired-group eligibility shortcut, identity assignment, model inference, consumer change or publication was added.

Next small task: inspect the eleven listed unresolved relevant targets against existing exact-title/redirect evidence and resolve only evidence-supported mappings, preserving the same source-component filter and uncertainty. Do not restore excluded notes, refs, galleries, navigation or general-table content through candidate lookup. Backup: Unprotected.
