# First-unit exact prerequisites — read-only inspection

Unit: enwiki page 48975579, processing revision 1375061414. Completed real_unit_0001 grouping remains unchanged: 136 occurrences / 69 prepared-surface groups. No exact matching, accepted QID assignment or global matching was run by this inspection.

## Present

- Sealed retained membership, full original/prepared member records, original IDs, typed source provenance and deterministic groups: real_unit_0001/ and its unchanged run_receipt.json.
- Verified complete raw source bytes for this revision: D:/Projects/GeoAI-simplified-agent-20261030/Data/external/simplified_agent_20261030/page_acquisition/raw/page-01475.txt, SHA256 40d9dd751d0731f5f46b5a7c5b38ae4eab8d4965d7fffb9de4602d8521146665.
- Existing collect_entities.raw_links parses 52 literal links / 47 distinct target titles from those bytes. This is source evidence, not a complete eligible QID inventory; templates/page-own identity and source-component eligibility remain separate.
- Cached title mapping at D:/Projects/GeoAI-luke-pilot-20261028/Data/external/hundred_page_pilot_20261028/collection_titles_final/title_qid_mapping.parquet covers 22 of those 47 distinct targets; 25 are not resolved by this inspected cache. Its evidence is cached/current title resolution, including BigQuery cache receipts dated 2026-10-18, not a historical item inventory.
- template_name_pilot_20261029/recovery_100_v2/title_qid_mapping.parquet likewise covers 22 targets, retaining explicit current/cached Wikipedia lookup provenance and retrieval dates. These cached mappings do not by themselves prove a QID appeared on this source revision.
- Reusable pure exact_pairs(groups,entities) in D:/Projects/GeoAI-luke-pilot-20261028/GG_Data/entity_resolution/hundred_page_pilot/match_exact.py; collect_entities.collect, recover_page_qids.recover_inventory and filter_qid_inventory.filter_inventory are existing inventory components. Their old full-pilot wrappers/default policies must not be executed blindly.

## Not established

A targeted read-only query of **23 entities.parquet inventories** below hundred_page_pilot_20261028 found no rows for page 48975579 at any revision. Thus no existing complete eligible same-page/revision QID inventory was found in these canonical historical candidate artifacts. This is a bounded search result, not a universal claim about every cache on disk.

Required missing artifact: a source-hash-bound inventory for this exact unit, with each QID's label/type/source evidence, unresolved title/template alternatives and explicit completeness/eligibility receipt. Raw retained mention closure is not that inventory; the unit's 186 bound omissions do not disappear and cannot establish full-page eligible candidate coverage.

Existing plan G3 still lists exact literal/alias/normalization and source/type eligibility as owner choices. The real unit contains DATE 21, LOC 45, MISC 40, ORG 24 and PER 6; the old helper permits MISC/unknown types while its wrapper defaults to excluding DATE. Those defaults are not newly approved decisions. Existing exact_pairs also withholds repaired/review-marked groups; an adapter must preserve those flags and occurrence eligibility rather than erase them to obtain matches.

G5 still requires occurrence-aware ambiguity handling and typed QID roles. A group is not proof of a shared identity; newer-input source IDs/SYNs must not be replaced with legacy/group IDs. The existing 69-group shape is nested key/members, whereas exact_pairs expects flat id/page/revision/name/type plus repair/review flags. This adapter is small but cannot substitute for missing inventory or accepted policy.

## Concrete next executable task

Build **R1 / Task 2-E3a source-bound candidate evidence for this unit only, offline**, in a fresh owned output: reuse raw_links and template_targets against the pinned raw source; join exact existing title caches while retaining retrieval/temporal provenance; preserve unresolved targets and unsupported template alternatives; classify source components with the approved INPUT source policy evidence. Keep all source offsets/hash and original occurrence bridges. Write a candidate-source ledger and coverage receipt explicitly marked incomplete where evidence is missing. Do not call it accepted exact output or inject gold/current global-name hits.

This provides concrete candidate/type/source examples for closing G3/G5 and identifying any remaining retrieval need. It requires no trained model. Actual exact promotion remains pending that unit inventory and the approved acceptance/occurrence-eligibility route. No new policy veto or framework is proposed.

All inspection used read-only existing artifacts and code; only this report was written in the owned folder. No nested agent, network request, installation, paid operation, consumer change or publication. Backup: Unprotected.
