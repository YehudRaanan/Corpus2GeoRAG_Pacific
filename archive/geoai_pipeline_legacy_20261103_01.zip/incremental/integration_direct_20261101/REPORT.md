# Direct synthetic integration — 2026-11-01

One generated case passed at 17:40:34 UTC through the existing components:
`group_mentions -> merge_assigned_qids -> exact existing fixture Entity rows -> build_graph -> select_native_views -> GraphStore`.

Only this new directory was written. No shared component or earlier fixture was changed. No production inputs, ingestion/category/training/cloud work, new identities, acquisition, Git operation or publication occurred.

## Measured result

- Nine original generated mentions retained: eight members in six groups, plus one explicit unresolved page/revision-attribution record. The unresolved record retains `revision_id=null`.
- Two LOC groups and one ORG group converge on Q1 while preserving separate typed roles. Q2 remains the existing fixture Event.
- Two same-name members without accepted decisions remain one pending local group with no assignment evidence and no invented QID/SYN. An explicitly unmatched different member retains the supplied existing `SYN_sample`.
- Consumer loads four nodes (`Q1::LOC`, `Q1::ORG`, `Q2::event`, `SYN_sample`), one native assertion and two directional views. Both relation-date views and the Event model-date row attach. Event-to-LOC traversal succeeds.
- Existing polygon and point joins match exactly; all copied model support bytes match. GeoParquet SHA256: `c470eb486a95e8d6105262b0ec04a965f1aaeb712c055d7a4756393a02a04a6a`.
- Graph values equal the existing synthetic snapshot graph exactly. No consumer fields were added. Occurrence/provenance/uncertainty remain in the private `identity_handoff.json`.
- Twenty-four protected existing code/artifact hashes match before/after. Ten output artifact hashes and the stage code hash are recorded in `verification.json`.

This case uses the existing **synthetic fixture catalog v2.1.2 with wd:P1**. It does not exercise the separate real v2.1.1 catalog, select a new mapping, compute co-occurrence, test corrections/retractions, integrate the snapshot publisher, implement cadence or measure production quality. Group assignments are supplied generated decisions; the check requires all members of an assigned group to agree. It is not a production occurrence-adjudication adapter.

## Verification actually run

Using the existing bridge virtual environment, process-only thread limits of one and bytecode disabled:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
$env:OMP_NUM_THREADS='1'
$env:OPENBLAS_NUM_THREADS='1'
$env:MKL_NUM_THREADS='1'
& 'D:\Projects\GeoAI-incremental-dev-20261101\contract_fixtures\.venv-bridge\Scripts\python.exe' -B 'D:\Projects\GeoAI-incremental-dev-20261101\integration_direct_20261101\check_integration.py'
```

Exit 0: `PASS: 1 synthetic integration; 9 retained mentions; 6 groups; Q1 LOC+ORG; pending 2+unbound 1 preserved; 4 consumer nodes; 2 views; exact existing geometry`.

A subsequent independent Python process read the persisted graph/model and handoff, loaded the unchanged consumer, repeated exact geometry/traversal/date checks, and verified all 24 protected hashes, 10 output hashes and the code hash. Exit 0: `PASS_FRESH_PROCESS_READBACK`.

The script deliberately refuses to overwrite `case_0001`; rerunning it requires a deliberately new case directory. The prior snapshot remains untouched.

## Execution issues and handoff

An attempted staging-file write outside this directory was rejected by automatic approval review; it did not execute. The safer direct write into the authorized integration directory succeeded. The first default-sandbox run reached output creation, then failed with WinError 5 before creating `case_0001`. Its absence was checked. The same authorized test then ran successfully with scoped execution approval. No shared-code bug was found and no operation remains denied, pending or uncertain.

Next proposed small increment: reuse the existing both-native consumer case in this composed identity handoff, preserving its independent assertions and dates. This first case is one-sided only, so it does not independently verify redundant-inverse suppression after identity integration. Further work requires its own scope from the parent.

Backup status: **Unprotected**. No Git operations were authorized or performed.
