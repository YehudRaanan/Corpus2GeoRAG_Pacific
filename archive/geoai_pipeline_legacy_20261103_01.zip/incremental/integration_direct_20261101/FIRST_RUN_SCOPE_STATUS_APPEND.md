

## Owner-approved first-run retained scope - materialization pending, 2026-11-01

The owner approved a first run of **1,301,119 verified mapped occurrences**, excluding **24,291 unmapped IN** and **65,985 pending** from that first run while retaining all raw records and provenance. These labels concern the prepared-input scope; they are not QID match decisions. This is not a claim that the listed counts describe the complete original corpus.

INPUT is materializing the approved scoped view and complete page/processing-revision unit membership and performing readback. At this status handoff, the final ready receipt and artifact/schema hashes have not yet been received. The scope decision is approved; materialization/readback readiness is **pending**. No real batch or page/revision unit was started by INTEGRATION, and no unit was chosen from stale input.

Read-only preparation identified the first model-independent operation as runtime **R2 local raw grouping**, consuming Task **2/E2 closed membership** and the existing grouping component. See [FIRST_REAL_UNIT_PREPARATION.md](D:/Projects/GeoAI-incremental-dev-20261101/integration_direct_20261101/FIRST_REAL_UNIT_PREPARATION.md). After INPUT's verified receipt, select one small complete declared unit, preserve original input/row/occurrence IDs and raw name/type, expose only the verified processing revision, and reconcile every member after output readback. This does not define a canonical publication batch under G12.

Exact matching remains separately conditional on a complete eligible same-page/revision QID inventory and existing G3/G5 policy/occurrence eligibility; trained-model availability is not required for raw grouping or separately eligible exact work. This status changes no consumer contract, matching threshold, training status, resource envelope or other existing gate. The existing production input-preparation barrier is not declared complete by this scope decision.
