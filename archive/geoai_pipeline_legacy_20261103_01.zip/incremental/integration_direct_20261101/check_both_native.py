"""Second generated case; retain the first case and all shared components."""
import gzip
import json
import shutil
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from check_integration import (BASE, HERE, GraphStore, _assert_geometry_join, build_graph,
                               digest, fixture, group_mentions, merge_assigned_qids,
                               read_json, select_native_views)


def check():
    first = read_json(HERE / "verification.json")
    protected = {**first["preserved_source_sha256"],
                 **{str(p): digest(p) for p in HERE.rglob("*") if p.is_file()}}
    for path, expected in first["output_sha256"].items():
        assert digest(HERE / "case_0001" / path) == expected
    assert digest(HERE / "check_integration.py") == first["code_sha256"]

    # Replay exactly the first generated identity inputs and accepted decisions.
    original = read_json(HERE / "case_0001/identity_handoff.json")
    rows = [m for group in original["merged"]["groups"] for m in group["members"]]
    rows += [record["member"] for record in original["unresolved"]]
    assignments = [a for bridge in original["merged"]["group_bridges"] for a in bridge["assignment_evidence"]]
    inputs_before = deepcopy((rows, assignments))
    grouped = group_mentions(rows)
    merged = merge_assigned_qids(grouped["groups"], assignments)
    handoff = dict(merged=merged, unresolved=grouped["unresolved"])
    assert handoff == original and (rows, assignments) == inputs_before
    assert sum(len(g["members"]) for g in merged["groups"]) + len(grouped["unresolved"]) == 9
    pending = [b for b in merged["group_bridges"] if not b["assignment_evidence"]]
    assert len(pending) == 1 and pending[0]["qid"] is None
    pending_group = next(g for g in merged["groups"] if g["group_id"] == pending[0]["group_id"])
    assert [m["occurrence_id"] for m in pending_group["members"]] == ["o7", "o8"]
    assert grouped["unresolved"][0]["member"]["revision_id"] is None

    # Select only already supplied fixture identities and type roles.
    keys = {(item["qid"], role["entity_group"]) for item in merged["registry"] for role in item["roles"]}
    bridges = {b["group_id"]: b for b in merged["group_bridges"]}
    for group in merged["groups"]:
        if bridges[group["group_id"]]["qid"] is None:
            keys.update((m["synthetic_id"], group["key"]["entity_group"])
                        for m in group["members"] if m.get("synthetic_id"))
    source = fixture()
    assert keys == {("Q1", "LOC"), ("Q1", "ORG"), ("Q2", "event"), ("SYN_sample", "LOC")}
    source["entities"] = [row for row in source["entities"]
                          if (row["entity_id"], row["type"]) in keys or row["type"] == "DATE"]
    source["relations"][0]["time_precision"] = {"from": [9]}
    # Same independent reverse assertion and date as the existing consumer test.
    source["relations"].append(dict(source["relations"][0], observation_id="obs-back",
                                    subject_entity_id="Q2", object_entity_id="Q1",
                                    time_from="+1943-00-00T00:00:00Z"))
    source_before = deepcopy(source)
    graph, _ = build_graph(**source)
    producer_edges = deepcopy(graph["edges"])
    selected = select_native_views(graph["edges"])
    assert len(producer_edges) == 4 and len(selected) == 2
    assert [edge["id"] for edge in selected] == ["obs-1", "obs-back"]
    assert all(any(edge is existing for existing in graph["edges"]) for edge in selected)
    assert all(not edge.get("derived") and edge.get("source_edge_id") is None for edge in selected)
    assert graph["edges"] == producer_edges and source == source_before
    published = dict(graph, edges=selected)
    first_graph = read_json(HERE / "case_0001/graph.json")
    assert {k: v for k, v in published.items() if k != "edges"} == {k: v for k, v in first_graph.items() if k != "edges"}

    output = HERE / "case_0002"
    output.mkdir()  # Never overwrite a completed case.
    model = output / "model"
    for path in (BASE / "model").rglob("*"):
        if path.is_file():
            target = model / path.relative_to(BASE / "model")
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    (model / "relations.json.gz").write_bytes(gzip.compress(json.dumps(source["relations"]).encode(), mtime=0))
    manifest = read_json(model / "manifest.json")
    manifest["outputs"]["relations.json.gz"] = digest(model / "relations.json.gz")
    (model / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (output / "graph.json").write_text(json.dumps(published, indent=2), encoding="utf-8")
    (output / "identity_handoff.json").write_text(json.dumps(handoff, indent=2), encoding="utf-8")

    store = GraphStore.from_json(output / "graph.json", model_dir=model)
    assert set(store.nodes) == {"Q1::LOC", "Q1::ORG", "Q2::event", "SYN_sample"}
    assert store.nodes["SYN_sample"].wikidata_id is None
    assert [edge.id for edge in store.edges] == ["obs-1", "obs-back"]
    assert [(edge.source, edge.target) for edge in store.edges] == [("Q1", "Q2"), ("Q2", "Q1")]
    assert store.schema()["assertion_count"] == 2 and store.relation_catalog == published["relation_catalog"]
    assert len(store.model_edge_dates) == 2 and "Q2::event" in store.model_node_dates
    native_rows = {row["observation_id"]: row for row in source["relations"]}
    for edge in store.edges:
        date = store.model_edge_dates[id(edge)]["start_date"]
        assert date["time"] == native_rows[edge.id]["time_from"] and date["precision"] == 9
    _assert_geometry_join(store)
    assert [row["id"] for row in store.locations_of("Q2::event")] == ["Q1::LOC"]
    for relative, expected in manifest["outputs"].items():
        assert digest(model / relative) == expected
        if relative != "relations.json.gz":
            assert digest(model / relative) == digest(BASE / "model" / relative)
    assert digest(output / "identity_handoff.json") == digest(HERE / "case_0001/identity_handoff.json")
    assert protected == {path: digest(Path(path)) for path in protected}
    result = dict(status="PASS", checked_utc=datetime.now(timezone.utc).isoformat(), synthetic_cases=1,
                  case="both-native", mentions=9, pending_identity_members=2, unresolved_attribution=1,
                  producer_views=4, selected_views=2, native_assertions=2, redundant_inverses_removed=2,
                  model_date_views=2, native_years=[1942, 1943], graph_nodes=4, geometry_joins=2,
                  catalog="fixture relation-map-v2.1.2, wd:P1; real v2.1.1 catalog NOT exercised",
                  protected_sha256=protected, code_sha256=digest(Path(__file__)),
                  output_sha256={str(p.relative_to(output)): digest(p) for p in output.rglob("*") if p.is_file()},
                  backup_status="Unprotected", production_run=False)
    (HERE / "verification_case_0002.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("PASS: both-native identity integration; 4 producer views -> 2 native assertions; dates 1942/1943; exact geometry; 9 mentions retained; case_0001 unchanged")


if __name__ == "__main__":
    check()
