# First real retained unit — R2 grouping only

**PASS**, 2026-11-01 19:47:10 UTC. Page 48975579 / processing revision 1375061414: **136 original occurrences -> 69 groups**, zero unresolved attribution. Seven members use a different authoritative processing surface; all original words/types and provenance remain available. No identity/model inference, graph export or publication ran.

Verified parent-pinned INPUT seal SHA256 03cd6fd90d609815c431ea234d9c32f0c10e98287b60d515439f15305b5e4089 and retained Parquet SHA256 bef85196798d583939a98976954e479fe03ae6596c12c808f9a7fb74def41e73. All six seal-referenced artifact hashes match; source bytes match the unit manifest. Full INPUT readback PASS covers 1,301,119 retained occurrences / 5,747 units / 5,693 pages. This job consumes exactly one declared retained unit; it does not repeat that full processing run.

The unit's 136 expected original row indices map to exactly the existing deterministic occurrence IDs using the reused mention_id helper. Complete membership was checked through the existing source_membership_ready contract. The parquet filter selects this one wiki/page/processing revision across row-group boundaries. No first-N selection or ID reindexing.

The compatibility view sets word to the verified processing_surface/prepared_word and retains word_original. Processing offsets are checked against prepared_text. Every other input field stays identical. The original full source-member records are also saved unchanged. Row 71 uses China-Burma-India Theater while preserving original China. The separate adapter self-check verifies Houston uses USS Houston display rather than the audit-only USS Houston (CA-30).

RED adapter check failed on the initial pass-through stub; GREEN passed after implementing the explicit surface mapping. The real grouping then passed repeated deterministic execution, exact 136-ID membership, no loss/duplicates, unchanged input records and output JSON readback. A fresh read-only process rehashed outputs/code and reconstructed the same 69 groups from saved source members, checking all original fields and seven changed surfaces.

Code: run_first_real_unit.py. Outputs: real_unit_0001/groups.json, source_members.json and run_receipt.json. Shared components and INPUT files were not modified; all six INPUT artifact hashes were rechecked after grouping. The script refuses to overwrite the existing output directory.

Closure is DECLARED_FIRST_RUN_MAPPED_OCCURRENCES_ONLY_NOT_WHOLE_PAGE. The unit has 186 bound omitted input rows; they remain outside this run and in the sealed omission ledger. First-run readiness is not complete page/entity-inventory coverage. This operation is not counted as a canonical publication batch under G12.

Next dependency: same-unit eligible QID inventory and the existing G3/G5 exact/occurrence-eligibility contract before exact promotion, or separately assigned model-independent inventory evidence. No source acquisition, automatic identity assignment or residual-model execution was authorized by this grouping task. Backup: Unprotected.
