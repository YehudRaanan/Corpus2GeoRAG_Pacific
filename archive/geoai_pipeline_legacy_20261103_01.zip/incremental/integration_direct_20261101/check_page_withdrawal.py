"""Generated correction -> aggregation check; preserve a page until last support."""
import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from aggregate_occurrences import aggregate_units
from occurrence_decisions import HERE, ROOT, SCOPE_FIELDS, replace_unit


def check():
    paths = [p for p in HERE.rglob("*") if p.is_file()]
    paths += [ROOT / "source_custody/local_unit_contract.py"]
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    protected = {str(path): digest(path) for path in paths}
    fixtures = json.loads((HERE / "case_0004/units.json").read_text())
    handoffs = []
    sources = {10: b"abc", 11: b"abd"}
    # A and B support different original mentions on the same physical page.
    # Their one shared explicitly unmatched row still deduplicates across revisions.
    for unit, indices, name in zip(fixtures, ({0, 2, 4, 5}, {1, 3, 4, 6}), ("a", "b")):
        handoff = deepcopy(unit["versions"][-1])
        handoff.update(version=f"unit-{name}-page-v1", prior_version=None)
        handoff["manifest"].update(expected_row_indices=sorted(indices), policy_version="fixture-page-support-v1")
        for shard in handoff["shards"]:
            shard.update(row_indices=sorted(indices), policy_version="fixture-page-support-v1")
        handoff["occurrences"] = [m for m in handoff["occurrences"] if m["original_row_index"] in indices]
        member_ids = {m["occurrence_id"] for m in handoff["occurrences"]}
        handoff["decisions"] = [d for d in handoff["decisions"] if d["occurrence_id"] in member_ids]
        for decision in handoff["decisions"]:
            if decision["occurrence_id"] == "o5":
                decision["qid"] = "Q2"  # Unrelated accepted Event support survives both corrections.
        handoffs.append(handoff)
    first, second = handoffs
    state = {}
    for handoff in handoffs:
        assert replace_unit(state, handoff, sources[handoff["manifest"]["support_revision_id"]]) is True
    initial = aggregate_units(state)
    assert initial["identity_counts"] == [dict(qid="Q1", mention_count=3, page_count=1),
                                          dict(qid="Q2", mention_count=1, page_count=1)]
    assert initial["unique_occurrences"] == 7 and initial["support_records"] == 8
    assert initial["unique_physical_pages"] == 1
    original_members = {key: deepcopy(versions[-1]["occurrences"]) for key, versions in state.items()}

    first_correction = deepcopy(first)
    first_correction.update(version="unit-a-page-v2", prior_version=first["version"])
    for decision in first_correction["decisions"]:
        if decision["qid"] == "Q1":
            decision["qid"] = None
    assert replace_unit(state, first_correction, sources[10]) is True
    after_first = aggregate_units(state)
    assert after_first["identity_counts"] == [dict(qid="Q1", mention_count=1, page_count=1),
                                             dict(qid="Q2", mention_count=1, page_count=1)], "Other unit still supports Q1 on this page"
    assert after_first["typed_counts"] == [dict(qid="Q1", entity_group="LOC", mention_count=1, page_count=1),
                                          dict(qid="Q2", entity_group="event", mention_count=1, page_count=1)]
    assert replace_unit(state, deepcopy(first_correction), sources[10]) is False
    assert aggregate_units(state) == after_first

    second_correction = deepcopy(second)
    second_correction.update(version="unit-b-page-v2", prior_version=second["version"])
    for decision in second_correction["decisions"]:
        if decision["qid"] == "Q1":
            decision["qid"] = None
    assert replace_unit(state, second_correction, sources[11]) is True
    final = aggregate_units(state)
    assert final["identity_counts"] == [dict(qid="Q2", mention_count=1, page_count=1)], "Last Q1 support must remove its page association"
    assert final["typed_counts"] == [dict(qid="Q2", entity_group="event", mention_count=1, page_count=1)]
    assert final["unique_occurrences"] == 7 and final["support_records"] == 8 and final["unique_physical_pages"] == 1
    assert sum(row["decision_values"] == [None] for row in final["occurrences"]) == 4
    assert sum(bool(row["pending_supports"]) for row in final["occurrences"]) == 2
    assert not any(row["identity_conflict"] for row in final["occurrences"])
    assert replace_unit(state, deepcopy(second_correction), sources[11]) is False
    assert aggregate_units(state) == final
    for key, versions in state.items():
        assert len(versions) == 2
        assert all(version["occurrences"] == original_members[key] for version in versions)
    restarted = {}
    for handoff in [first, first, second, second, first_correction, first_correction, second_correction, second_correction]:
        replace_unit(restarted, handoff, sources[handoff["manifest"]["support_revision_id"]])
    assert restarted == state and aggregate_units(restarted) == final
    assert protected == {str(path): digest(path) for path in paths}
    output = HERE / "case_0005"
    output.mkdir()
    transitions = [dict(stage="initial", aggregate=initial), dict(stage="first_unit_withdrawn", aggregate=after_first),
                   dict(stage="last_support_withdrawn", aggregate=final)]
    (output / "transitions.json").write_text(json.dumps(transitions, indent=2), encoding="utf-8")
    units = [dict(scope=dict(zip(SCOPE_FIELDS, key)), versions=versions) for key, versions in state.items()]
    (output / "units.json").write_text(json.dumps(units, indent=2), encoding="utf-8")
    for revision, data in sources.items():
        (output / f"source_revision_{revision}.bin").write_bytes(data)
    verification = dict(status="PASS", checked_utc=datetime.now(timezone.utc).isoformat(), closed_units=2,
                        retained_occurrences=7, revision_support_records=8, preserved_history_versions=4,
                        q1_mention_counts=[3, 1, 0], q1_page_counts=[1, 1, 0], q2_page_counts=[1, 1, 1],
                        pending_occurrences=2, final_explicit_unmatched=4, replay_updates=8,
                        consumer_export=False, protected_sha256=protected, code_sha256=digest(Path(__file__)),
                        output_sha256={str(p.relative_to(output)): digest(p) for p in output.iterdir()}, backup_status="Unprotected")
    (HERE / "verification_case_0005.json").write_text(json.dumps(verification, indent=2), encoding="utf-8")
    print("PASS: replacement -> aggregation; Q1 mentions 3->1->0, pages 1->1->0; Q2 page preserved; 7 originals retained; 4 history versions; replay stable")


if __name__ == "__main__":
    check()
