# Replacement through page aggregation — 2026-11-01

**PASS**, 18:03:57 UTC. `check_page_withdrawal.py` composes the unchanged `replace_unit` and `aggregate_units`. Only new case_0005 outputs in the owned integration directory were written.

Two generated closed revision units support different original mentions on one physical page; one shared explicitly unmatched row also tests origin deduplication. Their seven original row identities retain the existing synthetic input hash/indices. Finite membership sets and policy labels are generated fixture scope, not a real-input policy.

| Fixture stage | Q1 mentions | Q1 pages | Q2 pages |
|---|---:|---:|---:|
| Initial A+B | 3 | 1 | 1 |
| A withdraws its Q1 decisions | 1 | 1 | 1 |
| B withdraws last Q1 decision | 0 | 0 | 1 |

B's LOC occurrence keeps Q1's page after A's correction removes its LOC/ORG supports. After B's correction, only Q1's association disappears; the physical page and unrelated Q2 association remain.

All seven original members/eight revision supports remain. Final state has one accepted Q2 Event occurrence, four explicitly unmatched originals and two pending originals. Existing SYN/provenance remains intact; four complete handoff versions remain in history. Eight-update replay, including duplicates, reconstructs the same state and aggregate. No conflict arbitration, co-occurrence weight, consumer export or production persistence was added.

## Verification

Existing bridge Python, bytecode disabled:

```powershell
& 'D:\Projects\GeoAI-incremental-dev-20261101\contract_fixtures\.venv-bridge\Scripts\python.exe' -B 'D:\Projects\GeoAI-incremental-dev-20261101\integration_direct_20261101\check_page_withdrawal.py'
```

Exit 0: `PASS: replacement -> aggregation; Q1 mentions 3->1->0, pages 1->1->0; Q2 page preserved; 7 originals retained; 4 history versions; replay stable`.

Fresh-process readback verified 42 protected hashes/four output hashes, revalidated saved units against source bytes, reconstructed all transitions and matched all three saved aggregates. Duplicate corrections were no-ops. Exit 0: `PASS_FRESH_PROCESS_READBACK`.

Evidence: verification_case_0005.json, case_0005/transitions.json, units.json and two source-byte fixtures. Earlier cases/shared files remain unchanged. No catalog or GPU activity is exercised or asserted.

## Documentation and next interface

Minimal append-only plan edits were presented before modification in PLAN_STATUS_EDITS.md. The parent assigned this session sole status/evidence ownership of the two plans. Both append operations completed at 18:07:22 UTC. A fresh process verified that every prior byte is unchanged, each new status block appears once and the recorded suffix/file hashes match. Evidence: plan_status_update_receipt.json and the exact prior-byte copies in plan_status_before/.

The separate E2 session completed ten bounded initial-version durability checks. Its report and code were read only. The parent reports its 18 output/41 protected hashes independently verified. This session additionally rehashed the E2 code and all 18 recorded outputs; all matched. E2 has stopped writing. It does not establish correction-history persistence or power-loss durability.

Next ready read-only interface check: recover the existing E2 initial-version seals with their independently pinned hashes, replay those exact handoffs into the reducer and compare to case_0004; then inspect how a successor version would bind to that prior receipt. The current E2 receipt_for validates a handoff with replace_unit against an empty state, so it supports initial prior_version=None only. Accepting a correction seal requires a separately scoped prior-history-aware contract change; do not silently claim durable v2 support.

The downstream occurrence-aware Entity/mention bridge also remains: the group-level merger cannot represent heterogeneous homonym decisions. Real-data adapters, input barrier, relation/weight export and publication remain separate existing tasks/gates.

No shared-code bug or operational blocker for this completed test. No pending/uncertain action. Backup: **Unprotected**.
