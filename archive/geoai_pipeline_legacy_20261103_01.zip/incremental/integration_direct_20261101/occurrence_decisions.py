"""Generated-only decision replacement for one declared closed source unit."""
import hashlib
import json
import re
import sys
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "source_custody"))
from local_unit_contract import source_membership_ready

# The existing custody manifest's scope; decision version is a separate pointer.
SCOPE_FIELDS = ("input_sha256", "wiki_site", "page_id", "support_revision_id", "source_sha256", "policy_version")


def replace_unit(state, handoff, source_bytes):
    """Validate completely, then append a version; only the latest contributes."""
    manifest = handoff["manifest"]
    if not source_membership_ready(manifest, handoff["shards"], source_bytes):
        raise ValueError("Source unit is not closed")
    key = tuple(manifest[field] for field in SCOPE_FIELDS)
    if any(value in (None, "") for value in key):
        raise ValueError("Missing source unit scope")
    rows = handoff["occurrences"]
    members = {}
    indices = []
    for member in rows:
        if (member["wiki_site"], member["page_id"], member["revision_id"]) != (
                manifest["wiki_site"], manifest["page_id"], manifest["support_revision_id"]):
            raise ValueError("Occurrence page/revision scope differs")
        occurrence = member["occurrence_id"]
        index = member["original_row_index"]
        if not isinstance(occurrence, str) or not occurrence or occurrence in members:
            raise ValueError("Duplicate or invalid occurrence identity")
        if type(index) is not int or index < 0:
            raise ValueError("Invalid occurrence row index")
        if not isinstance(member["entity_group"], str) or not member["entity_group"]:
            raise ValueError("Missing supplied occurrence type")
        members[occurrence] = member
        indices.append(index)
    if len(indices) != len(set(indices)) or set(indices) != set(manifest["expected_row_indices"]):
        raise ValueError("Occurrence membership differs from closed manifest")
    decisions = {}
    for decision in handoff["decisions"]:
        occurrence = decision["occurrence_id"]
        if occurrence not in members or occurrence in decisions:
            raise ValueError("Unknown or repeated occurrence decision")
        qid = decision["qid"]
        if qid is not None and (not isinstance(qid, str) or not re.fullmatch(r"Q[1-9][0-9]*", qid)):
            raise ValueError("Accepted decision must contain one exact QID or None")
        if "evidence" not in decision:
            raise ValueError("Occurrence decision lacks evidence")
        decisions[occurrence] = decision
    version = handoff["version"]
    if not isinstance(version, str) or not version:
        raise ValueError("Missing supplied decision version")
    history = state.get(key, [])
    if history:
        current = history[-1]
        if version == current["version"]:
            if handoff != current:
                raise ValueError("Existing version has different content")
            return False  # An exact replay never contributes twice.
        if any(old["version"] == version for old in history):
            raise ValueError("Cannot restore a stale decision version")
        if manifest != current["manifest"] or rows != current["occurrences"]:
            raise ValueError("Replacement must preserve the same closed source scope and members")
    expected_prior = history[-1]["version"] if history else None
    if handoff["prior_version"] != expected_prior:
        raise ValueError("Declared prior version is not the active version")
    replacement = deepcopy(handoff)  # Complete validation precedes the only state mutation.
    state[key] = [*history, replacement]
    return True


def active_occurrences(state):
    """Retain complete members and distinguish no decision from explicit None."""
    # ponytail: rebuild the tiny active view; add an incremental index only after measurement.
    active = []
    for key, history in state.items():
        current = history[-1]
        decisions = {d["occurrence_id"]: d for d in current["decisions"]}
        active.extend(dict(unit_scope=dict(zip(SCOPE_FIELDS, key)), decision_version=current["version"],
                           member=deepcopy(member), decision=deepcopy(decisions.get(member["occurrence_id"])))
                      for member in current["occurrences"])
    return active


def self_check():
    protected_paths = [p for p in HERE.rglob("*") if p.is_file()]
    protected_paths += [ROOT / "source_custody/local_unit_contract.py"]
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    before = {str(path): digest(path) for path in protected_paths}
    old = json.loads((HERE / "case_0001/identity_handoff.json").read_text())
    rows = [deepcopy(m) for g in old["merged"]["groups"] for m in g["members"] if m["page_id"] == 1]
    for index, row in enumerate(rows):
        row["original_row_index"] = index  # Generated dataset indices only.
    source_bytes = b"abc"
    scope = dict(input_sha256=hashlib.sha256(json.dumps(rows, sort_keys=True).encode()).hexdigest(),
                 wiki_site="enwiki", page_id=1, support_revision_id=10,
                 source_sha256=hashlib.sha256(source_bytes).hexdigest(), policy_version="fixture-v1")
    manifest = dict(scope, expected_row_indices=list(range(7)))
    shard = dict(scope, row_indices=list(range(7)))
    decisions = [dict(occurrence_id=oid, qid=qid, evidence={"source": "generated accepted decision"})
                 for oid, qid in [("o1", "Q1"), ("o2", "Q2"), ("o4", "Q1"), ("o5", "Q2"), ("o6", None)]]
    v1 = dict(manifest=manifest, shards=[shard], occurrences=rows, decisions=decisions,
              version="decision-v1", prior_version=None)
    original = deepcopy(v1)
    state = {}
    assert replace_unit(state, v1, source_bytes) is True, "Closed unit must install its occurrence decisions"

    def counts():
        return Counter((r["decision"]["qid"], r["member"]["entity_group"])
                       for r in active_occurrences(state) if r["decision"] and r["decision"]["qid"] is not None)

    # Same raw-name group may contain distinct accepted occurrence identities.
    assert counts() == {("Q1", "LOC"): 1, ("Q2", "LOC"): 1, ("Q1", "ORG"): 1, ("Q2", "event"): 1}
    first = deepcopy(state)
    assert replace_unit(state, deepcopy(v1), source_bytes) is False and state == first
    v2 = deepcopy(v1)
    v2.update(version="decision-v2", prior_version="decision-v1")
    for decision in v2["decisions"]:
        if decision["occurrence_id"] == "o2":
            decision["qid"] = "Q1"
        if decision["occurrence_id"] in {"o4", "o5"}:
            decision["qid"] = None
    assert replace_unit(state, v2, source_bytes) is True
    assert counts() == {("Q1", "LOC"): 2}, "Old Q2 and ORG/event supports must be withdrawn"
    active = active_occurrences(state)
    assert len(active) == 7 and [r["member"] for r in active] == rows
    assert [r["member"]["occurrence_id"] for r in active if r["decision"] is None] == ["o7", "o8"]
    assert [r["member"]["occurrence_id"] for r in active if r["decision"] and r["decision"]["qid"] is None] == ["o4", "o5", "o6"]
    assert next(r for r in active if r["member"]["occurrence_id"] == "o6")["member"]["synthetic_id"] == "SYN_sample"
    versions = next(iter(state.values()))
    assert versions == [v1, v2] and len(state) == 1 and v1 == original
    stable = deepcopy(state)
    assert replace_unit(state, deepcopy(v2), source_bytes) is False and state == stable

    def reject(handoff, message):
        try:
            replace_unit(state, handoff, source_bytes)
        except ValueError as error:
            assert message in str(error), str(error)
        else:
            raise AssertionError("Invalid handoff was accepted: " + message)
        assert state == stable, "Rejected update must not alter active state or history"

    reject(v1, "stale")
    collision = deepcopy(v2)
    collision["decisions"][0]["qid"] = "Q9"
    reject(collision, "version")
    next_update = deepcopy(v2)
    next_update.update(version="decision-v3", prior_version="decision-v1")
    reject(next_update, "prior")
    next_update["prior_version"] = "decision-v2"
    incomplete = deepcopy(next_update)
    incomplete["shards"][0]["row_indices"] = [0]
    reject(incomplete, "closed")
    conflict = deepcopy(next_update)
    conflict["decisions"].append(dict(conflict["decisions"][0], qid="Q9"))
    reject(conflict, "decision")
    foreign = deepcopy(next_update)
    foreign["occurrences"][0]["revision_id"] = 11
    reject(foreign, "scope")
    # Replaying the same handoffs reconstructs the same active state and history.
    restarted = {}
    for update in [v1, v1, v2, v2]:
        replace_unit(restarted, update, source_bytes)
    assert restarted == state and active_occurrences(restarted) == active
    assert before == {str(path): digest(path) for path in protected_paths}
    output = HERE / "case_0003"
    output.mkdir()
    snapshot = [dict(scope=dict(zip(SCOPE_FIELDS, key)), versions=values) for key, values in state.items()]
    (output / "state.json").write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
    (output / "active_occurrences.json").write_text(json.dumps(active, indent=2), encoding="utf-8")
    (output / "source_fixture.bin").write_bytes(source_bytes)
    # Generated readback only; no atomic checkpoint or crash durability claim.
    restored = {tuple(unit["scope"][field] for field in SCOPE_FIELDS): unit["versions"]
                for unit in json.loads((output / "state.json").read_text())}
    assert restored == state and replace_unit(restored, v2, source_bytes) is False
    result = dict(status="PASS", checked_utc=datetime.now(timezone.utc).isoformat(), scope="one synthetic closed source unit",
                  retained_occurrences=7, versions=2, active_units=1, accepted_occurrences=2,
                  explicit_unmatched=3, pending_without_decision=2, rejected_invalid_handoffs=6,
                  replay_updates=4, counted_active_occurrences=7, consumer_export=False,
                  protected_sha256=before, code_sha256=digest(Path(__file__)),
                  output_sha256={str(p.relative_to(output)): digest(p) for p in output.iterdir()}, backup_status="Unprotected")
    (HERE / "verification_case_0003.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("PASS: closed-unit decision v1 -> v2; 7 members retained; old supports withdrawn; 3 explicit unmatched + 2 pending; replay counted once; 6 invalid handoffs rejected")


if __name__ == "__main__":
    self_check()
