"""Generated-only aggregation; no winner for conflicting occurrence decisions."""
import hashlib
import json
from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

from occurrence_decisions import HERE, ROOT, SCOPE_FIELDS, active_occurrences, replace_unit


def aggregate_units(state):
    """Deduplicate original rows; keep every revision's evidence separately."""
    # ponytail: rebuild this tiny view; use an index only after measured scale requires it.
    groups = defaultdict(list)
    all_pages = set()
    support_records = active_occurrences(state)
    for support in support_records:
        scope, member = support["unit_scope"], support["member"]
        input_hash, row_index = scope.get("input_sha256"), member.get("original_row_index")
        if not isinstance(input_hash, str) or not input_hash or type(row_index) is not int or row_index < 0:
            raise ValueError("Stable original occurrence identity requires input_sha256 and original_row_index")
        groups[(input_hash, row_index)].append(support)
        all_pages.add((scope["wiki_site"], scope["page_id"]))
    occurrences = []
    typed_mentions, typed_pages = defaultdict(set), defaultdict(set)
    identity_mentions, identity_pages = defaultdict(set), defaultdict(set)
    for origin, supports in sorted(groups.items()):
        supports.sort(key=lambda row: json.dumps(row["unit_scope"], sort_keys=True))
        values = {row["decision"]["qid"] for row in supports if row["decision"] is not None}
        pending = sum(row["decision"] is None for row in supports)
        pages = {(row["unit_scope"]["wiki_site"], row["unit_scope"]["page_id"]) for row in supports}
        kinds = {row["member"]["entity_group"] for row in supports}
        reasons = []
        if len(values) > 1:
            reasons.append("identity_conflict")
        if pending:
            reasons.append("pending_decision")
        if None in values:
            reasons.append("explicit_unmatched")
        if len(pages) != 1 or len(kinds) != 1:
            reasons.append("page_or_type_conflict")
        occurrences.append(dict(original_identity=dict(input_sha256=origin[0], original_row_index=origin[1]),
                                supports=supports, decision_values=sorted(values, key=lambda value: value or ""),
                                identity_conflict=len(values) > 1, pending_supports=pending,
                                not_counted_reasons=reasons))
        # Partial counts contain only fully decided, uncontested observed supports.
        # Conflicts stay as evidence above; this function never arbitrates them.
        if not reasons:
            qid, kind = next(iter(values)), next(iter(kinds))
            typed_mentions[(qid, kind)].add(origin)
            typed_pages[(qid, kind)].update(pages)
            identity_mentions[qid].add(origin)
            identity_pages[qid].update(pages)
    return dict(unique_occurrences=len(groups), support_records=len(support_records), unique_physical_pages=len(all_pages),
                occurrences=occurrences,
                typed_counts=[dict(qid=qid, entity_group=kind, mention_count=len(mentions), page_count=len(typed_pages[(qid, kind)]))
                              for (qid, kind), mentions in sorted(typed_mentions.items())],
                identity_counts=[dict(qid=qid, mention_count=len(mentions), page_count=len(identity_pages[qid]))
                                 for qid, mentions in sorted(identity_mentions.items())],
                counts_scope="Partial uncontested fully decided observed occurrences; no conflict resolution or consumer export")


def self_check():
    paths = [p for p in HERE.rglob("*") if p.is_file()]
    paths += [ROOT / "source_custody/local_unit_contract.py"]
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    protected = {str(path): digest(path) for path in paths}
    saved = json.loads((HERE / "case_0003/state.json").read_text())
    first = deepcopy(saved[0]["versions"][0])
    first.update(version="unit-a-decisions-v1", prior_version=None)
    for decision in first["decisions"]:
        if decision["occurrence_id"] == "o2":
            decision["qid"] = "Q1"
    second = deepcopy(first)
    second["version"] = "unit-b-decisions-v1"
    second["manifest"].update(support_revision_id=11, source_sha256=hashlib.sha256(b"abd").hexdigest())
    for shard in second["shards"]:
        shard.update(support_revision_id=11, source_sha256=second["manifest"]["source_sha256"])
    for member in second["occurrences"]:
        member["revision_id"] = 11  # Processing support only; original source_pointer stays intact.
    for decision in second["decisions"]:
        if decision["occurrence_id"] == "o5":
            decision["qid"] = "Q1"  # Explicit disagreement with the first unit's Q2.
    state = {}
    assert replace_unit(state, first, b"abc") is True
    assert replace_unit(state, second, b"abd") is True
    before = deepcopy(state)
    result = aggregate_units(state)
    assert result.get("unique_occurrences") == 7, "Repeated processing revisions must not duplicate original rows"
    assert result["support_records"] == 14 and result["unique_physical_pages"] == 1
    assert result["identity_counts"] == [dict(qid="Q1", mention_count=3, page_count=1)]
    assert result["typed_counts"] == [dict(qid="Q1", entity_group="LOC", mention_count=2, page_count=1),
                                     dict(qid="Q1", entity_group="ORG", mention_count=1, page_count=1)]
    conflict = [row for row in result["occurrences"] if row["identity_conflict"]]
    assert len(conflict) == 1 and conflict[0]["decision_values"] == ["Q1", "Q2"]
    assert {support["member"]["occurrence_id"] for support in conflict[0]["supports"]} == {"o5"}
    assert "identity_conflict" in conflict[0]["not_counted_reasons"]
    assert "resolved_qid" not in conflict[0], "Conflicting decisions have no invented winner"
    assert sum(row["decision_values"] == [None] for row in result["occurrences"]) == 1
    assert sum(row["pending_supports"] == 2 for row in result["occurrences"]) == 2
    assert sum(len(row["supports"]) for row in result["occurrences"]) == 14
    for row in result["occurrences"]:
        assert {support["unit_scope"]["support_revision_id"] for support in row["supports"]} == {10, 11}
        assert len(row["supports"]) == 2
    assert state == before
    # An exact replay and reversed unit arrival order must preserve the aggregate.
    assert replace_unit(state, deepcopy(second), b"abd") is False
    assert aggregate_units(state) == result
    reversed_state = {}
    replace_unit(reversed_state, second, b"abd")
    replace_unit(reversed_state, first, b"abc")
    assert aggregate_units(reversed_state) == result
    # Stable origin is required; identical names are never an identity fallback.
    missing_origin = deepcopy(state)
    del next(iter(missing_origin.values()))[-1]["occurrences"][0]["original_row_index"]
    try:
        aggregate_units(missing_origin)
    except ValueError as error:
        assert "original occurrence" in str(error)
    else:
        raise AssertionError("Missing original provenance must not fall back to name")
    assert state == before
    assert protected == {str(path): digest(path) for path in paths}
    output = HERE / "case_0004"
    output.mkdir()
    (output / "aggregation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    units = [dict(scope=dict(zip(SCOPE_FIELDS, key)), versions=versions) for key, versions in state.items()]
    (output / "units.json").write_text(json.dumps(units, indent=2), encoding="utf-8")
    (output / "source_revision_10.bin").write_bytes(b"abc")
    (output / "source_revision_11.bin").write_bytes(b"abd")
    verification = dict(status="PASS", checked_utc=datetime.now(timezone.utc).isoformat(),
                        closed_units=2, processing_revisions=[10, 11], support_records=14,
                        unique_occurrences=7, physical_pages=1, identity_conflicts=1,
                        uncontested_accepted_occurrences=3, explicit_unmatched_occurrences=1,
                        pending_occurrences=2, counts_are_partial=True, consumer_export=False,
                        stable_origin_fields=["input_sha256", "original_row_index"],
                        protected_sha256=protected, code_sha256=digest(Path(__file__)),
                        output_sha256={str(p.relative_to(output)): digest(p) for p in output.iterdir()}, backup_status="Unprotected")
    (HERE / "verification_case_0004.json").write_text(json.dumps(verification, indent=2), encoding="utf-8")
    print("PASS: 2 closed revision units; 14 supports -> 7 original occurrences; Q1 mentions=3/pages=1; LOC mentions=2/pages=1; 1 conflict retained without winner; replay/order stable")


if __name__ == "__main__":
    self_check()
