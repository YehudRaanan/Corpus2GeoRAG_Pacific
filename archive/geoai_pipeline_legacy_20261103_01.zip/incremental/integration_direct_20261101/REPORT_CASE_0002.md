# Both-native identity integration — 2026-11-01

**PASS**, 17:43:46 UTC. One generated case replays the first case's exact mention records and accepted assignments through `group_mentions -> merge_assigned_qids -> existing fixture Entity rows -> build_graph -> select_native_views -> GraphStore`.

- Four producer views become exactly two unchanged original native assertions, `obs-1` (Q1 -> Q2) and `obs-back` (Q2 -> Q1). Both redundant generated inverse views are removed.
- Consumer loads four typed/SYN nodes and two native assertions. Assertion dates remain independently 1942 and 1943, both precision 9. Both model-date joins and the Event record attach.
- Existing polygon/point geometry joins and Event-to-LOC traversal pass. Existing geometry/support bytes remain identical; only this new case's Relations model and its manifest hash change to include the second native assertion.
- All nine mentions remain in the private handoff, which is byte-identical to case_0001: two identity-pending members remain without an invented QID/SYN, and one attribution-pending member retains null revision.
- All 38 protected code/artifact hashes and ten new output hashes pass verification. The first script, report, verification and case outputs are untouched.

Catalog: **synthetic fixture relation-map-v2.1.2, wd:P1**. The separate real v2.1.1 catalog was not exercised. No production inputs, shared code changes, new identity policy, source acquisition, cloud operations, Git or publication.

## Commands actually run

Existing bridge Python, `-B`, with process-only OMP/OPENBLAS/MKL thread limits of one:

```powershell
& 'D:\Projects\GeoAI-incremental-dev-20261101\contract_fixtures\.venv-bridge\Scripts\python.exe' -B 'D:\Projects\GeoAI-incremental-dev-20261101\integration_direct_20261101\check_both_native.py'
```

Exit 0: `PASS: both-native identity integration; 4 producer views -> 2 native assertions; dates 1942/1943; exact geometry; 9 mentions retained; case_0001 unchanged`.

A fresh read-only Python process then reloaded case_0002, verified all protected/output/model-manifest hashes, rechecked geometry/traversal, both native assertions/dates and equality with case_0001's handoff. Exit 0: `PASS_FRESH_PROCESS_READBACK`. The first readback command used the parent working directory and could not import the sibling check module; rerunning from the integration directory resolved that command-environment issue without any file change.

Evidence: `verification_case_0002.json`. Versioned consumer/model/handoff outputs: `case_0002/`. Both case scripts intentionally refuse to overwrite their existing output directory.

## Next real dependency

The next production integration dependency is a sealed, occurrence-bound accepted-decision handoff identifying decision version and prior version. The current merger receives generated current-frontier group assignments; it does not implement correction/retraction, stale-version rejection, last-support withdrawal or physical-page count reduction. Those are plan stage 4 work, not established by either passing fixture. A tiny generated correction/retraction increment can be developed separately if assigned; real page batches still require the global input-preparation barrier and accepted upstream policies. Neither co-occurrence fallback nor snapshot publication/cadence is tested here.

No shared-component bug found; no denied, pending or uncertain action remains in this increment. Backup: **Unprotected**. Awaiting the parent's next scoped assignment.
