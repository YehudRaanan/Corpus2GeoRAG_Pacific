"""Exactly one sealed real unit: authoritative prepared-surface grouping only."""
import gzip
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
INPUT = ROOT / "review_treatments/first_run_input_20261101_v1"
sys.path[:0] = [str(ROOT / "grouping"), str(ROOT / "source_custody"), r"D:\Projects\GeoAI-luke-pilot-20261028"]
from group_mentions import group_mentions
from local_unit_contract import source_membership_ready
from GG_Data.pipeline.post_qid_entities import mention_id


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def processing_record(row):
    """Expose the declared prepared surface to the existing word-key helper."""
    surface = row["processing_surface"]
    assert row["prepared_word"] == surface
    start, end = row["processing_surface_start"], row["processing_surface_end"]
    assert 0 <= start < end <= len(row["prepared_text"])
    assert row["prepared_text"][start:end] == surface
    return dict(row, word_original=row["word"], word=surface)


def check_adapter():
    for original, repaired_audit, surface in [("China", "China-Burma-India Theater", "China-Burma-India Theater"),
                                              ("Houston", "USS Houston (CA-30)", "USS Houston")]:
        row = dict(word=original, entity_group="LOC", ingestion_word_repaired=repaired_audit,
                   prepared_word=surface, processing_surface=surface, prepared_text=surface,
                   processing_surface_start=0, processing_surface_end=len(surface))
        before = deepcopy(row)
        view = processing_record(row)
        assert view["word"] == surface, "Grouping must consume authoritative prepared display"
        assert view["word_original"] == original and row == before
        assert view["entity_group"] == row["entity_group"]


def run():
    import pyarrow.parquet as pq

    check_adapter()
    assert digest(INPUT / "seal.json") == "03cd6fd90d609815c431ea234d9c32f0c10e98287b60d515439f15305b5e4089"
    seal = json.loads((INPUT / "seal.json").read_text())
    assert seal["source_input_ready"] and seal["seal_status"] == "SEALED_DECLARED_RETAINED_SCOPE"
    artifact_fields = {"readback_receipt.json": "readback_receipt_sha256", "writer_receipt.json": "writer_receipt_sha256",
                       "retained_mentions.parquet": "retained_parquet_sha256", "omitted_mentions.parquet": "omission_ledger_sha256",
                       "sealed_units.jsonl.gz": "sealed_units_sha256", "first_unit.json": "first_unit_sha256"}
    hashes = {str(INPUT / name): digest(INPUT / name) for name in artifact_fields}
    for name, field in artifact_fields.items():
        assert hashes[str(INPUT / name)] == seal[field], name
    assert seal["retained_parquet_sha256"] == "bef85196798d583939a98976954e479fe03ae6596c12c808f9a7fb74def41e73"
    readback = json.loads((INPUT / "readback_receipt.json").read_text())
    assert readback["status"] == "PASS" and readback["full_independent_readback"]
    assert readback["counts"]["retained"] == seal["retained_occurrences"] == 1301119
    assert readback["all_prepared_surface_spans_and_typed_provenance_checked"]
    assert readback["all_unit_memberships_and_source_bytes_verified"]
    first = json.loads((INPUT / "first_unit.json").read_text())
    assert (first["page_id"], first["processing_revision_id"], first["retained_count"]) == (48975579, 1375061414, 136)
    with gzip.open(INPUT / "sealed_units.jsonl.gz", "rt", encoding="utf-8") as stream:
        unit = None
        for line in stream:
            candidate = json.loads(line)
            if (candidate["wiki_site"], candidate["page_id"], candidate["processing_revision_id"]) == (
                    first["wiki_site"], first["page_id"], first["processing_revision_id"]):
                unit = candidate
                break
    assert unit is not None
    assert all(unit[key] == value for key, value in first.items())
    assert unit["membership_complete"] and unit["source_bytes_verified"]
    source_bytes = Path(unit["source_path"]).read_bytes()
    assert hashlib.sha256(source_bytes).hexdigest() == unit["source_sha256"]
    expected_rows = set(unit["expected_row_indices"])
    assert len(expected_rows) == len(unit["expected_row_indices"]) == 136
    # Read exactly this page/revision; no grouping or inference for any other unit.
    rows = pq.read_table(INPUT / "retained_mentions.parquet", filters=[("wiki_site", "=", unit["wiki_site"]),
                         ("page_id", "=", unit["page_id"]), ("processing_revision_id", "=", unit["processing_revision_id"])],
                         use_threads=False).to_pylist()
    rows.sort(key=lambda row: row["source_row_index"])
    assert len(rows) == 136 and {r["source_row_index"] for r in rows} == expected_rows
    expected_ids = {mention_id(unit["input_sha256"], index) for index in expected_rows}
    assert len({r["occurrence_id"] for r in rows}) == 136 and {r["occurrence_id"] for r in rows} == expected_ids
    shard = {key: unit[key] for key in ("input_sha256", "wiki_site", "page_id", "support_revision_id", "source_sha256", "policy_version")}
    shard["row_indices"] = [r["source_row_index"] for r in rows]
    assert source_membership_ready(unit, [shard], source_bytes)
    original = deepcopy(rows)
    views = []
    for row in rows:
        assert row["input_sha256"] == unit["input_sha256"] and row["first_run_scope_member"]
        assert row["revision_id"] == row["processing_revision_id"] == unit["processing_revision_id"]
        assert row["processing_revision_sha256"] == unit["source_sha256"]
        views.append(processing_record(row))
    grouped = group_mentions(views)
    assert grouped == group_mentions(deepcopy(views)), "Grouping must be deterministic"
    assert rows == original and not grouped["unresolved"]
    members = [member for group in grouped["groups"] for member in group["members"]]
    assert len(members) == 136 and len({m["occurrence_id"] for m in members}) == 136
    assert {m["occurrence_id"] for m in members} == expected_ids
    assert {m["occurrence_id"]: m for m in members} == {m["occurrence_id"]: m for m in views}
    for group in grouped["groups"]:
        assert all(member["word"] == group["key"]["word"] and member["entity_group"] == group["key"]["entity_group"]
                   for member in group["members"])
    examples = [dict(source_row_index=r["source_row_index"], original_word=r["word"],
                     processing_surface=r["processing_surface"], ingestion_word_repaired=r["ingestion_word_repaired"])
                for r in rows if r["word"] != r["processing_surface"]]
    assert next(r for r in examples if r["source_row_index"] == 71)["processing_surface"] == "China-Burma-India Theater"
    assert hashes == {path: digest(Path(path)) for path in hashes}
    output = HERE / "real_unit_0001"
    output.mkdir()
    (output / "groups.json").write_text(json.dumps(grouped, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "source_members.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    assert json.loads((output / "groups.json").read_text(encoding="utf-8")) == grouped
    assert json.loads((output / "source_members.json").read_text(encoding="utf-8")) == original
    receipt = dict(status="PASS_ONE_REAL_R2_GROUPING_UNIT", checked_utc=datetime.now(timezone.utc).isoformat(),
                   input_seal_sha256=digest(INPUT / "seal.json"), artifact_sha256=hashes,
                   code_sha256=digest(Path(__file__)), grouping_code_sha256=digest(ROOT / "grouping/group_mentions.py"),
                   page_id=unit["page_id"], processing_revision_id=unit["processing_revision_id"],
                   retained_members=136, groups=len(grouped["groups"]), unresolved_attribution=0,
                   expected_occurrence_ids=sorted(expected_ids), all_members_retained_once=True, deterministic=True,
                   changed_surface_members=len(examples), changed_surface_examples=examples,
                   closure_scope=unit["coverage_scope"], bound_omitted_rows=unit["omitted_bound_input_rows"],
                   identity_inference=False, model_inference=False, publication=False, canonical_publication_batch_counted=False,
                   output_sha256={p.name: digest(p) for p in output.iterdir()}, backup_status="Unprotected")
    (output / "run_receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({key: receipt[key] for key in ("status", "checked_utc", "page_id", "processing_revision_id",
          "retained_members", "groups", "unresolved_attribution", "changed_surface_members", "bound_omitted_rows")}, ensure_ascii=False))


if __name__ == "__main__":
    if "--self-check" in sys.argv:
        check_adapter()
        print("PASS: prepared-surface adapter retains raw word/type; Houston uses display, not audited target")
    else:
        run()
