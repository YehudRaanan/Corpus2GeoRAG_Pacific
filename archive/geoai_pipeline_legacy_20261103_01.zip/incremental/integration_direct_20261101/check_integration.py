"""One generated integration case; existing components stay read-only."""
import json
import shutil
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(r"D:\Projects\GeoAI-incremental-dev-20261101")
MAIN = Path(r"D:\Projects\GeoAI")
HERE = Path(__file__).resolve().parent
BASE = ROOT / "snapshot_fixture/generation_fixture_0001"
sys.path[:0] = [str(MAIN), str(MAIN / "Agent"),
                *(str(ROOT / lane) for lane in ("grouping", "identity_merge", "relations", "contract_fixtures"))]

from group_mentions import group_mentions
from merge_assigned_qids import merge_assigned_qids
from native_pair_views import select_native_views
from GG_Data.pipeline.graph_export import build_graph
from GG_Data.pipeline.test_graph_export import fixture
from GG_Data.pipeline.final_package import digest, read_json
from geo_agent.graph_store import GraphStore
from test_export_consumer_bridge import _assert_geometry_join


def check():
    protected = [ROOT / "grouping/group_mentions.py", ROOT / "identity_merge/merge_assigned_qids.py",
                 ROOT / "relations/native_pair_views.py", ROOT / "snapshot_fixture/export_snapshot.py",
                 ROOT / "contract_fixtures/test_export_consumer_bridge.py",
                 MAIN / "GG_Data/pipeline/graph_export.py", MAIN / "GG_Data/pipeline/graph_contract.py",
                 MAIN / "GG_Data/pipeline/test_graph_export.py", MAIN / "GG_Data/pipeline/final_package.py",
                 MAIN / "Agent/geo_agent/graph_store.py", MAIN / "Agent/geo_agent/model_dates.py",
                 *(p for p in BASE.rglob("*") if p.is_file())]
    before = {str(path): digest(path) for path in protected}

    def mention(occurrence, word, kind="LOC", page=1, revision=10, **extra):
        return dict(occurrence_id=occurrence, word=word, entity_group=kind,
                    wiki_site="enwiki", page_id=page, revision_id=revision,
                    context="Generated fixture " + occurrence, aliases=[word],
                    source_pointer=dict(page=page, revision=revision, occurrence=occurrence), **extra)

    rows = [mention("o1", "fixture place"), mention("o2", "fixture place"),
            mention("o3", "fixture alias", page=2, revision=20),
            mention("o4", "fixture organization", "ORG"),
            mention("o5", "fixture event", "event"),
            mention("o6", "fixture unmatched", synthetic_id="SYN_sample"),
            mention("o7", "fixture pending homonym"), mention("o8", "fixture pending homonym"),
            mention("o9", "fixture missing revision", revision=None)]
    original = deepcopy(rows)
    grouped = group_mentions(rows)
    assert len(grouped["groups"]) == 6 and len(grouped["unresolved"]) == 1
    # Explicit generated decisions; do not infer a match from raw names.
    decisions = dict(o1="Q1", o2="Q1", o3="Q1", o4="Q1", o5="Q2", o6=None)
    assignments = []
    for group in grouped["groups"]:
        if not all(m["occurrence_id"] in decisions for m in group["members"]):
            continue  # Pending homonyms have neither accepted QID nor supplied SYN.
        values = {decisions[m["occurrence_id"]] for m in group["members"]}
        assert len(values) == 1, "Group members must agree on their already accepted decision"
        assignments.append(dict(group_id=group["group_id"], qid=values.pop(), evidence="generated accepted fixture"))
    merged = merge_assigned_qids(grouped["groups"], assignments)
    assert merged["groups"] == grouped["groups"] and rows == original
    registry = {item["qid"]: {role["entity_group"]: role["group_ids"] for role in item["roles"]}
                for item in merged["registry"]}
    assert set(registry) == {"Q1", "Q2"} and set(registry["Q1"]) == {"LOC", "ORG"}
    assert len(registry["Q1"]["LOC"]) == 2 and len(registry["Q1"]["ORG"]) == 1
    bridges = {b["group_id"]: b for b in merged["group_bridges"]}
    pending = [g for g in merged["groups"] if not bridges[g["group_id"]]["assignment_evidence"]]
    assert len(pending) == 1 and [m["occurrence_id"] for m in pending[0]["members"]] == ["o7", "o8"]
    assert grouped["unresolved"][0]["member"] == rows[-1]

    # Reuse exact existing Entity rows: no new QID, SYN, type, name or alias policy.
    source = fixture()
    source["relations"][0]["time_precision"] = {"from": [9]}  # Existing bridge completion.
    keys = {(qid, kind) for qid, roles in registry.items() for kind in roles}
    for group in merged["groups"]:
        if bridges[group["group_id"]]["qid"] is None:
            keys.update((m["synthetic_id"], group["key"]["entity_group"])
                        for m in group["members"] if m.get("synthetic_id"))
    templates = {(row["entity_id"], row["type"]): row for row in source["entities"]}
    assert keys == {("Q1", "LOC"), ("Q1", "ORG"), ("Q2", "event"), ("SYN_sample", "LOC")}
    assert keys <= templates.keys()
    source["entities"] = [row for row in source["entities"]
                          if (row["entity_id"], row["type"]) in keys or row["type"] == "DATE"]
    for name in ("entities", "events", "relations"):
        assert read_json(BASE / "model" / (name + ".json.gz")) == source[name]
    source_before = deepcopy(source)
    graph, _ = build_graph(**source)
    graph["edges"] = select_native_views(graph["edges"])
    assert source == source_before
    assert graph == read_json(BASE / "graph.json"), "Consumer fields or existing fixture semantics changed"
    assert [e["id"] for e in graph["edges"]] == ["obs-1", "obs-1::REVERSE"]

    output = HERE / "case_0001"
    output.mkdir()  # Preserve earlier output; a rerun needs a deliberately new case directory.
    model = output / "model"
    for path in (BASE / "model").rglob("*"):
        if path.is_file():
            target = model / path.relative_to(BASE / "model")
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    (output / "graph.json").write_text(json.dumps(graph, indent=2), encoding="utf-8")
    (output / "identity_handoff.json").write_text(json.dumps(dict(merged=merged, unresolved=grouped["unresolved"]), indent=2), encoding="utf-8")
    store = GraphStore.from_json(output / "graph.json", model_dir=model)
    assert set(store.nodes) == {"Q1::LOC", "Q1::ORG", "Q2::event", "SYN_sample"}
    assert set(store.resolve_ids("Q1")) == {"Q1::LOC", "Q1::ORG"}
    assert store.nodes["SYN_sample"].wikidata_id is None
    assert store.schema()["assertion_count"] == 1 and len(store.edges) == 2
    assert len(store.model_edge_dates) == 2 and "Q2::event" in store.model_node_dates
    assert [row["id"] for row in store.locations_of("Q2::event")] == ["Q1::LOC"]
    _assert_geometry_join(store)
    assert before == {str(path): digest(path) for path in protected}, "Reused code/artifact mutated"
    for path in (BASE / "model").rglob("*"):
        if path.is_file():
            assert digest(path) == digest(model / path.relative_to(BASE / "model"))
    result = dict(status="PASS", checked_utc=datetime.now(timezone.utc).isoformat(), synthetic_cases=1,
                  mentions=9, grouped_members=8, groups=6, unresolved_attribution=1,
                  pending_identity_groups=1, pending_identity_members=2, accepted_qids=2,
                  q1_typed_roles=2, graph_nodes=4, native_assertions=1, directional_views=2,
                  geometry_joins=2, model_date_views=2,
                  catalog="fixture relation-map-v2.1.2, wd:P1; real v2.1.1 catalog NOT exercised",
                  preserved_source_sha256=before, code_sha256=digest(Path(__file__)),
                  output_sha256={str(p.relative_to(output)): digest(p) for p in output.rglob("*") if p.is_file()},
                  limitations=["Generated accepted decisions only; no production matching or quality claim",
                               "Pending identity and attribution retained internally; no invented SYN or QID",
                               "No co-occurrence, retraction, snapshot publisher or cadence test"], backup_status="Unprotected")
    (HERE / "verification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("PASS: 1 synthetic integration; 9 retained mentions; 6 groups; Q1 LOC+ORG; pending 2+unbound 1 preserved; 4 consumer nodes; 2 views; exact existing geometry")


if __name__ == "__main__":
    check()
