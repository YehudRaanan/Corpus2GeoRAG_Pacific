# E2 supplied-history interface review — 2026-11-01

**PASS**, 18:16:42 UTC. Reviewed the changed `receipt_for`, `recover`, `seal_unit` and seven-check history test, without modifying or running mutating tests in E2. One independent integration check lives in `check_sealed_history.py`; its only writes are new case_0006 review evidence in this owned directory.

## Review conclusion

No blocking defect found within the declared generated v1/v2, single-writer, caller-pinned contract. Prior handoffs must share the six-field source scope. Existing replace_unit validates their ordering and each prior pointer before the new version is validated. The receipt hashes canonical prior-history content; recover compares the complete recomputed receipt. Initial receipts retain their old shape. Pending decisions remain distinct from explicit unmatched outcomes.

Caller-supplied history/pinned hashes remain a trust boundary, not an authenticated registry or automatic resume protocol. Verification covers supplied two-version chains and process interruption fixtures. Directory fsync, hardware/power-loss durability, distributed writers and production discovery remain unproven. No severity/identity policy is chosen by this review.

## Independent evidence

- Verified the history verification's externally supplied SHA256 and current E2/check code hashes, all 25 history artifact hashes and all 18 original-suite artifact hashes. E2 evidence reports seven new and ten original checks passing; the reviewer did not rerun its child-process crash suites.
- Recovered v1 handoffs from existing immutable seals using recorded unit hashes, replayed into a fresh reducer, then recovered v2 with exact prior histories. All three aggregates match integration case0005 exactly.
- Duplicate replay is a no-op. Six bad histories (missing, altered-but-valid and reversed for each unit) are rejected.
- Final state preserves seven originals/eight revision supports/four history versions, with two pending and four explicitly unmatched originals. The unrelated Q2 page remains; Q1 pages follow 1 -> 1 -> 0.
- Current E2 code reads an earlier initial-version receipt without history, confirming legacy receipt compatibility.
- One hundred protected code/artifact hashes remain unchanged. A subsequent fresh process reverified all protected/output hashes and exact saved transition equality.

Command: existing bridge Python with `-B` and PYTHONDONTWRITEBYTECODE=1, running `check_sealed_history.py`. Exit 0: `PASS: E2 sealed v1/v2 -> E4 all case0005 transitions; six bad histories rejected; pending2/unmatched4 retained; legacy receipt readable; E2 unchanged`. Fresh readback exited 0: `PASS_FRESH_PROCESS_REVIEW_EVIDENCE`.

Evidence: verification_case_0006.json and case_0006/replayed_transitions.json. Reviewed E2 code SHA256: 3497b831e9103972be6772b5a917f18708dcbdafd295c4fcf7c7be0836134f11.

## Plan record and next dependency

The exact proposed status append was presented in PLAN_HISTORY_STATUS_APPEND.md before modifying the two authorized shared plans. It qualifies the E2 history result and supersedes the earlier initial-version-only limitation chronologically, preserving all existing plan bytes. Both appends completed and independent readback verified prior bytes, suffix/file hashes and one new block per plan. Evidence: plan_history_status_receipt.json. The same readback separately checked v2 receipt IDs: pending o7/o8, explicit unmatched o1/o4/o6 for unit A and o2/o6 for unit B.

Next implementation dependency remains the occurrence-aware Entity/mention bridge and explicit frozen-frontier integration. Production still requires authoritative prepared-input/accepted-decision adapters and the existing input/resource gates. E2 supplies validated given chains; choosing/discovering a production frontier is not implemented here.

Process ruling: the parent's no-Git/no-subagent/read-only-E2 scope overrides generic executing-plans worktree/commit/reviewer scaffolding. The existing isolated directory, this task record and independent readback satisfy the bounded review; no Git operation, nested session, code fix, publication or broad-stage completion occurred. No operational blocker remains. Backup: **Unprotected**.
