# First-unit supported unique exact — 2026-11-01

**PASS**, 20:09:42 UTC. Applied the freshly authorized unique literal exact route for page 48975579 / processing revision 1375061414 with the existing exact_pairs function, retained-component source candidates and native type evidence. No model, publication, consumer change or nested agent.

Result: **10 accepted LOC/ORG/PER groups / 30 occurrences**. All **136 IDs** remain in occurrence_decisions; 106 stay pending, never NONE. At most one QID is assigned per group. The original groups, source members, candidate ledgers and receipts remain unchanged.

## Actual source/type and eligibility checks

- Every candidate QID comes from at least one IN source-component target in the same verified processing revision. Cached title/label/type metadata retains its separate temporal provenance.
- Reused filter_qid_inventory._types and its existing TYPE_ROOTS against the cached native ancestry. All ten accepted groups have their original LOC/ORG/PER type positively represented, with no missing class branches. Multiple supported categories are retained; no canonical type winner is selected.
- Reused exact_pairs across all 69 group names/types, preserving name/type conflicts, original IDs and repair/review flags. No aliases, case-folding, fuzzy threshold or stronger confidence gate was added. None of the 15 literal-positive groups has changed surface.
- The five positive MISC groups remain explicitly policy-pending instead of silently inheriting legacy wildcard compatibility. DATE and other unresolved groups remain in the 136-row output; no global DATE/MISC drop occurs.
- Six unresolved candidate targets remain unknown. They are recorded with the candidate-frontier hash and do not create a blanket block on these supported positive exact decisions or become NONE labels. This is the reviewed current candidate frontier, not a claim of complete page/corpus candidate coverage.

The actual plan retains G3 type/eligibility and G5 occurrence/typed-role semantics. This task uses the parent's explicit approved same-unit unique-exact instruction and the existing source/type evidence; it does not treat historical still-open alias/MISC policy text as a veto on the ten supported literal positives. It does not resolve residual/model/conflict policy or assign a synthetic ID.

## Exact owner decision still needed

Whether raw MISC may act as wildcard against these native categories, remain a stored MISC role or defer to later adjudication. Affects these five positive groups/seven occurrences: World War II (2), Doolittle Raid (2), Operation Matterhorn (1), Tokyo Rose (1), Distinguished Flying Cross (1). Operation Matterhorn also lacks native type evidence. No retyping to Event/PER/other class is invented. This specific unresolved choice is separate from already supported LOC/ORG/PER results.

## Verification and next handoff

verify_first_unit_exact.py exited 0. A second QID with the same Tokyo literal suppresses its exact result; shifting all candidate rows to another revision produces no exact result. Full 136-ID equality/cardinality, original input immutability and saved JSON readback pass. A fresh process rehashed code/outputs/protected inputs and independently checked 10 groups/30 decisions, one QID maximum, positive type evidence and all 136 original IDs. No identity accuracy percentage is inferred.

Artifacts: exact_unit_0001/decisions.json, receipt.json. These are private exact-stage records, not consumer graph fields or an applied E4 durable state update. Next existing-plan step is a version-bound accepted-decision handoff into the reviewed identity/membership reducer, preserving the pending 106 and correction/replay provenance. Any wider matching still uses the same relevant-component filter. Backup: Unprotected.
