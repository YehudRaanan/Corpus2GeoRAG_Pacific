"""One real unit's offline candidate evidence, restricted to approved components."""
import gzip
import hashlib
import importlib.util
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PILOT = Path(r"D:\Projects\GeoAI-luke-pilot-20261028")
sys.path.insert(0, str(PILOT))
from GG_Data.entity_resolution.hundred_page_pilot.collect_entities import raw_links
from GG_Data.entity_resolution.hundred_page_pilot.recover_page_qids import template_targets
import pyarrow.parquet as pq

POLICY = ROOT / "review_treatments/narrow_policy_20261101_v2/narrow_source_policy.py"
spec = importlib.util.spec_from_file_location("approved_narrow_policy", POLICY)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def decision(view, row):
    left, right = row.get("anchor_start"), row.get("anchor_end")
    if left is None or right is None:
        left, right = row.get("name_start"), row.get("name_end")
    if left is None or right is None or left == right:
        left, right = row["raw_start"], row["raw_end"]
    status, reason = policy.classify(view, left, right)
    return dict(status=status, reason=reason, checked_start=left, checked_end=right)


def run():
    # Source component decisions do not depend on extracted NER mention spans.
    tiny = "[[Tokyo]]<ref>[[Yokosuka]]</ref>\n==Notes==\n[[Sentai]]"
    tiny_view = policy.build_view(tiny)
    assert [decision(tiny_view, row)["status"] for row in raw_links(tiny)] == ["IN", "OUT", "OUT"]
    inp = ROOT / "review_treatments/first_run_input_20261101_v1"
    assert digest(inp / "seal.json") == "03cd6fd90d609815c431ea234d9c32f0c10e98287b60d515439f15305b5e4089"
    unit = json.loads((inp / "first_unit.json").read_text())
    assert (unit["page_id"], unit["processing_revision_id"]) == (48975579, 1375061414)
    source = Path(unit["source_path"])
    assert digest(source) == unit["source_sha256"]
    raw = source.read_text(encoding="utf-8")
    view = policy.build_view(raw)
    # Match the approved saved page projection, not a fresh alternative cleaning policy.
    cleaned = POLICY.parent / "cleaned_pages.jsonl.gz"
    writer = json.loads((inp / "writer_receipt.json").read_text())
    assert digest(cleaned) == writer["source_hashes"][str(cleaned)]
    with gzip.open(cleaned, "rt", encoding="utf-8") as stream:
        approved_page = next(json.loads(line) for line in stream if json.loads(line)["page_id"] == unit["page_id"]
                             and json.loads(line)["processing_revision_id"] == unit["processing_revision_id"])
    assert approved_page["raw_sha256"] == unit["source_sha256"]
    assert approved_page["text"] == view["cleaned_text"]
    assert approved_page["origin_segments"] == policy.origin_segments(view["origins"])
    links = [dict(row, component=decision(view, row)) for row in raw_links(raw)]
    templates = [dict(row, component=decision(view, row)) for row in template_targets(raw, include_unsupported=True)]
    assert len(links) == 52 and len({r["target_title"] for r in links}) == 47
    cache_root = PILOT / "Data/external/hundred_page_pilot_20261028"
    folders = [cache_root / "collection_titles_final", cache_root / "template_name_pilot_20261029/recovery_100_v2"]
    mappings, metadata = defaultdict(list), defaultdict(list)
    protected = {str(path): digest(path) for path in [POLICY, source, cleaned, inp / "seal.json",
                  inp / "writer_receipt.json", HERE / "real_unit_0001/run_receipt.json", HERE / "real_unit_0001/groups.json"]}
    meta_fields = ["qid", "label", "aliases", "native_types", "metadata_status", "label_status", "p31_status",
                   "metadata_revision", "metadata_modified", "metadata_temporal_basis", "metadata_source", "metadata_path", "metadata_retrieval_utc"]
    for folder in folders:
        for name in ("title_qid_mapping.parquet", "native_metadata.parquet"):
            path = folder / name
            protected[str(path)] = digest(path)
            for row in pq.read_table(path, use_threads=False).to_pylist():
                if name.startswith("title"):
                    mappings[row["target_title"]].append(dict(cache_file=str(path), assertion=row))
                else:
                    metadata[row["qid"]].append(dict(cache_file=str(path), assertion={k: row[k] for k in meta_fields if k in row}))
    targets, active_qids = [], set()
    for title in sorted({r["target_title"] for r in links}):
        sources = [r for r in links if r["target_title"] == title]
        included = any(r["component"]["status"] == "IN" for r in sources)
        assertions = mappings.get(title, []) if included else []
        qids = sorted({a["assertion"]["qid"] for a in assertions if a["assertion"].get("qid")})
        active_qids.update(qids)
        targets.append(dict(target_title=title, source_links=sources, included_from_relevant_component=included,
                            cached_title_assertions=assertions, candidate_qids=qids, mapping_conflict=len(qids) > 1,
                            cache_status="RESOLVED_CACHED_MAPPING" if qids else "UNRESOLVED" if included else "EXCLUDED_COMPONENT_ONLY"))
    candidates = [dict(qid=qid, cached_metadata=metadata.get(qid, []),
                       type_policy_applied=False, accepted_identity=False) for qid in sorted(active_qids)]
    included = [r for r in targets if r["included_from_relevant_component"]]
    unresolved = [r["target_title"] for r in included if not r["candidate_qids"]]
    assert sum(len(r["source_links"]) for r in targets) == 52
    assert all(not r["candidate_qids"] and not r["cached_title_assertions"] for r in targets if not r["included_from_relevant_component"])
    assert all(not t["target_title"] for t in templates), "New template targets require explicit ledger joining before use"
    assert protected == {path: digest(Path(path)) for path in protected}
    output = HERE / "candidate_ledger_0001"
    output.mkdir()
    payload = dict(source_unit=unit, source_temporal_basis="VERIFIED_PROCESSING_REVISION_NOT_ASSUMED_EXTRACTION_REVISION",
                   policy_code_sha256=protected[str(POLICY)], approved_projection_match=True,
                   all_raw_targets_with_inclusion_evidence=targets, template_evidence=templates,
                   active_cached_candidates=candidates, unresolved_relevant_targets=unresolved,
                   original_mention_types="DATE/MISC and all original types unchanged in real_unit_0001/source_members.json",
                   completeness="NOT_ESTABLISHED; unsupported templates/type/label/source gaps remain; no exact matching")
    (output / "ledger.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    assert json.loads((output / "ledger.json").read_text(encoding="utf-8")) == payload
    summary = dict(status="PASS_PARTIAL_RELEVANT_COMPONENT_CANDIDATE_EVIDENCE", checked_utc=datetime.now(timezone.utc).isoformat(),
                   pre_filter_counts=dict(raw_links=52, targets=47, cached_targets=22, unresolved=25),
                   link_component_counts=dict(Counter(r["component"]["status"] for r in links)),
                   relevant_targets=len(included), relevant_cached_targets=len(included)-len(unresolved),
                   unresolved_relevant_targets=len(unresolved), exclusively_excluded_targets=len(targets)-len(included),
                   candidate_qids=len(candidates), candidates_with_labels=sum(any(m["assertion"].get("label") for m in c["cached_metadata"]) for c in candidates),
                   candidates_with_native_types=sum(any(m["assertion"].get("native_types") for m in c["cached_metadata"]) for c in candidates),
                   mapping_conflicts=sum(r["mapping_conflict"] for r in targets), template_records=len(templates),
                   template_component_counts=dict(Counter(r["component"]["status"] for r in templates)),
                   template_target_candidates=0, accepted_matches=0, inventory_complete=False,
                   source_membership_and_grouping_unchanged=True, protected_sha256=protected,
                   code_sha256=digest(Path(__file__)), ledger_sha256=digest(output / "ledger.json"), backup_status="Unprotected")
    (output / "receipt.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if not k.endswith("sha256")}, ensure_ascii=False))


if __name__ == "__main__":
    run()
