# Five pending MISC literal positives — read-only decision examples

No pending state or accepted decision was changed. All 136 first-unit occurrence IDs and the ten accepted exact groups remain as previously recorded.

| Source surface / count | Cached candidate | Existing native type evidence | Narrow handling |
|---|---|---|---|
| World War II / 2 | Q362 | Q103495 world war; Q11514315 historical period | Separate Event-route evidence; not an ordinary MISC wildcard match or automatic approved anchor. |
| Doolittle Raid / 2 | Q713516 | Q2380335 airstrike | Separate Event-route evidence; retain source/QID candidate and do not force ordinary entity type. |
| Operation Matterhorn / 1 | Q1645012 | No native P31 types in inspected snapshot | Event-route hypothesis needs supporting class/source evidence; the operation name alone is not an invented Event type. |
| Tokyo Rose / 1 | Q1910347 | Q1969448 term | Does not provide PER/ORG/LOC support. Never infer a particular human identity from this phrase. |
| Distinguished Flying Cross / 1 | Q1754110 | Q18328097 courage award; Q4240305 cross | Does not provide PER/ORG/LOC support. Preserve the exact supported award QID without inventing a standard NER type. |

Labels above were read from the existing metadata snapshot, using the existing metadata_row helper for the entities and native class items. Evidence is C:/Users/User/.cache/geoai_bigquery_20261018/entity_metadata.json.gz, snapshot 2026-10-18T18:45:19.304197+00:00. Current/cached ontology evidence remains separate from the verified processing-revision source.

Existing approved plan: separate Event handling; expansion only from approved Event anchors to direct entities to second-hop LOC. G6 anchor/predicate scope is not silently selected by these names, coordinates or dates. G3 retains MISC/unknown type eligibility choices; G5 preserves typed roles and occurrence ambiguity without a canonical type winner. The five pending groups therefore remain separate from the ten supported ordinary exact groups; this is not a blanket MISC policy.

Smallest owner decision for the two non-Event examples: permit the two specifically source-supported unique literal QID identities internally while retaining raw MISC and deferring business/consumer population, or leave those two cases pending. This does not require approving all MISC classes, inventing a new consumer type or converting Tokyo Rose to PER. Event candidates remain in the separate route; actual Event inclusion/expansion requires the existing approved anchor scope.

Next ready implementation step is independent of this decision: bind the already accepted 30 exact occurrence decisions plus 106 pending records to a first version for the sealed unit and replay through the reviewed E2/E4 membership interface. No model or general MISC decision is needed for that existing accepted subset. The current task did not execute it.

For documentation, read counts_direct_20261101/REPORT.md, pair_relations_direct_20261101/REPORT.md and REPORT_COMBINED.md, geometry_direct_20261101/REPORT.md and its G8_G10_RECONCILIATION.md. Code hashes match their recorded receipts. Their existing tests were not rerun. Partial generated E4/E5/E6 evidence is recorded in the separate planned status append; no production-complete claim follows.
