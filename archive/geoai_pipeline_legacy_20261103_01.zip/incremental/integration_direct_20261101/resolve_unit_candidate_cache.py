"""Exact cached mapping/redirect evidence for unresolved retained source targets."""
import gzip
import hashlib
import json
import sys
from collections import defaultdict
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
PILOT = Path(r"D:\Projects\GeoAI-luke-pilot-20261028")
sys.path.insert(0, str(PILOT))
from GG_Data.entity_resolution.hundred_page_pilot.collect_entities import title_response, metadata_row
import pyarrow.parquet as pq


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run():
    previous = HERE / "candidate_ledger_0001"
    old_receipt = json.loads((previous / "receipt.json").read_text())
    assert digest(previous / "ledger.json") == old_receipt["ledger_sha256"]
    ledger = json.loads((previous / "ledger.json").read_text(encoding="utf-8"))
    original = deepcopy(ledger)
    wanted = set(ledger["unresolved_relevant_targets"])
    assert len(wanted) == 11
    assertions = defaultdict(list)
    paths = [previous / "ledger.json", previous / "receipt.json", HERE / "real_unit_0001/groups.json",
             HERE / "real_unit_0001/run_receipt.json"]
    cache_root = PILOT / "Data/external/hundred_page_pilot_20261028"
    mapping_files = list(cache_root.rglob("title_qid_mapping.parquet"))
    paths += mapping_files
    for path in mapping_files:
        for row in pq.read_table(path, use_threads=False).to_pylist():
            if row.get("target_title") in wanted and row.get("qid"):
                assertions[row["target_title"]].append(dict(basis="EXACT_EXISTING_TITLE_MAPPING", evidence=str(path), record=row))
    cache = Path(r"C:\Users\User\.cache\geoai_bigquery_20261018\entity_metadata.json.gz")
    snapshot = cache.with_name("table_snapshot.json")
    paths += [cache, snapshot]
    with gzip.open(cache, "rt", encoding="utf-8") as stream:
        metadata = json.load(stream)
    snapshot_time = json.loads(snapshot.read_text())["snapshot_at"]
    for qid, entity in metadata.items():
        title = entity.get("sitelinks", {}).get("enwiki", {}).get("title")
        if title in wanted:
            assertions[title].append(dict(basis="CACHED_EXACT_ENWIKI_SITELINK", evidence=str(cache),
                record=dict(target_title=title, canonical_target_title=title, qid=qid,
                            mapping_temporal_basis="CACHED_CURRENT_TITLE_RESOLUTION", mapping_retrieval_utc=snapshot_time)))
    # Search only existing saved request folders from the reused collection pipeline.
    requests = [p for folder in cache_root.rglob("*") if folder.is_dir() and folder.name in {"requests", "collection_requests"}
                for p in folder.glob("*.json.gz")]
    paths += requests
    observed = defaultdict(list)
    for path in requests:
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            saved = json.load(stream)
        if not saved.get("ok") or not saved.get("response_text"):
            continue
        response = json.loads(saved["response_text"])
        query = response.get("query", {})
        if not isinstance(query, dict):
            continue
        aliases = {r["from"] for key in ("normalized", "redirects", "converted") for r in query.get(key, [])}
        requested = set(str(saved.get("params", {}).get("titles", "")).split("|"))
        pages = query.get("pages", [])
        if isinstance(pages, dict):
            pages = list(pages.values())
        titles = {p.get("title") for p in pages}
        for target in wanted & (requested | aliases | titles):
            row = title_response(target, response, str(path), saved.get("retrieved_utc"))
            observed[target].append(dict(evidence=str(path), status=row["qid_status"]))
            if row.get("qid"):
                assertions[target].append(dict(basis="SAVED_EXPLICIT_TITLE_REDIRECT_RESPONSE", evidence=str(path),
                    record=row, redirect_normalization_evidence={key: query.get(key, []) for key in ("normalized", "redirects", "converted")}))
    protected = {str(path): digest(path) for path in paths}
    updates, new_qids = [], set()
    for target in sorted(wanted):
        qids = sorted({a["record"]["qid"] for a in assertions[target]})
        new_qids.update(qids)
        updates.append(dict(target_title=target, cached_assertions=assertions[target], candidate_qids=qids,
                            mapping_conflict=len(qids) > 1, observed_saved_responses=observed[target],
                            remaining_reason=None if qids else "NO_SUPPORTED_EXACT_TITLE_OR_REDIRECT_MAPPING_IN_INSPECTED_CACHES; not NONE"))
    by_title = {r["target_title"]: r for r in ledger["all_raw_targets_with_inclusion_evidence"]}
    for update in updates:
        target = by_title[update["target_title"]]
        assert target["included_from_relevant_component"]
        target["additional_cached_assertions"] = update["cached_assertions"]
        target["candidate_qids"] = update["candidate_qids"]
        target["cache_status"] = "RESOLVED_ADDITIONAL_CACHE" if update["candidate_qids"] else "UNRESOLVED"
    existing = {c["qid"] for c in ledger["active_cached_candidates"]}
    for qid in sorted(new_qids - existing):
        cached = metadata_row(qid, metadata.get(qid))
        ledger["active_cached_candidates"].append(dict(qid=qid, cached_metadata=[dict(cache_file=str(cache), assertion=cached,
            retrieval_utc=snapshot_time, temporal_basis="CACHED_CURRENT_METADATA")], type_policy_applied=False, accepted_identity=False))
    ledger["unresolved_relevant_targets"] = [u["target_title"] for u in updates if not u["candidate_qids"]]
    assert all(not t["candidate_qids"] for t in ledger["all_raw_targets_with_inclusion_evidence"] if not t["included_from_relevant_component"])
    assert ledger["template_evidence"] == original["template_evidence"]
    # Literal positive evidence only; absent/ambiguous candidates are never NONE.
    labels = defaultdict(set)
    for candidate in ledger["active_cached_candidates"]:
        for record in candidate["cached_metadata"]:
            label = record["assertion"].get("label")
            if label:
                labels[label].add(candidate["qid"])
    groups = json.loads((HERE / "real_unit_0001/groups.json").read_text(encoding="utf-8"))["groups"]
    literal = [dict(group_id=g["group_id"], surface=g["key"]["word"], entity_group=g["key"]["entity_group"],
                    occurrence_ids=[m["occurrence_id"] for m in g["members"]], candidate_qids=sorted(labels.get(g["key"]["word"], [])),
                    changed_surface=any(m["word_original"] != m["word"] for m in g["members"]), accepted=False)
               for g in groups]
    assert sum(len(g["occurrence_ids"]) for g in literal) == 136
    assert protected == {path: digest(Path(path)) for path in protected}
    output = HERE / "candidate_cache_0002"
    output.mkdir()
    for name, value in (("ledger.json", ledger), ("target_updates.json", updates), ("literal_positive_evidence.json", literal)):
        (output / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        assert json.loads((output / name).read_text(encoding="utf-8")) == value
    remaining = ledger["unresolved_relevant_targets"]
    result = dict(status="PASS_PARTIAL_CACHE_RESOLUTION", checked_utc=datetime.now(timezone.utc).isoformat(),
                  relevant_targets=30, newly_resolved_targets=11-len(remaining), resolved_targets=30-len(remaining), unresolved_targets=remaining,
                  active_candidate_qids=len(ledger["active_cached_candidates"]), mapping_files_inspected=len(mapping_files), saved_requests_inspected=len(requests),
                  positive_literal_groups=sum(bool(g["candidate_qids"]) for g in literal),
                  single_literal_candidate_groups=sum(len(g["candidate_qids"]) == 1 for g in literal),
                  positive_literal_occurrences=sum(len(g["occurrence_ids"]) for g in literal if g["candidate_qids"]),
                  accepted_matches=0, exact_stage_executed=False, missing_candidates_are_none=False,
                  protected_sha256=protected, code_sha256=digest(Path(__file__)),
                  output_sha256={p.name: digest(p) for p in output.iterdir()}, backup_status="Unprotected")
    (output / "receipt.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if not k.endswith("sha256")}, ensure_ascii=False))


if __name__ == "__main__":
    run()
