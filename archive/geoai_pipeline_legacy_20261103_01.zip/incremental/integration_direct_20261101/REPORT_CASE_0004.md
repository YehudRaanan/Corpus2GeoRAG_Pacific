# Two-unit occurrence aggregation — 2026-11-01

**PASS**, 17:55:44 UTC. One new readable file, `aggregate_occurrences.py`, reuses the previous occurrence-decision stage. Only the owned integration directory was written. Cases 0001–0003 and shared components remain unchanged.

## Stable identity and aggregation

Stable original occurrence identity is already available: `(unit_scope.input_sha256, member.original_row_index)`. The source-unit manifest binds the input hash, and each member retains its original generated row index. No name, context, revision ID or local group ID substitutes for this provenance. A check rejects a missing original row index instead of guessing.

Two independently closed generated units represent enwiki page 1 at processing/support revisions 10 and 11, with separately verified source bytes. Both refer to the same original seven input rows. The second processing revision is recorded separately; original source-pointer evidence is preserved in the complete support records.

The aggregate groups each original row once and retains both revision support records with their full decisions/evidence. Physical-page identity is `(wiki_site, page_id)`, so the two revisions remain one physical page. Typed QID roles remain separate. This is an in-memory diagnostic projection and generated evidence, not a production storage or consumer schema.

## Measured result

- Fourteen support records become seven unique original occurrences and one physical page.
- Q1 has three uncontested accepted mentions on one page: LOC has two mentions/one page, ORG has one mention/one page. Two identical raw-name LOC rows remain two distinct original occurrences.
- One original Event occurrence has Q2 in one unit and Q1 in the other. Both complete decisions remain in an explicit conflict record; no resolved QID or winner is created.
- One original occurrence remains explicitly unmatched, retaining the existing supplied SYN. Two original occurrences remain pending without decisions; both revisions' evidence remains present.
- Counts are explicitly partial: conflicting, pending, explicitly unmatched or inconsistent page/type records do not enter the uncontested accepted-count view. No conflict-resolution policy, matching threshold, negative inference or promotion rule is selected. In particular, the absence of Q2 from this partial count list does not resolve its conflicting evidence against it.
- Exact replay and reversed unit arrival order reproduce the same aggregate. State/input records remain unchanged.
- Thirty-four protected files retain their hashes; four output hashes and the code hash are recorded in `verification_case_0004.json`.

No pair support, co-occurrence strength, normalization, weighted consumer field or production persistence was implemented.

## Verification actually run

RED: the stub exited 1 with `AssertionError: Repeated processing revisions must not duplicate original rows`; no case output was created. GREEN used the existing bridge Python and bytecode disabled:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
& 'D:\Projects\GeoAI-incremental-dev-20261101\contract_fixtures\.venv-bridge\Scripts\python.exe' -B 'D:\Projects\GeoAI-incremental-dev-20261101\integration_direct_20261101\aggregate_occurrences.py'
```

Exit 0: `PASS: 2 closed revision units; 14 supports -> 7 original occurrences; Q1 mentions=3/pages=1; LOC mentions=2/pages=1; 1 conflict retained without winner; replay/order stable`.

A subsequent fresh read-only process verified all protected/output/code hashes, revalidated both saved closed units against their source bytes through `replace_unit`, replayed each once, rebuilt the exact aggregate, and independently checked the seven/14/one-page counts and both conflicting QIDs. Exit 0: `PASS_FRESH_PROCESS_READBACK`.

Evidence: `case_0004/aggregation.json`, `case_0004/units.json`, two tiny source-byte fixtures, and `verification_case_0004.json`.

## Exact integration gap

Case 0003 tested replacing one unit's decision version; this case tested two-unit aggregation and deduplication. The next unverified connection is a correction flowing through both stages together: removing one supporting occurrence must preserve a QID's page while another accepted occurrence still supports it, and remove that page only after its last uncontested support disappears. Conflict changes must also propagate without selecting a winner.

Downstream Entity/mention integration still requires an occurrence-aware bridge. The unchanged group-level merger cannot represent heterogeneous occurrence decisions by assigning one QID to the whole name group. Real page processing additionally needs the authoritative prepared-input/accepted-decision adapter and global input-preparation barrier; none was run here.

No catalog, consumer export, production data, acquisition, cloud, Git, publication or shared-code change. No operation remains denied, pending or uncertain. Backup: **Unprotected**.
