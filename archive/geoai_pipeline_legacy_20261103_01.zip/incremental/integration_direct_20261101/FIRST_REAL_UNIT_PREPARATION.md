# First real closed-unit preparation — read-only, 2026-11-01

Owner scope received through parent: first run retains 1,301,119 verified mapped occurrences; 24,291 unmapped IN and 65,985 pending remain outside this first run with all raw records/provenance preserved. INPUT is materializing and reading back the scoped view and complete unit membership. No readiness receipt was received by this preparation task. No real unit was selected or processed.

## First operation and plan mapping

First proposed operation is **local raw grouping only**, runtime R2, using the closed membership produced by development Task 2/E2 and model-independent interfaces under Task 3/E3a. G3 explicitly permits raw grouping for closed membership before exact uniqueness. This is a first page/revision unit job, not a definition of the canonical publication batch under G12.

Reuse `grouping/group_mentions.py::group_mentions(mentions)` from the incremental workspace. It groups exact `(wiki_site,page_id,revision_id,word,entity_group)` values, retains complete member dictionaries, separates unresolved attribution and assigns no QID. It requires no trained model, tokenizer, network, current Wikidata lookup, category decision or geometry acquisition.

## Receipt and adapter

Before selecting a unit, require INPUT's final successful full-readback/ready receipt for the newly approved first-run scope. It must pin actual view and complete membership artifact paths/hashes, original input identity, scope/policy version, expected occurrence identities, and verified processing page/revision/source support. The exact artifact names and final schema are not yet provided; do not substitute old ingestion, binding or caption artifacts.

After that receipt only, choose the smallest positive complete unit listed in its verified unit inventory (stable tie order wiki site/page/revision). Read all and only the declared members, across any input row-group boundaries. Check the exact original ID set/count against the unit manifest; do not take the first N rows or infer closure from a row-group boundary.

Minimal adapter in one future readable file: copy each complete ready record, expose the receipt-pinned processing revision as `revision_id`, preserve `extraction_revision_id` and original source pointers, and retain original `word`/`entity_group` for the grouping key. Repaired/clean display text stays separately available; it never silently replaces the raw key.

Existing `processing_revision_binding/bind_processing_revision.py::processing_view(base_row,binding)` shows the safe ID/page join and single-field processing-revision view; reuse the pure helper only if the new receipt supplies separate compatible base/binding records. Do not invoke its old fixed-path run. If the new INPUT view is already joined, validate it directly instead of rejoining stale sidecars.

Preserve `input_sha256`, `source_row_index` and `occurrence_id` exactly. If a later E4 handoff needs `original_row_index`, copy the verified source_row_index as an additional internal alias; never enumerate selected rows afresh. The existing full ingestion emits source_row_index rather than the synthetic handoff's original_row_index, so that bridge must be explicit.

## Proposed outputs and exit checks

Write a fresh, parent-assigned isolated output directory with `groups.json` (complete groups plus explicit unresolved records) and a private `run_receipt.json` binding the ready INPUT receipt/hashes, one unit key, exact member IDs/count, grouping code hash and observed counts. No consumer Entity/QID graph, synthetic ID population or publication output is produced by this first step. No new framework is needed.

Exit checks: one wiki/page/processing-revision/source scope; complete declared membership; original IDs unique; no excluded/pending-scope row admitted; every selected member retained exactly once; group keys use unchanged raw name/type; original context/offset/provenance preserved; no fabricated extraction revision; all IDs/counts reconcile after readback; repeat grouping is deterministic and does not add members. Any attribution failure remains explicit and prevents claiming this selected unit was fully bound. The existing generated grouping self-check may run before the one-unit job; nothing was executed in this preparation.

## Exact matching is a separate subsequent step

Existing pure `D:/Projects/GeoAI-luke-pilot-20261028/GG_Data/entity_resolution/hundred_page_pilot/match_exact.py::exact_pairs(groups,entities)` also needs no trained model. It expects flat group records (`id,page_id,revision_id,name,type` plus repaired/review flags) and a complete same-page/revision QID inventory with canonical labels/type/source evidence. Our group records are nested under key/members, so a small explicit adapter is needed; do not run its whole-file prepare wrapper or inherit exclude_date/source-policy defaults.

Missing for real exact promotion: the selected unit's verified complete eligible QID inventory, owner-approved G3 type/source/literal-label/alias policy and occurrence eligibility/ambiguity treatment (G5). The legacy compatible function permits MISC/unknown-type cases and legacy rows without type metadata; that behavior is not a fresh approval. Source/template collection modules can use network paths, so their presence is not evidence that a complete cached inventory exists. Without those inputs, stop at grouping or separately scoped candidate evidence; no accepted match may be inferred from raw string uniqueness. Residual/model adjudication additionally requires T4/G4.

## Current missing dependencies

1. Final INPUT ready receipt and exact first-run artifact/schema/member inventory; materialization/readback are still pending in the received status.
2. After receipt, a concrete smallest complete unit and measured size; none selected from stale inputs.
3. Parent's execution handoff for that one real unit/output directory; current authorization is read-only preparation only.
4. Eligible inventory/G3/G5 if proceeding beyond grouping. No trained model is needed for the grouping step itself.

No production job, candidate acquisition, model invocation, shared implementation edit or new resource operation occurred. Planned status append is FIRST_RUN_SCOPE_STATUS_APPEND.md; the parent authorized the two existing plan status sections only. Backup: Unprotected.
