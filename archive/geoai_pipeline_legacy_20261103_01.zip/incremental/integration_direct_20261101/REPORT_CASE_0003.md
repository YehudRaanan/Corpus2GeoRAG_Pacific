# Occurrence decisions and unit replacement — 2026-11-01

**PASS**, 17:49:30 UTC. `occurrence_decisions.py` contains the small in-memory stage and its generated self-check. Only the owned integration directory was written; all shared components and cases 0001/0002 remain unchanged.

## Handoff and source identity

Reuses `source_custody/local_unit_contract.py::source_membership_ready` to check actual generated source bytes and the complete declared row inventory. The internal unit key is the existing custody scope: input SHA256, wiki site, page ID, support revision ID, source SHA256 and policy version. Supplied opaque decision-version/prior-version strings are separate from this key; no ordering, model threshold or new production identity policy was selected.

Each handoff retains the complete occurrence records, original generated row indices, zero or one explicit QID/None decision per occurrence, and its evidence. Missing decision and explicit `qid=None` remain different. All validation precedes the single in-memory state replacement. Full prior handoffs remain in history; only the latest version supplies active records. The active view is rebuilt directly, without a count ledger, event framework or co-occurrence formula.

Fixture scope is one declared enwiki page 1 / revision 10 unit containing seven generated members from case_0001. The other page and unbound-revision records remain preserved in the untouched earlier case; they were not smuggled into this closed unit. The declared inventory/source fixture demonstrates only this synthetic closure, not real-input eligibility or extraction accuracy.

## Measured behavior

- v1 retains distinct occurrence decisions Q1 and Q2 for two identical raw-name members, plus separate Q1/ORG and Q2/Event roles. Group text never imposes one QID.
- v2 replaces v1's contribution for the same unit. Two LOC occurrences now support Q1. Last Q2 and ORG/Event assigned supports disappear from the active view, while the original records and v1 decisions remain in history.
- Seven active members remain: two accepted Q1/LOC, three explicit unmatched (`o4`, `o5`, `o6`), two pending without decisions (`o7`, `o8`). The previously supplied `SYN_sample` remains unchanged; no new SYN or QID is minted.
- Exact-current replay returns no change. Replaying `[v1,v1,v2,v2]` reconstructs the same single active unit and two history versions, with no duplicate contribution.
- Six invalid handoffs are rejected without changing state: stale v1, changed content under current version, wrong prior pointer, incomplete membership, repeated/conflicting occurrence decision, and foreign revision scope.
- Twenty-eight protected files retain their hashes. Three output hashes and the code hash are recorded in `verification_case_0003.json`.

The hand-counted support values above are occurrence counts for the test only. They are not physical-page co-occurrence counts, normalized weights or consumer `count` fields.

## Verification actually run

RED: stub implementation exited 1 with `AssertionError: Closed unit must install its occurrence decisions`. It wrote no case output. After implementing the small stage:

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
& 'D:\Projects\GeoAI-incremental-dev-20261101\contract_fixtures\.venv-bridge\Scripts\python.exe' -B 'D:\Projects\GeoAI-incremental-dev-20261101\integration_direct_20261101\occurrence_decisions.py'
```

GREEN exit 0: `PASS: closed-unit decision v1 -> v2; 7 members retained; old supports withdrawn; 3 explicit unmatched + 2 pending; replay counted once; 6 invalid handoffs rejected`.

A fresh read-only Python process verified the code/protected/output hashes, rebuilt the saved state, reproduced the exact active view, replayed the current handoff twice without adding contributions, and independently checked the final seven/2/3/2 counts. Exit 0: `PASS_FRESH_PROCESS_READBACK`.

Evidence outputs: `case_0003/state.json`, `case_0003/active_occurrences.json`, `case_0003/source_fixture.bin`. These are generated readback evidence, not a crash-safe checkpoint or production storage protocol. No consumer export or relation catalog is exercised by this step.

## Next dependency and limits

Next stage-4 increment is aggregation across closed units, deduplicating the same original occurrence across support revisions and retaining conflicting identity evidence. This must feed an occurrence-aware identity/membership projection: the unchanged group-level merger cannot assign one QID to a heterogeneous homonym group. Physical-page counts and pair relations depend on that consistent projection; weighted consumer representation remains an owner decision.

Real execution additionally needs the upstream accepted-decision handoff and global input-preparation barrier. No production processing, model acceptance, co-occurrence weights, crash durability, concurrency or publication is claimed. No shared-code bug was found. No operation remains denied, pending or uncertain. Backup: **Unprotected**.
