"""Seal/replay the first unit's approved exact decisions; pending is not NONE."""
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
E2 = ROOT / "durable_units_direct_20261101"
sys.path.insert(0, str(E2))
from durable_unit import encoded, recover, seal_unit
from occurrence_decisions import replace_unit
from aggregate_occurrences import aggregate_units


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def replay_check(slot, pinned_hash, source_bytes, exact):
    loaded = recover(slot, pinned_hash)
    assert loaded["status"] == "sealed"
    handoff = loaded["handoff"]
    assert len(handoff["occurrences"]) == 136 and len(handoff["decisions"]) == 30
    state = {}
    assert replace_unit(state, handoff, source_bytes) is True
    initial = deepcopy(state)
    assert replace_unit(state, deepcopy(handoff), source_bytes) is False and state == initial
    aggregate = aggregate_units(state)
    assert aggregate == aggregate_units(state)
    assert aggregate["unique_occurrences"] == aggregate["support_records"] == 136
    assert aggregate["unique_physical_pages"] == 1
    assert len(aggregate["identity_counts"]) == 10
    assert sum(row["mention_count"] for row in aggregate["identity_counts"]) == 30
    assert all(row["page_count"] == 1 for row in aggregate["identity_counts"])
    assert sum(bool(row["pending_supports"]) for row in aggregate["occurrences"]) == 106
    assert sum(row["decision_values"] == [None] for row in aggregate["occurrences"]) == 0
    assert len(state) == 1 and len(next(iter(state.values()))) == 1
    pending = {row["occurrence_id"]: row for row in handoff["pending_evidence"]}
    accepted = {row["occurrence_id"]: row["evidence"]["exact_occurrence_record"] for row in handoff["decisions"]}
    assert set(pending).isdisjoint(accepted) and len(pending) == 106
    assert [accepted.get(row["occurrence_id"], pending.get(row["occurrence_id"])) for row in exact["occurrence_decisions"]] == exact["occurrence_decisions"]
    assert set(loaded["receipt"]["pending_occurrence_ids"]) == set(pending)
    assert loaded["receipt"]["explicit_unmatched_occurrence_ids"] == []
    assert all(row["accepted_qid"] is None for row in pending.values() if row["raw_type"] == "MISC")
    assert {row["supports"][0]["member"]["occurrence_id"] for row in aggregate["occurrences"]} == set(pending) | set(accepted)
    return loaded, aggregate


def run():
    inp = ROOT / "review_treatments/first_run_input_20261101_v1"
    assert digest(inp / "seal.json") == "03cd6fd90d609815c431ea234d9c32f0c10e98287b60d515439f15305b5e4089"
    seal = json.loads((inp / "seal.json").read_text())
    assert seal["source_input_ready"] and digest(inp / "first_unit.json") == seal["first_unit_sha256"]
    unit = json.loads((inp / "first_unit.json").read_text())
    stage = HERE / "exact_unit_0001"
    exact_receipt = json.loads((stage / "receipt.json").read_text())
    assert exact_receipt["status"] == "PASS_FIRST_UNIT_SUPPORTED_UNIQUE_EXACT"
    assert digest(stage / "decisions.json") == exact_receipt["decisions_sha256"]
    exact = json.loads((stage / "decisions.json").read_text(encoding="utf-8"))
    r2 = HERE / "real_unit_0001"
    r2_receipt = json.loads((r2 / "run_receipt.json").read_text())
    assert digest(r2 / "source_members.json") == r2_receipt["output_sha256"]["source_members.json"]
    rows = json.loads((r2 / "source_members.json").read_text(encoding="utf-8"))
    assert {r["source_row_index"] for r in rows} == set(unit["expected_row_indices"]) and len(rows) == 136
    assert {r["occurrence_id"] for r in rows} == set(r2_receipt["expected_occurrence_ids"])
    source_path = Path(unit["source_path"])
    source = source_path.read_bytes()
    assert hashlib.sha256(source).hexdigest() == unit["source_sha256"]
    paths = [E2 / "durable_unit.py", HERE / "occurrence_decisions.py", HERE / "aggregate_occurrences.py",
             ROOT / "source_custody/local_unit_contract.py", source_path, inp / "seal.json", inp / "first_unit.json",
             stage / "decisions.json", stage / "receipt.json", r2 / "source_members.json", r2 / "run_receipt.json"]
    protected = {str(path): digest(path) for path in paths}
    assert protected[str(E2 / "durable_unit.py")] == "3497b831e9103972be6772b5a917f18708dcbdafd295c4fcf7c7be0836134f11"
    members = [dict(row, original_row_index=row["source_row_index"]) for row in rows]
    decisions, pending = [], []
    for row in exact["occurrence_decisions"]:
        if row["accepted_qid"] is not None:
            decisions.append(dict(occurrence_id=row["occurrence_id"], qid=row["accepted_qid"],
                evidence=dict(exact_occurrence_record=row, exact_decisions_sha256=exact_receipt["decisions_sha256"],
                              exact_receipt_sha256=protected[str(stage / "receipt.json")])))
        else:
            assert row["none_decision"] is False
            pending.append(row)  # No explicit qid=None decision: absence remains pending.
    assert len(decisions) == 30 and len(pending) == 106
    scope_fields = ("input_sha256", "wiki_site", "page_id", "support_revision_id", "source_sha256", "policy_version")
    shard = {field: unit[field] for field in scope_fields}
    shard["row_indices"] = [row["source_row_index"] for row in rows]
    handoff = dict(manifest=unit, shards=[shard], occurrences=members, decisions=decisions,
                   pending_evidence=pending, version="first-unit-exact-v1", prior_version=None,
                   input_seal_sha256=protected[str(inp / "seal.json")])
    output = HERE / "real_handoff_0001"
    output.mkdir()
    slot = output / "sealed_v1"
    pinned = hashlib.sha256(encoded(handoff)).hexdigest()
    assert seal_unit(slot, handoff, source, pinned) is True
    loaded, aggregate = replay_check(slot, pinned, source, exact)
    assert loaded["handoff"] == handoff
    for original, saved in zip(rows, loaded["handoff"]["occurrences"]):
        assert all(saved[k] == value for k, value in original.items())
    sealed_before = {p.name: (digest(p), p.stat().st_mtime_ns) for p in slot.iterdir()}
    assert seal_unit(slot, deepcopy(handoff), source, pinned) is False
    assert sealed_before == {p.name: (digest(p), p.stat().st_mtime_ns) for p in slot.iterdir()}
    (output / "aggregate.json").write_text(json.dumps(aggregate, ensure_ascii=False, indent=2), encoding="utf-8")
    assert json.loads((output / "aggregate.json").read_text(encoding="utf-8")) == aggregate
    assert protected == {path: digest(Path(path)) for path in protected}
    receipt = dict(status="PASS_REAL_FIRST_VERSION_E2_E4_HANDOFF", checked_utc=datetime.now(timezone.utc).isoformat(),
                   page_id=unit["page_id"], processing_revision_id=unit["processing_revision_id"],
                   decision_version=handoff["version"], prior_version=None, pinned_unit_sha256=pinned,
                   original_occurrences=136, accepted_occurrences=30, pending_occurrences=106, explicit_none=0,
                   active_units=1, history_versions=1, physical_pages=1, accepted_identities=10,
                   exact_retry_unchanged=True, original_fields_preserved=True, exact_decisions_roundtrip=True,
                   misc_policy_unchanged=True, protected_sha256=protected, code_sha256=digest(Path(__file__)),
                   output_sha256={str(p.relative_to(output)): digest(p) for p in output.rglob("*") if p.is_file()},
                   consumer_export=False, publication=False, limits="One local writer/version; reviewed interface only, no power-loss or production resume guarantee", backup_status="Unprotected")
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in receipt.items() if not k.endswith("sha256")}, ensure_ascii=False))


if __name__ == "__main__":
    run()
