"""Read-only E2 recovery -> E4 replay; write review evidence only in our folder."""
import hashlib
import json
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
E2 = HERE.parent / "durable_units_direct_20261101"
RUN = E2 / "history_20261101T181248496557Z"
sys.path.insert(0, str(E2))
from durable_unit import encoded, recover
from occurrence_decisions import SCOPE_FIELDS, replace_unit
from aggregate_occurrences import aggregate_units


def check():
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    metadata = RUN / "verification.json"
    assert digest(metadata) == "8dfaa1de832cf80eda409e52d57e7f3ba441ecd8f5c1081e0972610758239417"
    evidence = json.loads(metadata.read_text())
    assert evidence["passed"] == 7 and evidence["failed"] == 0
    assert digest(E2 / "durable_unit.py") == evidence["code_sha256"]
    assert digest(E2 / "check_history.py") == evidence["check_sha256"]
    for relative, expected in evidence["output_sha256"].items():
        assert digest(RUN / relative) == expected
    original_suite = E2 / "run_20261101T181249330384Z"
    original = json.loads((original_suite / "verification.json").read_text())
    assert original["passed"] == 10 and original["failed"] == 0
    assert original["code_sha256"] == evidence["code_sha256"]
    for relative, expected in original["output_sha256"].items():
        assert digest(original_suite / relative) == expected
    protected_paths = [p for p in HERE.rglob("*") if p.is_file()]
    protected_paths += [p for folder in (RUN, original_suite) for p in folder.rglob("*") if p.is_file()]
    protected_paths += [E2 / "durable_unit.py", E2 / "check_history.py", E2 / "REPORT_HISTORY.md"]
    protected = {str(path): digest(path) for path in protected_paths}
    expected = json.loads((HERE / "case_0005/transitions.json").read_text())
    state, recovered, transitions = {}, [], []
    for index in range(2):
        relative = f"unit_{index}_v1\\unit.private.json"
        loaded = recover(RUN / f"unit_{index}_v1", evidence["output_sha256"][relative])
        assert loaded["status"] == "sealed"
        handoff = loaded["handoff"]
        source = (RUN / f"unit_{index}_v1/source.private.bin").read_bytes()
        assert replace_unit(state, handoff, source) is True
        assert replace_unit(state, handoff, source) is False
        recovered.append(handoff)
    transitions.append(dict(stage=expected[0]["stage"], aggregate=aggregate_units(state)))
    for index in range(2):
        pinned = evidence["output_sha256"][f"unit_{index}_v2\\unit.private.json"]
        slot = RUN / f"unit_{index}_v2"
        loaded = recover(slot, pinned, prior_history=[recovered[index]])
        handoff = loaded["handoff"]
        assert loaded["receipt"]["prior_history_sha256"] == hashlib.sha256(encoded([recovered[index]])).hexdigest()
        source = (slot / "source.private.bin").read_bytes()
        assert replace_unit(state, handoff, source) is True
        assert replace_unit(state, handoff, source) is False
        transitions.append(dict(stage=expected[index + 1]["stage"], aggregate=aggregate_units(state)))
        altered = deepcopy(recovered[index])
        altered["decisions"][0]["qid"] = "Q999"
        for history in ([], [altered], [handoff, recovered[index]]):
            try:
                recover(slot, pinned, prior_history=history)
            except ValueError:
                pass
            else:
                raise AssertionError("Missing, altered or reversed prior history must fail")
    assert transitions == expected
    final = transitions[-1]["aggregate"]
    assert len(state) == 2 and all(len(versions) == 2 for versions in state.values())
    assert final["unique_occurrences"] == 7 and final["support_records"] == 8
    assert final["identity_counts"] == [dict(qid="Q2", mention_count=1, page_count=1)]
    assert sum(bool(r["pending_supports"]) for r in final["occurrences"]) == 2
    assert sum(r["decision_values"] == [None] for r in final["occurrences"]) == 4
    # Current code can still read the earlier initial-version receipt without history.
    legacy = E2 / "run_20261101T180253493049Z"
    old_evidence = json.loads((legacy / "verification.json").read_text())
    assert recover(legacy / "before_seal", old_evidence["output_sha256"]["before_seal\\unit.private.json"])["status"] == "sealed"
    assert protected == {str(path): digest(path) for path in protected_paths}
    output = HERE / "case_0006"
    output.mkdir()
    (output / "replayed_transitions.json").write_text(json.dumps(transitions, indent=2), encoding="utf-8")
    result = dict(status="PASS", checked_utc=datetime.now(timezone.utc).isoformat(),
                  review="No blocking defect found within caller-pinned generated v1/v2 single-writer scope",
                  e2_reported_checks=dict(history=7, original=10), e2_suites_rerun=False,
                  e2_history_artifacts_verified=len(evidence["output_sha256"]),
                  e2_original_artifacts_verified=len(original["output_sha256"]),
                  caller_owned_history_and_pins_required=True, sealed_units=2, recovered_versions=4,
                  rejected_bad_histories=6, pending_occurrences=2, explicit_unmatched=4,
                  code_sha256=digest(Path(__file__)), e2_code_sha256=evidence["code_sha256"],
                  protected_sha256=protected, output_sha256={str(p.relative_to(output)): digest(p) for p in output.iterdir()},
                  limits="Read-only recovery of existing synthetic seals; no new crash or power-loss tests; no production resume registry", backup_status="Unprotected")
    (HERE / "verification_case_0006.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("PASS: E2 sealed v1/v2 -> E4 all case0005 transitions; six bad histories rejected; pending2/unmatched4 retained; legacy receipt readable; E2 unchanged")


if __name__ == "__main__":
    check()
