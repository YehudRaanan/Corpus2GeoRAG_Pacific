"""Authorized append-only evidence maintenance for exactly the two shared plans."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
PLAN_ROOT = Path(r"C:\Users\User\Documents\Codex\2026-11-01\task")
TARGETS = [PLAN_ROOT / "GEOAI_DEVELOPMENT_PLAN.md", PLAN_ROOT / "GEOAI_RUNTIME_BATCH_PLAN.md"]
MARKER = "## Direct-session ownership and fixture evidence - 2026-11-01"
sha = lambda data: hashlib.sha256(data).hexdigest()

STATUS = """

## Direct-session ownership and fixture evidence - 2026-11-01

Parent-assigned direct-session status/evidence update. Earlier dated records remain historical. Existing approved tasks, gates, source policies, budget, consumer contract and production input barrier are unchanged. The parent manages dispatch; this records the assigned ownership and observed fixtures.

| Direct lane | Existing plan mapping | Assigned scope |
|---|---|---|
| INPUT | Tasks 1-2 / E1-E2; R0-R1 | Authoritative input preparation, cleaning/templates and page/revision binding in its existing input lane. Full-input readiness requires that owner's verified evidence. |
| TRAIN | T0-T4; joins Task 3 / E3b | Exclusive joint-model preparation/capacity, authorized two-stage training and artifact receipts. This update verifies no actual GPU execution, completed warmup/joint training or fitted artifact; those require TRAIN receipts. |
| INTEGRATION | Task 4 / E4; limited fixtures for Tasks 1,5,7,8 | Writes integration_direct_20261101 only; shared implementations read-only. Sole status/evidence writer of these two plans by parent assignment. |
| E2 durability | Task 2 / E2 | Separate direct session owns durable_units_direct_20261101; generated sealed-unit checks only. It does not own INPUT preparation or E4 aggregation. Bounded increment completed; parent reports worker stopped. |

Generated evidence under D:/Projects/GeoAI-incremental-dev-20261101/integration_direct_20261101, all with fresh-process readback:

| Case / report | Measured result and boundary |
|---|---|
| [0001](D:/Projects/GeoAI-incremental-dev-20261101/integration_direct_20261101/REPORT.md) | Grouping -> accepted-QID merge -> exact existing Entity rows -> exporter/native selector -> consumer. Nine retained mentions, four nodes/two views, unchanged geometry; pending/unbound evidence private. |
| [0002](D:/Projects/GeoAI-incremental-dev-20261101/integration_direct_20261101/REPORT_CASE_0002.md) | Both-native: four producer views -> two native assertions, independent 1942/1943 dates; previous case/geometry unchanged. |
| [0003](D:/Projects/GeoAI-incremental-dev-20261101/integration_direct_20261101/REPORT_CASE_0003.md) | One closed-unit occurrence-decision replacement: seven members/two history versions; six invalid handoffs rejected; exact replay adds no contribution. |
| [0004](D:/Projects/GeoAI-incremental-dev-20261101/integration_direct_20261101/REPORT_CASE_0004.md) | Two revision units: 14 supports -> seven original occurrences, keyed by input hash + original row index. Q1 three mentions/one page; one identity conflict retained without winner. Counts are partial. |
| [0005](D:/Projects/GeoAI-incremental-dev-20261101/integration_direct_20261101/REPORT_CASE_0005.md) | Replacement -> aggregation: Q1 mentions 3->1->0 and pages 1->1->0; Q2 page remains. Seven originals/eight supports/four history versions retained; replay stable. |

Separate E2 evidence: [REPORT](D:/Projects/GeoAI-incremental-dev-20261101/durable_units_direct_20261101/REPORT.md), [verification](D:/Projects/GeoAI-incremental-dev-20261101/durable_units_direct_20261101/run_20261101T180253493049Z/verification.json). Ten focused checks passed: private source/unit writes, hash/membership readback, sealed receipt, process interruption before/after seal, recovery, exact retry and hash conflicts; recovered units reproduce case 0004. Parent independently verified 18 outputs/41 protected hashes. Initial versions, one writer and simulated process interruption only; not correction-history persistence, production recovery, directory fsync or power-loss durability.

These are partial development fixtures, not broad Tasks 2-8 completion or production batches. Cases 0001/0002 use synthetic catalog v2.1.2, distinct from the earlier real-v2.1.1 selector check. Cases 0003-0005 exercise no relation catalog or weighted consumer export.

Remaining interfaces: authoritative prepared-input/accepted decisions, occurrence-aware Entity/mention projection for heterogeneous name groups, E2 sealed-receipt replay with versioned reducer history, pair relation/count integration and coherent publication. Current E2 receipt validation starts from an empty reducer, so successor decisions with prior_version require separately scoped history-aware integration. Conflicting/pending evidence remains explicit; no winner or acceptance policy is selected. Existing G11 weight representation, G12 batch/timer semantics, global input barrier and production resource gates remain in force. Fixture JSON readback is not crash durability. No cloud, acquisition, Git, publication or worker dispatch occurred in this documentation operation. Backup: Unprotected.
"""

if __name__ == "__main__":
    assert (HERE / "PLAN_STATUS_EDITS.md").is_file()
    for case in range(1, 6):
        name = "verification.json" if case == 1 else f"verification_case_{case:04d}.json"
        assert json.loads((HERE / name).read_text())["status"] == "PASS"
    originals = {path: path.read_bytes() for path in TARGETS}
    assert all(MARKER.encode() not in data for data in originals.values()), "Status already appended; inspect before retry"
    backup = HERE / "plan_status_before"
    backup.mkdir()
    receipt = dict(updated_utc=datetime.now(timezone.utc).isoformat(), operation="append status/evidence only", files=[])
    for path, before in originals.items():
        (backup / path.name).write_bytes(before)
        addition = STATUS.replace("\n", "\r\n").encode("utf-8")
        assert path.read_bytes() == before, "Plan changed before append"
        with path.open("ab") as stream:
            stream.write(addition)
        after = path.read_bytes()
        assert after == before + addition, "Prior bytes or status differ"
        receipt["files"].append(dict(path=str(path), before_bytes=len(before), before_sha256=sha(before),
                                     appended_bytes=len(addition), appended_sha256=sha(addition),
                                     after_sha256=sha(after), prior_bytes_preserved=True))
    (HERE / "plan_status_update_receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print("PASS: both plans appended with status/evidence only; every prior byte preserved; four direct ownership lanes recorded")
