# Eleven retained targets — bounded cache/redirect follow-up

**PASS**, 2026-11-01 20:01:38 UTC. Examined seven existing title-mapping tables, 345 saved collection request responses and the existing Wikidata metadata/sitelink snapshot. No network request, broad crawl, cache mutation or new QID was fabricated. The earlier ledger and first-unit grouping remain unchanged.

Five formerly unresolved source targets now have exact cached enwiki sitelink evidence:

| Retained target | Cached QID |
|---|---|
| Boeing B-29 Superfortress variants | Q3641558 |
| Haywood S. Hansell | Q5687462 |
| Mather Air Force Base | Q6786927 |
| Nakajima Ki-44 | Q700727 |
| Tokyo Rose | Q1910347 |

Evidence is C:/Users/User/.cache/geoai_bigquery_20261018/entity_metadata.json.gz with table_snapshot.json timestamp 2026-10-18T18:45:19.304197+00:00. This is current/cached title-to-QID metadata, separate from the verified processing-revision source spans. Saved redirect responses did not supply an additional supported mapping for the remaining targets; no case-folding, alias or fuzzy inference was substituted.

Coverage is now **24/30 relevant titles**, with **23 distinct cached QID candidates**. All original component decisions and source records remain identical. Exclusively excluded targets still contribute no active QID; the 66 template records, including two ambiguous wrappers and unsupported IN templates, remain explicit and unchanged.

## Remaining targets and exact reason

- 3d Photographic Squadron
- 47th Sentai
- Photographic processing
- Ralph D. Steakley
- ground speed
- jet stream

For each: no supported exact title/sitelink or saved explicit normalization/redirect-to-QID evidence was found in the inspected caches. This means pending mapping evidence, not that the source has no matching identity and not a NONE training/inference label. The exact per-target evidence/search results are target_updates.json.

## Positive exact evidence and G3/G5

The known relevant candidates' cached canonical labels provide **15 single-literal-candidate groups / 37 occurrences**. These are case-sensitive label-equality diagnostics, not executed exact_pairs acceptance or calibrated identity decisions. All 69 groups/136 original occurrence IDs remain represented, including every DATE/MISC group, repair flags and unresolved record.

The 15 positive groups are LOC five, ORG four, PER one and MISC five; none has a changed processing surface. Thus DATE exclusion or repaired-group policy does not need to block reviewing these positive records. Source/type evidence can first be checked on the ten LOC/ORG/PER groups, with MISC eligibility kept explicit instead of silently treating unknown types as compatible.

Missing coverage for six other titles is **not a blanket veto on supported positive exact evidence** and does not require complete corpus coverage. For acceptance, the existing G3 source/type/literal eligibility and G5 occurrence/repair/ambiguity treatment must apply to the affected positive records. We did not silently inherit legacy MISC/unknown-type compatibility, DATE exclusion or repaired-group skipping. A unique known candidate is not asserted unique among unobserved eligible alternatives. No automatic accepted decision or SYN assignment was produced. The next concrete policy/application step can focus on these 15 groups and their supported source/type/repair evidence rather than waiting for every target to resolve.

## Verification

resolve_unit_candidate_cache.py ran with the existing .venv-template-pilot, bytecode disabled. It wrote only candidate_cache_0002/{ledger.json,target_updates.json,literal_positive_evidence.json,receipt.json}. JSON readback passed; all inspected cache and prior result hashes stayed unchanged. A separate fresh process reverified code/protected/output hashes, 24 mapped relevant targets/23 QIDs, unchanged component/template evidence, all 136 unique IDs and zero accepted decisions. No consumer output or publication. Backup: Unprotected.
