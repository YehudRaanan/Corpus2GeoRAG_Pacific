"""E2 generated-fixture check. One writer; no production/power-loss guarantee."""
import hashlib
import json
import os
import subprocess
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True  # Imports must not write into shared source folders.
HERE = Path(__file__).resolve().parent
ROOT = Path("D:/Projects/GeoAI-incremental-dev-20261101")
INTEGRATION = ROOT / "integration_direct_20261101"
sys.path.insert(0, str(INTEGRATION))
from aggregate_occurrences import aggregate_units
from occurrence_decisions import SCOPE_FIELDS, active_occurrences, replace_unit
from local_unit_contract import source_membership_ready


# Stable JSON gives the caller a pinned byte hash. Example: key order alone changes nothing.
def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def sha(data):
    return hashlib.sha256(data).hexdigest()


# A seal records custody, not resolved identities. Example: o7/o8 stay pending after sealing.
def receipt_for(handoff, source_bytes, prior_history=()):
    if not source_membership_ready(handoff["manifest"], handoff["shards"], source_bytes):
        raise ValueError("Source membership is incomplete; unit stays unsealed")
    state = {}
    # Example: replay sealed v1 before validating v2; never turn a correction into a new initial version.
    scope = tuple(handoff["manifest"][k] for k in SCOPE_FIELDS)
    for previous in prior_history:
        if tuple(previous["manifest"][k] for k in SCOPE_FIELDS) != scope:
            raise ValueError("Prior history belongs to a different unit scope")
        replace_unit(state, previous, source_bytes)
    if handoff["prior_version"] != (prior_history[-1]["version"] if prior_history else None):
        raise ValueError("Declared prior version is not the supplied active history version")
    replace_unit(state, handoff, source_bytes)  # Reuse exact membership/decision validation.
    active = active_occurrences(state)
    receipt = dict(format="generated-unit-seal-v1", unit_sha256=sha(encoded(handoff)),
                source_sha256=sha(source_bytes),
                scope={k: handoff["manifest"][k] for k in SCOPE_FIELDS},
                decision_version=handoff["version"],
                pending_occurrence_ids=[r["member"]["occurrence_id"] for r in active if r["decision"] is None],
                explicit_unmatched_occurrence_ids=[r["member"]["occurrence_id"] for r in active
                                                  if r["decision"] is not None and r["decision"]["qid"] is None])
    if prior_history:
        receipt["prior_history_sha256"] = sha(encoded(prior_history))
    return receipt


# Missing seal means pending, even with complete files. Example: exit before rename -> no acknowledgment.
def recover(directory, expected_unit_sha256, prior_history=()):
    directory = Path(directory)
    if not (directory / "seal.json").exists():
        return dict(status="pending", reason="unsealed")
    receipt = json.loads((directory / "seal.json").read_text(encoding="utf-8"))
    unit_bytes = (directory / "unit.private.json").read_bytes()
    if sha(unit_bytes) != expected_unit_sha256 or receipt.get("unit_sha256") != expected_unit_sha256:
        raise ValueError("Sealed unit hash differs from caller's pinned hash")
    handoff = json.loads(unit_bytes)
    expected_receipt = receipt_for(handoff, (directory / "source.private.bin").read_bytes(), prior_history)
    if receipt != expected_receipt:
        raise ValueError("Seal differs from validated unit/source receipt")
    return dict(status="sealed", handoff=handoff, receipt=receipt)


# Close and flush each private file before validation. Example: a short write never earns a seal.
def write_flushed(path, content):
    with path.open("wb") as stream:
        stream.write(content)
        stream.flush()
        os.fsync(stream.fileno())


# Only the final rename acknowledges completion. Example: same sealed unit -> False, no new receipt.
def seal_unit(directory, handoff, source_bytes, expected_unit_sha256, stop_at=None, prior_history=()):
    directory = Path(directory)
    unit_bytes = encoded(handoff)
    if sha(unit_bytes) != expected_unit_sha256:
        raise ValueError("Proposed unit hash differs from caller's pinned hash")
    if (directory / "seal.json").exists():
        receipt_for(handoff, source_bytes, prior_history)  # Reject wrong source/history on an exact retry.
        recover(directory, expected_unit_sha256, prior_history)
        return False
    directory.mkdir(parents=True, exist_ok=True)
    write_flushed(directory / "unit.private.json", unit_bytes)
    write_flushed(directory / "source.private.bin", source_bytes)
    stored_bytes = (directory / "unit.private.json").read_bytes()
    if sha(stored_bytes) != expected_unit_sha256:
        raise ValueError("Stored unit hash differs from caller's pinned hash")
    receipt = receipt_for(json.loads(stored_bytes), (directory / "source.private.bin").read_bytes(), prior_history)
    write_flushed(directory / "seal.private.json", encoded(receipt))
    if stop_at == "before_seal":
        os._exit(73)  # Test-only process interruption, after private write and before acknowledgment.
    # ponytail: single writer, same-directory rename; no locks or power-loss guarantee.
    (directory / "seal.private.json").rename(directory / "seal.json")
    if stop_at == "after_seal":
        os._exit(73)  # Test-only interruption before the caller receives the success response.
    return True


# Each run gets a new directory. Example: a previous failed test remains available for inspection.
def self_check():
    protected_paths = [p for p in INTEGRATION.rglob("*") if p.is_file()]
    protected_paths += list((ROOT / "source_custody").glob("*.py"))
    protected = {str(p): sha(p.read_bytes()) for p in protected_paths}
    evidence = json.loads((INTEGRATION / "verification_case_0004.json").read_text())
    fixture = INTEGRATION / "case_0004"
    for name, digest in evidence["output_sha256"].items():
        assert sha((fixture / name).read_bytes()) == digest, name
    units = json.loads((fixture / "units.json").read_text())
    first, second = [u["versions"][0] for u in units]
    source_a = (fixture / "source_revision_10.bin").read_bytes()
    source_b = (fixture / "source_revision_11.bin").read_bytes()
    expected_a, expected_b = sha(encoded(first)), sha(encoded(second))
    run = HERE / ("run_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    run.mkdir()
    checks = []

    def rejects(operation):
        try:
            operation()
        except ValueError:
            return
        raise AssertionError("Expected ValueError")

    # Real child-process exits leave files behind. Example: before_seal -> pending, never complete.
    def interrupted(name, handoff, source, expected, point):
        directory = run / name
        directory.mkdir()
        (directory / "request.json").write_bytes(encoded(handoff))
        (directory / "request.bin").write_bytes(source)
        child = subprocess.run([sys.executable, "-B", str(Path(__file__)), "interrupt",
                                str(directory), expected, point], capture_output=True, text=True)
        assert child.returncode == 73, (child.returncode, child.stdout, child.stderr)
        return directory

    a = interrupted("before_seal", first, source_a, expected_a, "before_seal")
    assert recover(a, expected_a) == {"status": "pending", "reason": "unsealed"}
    assert not (a / "seal.json").exists()
    checks.append("process_exit_before_seal_is_pending")
    assert seal_unit(a, first, source_a, expected_a) is True
    recovered_a = recover(a, expected_a)
    assert recovered_a["handoff"] == first and recovered_a["status"] == "sealed"
    checks.append("retry_after_before_seal_completes")

    b = interrupted("after_seal", second, source_b, expected_b, "after_seal")
    recovered_b = recover(b, expected_b)
    assert recovered_b["handoff"] == second and recovered_b["status"] == "sealed"
    checks.append("process_exit_after_seal_recovers")
    before = {str(p): (sha(p.read_bytes()), p.stat().st_mtime_ns)
              for d in (a, b) for p in d.iterdir()}
    assert seal_unit(a, first, source_a, expected_a) is False
    assert seal_unit(b, second, source_b, expected_b) is False
    assert before == {str(Path(p)): (sha(Path(p).read_bytes()), Path(p).stat().st_mtime_ns) for p in before}
    assert len(list(run.rglob("seal.json"))) == 2
    checks.append("exact_retries_do_not_write_or_duplicate_seal")

    altered = deepcopy(first)
    altered["decisions"][0]["qid"] = "Q999"
    rejects(lambda: seal_unit(a, altered, source_a, expected_a))
    rejects(lambda: seal_unit(a, altered, source_a, sha(encoded(altered))))
    rejects(lambda: recover(a, "0" * 64))
    checks.append("conflicting_proposed_and_existing_hashes_rejected")

    rejects(lambda: seal_unit(a, first, b"wrong source", expected_a))
    bad_source = run / "wrong_source"
    rejects(lambda: seal_unit(bad_source, first, b"wrong source", expected_a))
    incomplete = deepcopy(first)
    incomplete["shards"][0]["row_indices"].pop()
    missing = run / "incomplete_membership"
    rejects(lambda: seal_unit(missing, incomplete, source_a, sha(encoded(incomplete))))
    assert not (bad_source / "seal.json").exists() and not (missing / "seal.json").exists()
    checks.append("wrong_source_and_incomplete_membership_never_seal")

    partial = run / "partial_private"
    partial.mkdir()
    (partial / "unit.private.json").write_bytes(b'{"manifest":')
    assert recover(partial, expected_a)["status"] == "pending"
    assert seal_unit(partial, first, source_a, expected_a) is True
    assert recover(partial, expected_a)["handoff"] == first
    checks.append("unsealed_partial_file_can_be_rewritten_on_retry")

    # Tamper only with test-owned copies. Example: a valid seal cannot hide altered source bytes.
    for filename in ("source.private.bin", "unit.private.json", "seal.json"):
        target = partial / filename
        original = target.read_bytes()
        target.write_bytes(original + b"x")
        rejects(lambda: recover(partial, expected_a))
        target.write_bytes(original)
    assert recover(partial, expected_a)["status"] == "sealed"
    checks.append("sealed_source_unit_and_receipt_tampering_rejected")

    state = {}
    for recovered, source in ((recovered_a, source_a), (recovered_b, source_b)):
        assert replace_unit(state, recovered["handoff"], source) is True
        assert replace_unit(state, recovered["handoff"], source) is False
    result = aggregate_units(state)
    assert result == json.loads((fixture / "aggregation.json").read_text())
    assert recovered_a["receipt"]["pending_occurrence_ids"] == ["o7", "o8"]
    assert recovered_b["receipt"]["pending_occurrence_ids"] == ["o7", "o8"]
    assert result["unique_occurrences"] == 7 and result["support_records"] == 14
    assert sum(r["identity_conflict"] for r in result["occurrences"]) == 1
    checks.append("recovered_units_preserve_provenance_pending_conflict_and_aggregate")
    assert protected == {str(p): sha(p.read_bytes()) for p in protected_paths}
    checks.append("shared_inputs_unchanged")
    (run / "recovered_aggregation.json").write_bytes(encoded(result))
    report = dict(status="PASS", checks=checks, passed=len(checks), failed=0,
                  checked_utc=datetime.now(timezone.utc).isoformat(),
                  code_sha256=sha(Path(__file__).read_bytes()), protected_sha256=protected,
                  input_verification_sha256=sha((INTEGRATION / "verification_case_0004.json").read_bytes()),
                  output_sha256={str(p.relative_to(run)): sha(p.read_bytes()) for p in run.rglob("*") if p.is_file()},
                  backup_status="Unprotected", production=False, power_loss_guarantee=False,
                  limits="One writer, initial decision versions, synthetic units, process exits only; no DB/queue/cadence")
    (run / "verification.json").write_bytes(encoded(report))
    print(json.dumps(dict(status="PASS", passed=len(checks), failed=0, run=str(run),
                         code_sha256=report["code_sha256"], verification_sha256=sha((run / "verification.json").read_bytes()))))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "interrupt":
        path = Path(sys.argv[2])
        seal_unit(path, json.loads((path / "request.json").read_text(encoding="utf-8")),
                  (path / "request.bin").read_bytes(), sys.argv[3], sys.argv[4])
    else:
        self_check()
