# E2 follow-up: sealed corrections with prior history

Status: **PASS — 7 new history checks and 10 existing E2 checks**, 2026-11-01 18:12 UTC. No shared source or plan edits.

This follow-up supersedes the initial-version-only limitation in REPORT.md. It is still a generated-fixture experiment with one local writer and no production or power-failure guarantee.

## Minimal interface change

`receipt_for`, `seal_unit` and `recover` now accept `prior_history=()`. For a correction, the caller supplies the previously recovered handoffs for that same source unit, ordered from first to latest. The implementation rebuilds validation state with the existing `replace_unit`, requires `prior_version` to match the last prior version, then validates the proposed correction. The receipt binds the full prior history using `prior_history_sha256`. Initial-version receipts keep their existing format and remain readable.

Example: recover v1 using its independently pinned unit hash, pass `[v1]` when sealing/recovering v2, and replay the recovered handoffs into the existing reducer. Each version has its own immutable slot. Exact retries use the same prior history and return False without writing. Source unit scope and occurrence membership remain unchanged by corrections.

No registry, directory scanner, automatic history discovery or reducer database was added. The caller still owns ordering, slot paths, prior-history retrieval and independently pinned hashes. This verifies a supplied chain; it is not a general production resume protocol.

## Evidence and behavior

Read the exact `check_page_withdrawal.py`, `occurrence_decisions.py`, `verification_case_0005.json` and case-0005 artifacts before changing code. Verified all four case-0005 output hashes before reuse.

The first new check failed as expected because `seal_unit` lacked `prior_history`; the child process reported TypeError for that missing argument. The minimal implementation then passed these seven checks in `check_history.py`:

1. Both original v1 units seal and recover before their v2 corrections.
2. Missing history and altered-but-contract-valid prior content cannot recover a correction; each v2 receipt binds its exact prior-history hash.
3. Actual child-process exit before one v2 seal and after the other v2 seal permits the expected pending/retry or sealed recovery.
4. Exact v2 retries preserve all file hashes and modification times.
5. Replay into a fresh reducer exactly matches all three integration case-0005 transitions, preserves two versions per unit and retains every original member. Duplicate replay contributes nothing twice.
6. A stale `prior_version` is rejected; first-version receipts remain readable without prior history.
7. Protected shared inputs remain unchanged.

Replayed Q1 mention counts: **3 → 1 → 0**. Q1 page counts: **1 → 1 → 0**. Q2 page support: **1 → 1 → 1**. Seven original occurrences, eight support records and four history versions remain. The final two pending occurrences stay pending and four explicitly unmatched occurrences remain distinct from pending.

The original ten-check suite also passed after the change. No broader corpus or paid job ran; no agents or nested sessions were created.

## Artifacts and hashes

Owned root: `D:\Projects\GeoAI-incremental-dev-20261101\durable_units_direct_20261101`.

| Artifact | SHA-256 |
|---|---|
| durable_unit.py | 3497b831e9103972be6772b5a917f18708dcbdafd295c4fcf7c7be0836134f11 |
| history_20261101T181248496557Z/verification.json | 8dfaa1de832cf80eda409e52d57e7f3ba441ecd8f5c1081e0972610758239417 |
| run_20261101T181249330384Z/verification.json | e3369076720e7f5b4bee11490618bd5ef1340d6c53716e9637fdf2879d4136c6 |

The history verification records the test-code hash, all generated artifact hashes and protected-input hashes. The generated `replayed_transitions.json` equals the integration transitions as parsed data. Old failed and successful run directories were preserved.

Run the checks using `python -B ...\check_history.py` and `python -B ...\durable_unit.py`; both create new owned run directories.

## Remaining dependency and proposed plan edit

No blocker remains for this bounded generated v1→v2 increment. Parent review/integration is next. Production still requires the approved ingestion/cleaning/binding barrier and runtime envelope; no power-loss, distributed writer or automatic full-ingestion recovery claim is made. Backup status remains **Unprotected**.

Proposed status edit for parent only:

> E2 follow-up PASS: seven generated correction/history checks plus ten original checks. Durable v1/v2 seals bind exact prior history; before/after-seal process exits recover; duplicate retries do not rewrite or double-contribute; fresh reducer replay exactly matches case0005 withdrawals, retaining prior versions, provenance and explicit pending. One writer and caller-provided ordered histories/pinned hashes only; production recovery and power-loss durability remain unproven. Evidence: durable_units_direct_20261101/REPORT_HISTORY.md.
