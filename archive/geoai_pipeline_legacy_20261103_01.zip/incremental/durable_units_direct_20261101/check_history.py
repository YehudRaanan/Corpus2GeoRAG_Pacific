"""Small generated E2 correction/restart check against integration case 0005."""
import json
import subprocess
import sys
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
from durable_unit import HERE, INTEGRATION, ROOT, SCOPE_FIELDS, aggregate_units, encoded, recover, replace_unit, seal_unit, sha


def check():
    protected_paths = [p for p in INTEGRATION.rglob("*") if p.is_file()]
    protected_paths += list((ROOT / "source_custody").glob("*.py"))
    protected = {str(p): sha(p.read_bytes()) for p in protected_paths}
    fixture = INTEGRATION / "case_0005"
    evidence = json.loads((INTEGRATION / "verification_case_0005.json").read_text())
    for name, digest in evidence["output_sha256"].items():
        assert sha((fixture / name).read_bytes()) == digest
    units = json.loads((fixture / "units.json").read_text())
    expected = json.loads((fixture / "transitions.json").read_text())
    run = HERE / ("history_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    run.mkdir()
    checks, slots, history = [], [], {}

    def rejects(operation):
        try:
            operation()
        except ValueError:
            return
        raise AssertionError("Invalid/missing history should fail")

    # v1 must be recovered before v2. Example: no prior state -> correction cannot be sealed.
    for index, unit in enumerate(units):
        source = (fixture / f"source_revision_{unit['scope']['support_revision_id']}.bin").read_bytes()
        v1, v2 = unit["versions"]
        first = run / f"unit_{index}_v1"
        assert seal_unit(first, v1, source, sha(encoded(v1))) is True
        old = recover(first, sha(encoded(v1)))["handoff"]
        key = tuple(unit["scope"][k] for k in SCOPE_FIELDS)
        history[key] = [old]
        invalid = run / f"missing_prior_{index}"
        rejects(lambda: seal_unit(invalid, v2, source, sha(encoded(v2))))
        assert not (invalid / "seal.json").exists()
        second = run / f"unit_{index}_v2"
        second.mkdir()
        for name, value in (("request.json", v2), ("history.json", [old])):
            (second / name).write_bytes(encoded(value))
        (second / "request.bin").write_bytes(source)
        point = "before_seal" if index == 0 else "after_seal"
        child = subprocess.run([sys.executable, "-B", str(Path(__file__)), "interrupt", str(second), point],
                               capture_output=True, text=True)
        assert child.returncode == 73, (child.returncode, child.stdout, child.stderr)
        if point == "before_seal":
            assert recover(second, sha(encoded(v2)), prior_history=[old])["status"] == "pending"
            assert seal_unit(second, v2, source, sha(encoded(v2)), prior_history=[old]) is True
        loaded = recover(second, sha(encoded(v2)), prior_history=[old])
        assert loaded["handoff"] == v2
        assert loaded["receipt"]["prior_history_sha256"] == sha(encoded([old]))
        rejects(lambda: recover(second, sha(encoded(v2))))
        altered = deepcopy(old)
        altered["decisions"][0]["qid"] = "Q999"
        rejects(lambda: recover(second, sha(encoded(v2)), prior_history=[altered]))
        slots.append((first, second, source, key, v1, v2))
    checks += ["v1_sealed_and_recovered_before_v2", "v2_requires_exact_validated_history",
               "v2_process_exit_before_and_after_seal_recovers"]

    # An exact retry is not a new acknowledgment. Example: v2 remains one immutable receipt.
    before = {str(p): (sha(p.read_bytes()), p.stat().st_mtime_ns) for p in run.rglob("*") if p.is_file()}
    for _, second, source, key, _, v2 in slots:
        assert seal_unit(second, v2, source, sha(encoded(v2)), prior_history=history[key]) is False
    assert before == {p: (sha(Path(p).read_bytes()), Path(p).stat().st_mtime_ns) for p in before}
    checks.append("v2_retries_preserve_receipts_and_files")

    # Replay reads sealed files into a fresh reducer. Q1 page support survives until its last withdrawal.
    state, transitions = {}, []
    for phase in (0, 1):
        for first, second, source, key, v1, v2 in slots:
            directory, proposed = (first, v1) if phase == 0 else (second, v2)
            loaded = recover(directory, sha(encoded(proposed)), prior_history=state.get(key, []))
            assert replace_unit(state, loaded["handoff"], source) is True
            assert replace_unit(state, loaded["handoff"], source) is False
            if phase == 1 or len(state) == 2:
                transitions.append(dict(stage=expected[len(transitions)]["stage"], aggregate=aggregate_units(state)))
    assert transitions == expected
    assert all(len(versions) == 2 for versions in state.values())
    assert all(versions[0]["occurrences"] == versions[1]["occurrences"] for versions in state.values())
    checks.append("fresh_reducer_replay_matches_all_case0005_transitions_and_retains_history")

    # A stale correction cannot follow v2. Existing immutable v1 seals remain readable without history.
    for first, _, source, key, v1, v2 in slots:
        assert recover(first, sha(encoded(v1)))["handoff"] == v1
        stale = deepcopy(v2)
        stale["version"] += "-bad"
        rejects(lambda: seal_unit(run / "stale", stale, source, sha(encoded(stale)), prior_history=state[key]))
    checks.append("stale_prior_rejected_and_v1_receipts_stay_readable")
    assert protected == {str(p): sha(p.read_bytes()) for p in protected_paths}
    checks.append("shared_inputs_unchanged")
    (run / "replayed_transitions.json").write_bytes(encoded(transitions))
    report = dict(status="PASS", passed=len(checks), failed=0, checks=checks,
                  code_sha256=sha((HERE / "durable_unit.py").read_bytes()), check_sha256=sha(Path(__file__).read_bytes()),
                  protected_sha256=protected, input_verification_sha256=sha((INTEGRATION / "verification_case_0005.json").read_bytes()),
                  output_sha256={str(p.relative_to(run)): sha(p.read_bytes()) for p in run.rglob("*") if p.is_file()},
                  limits="Generated v1/v2, caller-supplied verified history and pinned hashes, one writer; no production/power-loss guarantee",
                  backup_status="Unprotected")
    (run / "verification.json").write_bytes(encoded(report))
    print(json.dumps(dict(status="PASS", passed=len(checks), failed=0, run=str(run),
                         code_sha256=report["code_sha256"], verification_sha256=sha((run / "verification.json").read_bytes()))))


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "interrupt":
        path = Path(sys.argv[2])
        handoff = json.loads((path / "request.json").read_text())
        seal_unit(path, handoff, (path / "request.bin").read_bytes(), sha(encoded(handoff)),
                  stop_at=sys.argv[3], prior_history=json.loads((path / "history.json").read_text()))
    else:
        check()
