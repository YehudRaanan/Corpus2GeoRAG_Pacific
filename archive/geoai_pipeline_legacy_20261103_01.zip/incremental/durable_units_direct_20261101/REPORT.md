# E2 bounded durability increment — 2026-11-01

Historical initial increment. The current code also supports supplied prior history; see REPORT_HISTORY.md for the follow-up interface, current code hash and seven additional checks. Hashes below describe the original run.

Status: **PASS, 10 focused checks, 0 failed** in the completed run. This is generated-fixture development, not full task-2 acceptance or production durability.

Owned directory: `D:\Projects\GeoAI-incremental-dev-20261101\durable_units_direct_20261101`.
Code: `durable_unit.py`, one readable Python file, standard library only.
Completed run: `run_20261101T180253493049Z`.

## Behavior and exact interface

`seal_unit(directory, handoff, source_bytes, expected_unit_sha256)` writes the unchanged handoff as canonical UTF-8 JSON and retains exact source bytes in private files, reads them back, checks the caller-pinned unit hash, and validates custody/membership using existing `source_membership_ready` and `replace_unit`. A flushed private receipt becomes `seal.json` through a same-directory rename. Only this final seal acknowledges completion. It returns True for a new seal and False for an exact retry, without rewriting a sealed unit.

`recover(directory, expected_unit_sha256)` returns explicit `status=pending, reason=unsealed` before the seal exists. With a seal, it checks the exact stored unit hash, source bytes, membership, occurrence/decision contract and receipt before returning the original handoff and receipt with `status=sealed`. Invalid sealed content raises; it is never silently promoted or rewritten. The caller must retain the expected hash independently; this fixture does not establish an authenticated external registry.

The private receipt retains the six existing scope fields: `input_sha256`, `wiki_site`, `page_id`, `support_revision_id`, `source_sha256`, `policy_version`, plus the supplied decision version and explicit pending/unmatched IDs. No consumer contract changed. `sealed` describes persistence/custody, not resolved identity decisions.

## Input provenance

Read `source_custody/local_unit_contract.py`, `integration_direct_20261101/occurrence_decisions.py`, `aggregate_occurrences.py`, `verification_case_0004.json`, and the exact generated case-0004 unit/source artifacts. All four case-0004 artifact hashes were checked against that verification before use. No shared sources or plans were edited; hashes of existing integration files and custody code were checked unchanged.

The two supplied initial versions are `unit-a-decisions-v1` and `unit-b-decisions-v1` with `prior_version=None`, processing support revisions 10 and 11. Original occurrence provenance, source pointers, aliases and evidence remain byte-equivalent in canonical handoff data. The source bytes are exactly `abc` and `abd`. These are generated examples; `input_sha256` is an inherited fixture label, not a claim that a full input corpus was read or verified.

## Actual checks

1. Child Python process exits with code 73 before the seal rename: recovery is pending and no acknowledgment exists.
2. Retry after that exit creates a validated seal and recovers the unchanged handoff.
3. Child process exits with code 73 after the seal rename: recovery succeeds even though the caller never received a response.
4. Exact retries of both sealed units return False and preserve all file hashes and modification times; no duplicate seal.
5. Conflicting proposed content under an old hash, new content/hash against an existing slot, and wrong expected recovery hash are rejected.
6. Wrong source bytes and incomplete shard membership create no seal.
7. A truncated unsealed private JSON file remains pending and can be rewritten by an authorized retry with the pinned complete input.
8. Altered sealed source bytes, unit bytes or receipt JSON are rejected. Only test-owned copies were modified and restored.
9. Recovered units replay into the existing reducer with no duplicate contribution; aggregation equals the existing case-0004 JSON as data. There are 14 supports, seven original occurrences, one identity conflict without an invented winner, and pending IDs o7/o8 in both receipts. Explicit unmatched o6 stays separate.
10. Protected shared input files remain unchanged.

The first acceptance run failed as expected while `seal_unit` was still a NotImplementedError stub. The completed implementation then passed all ten checks. The earlier failed run directory was retained rather than deleted.

Run with `python -B D:\Projects\GeoAI-incremental-dev-20261101\durable_units_direct_20261101\durable_unit.py`; each check run creates a new directory inside the owned folder. No dependencies were installed, no agents/sessions were spawned, and no network/cloud/resource/security/Git changes were made.

## SHA-256 evidence

| Artifact | SHA-256 |
|---|---|
| durable_unit.py | 2cd3da2a4842f606bfa5b66fd95fc9cc963a7ef9fbb920b81b41e7d828a5f03f |
| completed-run verification.json | cacb53f7860e2e9b51c3c209813fef49bc140408ca5c6b88b8b678ad455f294f |
| before_seal/seal.json | e201826cfd48104d24539e481a7bbf3f22ee70edb2eb9842b2f72ad87b0c320b |
| after_seal/seal.json | 21c0602243857703e6280a92db0eabb5100a7bb07d4299d50e82a340b77d8ac3 |
| before_seal/unit.private.json | 98e93b6852a6dfa3bb826de8058d11dd85435d8538058e187bc96d88ed21cedd |
| after_seal/unit.private.json | e17611fe68c98eb1bacffc8a33309d1db221928f5ea59d188bc5b5a6c818f67d |
| recovered_aggregation.json | c711b5b4d335a6ff8a3d15ad403d011f9f35867c7c58f9801ae3e6b901450625 |

All relative output hashes and protected-source hashes are recorded in completed-run `verification.json`.

## Limits and next dependency

One local writer and initial decision versions only. No DB locks, distributed queue, batch cadence, full-corpus work, automatic ingestion resume, correction-version history persistence, directory fsync or hardware/power-failure guarantee. The child exits simulate process interruption at two exact boundaries, not every possible fault. Private orphan files remain pending and are intentionally retained. The passed fixture does not prove declared inventory completeness against a real corpus or close production G16.

Backup status: **Unprotected**. This parent workspace has no Git repository; no off-device backup was established. Parent owns integration and backup decisions.

No implementation blocker remains for this bounded increment. Next dependency is parent review of this private seal/expected-hash interface and a separately scoped integration of durable receipt replay with versioned reducer history; any production batch work still depends on the approved ingestion/cleaning/binding barrier and runtime envelope. These next steps were not executed.

Proposed plan status edit, for parent only (shared plans were read-only):

> E2/task 2 bounded generated-fixture durability increment PASS (10 focused checks): private unit/source write, readback hash/membership validation, sealed receipt, process interruption before/after seal, exact retry without duplicate acknowledgment, conflicting hashes rejected, and original pending/provenance/conflicts retained after replay. Initial versions and one writer only; not production durability, power-loss protection, full ingestion resume, or full E2 acceptance. Evidence: durable_units_direct_20261101/REPORT.md and run_20261101T180253493049Z/verification.json.
