"""Regression examples for the extracted callable, with the approved real processor."""
import importlib.util
import unittest
from pathlib import Path

HERE=Path(__file__).parent
DATE=Path(r'D:\Projects\GeoAI-incremental-dev-20261101\runtime_model_inputs_direct_20261101\date_route\structured_temporal_v1\execute_date_route_v1.py')


class DateContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=HERE/'check_routes.py'
        assert path.exists(), 'Missing reusable run_frontier callable'
        spec=importlib.util.spec_from_file_location('checks',path)
        cls.checks=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.checks)

    def unit(self,decisions):
        return dict(manifest=dict(page_id=1,processing_revision_id=2),decisions=decisions,
            occurrences=[dict(occurrence_id='DATE_A',entity_group='DATE')])

    def test_other_occurrence_qid_is_never_borrowed(self):
        result=self.checks.evaluate_dates(self.unit([dict(occurrence_id='OTHER',qid='Q1')]),DATE,{})
        self.assertEqual(result[0]['reason'],'NO_SAME_PAGE_REVISION_RESOLVED_QID')

    def test_same_occurrence_qid_without_native_record_is_explicit(self):
        result=self.checks.evaluate_dates(self.unit([dict(occurrence_id='DATE_A',qid='Q1')]),DATE,{})
        self.assertEqual(result[0]['reason'],'MISSING_NATIVE_RECORD_FOR_RESOLVED_QID')

    def test_same_occurrence_native_record_is_actually_inspected(self):
        native={'Q1':dict(envelope=dict(requested_qid='Q1',entity=dict(id='Q1',lastrevid=3,claims={}))) }
        result=self.checks.evaluate_dates(self.unit([dict(occurrence_id='DATE_A',qid='Q1')]),DATE,native)
        self.assertEqual(result[0]['evidence']['structured_time_lookup'],'NATIVE_RECORD_INSPECTED')
        self.assertEqual(result[0]['reason'],'UNKNOWN_APPROVED_TEMPORAL_CLASSIFICATION')
        self.assertFalse(result[0]['evidence']['raw_text_parsed'])

    def test_conflicting_same_occurrence_qids_remain_unresolved(self):
        result=self.checks.evaluate_dates(self.unit([dict(occurrence_id='DATE_A',qid=q) for q in ['Q1','Q2']]),DATE,{})
        self.assertEqual(result[0]['reason'],'CONFLICTING_SAME_SCOPE_QID_DECISIONS')

    def test_native_identity_mismatch_is_rejected(self):
        native={'Q1':dict(envelope=dict(requested_qid='Q1',entity=dict(id='Q2'))) }
        with self.assertRaisesRegex(ValueError,'NATIVE_QID_MISMATCH'):
            self.checks.evaluate_dates(self.unit([dict(occurrence_id='DATE_A',qid='Q1')]),DATE,native)


if __name__=='__main__':unittest.main()
