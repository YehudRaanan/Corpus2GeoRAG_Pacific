"""Exercise the actual Event-membership expression in run_frontier, not a replica."""
import ast
import json
import unittest
from pathlib import Path

HERE=Path(__file__).parent
GAP=Path(r'D:\Projects\GeoAI-incremental-dev-20261101\orchestration_direct_20261101\cpu_trigram_full_5747_0001\automatic_downstream_v1\eligibility_event_membership_gap.json')


def actual_membership(outcomes):
    tree=ast.parse((HERE/'check_routes.py').read_text(encoding='utf8'))
    node=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='event_ids' for t in n.targets))
    return eval(compile(ast.Expression(node.value),'actual_run_frontier_membership','eval'),dict(outcomes=outcomes))


class EventMembership(unittest.TestCase):
    def test_explicit_event_tags_remain_required(self):
        rows=[dict(occurrence_id=str(i),reason=[tag]) for i,tag in enumerate(['EVENT_SEPARATE','EVENT_DEFERRED','EVENT_NATIVE_SCOPE_PENDING'])]
        self.assertEqual(actual_membership(rows),{'0','1','2'})

    def test_all_six_actual_false_positives_are_excluded(self):
        gap=json.loads(GAP.read_text(encoding='utf8'))
        rows=[r for unit in gap['units'] for r in unit['missing_examples']]
        self.assertEqual(len(rows),6)
        self.assertEqual(actual_membership(rows),set())

    def test_free_form_target_containing_event_does_not_make_a_route(self):
        rows=[dict(occurrence_id='ordinary',reason=['VERIFIED_OCCURRENCE_IN_UNRESOLVED_SOURCE_TARGET:Events leading to the attack on Pearl Harbor']),
              dict(occurrence_id='tagged',reason=['VERIFIED_OCCURRENCE_IN_UNRESOLVED_SOURCE_TARGET:Seventeenth Air Force','EVENT_SEPARATE'])]
        self.assertEqual(actual_membership(rows),{'tagged'})

    def test_bare_or_embedded_or_lowercase_event_is_not_an_event_tag(self):
        rows=[dict(occurrence_id=str(i),reason=[tag]) for i,tag in enumerate(['EVENT','SOME_EVENT_TAG','event_SEPARATE','Seventeenth'])]
        self.assertEqual(actual_membership(rows),set())


if __name__=='__main__':unittest.main()
