"""DATE/context execution and existing route verification for an immutable frontier.

Call run_frontier(spec, new_output_directory). Every input path is supplied in spec;
all descriptors contain path and SHA256. This writes QA receipts, never live state.
"""
import ast
import hashlib
import html
import importlib.util
import json
import sqlite3
import sys
import zlib
from collections import Counter
from pathlib import Path

FIELDS=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
CONTEXT_ALIAS={'UNAPPROVED_SOURCE_CONTEXT_SURFACE':'PENDING_NO_VERIFIED_CONTEXT'}


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def check(ref):
    if sha(ref['path'])!=ref['sha256']:raise ValueError('ARTIFACT_HASH_MISMATCH: '+ref['path'])
def pinned(ref):check(ref);return read(ref['path'])
def save(path,value):
    with Path(path).open('x',encoding='utf8') as handle:json.dump(value,handle,sort_keys=True,indent=2,ensure_ascii=False)
    return pin(path)
def decision_map(unit):return {d['occurrence_id']:d for d in unit['decisions']}


# Example: OTHER->Q1 cannot supply time for DATE_A. The approved processor itself
# also handles DATE_A->Q1 with a missing or verified native source; no new rule.
def evaluate_dates(unit,processor_path,registry):
    spec=importlib.util.spec_from_file_location('approved_date_check',processor_path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return [module.decide(row,unit['decisions'],unit['manifest'],registry)
        for row in sorted(unit['occurrences'],key=lambda r:r['occurrence_id']) if row['entity_group']=='DATE']


# Extract the existing pure functions to avoid importing unrelated model/graph
# packages. The source files are pinned, and the extracted bodies are unchanged.
def existing_validators(context_ref,route_ref):
    check(context_ref);check(route_ref)
    tree=ast.parse(Path(context_ref['path']).read_text(encoding='utf8'))
    basis=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='basis')
    loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='member'
        and any(isinstance(v,ast.Constant) and v.value=='PREPARED_SPAN_NOT_VERIFIED' for v in ast.walk(n)))
    context_code=compile(ast.fix_missing_locations(ast.Module(body=[basis,loop],type_ignores=[])),context_ref['path'],'exec')
    tree=ast.parse(Path(route_ref['path']).read_text(encoding='utf8'))
    functions=[n for n in tree.body if isinstance(n,ast.FunctionDef)]
    env=dict(Path=Path,pinned=pinned,read=read,digest=sha,content_hash=digest,ROUTES=('date_route','event_route','context_route'))
    exec(compile(ast.fix_missing_locations(ast.Module(body=functions,type_ignores=[])),route_ref['path'],'exec'),env)
    return context_code,env['route_completion']


def run_frontier(spec,output_directory):
    """spec: frontier, cpu_receipts[], date_processor, context_processor, route_validator;
    optional event_handoff and native_registry. Inputs are pinned descriptors.
    Missing Event execution is reported NOT_RUN, never inferred from a CPU pass.
    """
    frontier=pinned(spec['frontier']);database=frontier['database'];check(database)
    for name in ['date_processor','context_processor','route_validator']:check(spec[name])
    registry=pinned(spec['native_registry'])['selected_references'] if spec.get('native_registry') else {}
    context_code,verify=existing_validators(spec['context_processor'],spec['route_validator'])
    connection=sqlite3.connect(Path(database['path']).as_uri()+'?mode=ro',uri=True)
    try:entries=connection.execute('SELECT c.scope,c.version,c.sha256,c.payload FROM active a JOIN contributions c ON c.seq=a.seq ORDER BY c.scope').fetchall()
    finally:connection.close()
    actual={(tuple(json.loads(k)),v,s) for k,v,s,p in entries}
    expected={(tuple(e['scope']),e['active_head']['version'],e['active_head']['sha256']) for e in frontier['frontier']}
    assert len(actual)==len(entries)==frontier['active_units'] and actual==expected
    cpus={}
    for ref in spec['cpu_receipts']:
        cpu=pinned(ref);key=tuple(cpu['source_scope'][k] for k in FIELDS)
        if key in cpus:raise ValueError('DUPLICATE_CPU_SCOPE')
        cpus[key]=(ref,cpu)
    assert set(cpus)=={k for k,v,s in actual}, 'CPU binding must cover precisely this frontier'
    event_by_scope={};event=None
    if spec.get('event_handoff'):
        event=pinned(spec['event_handoff']);check(event['processor'])
        event_rows=pinned(event['artifacts']['per_unit'])
        event_by_scope={tuple(e['source_scope'][k] for k in FIELDS):e for e in event_rows}
        assert len(event_by_scope)==len(event_rows)
    output=Path(output_directory);output.mkdir(parents=True,exist_ok=False)
    spec_ref=save(output/'input_spec.json',spec)
    totals=Counter();reasons=Counter();reports=[];seen=set()
    for key,version,blob_sha,payload in entries:
        raw=zlib.decompress(payload);assert hashlib.sha256(raw).hexdigest()==blob_sha
        unit=json.loads(raw);manifest=unit['manifest'];scope={k:manifest[k] for k in FIELDS}
        assert tuple(scope.values())==tuple(json.loads(key)) and unit['version']==version
        rows={r['occurrence_id']:r for r in unit['occurrences']}
        assert len(rows)==len(unit['occurrences']) and not seen.intersection(rows);seen.update(rows)
        cpu_ref,cpu=cpus[tuple(json.loads(key))]
        assert cpu['execution']=='EXECUTED_LOCAL_CPU' and cpu['model_calls']==0
        outcomes=pinned(cpu['outcomes']);pool=pinned(cpu['source_pool']);patch=pinned(cpu['decision_patch'])
        assert len(outcomes)==len(rows) and {r['occurrence_id'] for r in outcomes}==set(rows)
        assert decision_map(patch)==decision_map(unit)
        source=Path(manifest['source_path']).read_bytes();assert hashlib.sha256(source).hexdigest()==manifest['source_sha256']
        folder=output/f"unit_{manifest['page_id']}_{manifest['support_revision_id']}";folder.mkdir()
        def receipt(name,members,terminal,processor,artifacts,**extra):
            return save(folder/(name+'.json'),dict(status='COMPLETED_UNRESOLVED' if any(r['status']=='UNRESOLVED' for r in terminal) else 'COMPLETED',
                execution='EXECUTED',source_scope=scope,input_occurrences_sha256=digest(sorted(members,key=lambda r:r['occurrence_id'])),
                outcomes=terminal,processor=processor,artifacts=artifacts,decision_version=version,
                frozen_contribution_sha256=blob_sha,execution_adapter=pin(Path(__file__)),**extra))
        date_rows=[r for r in rows.values() if r['entity_group']=='DATE']
        for row in date_rows:
            assert row['page_id']==manifest['page_id'] and row['processing_revision_id']==manifest['processing_revision_id']
            assert row['processing_revision_sha256']==manifest['source_sha256']
        dates=evaluate_dates(unit,spec['date_processor']['path'],registry)
        date_artifacts=[save(folder/'date_outcomes.json',dates)]
        if spec.get('native_registry'):date_artifacts.append(spec['native_registry'])
        date_ref=receipt('date_route',date_rows,[{k:r[k] for k in ['occurrence_id','status','method','reason']} for r in dates],
            spec['date_processor'],date_artifacts,temporal_basis='STRUCTURED_QID_WIKIDATA',raw_text_parsed=False)
        reasons.update(r['reason'] for r in dates)
        context_ids={r['occurrence_id'] for r in outcomes if any(x=='PENDING_NO_VERIFIED_CONTEXT' or x in CONTEXT_ALIAS for x in r['reason'])}
        names={g['id']:g['name'] for g in pool['groups']};names.update({g['group_id']:g['name'] for g in pool['deferred_routes']['groups']})
        by_oid={r['occurrence_id']:r for r in outcomes};evidence=[];context_terminal=[]
        for oid in sorted(context_ids):
            row=rows[oid];word=names[by_oid[oid]['group_id']]
            env=dict(json=json,html=html,raw_source=source.decode('utf8'),g=dict(members=[row]),word=word,
                REV=manifest['support_revision_id'],unit=dict(source_sha256=manifest['source_sha256']),usable=[],bad=[])
            exec(context_code,env)
            assert len(env['bad'])+len(env['usable'])==1
            why=';'.join(env['bad'][0]['reasons']) if env['bad'] else 'VERIFIED_SOURCE_CONTEXT'
            context_terminal.append(dict(occurrence_id=oid,status='UNRESOLVED' if env['bad'] else 'RESOLVED',method='PINNED_EXISTING_DATA_CONTEXT_VALIDATOR',reason=why))
            evidence.append(dict(original=row,group_name=word,original_policy_outcome=by_oid[oid],repeated=env['bad'],usable_source_context=bool(env['usable'])))
        context_ref=receipt('context_route',[rows[oid] for oid in context_ids],context_terminal,spec['context_processor'],
            [save(folder/'context_outcomes.json',evidence),cpu_ref,cpu['outcomes'],cpu['source_pool']])
        routing=[];aliases=[]
        for row in outcomes:
            added=[alias for original,alias in CONTEXT_ALIAS.items() if original in row['reason'] and alias not in row['reason']]
            routing.append(dict(row,reason=row['reason']+added))
            if added:aliases.append(dict(occurrence_id=row['occurrence_id'],original_reasons=row['reason'],added_route_aliases=added))
        routing_ref=save(folder/'all_occurrence_decision_evidence.json',routing)
        aliases_ref=save(folder/'explicit_context_reason_aliases.json',dict(mapping=CONTEXT_ALIAS,rows=aliases,original_evidence=cpu['outcomes']))
        matching=save(folder/'matching_for_route_audit.json',dict(policy_verification=routing_ref,original_cpu_receipt=cpu_ref,reason_alias_evidence=aliases_ref))
        stages=dict(date_route=date_ref,context_route=context_ref)
        # EVENT_SEPARATE is a route tag; a target named "Seventeenth" is not.
        # Keep membership identical to the pinned route_completion_v2 validator.
        event_ids={r['occurrence_id'] for r in outcomes if any(str(x).startswith('EVENT_') for x in r['reason'])}
        prior=event_by_scope.get(tuple(json.loads(key)))
        if prior is not None:
            assert prior['decision_version']==version and prior['source_scope']==scope
            assert prior['execution']=='EXECUTED' and prior['status'] in ['COMPLETED','COMPLETED_UNRESOLVED']
            assert {r['occurrence_id'] for r in prior['outcomes']}==event_ids
            assert decision_map(pinned(prior['source_unit']))==decision_map(unit)
            prior=dict(prior,execution='REUSED_VERIFIED_OUTPUT',processor=event['processor'],artifacts=[spec['event_handoff'],event['artifacts']['per_unit'],prior['source_unit']],
                outcomes=[dict(x,method=x.get('method','VERIFIED_NATIVE_EVENT_ROUTE')) for x in prior['outcomes']],metadata_adapter=pin(Path(__file__)))
            stages['event_route']=save(folder/'event_route.json',prior)
        verified=verify(stages,unit,matching)
        totals.update(dict(units=1,occurrences=len(rows),DATE=len(date_rows),context=len(context_ids),Event=len(event_ids),routes_complete_units=int(verified['complete'])))
        reports.append(dict(source_scope=scope,decision_version=version,frozen_contribution_sha256=blob_sha,routes=stages,route_verification=verified,
            CPU_receipt=cpu_ref,context_reason_alias_evidence=aliases_ref))
    check(database)
    for ref in [spec['frontier'],spec['date_processor'],spec['context_processor'],spec['route_validator']]:check(ref)
    result=dict(status='PASS_REQUIRED_ROUTES' if totals['routes_complete_units']==len(entries) else 'PENDING_REQUIRED_ROUTES',counts=dict(totals),DATE_reasons=dict(reasons),units=reports,
        input_spec=spec_ref,callable=pin(Path(__file__)),identity_changes=0,raw_text_dates_parsed=False,live_state_written=False,canonical_completion_adopted=False,
        full_pipeline_completion_claim=False,scope='Required DATE/context/Event routes only; INTEGRATION verifies downstream stages and adopts completion separately.')
    save(output/'route_completion_handoff.json',result)
    return result


if __name__=='__main__':
    result=run_frontier(read(sys.argv[1]),sys.argv[2])
    print(json.dumps(dict(status=result['status'],counts=result['counts'],DATE_reasons=result['DATE_reasons'])))
