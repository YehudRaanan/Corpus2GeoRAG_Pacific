"""Independent1308 readback using the already verified935 checks, with dynamic support counts."""
import ast
import hashlib
import json
import sqlite3
import zlib
from collections import Counter,defaultdict
from pathlib import Path
from typing import Any
from pydantic import BaseModel,ConfigDict,Field

HERE=Path(__file__).parent
SCHEMA=Path(r'D:\Projects\GeoAI-incremental-dev-20261101\publisher_direct_20261101\publication_latest_0001\live_cpu269_0001\remote_readback\GG_Data\agent_export\latest\runtime\geo_agent\graph_store.py')
def read(path):return json.loads(Path(path).read_text(encoding='utf8'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pinned(ref):assert sha(ref['path'])==ref['sha256'];return read(ref['path'])
def pin(path):return dict(path=str(path),sha256=sha(path))


def main():
    hand=read(HERE/'frozen1308_0001/CITATION_HANDOFF.json');spec=pinned(hand['input_spec'])
    graph=pinned(hand['graph']);base=pinned(spec['graph']);front=pinned(spec['frontier'])
    assert graph['edges']==base['edges'] and graph['metadata']==base['metadata']
    assert [{k:v for k,v in n.items()if k!='sources'}for n in graph['nodes']]==[{k:v for k,v in n.items()if k!='sources'}for n in base['nodes']]
    tree=ast.parse(SCHEMA.read_text(encoding='utf8'));classes=[n for n in tree.body if isinstance(n,ast.ClassDef)and n.name in ['Source','Node']]
    env=dict(BaseModel=BaseModel,ConfigDict=ConfigDict,Field=Field,Any=Any)
    exec(compile(ast.fix_missing_locations(ast.Module(body=classes,type_ignores=[])),str(SCHEMA),'exec'),env)
    targets=defaultdict(list);examples={};counts=Counter()
    for node in graph['nodes']:
        parsed=env['Node'].model_validate(node).model_dump()
        assert [s['text']for s in parsed['sources']]==[s['text']for s in node['sources']]
        assert node.get('sources') or node['id'] in {x['node_id'] for x in hand['missing_entities']}
        pages={s['page_id']for s in node['sources']}
        for source in node['sources']:
            assert source['occurrence_id']==min(source['occurrence_ids']) and len(source['occurrence_ids'])==len(set(source['occurrence_ids']))
            for oid in source['occurrence_ids']:targets[oid].append((node,source))
            if source['position']['representative'] is True:examples.setdefault('representative',dict(node_id=node['id'],source=source))
            if source['position']['retained_text_raw_span'] is None:examples.setdefault('quote_span_unproven',dict(node_id=node['id'],source=source))
            if len(source['occurrence_ids'])>1:examples.setdefault('deduplicated',dict(node_id=node['id'],source=source))
            if node['type']=='event':examples.setdefault('Event',dict(node_id=node['id'],source=source))
            if len(pages)>1:examples.setdefault('multiple_distinct_pages',dict(node_id=node['id'],pages=sorted(pages)[:8],source=source))
    event=pinned(spec['event_handoff']);event_units=pinned(event['artifacts']['per_unit'])
    events={tuple(x['source_scope'][k]for k in ['input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version']):x for x in event_units}
    database=front['database'];assert sha(database['path'])==database['sha256']
    con=sqlite3.connect(Path(database['path']).as_uri()+'?mode=ro',uri=True);seen=set()
    try:
        for key,payload in con.execute('select c.scope,c.payload from active a join contributions c on c.seq=a.seq'):
            unit=json.loads(zlib.decompress(payload));m=unit['manifest'];raw_path=Path(m['source_path']);assert sha(raw_path)==m['source_sha256'];raw=raw_path.read_bytes().decode('utf8')
            decisions={d['occurrence_id']:d for d in unit['decisions']}
            event_row=events[tuple(json.loads(key))];assert event_row['decision_version']==unit['version']
            event_ids={o['occurrence_id']:o.get('accepted_event_qids',[])for o in event_row['outcomes']}
            for row in unit['occurrences']:
                oid=row['occurrence_id']
                if oid not in targets:continue
                assert oid not in seen;seen.add(oid)
                for node,source in targets[oid]:
                    assert source['text']==row['Text'] and source['text_basis']=='EXACT_RETAINED_EXTRACTION_TEXT'
                    assert source['page_id']==row['page_id']==m['page_id']
                    assert source['processing_revision_id']==row['processing_revision_id']==m['processing_revision_id']
                    assert source['extraction_revision_id']==row.get('extraction_revision_id')
                    assert source['processing_revision_sha256']==row['processing_revision_sha256']==m['source_sha256']
                    assert source['url']==f"https://en.wikipedia.org/?curid={m['page_id']}"
                    assert source['processing_revision_url']==f"https://en.wikipedia.org/w/index.php?oldid={m['processing_revision_id']}"
                    pos=source['position'];assert pos['source_position_role']==row['source_position_role']
                    if pos['raw_anchor_span'] is not None:
                        a,b=pos['raw_anchor_span'];assert [a,b]==[row['selected_raw_start'],row['selected_raw_end']]
                        assert raw[a:b]==pos['anchor_text']==row['processing_surface']
                    if pos['retained_text_raw_span'] is not None:
                        a,b=pos['retained_text_raw_span'];assert raw[a:b]==source['text']
                    if source['extraction_revision_id'] is None:assert not pos['original_extraction_position_proven']
                    if pos['original_extraction_position_proven']:
                        assert source['extraction_revision_id']==source['processing_revision_id'] and pos['source_position_role']=='VERIFIED_ORIGINAL_CONTAINING_PLACEMENT'
                    if node['type']=='event':assert node['wikidata_id'] in event_ids[oid];counts['Event_occurrence_evidence']+=1
                    else:assert decisions[oid]['qid']==node['wikidata_id'] and node['id']==decisions[oid]['qid']+'::'+row['entity_group']
                    counts['exact_retained_text_and_scope_checks']+=1
            counts['units_read']+=1
    finally:con.close()
    assert set(targets)==seen and counts['units_read']==front['active_units']==1308
    assert counts['exact_retained_text_and_scope_checks']==hand['counts']['attached_occurrence_evidence']
    assert sha(database['path'])==database['sha256']
    result=dict(status='PASS_INDEPENDENT1308_CITATION_READBACK',counts=dict(counts),nodes_schema_validated=len(graph['nodes']),source_records=sum(len(n['sources'])for n in graph['nodes']),
        graph=hand['graph'],citation_handoff=pin(HERE/'frozen1308_0001/CITATION_HANDOFF.json'),schema=pin(SCHEMA),examples=examples,
        original_graph_unchanged=spec['graph'],snapshot_unchanged=database,identities_and_edges_unchanged=True,live_state_writes=False)
    with (HERE/'independent_verification1308.json').open('x',encoding='utf8') as handle:json.dump(result,handle,ensure_ascii=False,indent=2,sort_keys=True)
    print(json.dumps({k:v for k,v in result.items()if k!='examples'}))


if __name__=='__main__':main()
