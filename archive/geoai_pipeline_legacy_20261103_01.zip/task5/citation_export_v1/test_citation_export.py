import ast
import copy
import importlib.util
import unittest
from pathlib import Path
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

HERE=Path(__file__).parent
SCHEMA=Path(r'D:\Projects\GeoAI-incremental-dev-20261101\publisher_direct_20261101\publication_latest_0001\live_cpu269_0001\remote_readback\GG_Data\agent_export\latest\runtime\geo_agent\graph_store.py')


class CitationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=HERE/'citation_export.py';assert path.exists(),'Citation adapter is missing'
        spec=importlib.util.spec_from_file_location('citations',path);cls.api=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.api)

    def evidence(self):
        manifest=dict(page_id=123,wiki_site='enwiki',processing_revision_id=456,source_sha256='abc')
        row=dict(occurrence_id='one',page_id=123,wiki_site='enwiki',processing_revision_id=456,processing_revision_sha256='abc',
            extraction_revision_id=None,revision_id=456,Text='Alpha visited Beta.',start=0,end=5,processing_surface='Alpha',
            selected_raw_start=0,selected_raw_end=5,source_position_role='VERIFIED_ORIGINAL_CONTAINING_PLACEMENT')
        return row,manifest,'Alpha visited Beta.'

    def test_unknown_extraction_revision_is_not_processing_revision(self):
        row,m,raw=self.evidence();source=self.api.source_for(row,m,raw)
        self.assertEqual(source['text'],row['Text']);self.assertEqual(source['processing_revision_id'],456)
        self.assertIsNone(source['extraction_revision_id']);self.assertFalse(source['position']['original_extraction_position_proven'])
        self.assertEqual(source['url'],'https://en.wikipedia.org/?curid=123')

    def test_representative_location_is_explicit(self):
        row,m,raw=self.evidence();row['source_position_role']='DETERMINISTIC_REPRESENTATIVE_NOT_PROVEN_ORIGINAL'
        source=self.api.source_for(row,m,raw);self.assertTrue(source['position']['representative'])
        self.assertFalse(source['position']['original_extraction_position_proven'])

    def test_unmapped_retained_quote_is_not_reconstructed(self):
        row,m,raw=self.evidence();row['Text']='Retained earlier wording.'
        source=self.api.source_for(row,m,raw);self.assertEqual(source['text'],'Retained earlier wording.')
        self.assertIsNone(source['position']['retained_text_raw_span'])

    def test_bad_page_or_revision_or_wiki_is_rejected(self):
        for key,value in [('page_id',999),('processing_revision_id',999),('wiki_site','evil.example')]:
            row,m,raw=self.evidence();row[key]=value
            with self.assertRaises(ValueError):self.api.source_for(row,m,raw)

    def test_no_retained_text_never_produces_a_quote(self):
        row,m,raw=self.evidence();row['Text']=''
        with self.assertRaisesRegex(ValueError,'MISSING_RETAINED_TEXT'):self.api.source_for(row,m,raw)

    def test_dedup_retains_all_occurrence_ids_and_distinct_positions(self):
        row,m,raw=self.evidence();a=self.api.source_for(row,m,raw);b=copy.deepcopy(a);b['occurrence_id']='two'
        c=copy.deepcopy(a);c['occurrence_id']='three';c['position']['raw_anchor_span']=[20,25]
        result=self.api.deduplicate([b,a,c]);self.assertEqual(len(result),2)
        merged=next(x for x in result if x['occurrence_id']=='one');self.assertEqual(merged['occurrence_ids'],['one','two'])

    def test_existing_consumer_keeps_citation_fields(self):
        tree=ast.parse(SCHEMA.read_text(encoding='utf8'));classes=[x for x in tree.body if isinstance(x,ast.ClassDef)and x.name in ['Source','Node']]
        env=dict(BaseModel=BaseModel,ConfigDict=ConfigDict,Field=Field,Any=Any)
        exec(compile(ast.fix_missing_locations(ast.Module(body=classes,type_ignores=[])),str(SCHEMA),'exec'),env)
        row,m,raw=self.evidence();source=self.api.source_for(row,m,raw)
        graph=dict(nodes=[dict(id='Q1::MISC',wikidata_id='Q1',name='Alpha',type='MISC')],edges=[])
        before=copy.deepcopy(graph);out=self.api.attach_sources(graph,{'Q1::MISC':[source]})
        loaded=env['Node'].model_validate(out['nodes'][0]).model_dump()
        self.assertEqual(loaded['sources'][0]['text'],row['Text']);self.assertEqual(loaded['sources'][0]['page_id'],123)
        self.assertEqual(graph,before);self.assertEqual(out['edges'],graph['edges'])


if __name__=='__main__':unittest.main()
