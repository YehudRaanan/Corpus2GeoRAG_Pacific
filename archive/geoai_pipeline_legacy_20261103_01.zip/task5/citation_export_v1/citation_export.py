"""Add retained Wikipedia citations to an immutable graph; never resolve identities.

Example: an entity with three distinct retained passages keeps three sources.
Repeated identical evidence keeps all supporting occurrence IDs in one source.
"""
import copy
import hashlib
import json
import sqlite3
import sys
import zlib
from collections import Counter
from pathlib import Path

FIELDS=('input_sha256','wiki_site','page_id','support_revision_id','source_sha256','policy_version')
ORIGINAL='VERIFIED_ORIGINAL_CONTAINING_PLACEMENT'
REPRESENTATIVE='DETERMINISTIC_REPRESENTATIVE_NOT_PROVEN_ORIGINAL'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def pin(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def checked(ref):
    if sha(ref['path'])!=ref['sha256']:raise ValueError('ARTIFACT_HASH_MISMATCH: '+ref['path'])
    return read(ref['path'])
def save(path,value):
    with Path(path).open('x',encoding='utf8') as handle:json.dump(value,handle,ensure_ascii=False,sort_keys=True,separators=(',',':'))
    return pin(path)


# Example: revision_id=456 is the processing version, not proof that extraction
# occurred in 456. Only the explicit extraction_revision_id field supplies it.
def source_for(row,manifest,raw_text):
    for field in ['page_id','wiki_site','processing_revision_id']:
        if row.get(field)!=manifest[field]:raise ValueError('SOURCE_SCOPE_MISMATCH: '+field)
    if row.get('processing_revision_sha256')!=manifest['source_sha256']:raise ValueError('SOURCE_REVISION_HASH_MISMATCH')
    if row['wiki_site']!='enwiki':raise ValueError('UNSUPPORTED_WIKI_SITE')
    page=row['page_id'];revision=row['processing_revision_id']
    if type(page)is not int or page<=0 or type(revision)is not int or revision<=0:raise ValueError('INVALID_WIKIPEDIA_ID')
    text=row.get('Text')
    if not isinstance(text,str) or not text:raise ValueError('MISSING_RETAINED_TEXT')
    extraction=row.get('extraction_revision_id')
    if extraction is not None and (type(extraction)is not int or extraction<=0):raise ValueError('INVALID_EXTRACTION_REVISION_ID')
    start,end=row.get('selected_raw_start'),row.get('selected_raw_end');surface=row.get('processing_surface')
    anchor_ok=(type(start)is int and type(end)is int and 0<=start<end<=len(raw_text)
        and isinstance(surface,str) and raw_text[start:end]==surface)
    # Prove a full quote span only from the existing local and raw offsets plus
    # exact character equality. A failed proof leaves the mapping explicitly null.
    quote_span=None
    local_start,local_end=row.get('start'),row.get('end')
    if anchor_ok and type(local_start)is int and type(local_end)is int and 0<=local_start<local_end<=len(text) and text[local_start:local_end]==surface:
        candidate=start-local_start
        if candidate>=0 and raw_text[candidate:candidate+len(text)]==text:quote_span=[candidate,candidate+len(text)]
    role=row.get('source_position_role')
    position=dict(source_position_role=role or 'UNKNOWN',representative=True if role==REPRESENTATIVE else False if role==ORIGINAL else None,
        proof_scope='PROCESSING_REVISION_ONLY',raw_anchor_span=[start,end] if anchor_ok else None,
        anchor_text=surface,anchor_verified=anchor_ok,retained_text_raw_span=quote_span,
        original_extraction_position_proven=bool(anchor_ok and role==ORIGINAL and extraction==revision))
    return dict(page=f'enwiki:{page}',page_id=page,wiki_site='enwiki',url=f'https://en.wikipedia.org/?curid={page}',
        processing_revision_url=f'https://en.wikipedia.org/w/index.php?oldid={revision}',occurrence_id=row['occurrence_id'],
        text=text,text_basis='EXACT_RETAINED_EXTRACTION_TEXT',processing_revision_id=revision,
        processing_revision_sha256=manifest['source_sha256'],extraction_revision_id=extraction,position=position)


# Same text at two distinct locations remains two sources. If evidence is truly
# identical, retain the complete occurrence-ID list instead of dropping provenance.
def deduplicate(sources):
    unique={}
    for source in sources:
        value={k:v for k,v in source.items() if k not in ['occurrence_id','occurrence_ids']};key=digest(value)
        if key not in unique:unique[key]=dict(value,occurrence_ids=set())
        unique[key]['occurrence_ids'].update(source.get('occurrence_ids',[source['occurrence_id']]))
    result=[]
    for source in unique.values():
        ids=sorted(source['occurrence_ids']);result.append(dict(source,occurrence_id=ids[0],occurrence_ids=ids))
    return sorted(result,key=lambda x:(x['page_id'],x['processing_revision_id'],x['occurrence_id']))


def attach_sources(graph,by_node):
    result=dict(graph);nodes=[]
    for node in graph['nodes']:
        added=by_node.get(node['id'],[])
        nodes.append(dict(node,sources=list(node.get('sources',[]))+added) if added else dict(node))
    result['nodes']=nodes
    return result


def export_citations(spec,output_directory):
    """spec contains pinned frontier, graph, event_handoff and consumer_handoff.
    Output is additive graph JSON plus coverage; every missing source stays explicit.
    """
    frontier=checked(spec['frontier']);graph=checked(spec['graph']);consumer=checked(spec['consumer_handoff'])
    assert consumer['CPU_units']==frontier['active_units'] and consumer['graph']==spec['graph']
    assert consumer['status']=='PASS_FROZEN_FULL_ORDINARY_EVENT_ACTIVE_GEO_CONSUMER'
    manifest=checked(consumer['manifest']);assert manifest['event_route']==spec['event_handoff']
    event=checked(spec['event_handoff']);event_units=checked(event['artifacts']['per_unit'])
    event_by_scope={tuple(x['source_scope'][k]for k in FIELDS):x for x in event_units}
    assert len(event_by_scope)==len(event_units)==frontier['active_units']
    db=frontier['database'];assert sha(db['path'])==db['sha256']
    expected={tuple(x['scope']):x['active_head']for x in frontier['frontier']}
    nodes={n['id']:n for n in graph['nodes']};assert len(nodes)==len(graph['nodes'])
    by_node={};counts=Counter();examples=[];exceptions=[];visited=set();input_sources=[]
    connection=sqlite3.connect(Path(db['path']).as_uri()+'?mode=ro',uri=True)
    try:
        cursor=connection.execute('SELECT c.scope,c.version,c.sha256,c.payload FROM active a JOIN contributions c ON c.seq=a.seq ORDER BY c.scope')
        for key,version,blob_sha,payload in cursor:
            scope=tuple(json.loads(key));assert scope not in visited;visited.add(scope)
            assert expected[scope]==dict(version=version,sha256=blob_sha)
            raw=zlib.decompress(payload);assert hashlib.sha256(raw).hexdigest()==blob_sha
            unit=json.loads(raw);m=unit['manifest'];assert tuple(m[k]for k in FIELDS)==scope
            source_path=Path(m['source_path']);source=source_path.read_bytes();assert hashlib.sha256(source).hexdigest()==m['source_sha256']
            input_sources.append(dict(path=str(source_path),sha256=m['source_sha256']))
            raw_text=source.decode('utf8');rows={x['occurrence_id']:x for x in unit['occurrences']}
            assert len(rows)==len(unit['occurrences']);counts['retained_occurrences']+=len(rows)
            assignments=[]
            for decision in unit['decisions']:
                oid=decision['occurrence_id'];assert oid in rows
                if decision.get('qid'):assignments.append((decision['qid']+'::'+rows[oid]['entity_group'],oid,'ACCEPTED_ORDINARY_IDENTITY'))
            prior=event_by_scope[scope];assert prior['decision_version']==version
            original=checked(prior['source_unit'])
            assert {x['occurrence_id']:x for x in original['decisions']}=={x['occurrence_id']:x for x in unit['decisions']}
            assert tuple(original['manifest'][k]for k in FIELDS)==scope
            event_rows=sorted([rows[x['occurrence_id']]for x in prior['outcomes']],key=lambda x:x['occurrence_id'])
            assert digest(event_rows)==prior['input_occurrences_sha256']
            for outcome in prior['outcomes']:
                for qid in outcome.get('accepted_event_qids',[]):
                    assert outcome['status']=='RESOLVED'
                    assignments.append((qid+'::event',outcome['occurrence_id'],'VERIFIED_EVENT_ROUTE'))
            for node_id,oid,route in assignments:
                if node_id not in nodes:counts['assigned_occurrences_outside_exported_population']+=1;continue
                row=rows[oid]
                try:citation=source_for(row,m,raw_text)
                except ValueError as error:
                    exceptions.append(dict(node_id=node_id,occurrence_id=oid,reason=str(error)));counts['missing_citation_occurrences']+=1;continue
                counts['attached_occurrence_evidence']+=1
                counts['representative_placement_occurrences']+=int(citation['position']['representative'] is True)
                counts['verified_processing_anchor_occurrences']+=int(citation['position']['anchor_verified'])
                counts['verified_full_quote_processing_span_occurrences']+=int(citation['position']['retained_text_raw_span'] is not None)
                counts['unknown_extraction_revision_occurrences']+=int(citation['extraction_revision_id'] is None)
                by_node.setdefault(node_id,[]).append(citation)
                if len(examples)<4 or (route=='VERIFIED_EVENT_ROUTE' and not any(x['route']==route for x in examples)):
                    examples.append(dict(node_id=node_id,route=route,source=citation,unit_scope=list(scope)))
            counts['units']+=1
    finally:connection.close()
    assert visited==set(expected) and sha(db['path'])==db['sha256']
    by_node={node:deduplicate(values)for node,values in by_node.items()}
    counts['unique_source_records']=sum(len(v)for v in by_node.values())
    counts['deduplicated_occurrence_evidence']=counts['attached_occurrence_evidence']-counts['unique_source_records']
    counts['exported_nodes']=len(nodes);counts['nodes_with_sources']=len(by_node);counts['nodes_missing_sources']=len(nodes)-len(by_node)
    result=attach_sources(graph,by_node)
    assert result['edges']==graph['edges']
    assert [{k:v for k,v in n.items()if k!='sources'}for n in result['nodes']]==[{k:v for k,v in n.items()if k!='sources'}for n in graph['nodes']]
    output=Path(output_directory);output.mkdir(parents=True,exist_ok=False)
    spec_ref=save(output/'input_spec.json',spec);graph_ref=save(output/'graph_with_sources.json',result)
    missing=[dict(node_id=n['id'],qid=n.get('wikidata_id'),reason='NO_VERIFIED_RETAINED_OCCURRENCE_FOR_THIS_EXPORTED_TYPED_NODE')for n in graph['nodes']if n['id']not in by_node]
    coverage=dict(status='VERIFIED_RETAINED_CITATION_EXPORT',counts=dict(counts),missing_entities=missing,missing_occurrences=exceptions,
        examples=examples,graph=graph_ref,input_spec=spec_ref,processor=pin(Path(__file__)),input_source_files=input_sources,
        original_graph_unchanged=spec['graph'],identity_changes=0,decision_changes=0,live_state_writes=False,publication=False,
        compatibility='Existing Source.page/url plus extra=allow citation fields; only node.sources is added. Node.text and edge data are unchanged.',
        limitations=['Extraction revision is never inferred from revision_id or processing_revision_id.',
            'Retained Text is verbatim stored evidence. A null retained_text_raw_span means its full wording was not proven at the processing revision offset.',
            'Representative placements are explicitly labelled and never prove original extraction positions.',
            'Source text is available as node.sources[].text; this does not change existing Agent search or response rendering.'])
    save(output/'CITATION_HANDOFF.json',coverage)
    return coverage


if __name__=='__main__':
    report=export_citations(read(sys.argv[1]),sys.argv[2]);print(json.dumps(dict(status=report['status'],counts=report['counts'],graph=report['graph'])))
