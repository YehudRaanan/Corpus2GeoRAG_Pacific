"""Prove content equivalence before reusing citations for the all-C generation.

The enriched graph and original exhaustive citation verification are preserved.
Only new receipts are written; this never edits a live runner or a consumer.
"""
import gzip
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).parent
CURRENT=Path(r'C:\Users\User\Documents\Codex\2026-11-01\task-4\publisher_downstream_v2\c10f5ef5ef69fcb8_autochain-C-v1\VERIFIED_HANDOFF.json')
OUT=HERE/'all_C1308_compatibility_0001'
def read(path):return json.loads(Path(path).read_text(encoding='utf8'))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path):return dict(path=str(path),sha256=sha(path))
def checked(ref):
    assert sha(ref['path'])==ref['sha256'],ref['path']
    return read(ref['path'])
def save(name,value):
    path=OUT/name
    with path.open('x',encoding='utf8')as handle:json.dump(value,handle,ensure_ascii=False,sort_keys=True,indent=2)
    return pin(path)


def main():
    old_ref=pin(HERE/'PUBLISHER_HANDOFF1308.json');old=checked(old_ref)
    old_spec=checked(old['input_spec']);coverage=checked(old['coverage']);prior_verification=checked(old['independent_verification'])
    assert prior_verification['graph']==old['graph'] and prior_verification['original_graph_unchanged']==old_spec['graph']
    assert prior_verification['counts']['exact_retained_text_and_scope_checks']==62103
    enriched=checked(old['graph']);old_graph=checked(old_spec['graph'])
    current_ref=pin(CURRENT);current=checked(current_ref)
    assert current['status']=='PASS_FROZEN_FULL_ORDINARY_EVENT_ACTIVE_GEO_CONSUMER' and current['CPU_units']==1308
    assert current['consumer_checks']==dict(nodes=1981,edges=19958,geometries=655,support_identities=10060)
    new_graph=checked(current['graph']);new_manifest=checked(current['manifest']);checked(current['receipt']);checked(current['independent_verification'])
    assert new_graph==old_graph and current['graph']['sha256']==old_spec['graph']['sha256']
    assert enriched['edges']==new_graph['edges']
    assert [{k:v for k,v in n.items()if k!='sources'}for n in enriched['nodes']]==[{k:v for k,v in n.items()if k!='sources'}for n in new_graph['nodes']]
    outer=checked(current['request']['event_handoff']);assert outer['frozen_frontier']==old_spec['frontier']
    front=checked(old_spec['frontier']);assert front['active_units']==1308
    assert sha(front['database']['path'])==front['database']['sha256']==prior_verification['snapshot_unchanged']['sha256']
    old_event=checked(old_spec['event_handoff']);new_event=checked(new_manifest['event_route'])
    old_units=checked(old_event['artifacts']['per_unit']);new_units=checked(new_event['artifacts']['per_unit'])
    assert old_units==new_units and len(new_units)==1308 and old_event['decision_binding']==new_event['decision_binding']
    # Equal complete per-unit records preserve scope, decision version, exact
    # occurrence membership, accepted Event QIDs and pinned original source units.
    models=[]
    for name in ['entities.json.gz','events.json.gz','relations.json.gz','cooccurrence_support.json.gz','geography.json.gz']:
        a=Path(old_spec['graph']['path']).parent/'model'/name;b=Path(current['graph']['path']).parent/'model'/name
        assert json.loads(gzip.decompress(a.read_bytes()))==json.loads(gzip.decompress(b.read_bytes()))
        models.append(dict(name=name,old=pin(a),current=pin(b),complete_JSON_content_equal=True))
    # Retained rows are in the unchanged immutable database. Recheck the raw byte
    # sources too, preserving the earlier proof for quote/anchor offset claims.
    for ref in coverage['input_source_files']:assert sha(ref['path'])==ref['sha256'],ref['path']
    assert sha(old['adapter']['path'])==old['adapter']['sha256']
    assert sha(HERE/'frozen935_0001/graph_with_sources.json')=='c4646a501d4a22a74d0979c350a34a3e51fe869aa58e7b8e9898b274fbe7a661'
    OUT.mkdir(exist_ok=False)
    spec=dict(old_spec,graph=current['graph'],consumer_handoff=current_ref,event_handoff=new_manifest['event_route'])
    spec_ref=save('input_spec.json',spec)
    proof=dict(status='PASS_EXACT1308_ALL_C_CONTENT_EQUIVALENCE',method='CONTENT_EQUIVALENCE_PLUS_PINNED_PRIOR_EXHAUSTIVE_CITATION_READBACK',
        old_handoff=old_ref,current_consumer=current_ref,frontier=old_spec['frontier'],snapshot=front['database'],
        old_graph=old_spec['graph'],current_graph=current['graph'],reused_enriched_graph=old['graph'],base_graph_bytes_identical=True,
        Event_per_unit_records_identical=1308,old_Event=old_spec['event_handoff'],current_Event=new_manifest['event_route'],
        Event_membership= dict(old=old_event['artifacts']['per_unit'],current=new_event['artifacts']['per_unit']),
        models=models,retained_raw_sources_rechecked=len(coverage['input_source_files']),
        prior_exhaustive_verification=old['independent_verification'],prior_exact_occurrence_checks=62103,
        processor=pin(Path(__file__)),identities_and_edges_unchanged=True,live_state_writes=False,publication=False)
    proof_ref=save('compatibility_proof.json',proof)
    new_coverage=dict(coverage,input_spec=spec_ref,compatible_consumer=current_ref,compatibility_proof=proof_ref,
        execution='REUSED_VERIFIED_CITATIONS_AFTER_EXACT_CONTENT_EQUIVALENCE',predecessor_coverage=old['coverage'],original_graph_unchanged=current['graph'])
    coverage_ref=save('CITATION_HANDOFF.json',new_coverage)
    independent=dict(prior_verification,status='PASS_INDEPENDENT1308_ALL_C_CITATION_COMPATIBILITY',
        method=proof['method'],original_graph_unchanged=current['graph'],citation_handoff=coverage_ref,
        current_consumer=current_ref,compatibility_proof=proof_ref,predecessor_exhaustive_verification=old['independent_verification'])
    independent_ref=save('independent_verification.json',independent)
    result=dict(old,status='READY_VERIFIED1308_ALL_C_COMPATIBLE_CITATION_EXPORT',consumer_handoff=current_ref,input_spec=spec_ref,
        graph=old['graph'],coverage=coverage_ref,independent_verification=independent_ref,exact_frontier_binding=proof_ref,
        previous_handoff=old_ref,compatibility_proof=proof_ref,verification_method=proof['method'],verification_script=pin(Path(__file__)),
        completion_scope='Existing admission for the same immutable1308 frontier is preserved; this is not a new all-C completion or publication claim.',
        integration_note='Use this separate current-consumer binding. Enriched graph bytes were reused only after exact graph, Event per-unit records, decision bindings, public model contents, frozen database and raw sources were verified unchanged.')
    handoff_ref=save('PUBLISHER_HANDOFF.json',result)
    print(json.dumps(dict(status=result['status'],handoff=handoff_ref,consumer=current_ref,counts=result['counts'],compatibility_proof=proof_ref)))


if __name__=='__main__':main()
