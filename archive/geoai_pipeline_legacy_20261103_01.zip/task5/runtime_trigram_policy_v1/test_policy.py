import copy
import unittest
from runtime_trigram import a_length,b_prefix,reconcile,decide_pool,merge_occurrences


class RuntimePolicyTests(unittest.TestCase):
    def test_length_settings_replace_old_union_settings(self):
        self.assertEqual(a_length('Ellon',{'Q1':.3,'Q2':.05})['selected'],['Q1'])
        self.assertEqual(a_length('Long name',{'Q1':.6,'Q2':.45})['selected'],['Q1'])
        self.assertEqual(a_length('Long name',{'Q1':.49,'Q2':.1})['status'],'NONE')

    def test_b_uses_point_one_drop_and_preserves_multiple_ties(self):
        self.assertEqual(b_prefix({'r1':.9,'r2':.9,'r3':.75})['selected'],['r1','r2'])
        self.assertEqual(b_prefix({'r1':.9,'r2':.85})['status'],'PENDING')

    def test_top_tie_consensus_cannot_choose_lower_score(self):
        scores={'Q1':1.,'Q2':1.,'Q3':.9}
        self.assertEqual(reconcile(['Q1'],['Q1','Q2'],scores,False)['selected'],['Q1'])
        self.assertEqual(reconcile(['Q3'],['Q1','Q2','Q3'],scores,False)['status'],'PENDING')

    def test_pending_never_none_and_incomplete_inventory_holds(self):
        self.assertEqual(reconcile([],[],{},True)['status'],'PENDING')
        self.assertEqual(reconcile([],[],{},False)['status'],'NONE')
        out=decide_pool([{'id':'r','name':'Paris'}],[{'id':'Q1','name':'Paris','aliases':[]}],complete=False)
        self.assertEqual(out['groups']['r']['status'],'PENDING')

    def test_aliases_are_symmetric_and_no_identity_is_consumed(self):
        groups=[{'id':'r1','name':'Omphis'},{'id':'r2','name':'Omphis'},{'id':'r3','name':'unrelated'}]
        entities=[{'id':'Q1','name':'Taxiles','aliases':['Omphis']},{'id':'Q2','name':'Other','aliases':[]}]
        before=copy.deepcopy((groups,entities));out=decide_pool(groups,entities)
        self.assertEqual(out['groups']['r1']['qid'],'Q1');self.assertEqual(out['groups']['r2']['qid'],'Q1')
        self.assertEqual(out['B']['Q1']['selected'],['r1','r2']);self.assertEqual((groups,entities),before)

    def test_exact_is_unchanged_and_route_hold_stays_pending(self):
        exact=[{'occurrence_id':'x','qid':'Q9','evidence':{'method':'APPROVED_UNIQUE_LITERAL_EXACT'}}]
        mapping=[{'occurrence_id':'x','group_id':'g','route':'PROTECTED_EXACT','protected_exact_qid':'Q9'},
                 {'occurrence_id':'d','group_id':'date-only','route':'DATE_DEFERRED','protected_exact_qid':None},
                 {'occurrence_id':'o','group_id':'g','route':'ORDINARY_MODEL_INPUT','protected_exact_qid':None}]
        result=merge_occurrences(mapping,{'g':{'status':'NONE','qid':None,'reason':'COMPLETE_NEGATIVE_CHECKS'}},exact,{})
        self.assertEqual(result['patch']['decisions'][:1],exact)
        self.assertEqual(result['results'][1]['status'],'PENDING')
        self.assertEqual(result['results'][1]['reason'],['DATE_DEFERRED'])
        self.assertEqual(result['results'][2]['status'],'NONE')


if __name__=='__main__':
    unittest.main()
