"""Approved CPU-only trigram policy; pure decisions, no canonical state writes."""
import copy
import hashlib
import json
import re
import unicodedata
from pathlib import Path

ROOT=Path(__file__).parent
POLICY=json.loads((ROOT/'policy.json').read_text(encoding='utf8'))
EPS=POLICY['numeric_tolerance']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalize(text):
    text=unicodedata.normalize('NFKD',text.casefold())
    text=''.join(c for c in text if not unicodedata.combining(c))
    return ' '.join(re.findall(r'[^\W_]+',text))


def grams(text):
    text=normalize(text)
    return frozenset(text[i:i+3] for i in range(len(text)-2)) if len(text)>=3 else frozenset([text])-{''}


def score(name,entity):
    a=grams(name)
    return max((2*len(a&b)/(len(a)+len(b)) for n in [entity['name']]+(entity.get('aliases') or []) if (b:=grams(n)) and a),default=0.)


def result(status,selected=(),reason=''):
    return dict(status=status,selected=sorted(selected),reason=reason)


# Example: Ellon uses .3/.2; a longer name uses .5/.1, not the old union .2.
def a_length(name,scores):
    p=POLICY['A'];short=sum(c.isalnum() for c in normalize(name))<=p['short_max_alnum']
    floor=p['short_floor'] if short else p['long_floor']
    margin=p['short_margin'] if short else p['long_margin']
    ranked=sorted(scores,key=lambda q:(-scores[q],q))
    if not ranked:return result('PENDING',reason='EMPTY_DECLARED_POOL')
    best=scores[ranked[0]]
    if best<floor:return result('NONE',reason='COMPLETE_POOL_ALL_BELOW_FLOOR')
    if len(ranked)<2:return result('PENDING',reason='NO_OTHER_ENTITY_FOR_MARGIN')
    runner=scores[ranked[1]]
    if best==runner:return result('PENDING',reason='TOP_ENTITY_TIE')
    if best-runner+EPS<margin:return result('PENDING',reason='INSUFFICIENT_ADDITIVE_MARGIN')
    return result('IDENTITY',[ranked[0]],'LENGTH_FLOOR_AND_MARGIN')


# Example: .9,.9,.75 chooses both .9 occurrences. A .15 drop passes B=.1.
def b_prefix(scores):
    p=POLICY['B'];levels=sorted(set(scores.values()),reverse=True)
    if not levels:return result('PENDING',reason='EMPTY_DECLARED_POOL')
    if levels[0]<p['floor']:return result('NONE',reason='COMPLETE_POOL_ALL_BELOW_FLOOR')
    for upper,lower in zip(levels,levels[1:]):
        if upper<p['floor']:break
        if upper-lower+EPS>=p['first_distinct_score_drop']:
            return result('IDENTITY',[r for r,v in scores.items() if v>=upper and v>=p['floor']], 'PREFIX_ABOVE_FIRST_CLEAR_DROP')
    return result('PENDING',reason='NO_CLEAR_DROP_ABOVE_FLOOR')


# Agreement can select one of tied highest IDs, never a lower-scoring identity.
def reconcile(a,b,scores,pending):
    proposals=set(a)|set(b)
    if not proposals:return result('PENDING' if pending else 'NONE',reason='UNRESOLVED_CHECK' if pending else 'COMPLETE_NEGATIVE_CHECKS')
    best=max(scores[q] for q in proposals);top={q for q in proposals if scores[q]==best}
    if len(top)==1:return result('IDENTITY',top,'UNIQUE_HIGHEST_ELIGIBLE_TRIGRAM')
    both=top&set(a)&set(b)
    if len(both)==1:return result('IDENTITY',both,'UNIQUE_TOP_BIDIRECTIONAL_TRIGRAM_CONSENSUS')
    return result('PENDING',reason='ELIGIBLE_TOP_TIE')


def decide_pool(groups,entities,*,complete=True):
    """Groups need id/name; entities need id/name/verified aliases. IDs stay global."""
    gids=[g['id'] for g in groups];qids=[e['id'] for e in entities]
    if len(set(gids))!=len(gids) or len(set(qids))!=len(qids):raise ValueError('Duplicate group or identity')
    if any(not re.fullmatch(r'Q[1-9][0-9]*',q) for q in qids):raise ValueError('Verified QID required')
    if not complete:
        return dict(groups={gid:dict(result('PENDING',reason='INCOMPLETE_DECLARED_INVENTORY'),qid=None) for gid in gids},A={},B={},pair_scores={})
    scores={g['id']:{e['id']:score(g['name'],e) for e in entities} for g in groups}
    a={g['id']:a_length(g['name'],scores[g['id']]) for g in groups}
    b={q:b_prefix({g['id']:scores[g['id']][q] for g in groups}) for q in qids}
    final={}
    for gid in gids:
        bv=[q for q in qids if gid in b[q]['selected']]
        pending=a[gid]['status']=='PENDING' or any(b[q]['status']=='PENDING' for q in qids)
        d=reconcile(a[gid]['selected'],bv,scores[gid],pending)
        d.update(qid=d['selected'][0] if d['selected'] else None,A=copy.deepcopy(a[gid]),B_ids=bv,
            eligible_routes={q:(["trigram_raw_length"] if q in a[gid]['selected'] else [])+(["trigram_entity_prefix"] if q in bv else []) for q in sorted(set(a[gid]['selected'])|set(bv))},
            global_completeness_claim=False)
        final[gid]=d
    return dict(groups=final,A=a,B=b,pair_scores=scores)


# Exact patch entries are copied byte-for-byte as JSON values. Date/Event and
# source-context holds remain pending even when an ordinary group has a proposal.
def merge_occurrences(mapping,group_decisions,exact_decisions,holds):
    exact={d['occurrence_id']:d for d in exact_decisions}
    if len(exact)!=len(exact_decisions):raise ValueError('Duplicate protected exact decision')
    ids=[m['occurrence_id'] for m in mapping]
    if len(ids)!=len(set(ids)) or not set(exact)<=set(ids):raise ValueError('Occurrence membership mismatch')
    rows=[];residual=[]
    for member in mapping:
        oid=member['occurrence_id'];gid=member['group_id'];route=member['route']
        if oid in exact:
            if route!='PROTECTED_EXACT' or member.get('protected_exact_qid')!=exact[oid]['qid']:raise ValueError('Protected exact binding differs')
            rows.append(dict(occurrence_id=oid,group_id=gid,status='IDENTITY',qid=exact[oid]['qid'],reason=['PROTECTED_EXACT_UNCHANGED'],protected_exact=True,evidence=copy.deepcopy(exact[oid]['evidence'])))
            continue
        reasons=list(holds.get(oid,[]))
        if route!='ORDINARY_MODEL_INPUT':reasons.append(route)
        d=group_decisions.get(gid)
        if d is None and route=='ORDINARY_MODEL_INPUT':reasons.append('NO_COMPLETE_DECLARED_GROUP_CHECK')
        status='PENDING' if reasons else d['status']
        qid=None if reasons else d['qid']
        evidence=dict(policy_version=POLICY['version'],policy_sha256=sha(ROOT/'policy.json'),
            source_route=route,scope_hold_reasons=sorted(set(reasons)),group_proposal=copy.deepcopy(d),
            none_decision=status=='NONE',none_scope='DECLARED_CANDIDATE_POOL_ONLY',global_completeness_claim=False,
            model_calls=0,identity_acceptance_distinct_from_consumer_population=True)
        row=dict(occurrence_id=oid,group_id=gid,status=status,qid=qid,reason=sorted(set(reasons)) if reasons else [d['reason']],protected_exact=False,evidence=evidence)
        rows.append(row)
        if status in ('IDENTITY','NONE'):
            residual.append(dict(occurrence_id=oid,qid=qid,evidence=dict(evidence,decision='ACCEPTED_IDENTITY' if status=='IDENTITY' else 'EXPLICIT_NONE')))
    combined=copy.deepcopy(exact_decisions)+residual
    return dict(patch=dict(decision_version=POLICY['version'],decisions=combined),
        residual_patch=dict(decision_version=POLICY['version']+':residual',decisions=residual),results=rows)
