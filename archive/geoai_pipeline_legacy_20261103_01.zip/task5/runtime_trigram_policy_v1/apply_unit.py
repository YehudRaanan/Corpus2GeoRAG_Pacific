"""Read pinned prepared units; return a versioned patch without applying it."""
import copy
import json
import re
from collections import Counter
from pathlib import Path
import runtime_trigram as p


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def apply_prepared_unit(data_directory,*,expected_manifest_sha256,decision_version=None):
    data=Path(data_directory);manifest=read(data/'manifest.json');scope=manifest['scope']
    if p.sha(data/'manifest.json')!=expected_manifest_sha256:raise ValueError('Prepared manifest hash differs')
    handoff=read(data/'inference_handoff.json')
    if handoff['manifest_sha256']!=expected_manifest_sha256:raise ValueError('Prepared handoff binding differs')
    required=['all_groups_and_members.json','all_occurrence_mapping.json','entity_candidates.json',
        'capacity_ready_requests.json','capacity_pending_requests.json','exact_decision_patch.json','deferred_routes.json']
    if (data/'alias_evidence.json').is_file():required.append('alias_evidence.json')
    pins={str(data/'manifest.json'):expected_manifest_sha256,str(data/'inference_handoff.json'):p.sha(data/'inference_handoff.json')}
    for file,digest in manifest.get('protected_source_sha256',{}).items():
        if p.sha(file)!=digest:raise ValueError('Pinned original source changed: '+file)
        pins[file]=digest
    declared=dict(manifest.get('output_sha256',{}));declared.update(handoff.get('file_sha256',{}))
    for name in required:
        path=data/name;digest=p.sha(path)
        if name in declared and declared[name]!=digest:raise ValueError('Prepared input changed: '+name)
        pins[str(path)]=digest
    groups=read(data/'all_groups_and_members.json')['groups']
    source=Path(manifest['source_directory'])
    if read(source/'groups.json')['groups']!=groups:raise ValueError('Source group membership changed')
    mapping=read(data/'all_occurrence_mapping.json');by_id={m['occurrence_id']:m for m in mapping}
    if len(by_id)!=len(mapping) or len(mapping)!=scope['occurrences']:raise ValueError('Occurrence count differs')
    members={m['occurrence_id']:(g,m) for g in groups for m in g['members']}
    if len(members)!=len(mapping) or set(members)!=set(by_id):raise ValueError('Original occurrence membership differs')
    for oid,(g,m) in members.items():
        if by_id[oid]['group_id']!=g['group_id']:raise ValueError('Occurrence/group binding differs')
        if (m['page_id'],m['processing_revision_id'])!=(scope['page_id'],scope['processing_revision_id']):raise ValueError('Source page/revision differs')
    entities=read(data/'entity_candidates.json');entity={x['qid']:x for x in entities}
    if len(entity)!=len(entities) or len(entity)!=scope['candidate_QIDs']:raise ValueError('Candidate identity inventory differs')
    alias={x['qid']:x for x in read(data/'alias_evidence.json')} if (data/'alias_evidence.json').is_file() else {}
    if not set(alias)<=set(entity):raise ValueError('Alias snapshot contains an undeclared identity')
    cached_responses={}
    for q,x in entity.items():
        ev=alias.get(q);official=[]
        if ev:
            s=ev['source'];file=Path(s['response_file'])
            if str(file) not in cached_responses:
                if p.sha(file)!=s['response_sha256']:raise ValueError('Alias response hash differs')
                pins[str(file)]=s['response_sha256'];cached_responses[str(file)]=read(file)
            record=cached_responses[str(file)]['entities'][q]
            official=[a['value'] for a in record.get('aliases',{}).get('en',[])]
            if s['qid']!=q or s['aliases']!=official or s['source_revision']!=record['lastrevid']:raise ValueError('Official alias identity/revision differs')
        known={x['label']};known.update(official)
        for old in x.get('metadata_evidence',[]):
            assertion=old.get('assertion',{})
            if assertion.get('qid',q)!=q:raise ValueError('Native metadata identity differs')
            known.update(assertion.get('aliases') or []);known.add(assertion.get('label',''))
        if any(a not in known for a in x.get('aliases') or []):raise ValueError('Unattributed runtime alias')
        if ev and list(dict.fromkeys(ev['previous_aliases']+ev['added_aliases']))!=x['aliases']:raise ValueError('Alias application snapshot differs')
    event_qids={x['qid'] for x in read(data/'deferred_routes.json')['event_candidates']}
    ordinary_qids=set(entity)-event_qids
    ordinary_groups={m['group_id'] for m in mapping if m['route']=='ORDINARY_MODEL_INPUT'}
    requests=read(data/'capacity_ready_requests.json')+read(data/'capacity_pending_requests.json')
    reverse={};forward={};incomplete=[]
    for request in requests:
        raw=request['raw'];direction=raw['direction'];gid=raw['entity']['id'];ids=[x['id'] for x in raw['candidates']]
        family=reverse if direction=='reverse' else forward if direction=='forward' else None
        if family is None or gid in family:raise ValueError('Duplicate/unknown declared logical request')
        family[gid]=raw
        expected=ordinary_qids if direction=='reverse' else ordinary_groups
        if len(ids)!=len(set(ids)) or set(ids)!=expected:incomplete.append('NONRECIPROCAL_DECLARED_CANDIDATES')
        wiki=raw['candidates'] if direction=='reverse' else [raw['entity']]
        for w in wiki:
            if w['id'] not in entity or w['name']!=entity[w['id']]['label'] or w.get('aliases',[])!=entity[w['id']]['aliases']:raise ValueError('Directions do not share the verified alias snapshot')
    if set(reverse)!=ordinary_groups or set(forward)!=ordinary_qids:incomplete.append('UNRUN_OR_MISSING_DECLARED_LIST')
    if len(ordinary_groups)!=scope['ordinary_raw_groups'] or len(ordinary_qids)!=scope['ordinary_QIDs'] or len(requests)!=scope['questions']:incomplete.append('DECLARED_INVENTORY_COUNT_DIFFERS')
    grouped={g['group_id']:g for g in groups}
    raw_groups=[dict(id=gid,name=reverse[gid]['entity']['name'] if gid in reverse else grouped[gid]['key']['word']) for gid in sorted(ordinary_groups)]
    wiki=[dict(id=q,name=entity[q]['label'],aliases=entity[q]['aliases']) for q in sorted(ordinary_qids)]
    pool=p.decide_pool(raw_groups,wiki,complete=not incomplete)
    exact=read(data/'exact_decision_patch.json')
    if len(exact['decisions'])!=scope['protected_exact_occurrences']:raise ValueError('Protected exact count differs')
    for d in exact['decisions']:
        ev=d['evidence']
        if ev.get('method')!='APPROVED_UNIQUE_LITERAL_EXACT' or (ev['page_id'],ev['processing_revision_id'])!=(scope['page_id'],scope['processing_revision_id']):raise ValueError('Protected exact source proof differs')
    holds={}
    event_file=data/'occurrence_event_routing_flags.json';flags={}
    if event_file.is_file():
        pins[str(event_file)]=p.sha(event_file);flags={x['occurrence_id']:x for x in read(event_file)}
    for oid,(g,m) in members.items():
        reasons=[]
        if oid in flags:reasons.append('SEPARATE_EVENT_ANCHOR_EVIDENCE_NOT_ORDINARY_IDENTITY')
        if by_id[oid]['route']=='ORDINARY_MODEL_INPUT' and m.get('processing_surface_status') not in ('VERIFIED_ORIGINAL_SPAN_ONLY','VERIFIED_EXPANDED_SOURCE_ANCHOR'):reasons.append('UNAPPROVED_SOURCE_CONTEXT_SURFACE')
        for link in re.finditer(r'\[\[([^\]\n]+)\]\]',m['Text']):
            target=link.group(1).split('|')[0].split('#')[0].strip()
            if target in scope.get('unresolved_targets',[]) and link.start()<=m['start']<m['end']<=link.end():reasons.append('VERIFIED_OCCURRENCE_IN_UNRESOLVED_SOURCE_TARGET:'+target)
        if reasons:holds[oid]=reasons
    value=p.merge_occurrences(mapping,pool['groups'],exact['decisions'],holds)
    def source_evidence(oid):
        g,member=members[oid]
        return dict(page_id=scope['page_id'],processing_revision_id=scope['processing_revision_id'],
            group_id=g['group_id'],source_member=copy.deepcopy(member),
            input_manifest=dict(path=str(data/'manifest.json'),sha256=expected_manifest_sha256),
            entity_inventory_sha256=pins[str(data/'entity_candidates.json')],
            alias_evidence_sha256=pins.get(str(data/'alias_evidence.json')),
            policy_source_sha256=p.sha(p.ROOT/'runtime_trigram.py'),adapter_sha256=p.sha(Path(__file__)))
    for row in value['results']:
        if not row['protected_exact']:row['evidence'].update(source_evidence(row['occurrence_id']))
    for d in value['residual_patch']['decisions']:
        d['evidence'].update(source_evidence(d['occurrence_id']))
    # combined patch has separate residual JSON values; bind the same provenance.
    for d in value['patch']['decisions'][len(exact['decisions']):]:
        d['evidence'].update(source_evidence(d['occurrence_id']))
    version=decision_version or p.POLICY['version']+f":{scope['page_id']}:{scope['processing_revision_id']}"
    value['patch']['decision_version']=version;value['residual_patch']['decision_version']=version+':residual'
    for row in value['results']:
        g=grouped[row['group_id']];row.update(raw_name=g['key']['word'],raw_type=g['key']['entity_group'])
    counts=Counter(row['status'] for row in value['results'])
    for path,digest in pins.items():
        if p.sha(path)!=digest:raise ValueError('Source changed during pure policy evaluation')
    value['summary']=dict(status='TRIGRAM_POLICY_PATCH_NOT_INTEGRATED',policy_version=p.POLICY['version'],
        policy_sha256=p.sha(p.ROOT/'policy.json'),callable_sha256=p.sha(p.ROOT/'runtime_trigram.py'),adapter_sha256=p.sha(Path(__file__)),
        page_id=scope['page_id'],processing_revision_id=scope['processing_revision_id'],input_version=manifest['input_version'],
        ordinary_raw_groups=len(ordinary_groups),ordinary_QIDs=len(ordinary_qids),pairs=len(ordinary_groups)*len(ordinary_qids),
        occurrences=len(mapping),protected_exact=len(exact['decisions']),after=dict(counts),
        before_exact_only=dict(IDENTITY=len(exact['decisions']),NONE=0,PENDING=len(mapping)-len(exact['decisions'])),
        before_scope='PREPARED_SOURCE_EXACT_ONLY_NOT_CURRENT_CANONICAL',declared_list_complete=not incomplete,incomplete_reasons=sorted(set(incomplete)),
        runtime_entities_with_aliases=sum(bool(x['aliases']) for x in wiki),runtime_aliases=sum(len(x['aliases']) for x in wiki),
        official_alias_provider_qids=len(alias),native_alias_evidence_used_without_new_fetch=True,
        aliases_identical_both_directions=True,alias_empty_diagnostic_comparability=False,source_pins=pins,
        global_completeness_claim=False,model_calls=0,canonical_state_read_or_written=False,consumer_written=False)
    value['group_cases']=pool
    return value
