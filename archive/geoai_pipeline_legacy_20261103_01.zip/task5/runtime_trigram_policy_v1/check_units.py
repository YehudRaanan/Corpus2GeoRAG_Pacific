"""Only three existing units, deterministic CPU dry runs. No integration writes."""
import json
from collections import Counter
from pathlib import Path
import runtime_trigram as p
from apply_unit import apply_prepared_unit

ROOT=Path(__file__).parent
PROJECT=Path(r'D:\Projects\GeoAI-incremental-dev-20261101')
BASE=PROJECT/'runtime_model_inputs_direct_20261101/per_unit_builder_v1'
CASES={3:'unit_0003_64096955_1372397745_v1',9:'pending_0009_28702915_1299260129_full_v3',16:'batch_0011_0020_v4/unit_0016_559609_1345020428_v4'}


def canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))


def main():
    destination=ROOT/'dry_run_0002';destination.mkdir(exist_ok=False);summary=[]
    for unit,relative in CASES.items():
        data=BASE/relative;manifest=p.sha(data/'manifest.json')
        value=apply_prepared_unit(data,expected_manifest_sha256=manifest)
        assert canonical(value)==canonical(apply_prepared_unit(data,expected_manifest_sha256=manifest))
        exact=json.loads((data/'exact_decision_patch.json').read_text(encoding='utf8'))['decisions']
        assert value['patch']['decisions'][:len(exact)]==exact
        out=destination/f'unit_{unit}';out.mkdir()
        payload={'decision_patch.json':value['patch'],'residual_decision_patch.json':value['residual_patch'],
                 'all_occurrence_decision_evidence.json':value['results'],'group_cases.json':value['group_cases'],'receipt.json':value['summary']}
        for name,contents in payload.items():
            with (out/name).open('x',encoding='utf8') as f:json.dump(contents,f,ensure_ascii=False,sort_keys=True,indent=2)
        entry=dict(unit=unit,**{k:v for k,v in value['summary'].items() if k!='source_pins'},
                   patch=dict(path=str(out/'decision_patch.json'),sha256=p.sha(out/'decision_patch.json')),
                   replay_equal=True,protected_exact_unchanged=True)
        prior=PROJECT/f'candidate_check_fix_direct_20261102/dry_run_v2_0004/unit_{unit}/decision_evidence.json'
        if prior.is_file():
            rows=json.loads(prior.read_text(encoding='utf8'))
            if isinstance(rows,list) and {r['occurrence_id'] for r in rows}=={r['occurrence_id'] for r in value['results']}:
                before={r['occurrence_id']:(r['status'],r.get('qid')) for r in rows}
                entry['previous_model_policy_snapshot']=dict(path=str(prior),sha256=p.sha(prior),counts=dict(Counter(r['status'] for r in rows)),
                    changed_occurrences=sum(before[r['occurrence_id']]!=(r['status'],r.get('qid')) for r in value['results']),
                    scope='HISTORICAL_V2_POLICY_SNAPSHOT_NOT_CURRENT_CANONICAL_STATE')
        summary.append(entry)
        print(json.dumps(entry,ensure_ascii=True))
    with (destination/'summary.json').open('x',encoding='utf8') as f:json.dump(summary,f,indent=2)
    assert 'torch' not in __import__('sys').modules


if __name__=='__main__':main()
