"""Independent comparison to the previously tested diagnostic primitives."""
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path
import runtime_trigram as p

ROOT=Path(__file__).parent
OLD=ROOT.parent/'trigram_only_v1'
sys.path.insert(0,str(OLD))
import margin_drop as previous
import length_ablation as length
import evaluate as prior


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def main():
    units=read(ROOT/'dry_run_0002/summary.json');tri=previous.load_tri();pairs=raws=forwards=exact_count=0
    for entry in units:
        directory=ROOT/f"dry_run_0002/unit_{entry['unit']}"
        receipt=read(directory/'receipt.json');pool=read(directory/'group_cases.json');rows=read(directory/'all_occurrence_decision_evidence.json')
        pins=receipt['source_pins']
        for path,expected in pins.items():assert p.sha(path)==expected
        manifest_path=next(Path(path) for path in pins if Path(path).name=='manifest.json')
        data=manifest_path.parent;manifest=read(manifest_path);scope=manifest['scope']
        raw_requests=read(data/'capacity_ready_requests.json')+read(data/'capacity_pending_requests.json')
        names={r['raw']['entity']['id']:r['raw']['entity']['name'] for r in raw_requests if r['raw']['direction']=='reverse'}
        entities={x['qid']:dict(id=x['qid'],name=x['label'],aliases=x['aliases']) for x in read(data/'entity_candidates.json')}
        for gid,scores in pool['pair_scores'].items():
            for q,value in scores.items():
                assert value==prior.score(names[gid],entities[q],tri);pairs+=1
            a=length.adjusted_raw(names[gid],scores,.3,.2)
            assert (a['status'],a['selected'])==(pool['A'][gid]['status'],pool['A'][gid]['selected']);raws+=1
            bv=[q for q,out in pool['B'].items() if gid in out['selected']]
            pending=a['status']=='PENDING' or any(out['status']=='PENDING' for out in pool['B'].values())
            expected=previous.arbitrate(set(a['selected'])|set(bv),scores,pending,set(a['selected'])&set(bv))
            actual=pool['groups'][gid]
            assert (expected['status'],expected['selected'])==(actual['status'],actual['selected'])
        for q,actual in pool['B'].items():
            scores={gid:ss[q] for gid,ss in pool['pair_scores'].items()}
            expected=previous.entity_prefix(scores,.5,.1)
            assert (expected['status'],expected['selected'])==(actual['status'],actual['selected']);forwards+=1
        exact=read(data/'exact_decision_patch.json')['decisions'];patch=read(directory/'decision_patch.json')
        assert patch['decisions'][:len(exact)]==exact;exact_count+=len(exact)
        assert len(rows)==scope['occurrences'];assert Counter(r['status'] for r in rows)==receipt['after']
        exact_ids={r['occurrence_id'] for r in exact};mapping=read(data/'all_occurrence_mapping.json')
        ordinary={r['occurrence_id'] for r in mapping if r['route']=='ORDINARY_MODEL_INPUT'}
        accepted={r['occurrence_id'] for r in patch['decisions']}
        pending={r['occurrence_id'] for r in rows if r['status']=='PENDING'}
        assert not accepted&pending
        assert all(r['status']=='PENDING' for r in rows if r['occurrence_id'] not in ordinary|exact_ids)
        for row in rows:
            if row['protected_exact']:continue
            assert row['evidence']['page_id']==scope['page_id']
            assert row['evidence']['processing_revision_id']==scope['processing_revision_id']
            assert row['evidence']['source_member']['occurrence_id']==row['occurrence_id']
        scope_contract=dict(ordinary_occurrence_ids=sorted(ordinary),pending_ordinary_occurrence_ids=sorted(pending&ordinary),
            protected_exact_occurrence_ids=sorted(exact_ids),held_separate_route_occurrence_ids=sorted(set(r['occurrence_id'] for r in rows)-ordinary-exact_ids),
            source_base_directory=manifest['source_directory'],source_base_unit_sha256=read(data/'inference_handoff.json')['source_unit_sha256'],
            replacement='REPLACE_ORDINARY_POLICY_SNAPSHOT_NOT_SPARSE_OVERLAY',
            history='Build successor from verified source base plus unchanged protected exact and current ordinary results;keep previous sealed versions as history.',
            separate_routes='Do not erase verified Date/Event stage successors with these ordinary-policy hold rows. Integrator composes those separate scopes.')
        with (directory/'replacement_scope.json').open('x',encoding='utf8') as f:json.dump(scope_contract,f,indent=2)
        assert p.sha(directory/'decision_patch.json')==entry['patch']['sha256']
    report=dict(status='PASS_RUNTIME_POLICY_PARITY_SOURCE_PINS_AND_EXACT',pair_scores=pairs,A_groups=raws,B_queries=forwards,
        protected_exact_unchanged=exact_count,units=len(units),declared_lists_complete=True,
        previous_tested_primitives=dict(A='length_ablation.adjusted_raw(.3,.2)',B='margin_drop.entity_prefix(.5,.1)',joint='margin_drop.arbitrate with unique top consensus'),
        source_files_unchanged=True,no_model_calls=True,canonical_state_written=False,verification_code_sha256=p.sha(Path(__file__)))
    with (ROOT/'dry_run_0002/independent_verification.json').open('x',encoding='utf8') as f:json.dump(report,f,indent=2)
    print(json.dumps(report))


if __name__=='__main__':main()
